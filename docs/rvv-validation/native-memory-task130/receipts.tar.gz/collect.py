from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/vick/rvdbt-native-memory-task130')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data): (root/name).write_text(json.dumps(data,indent=2)+'\n')
identity=json.loads((root/'SOURCE_IDENTITY.json').read_text())
diff=[p for p,h in identity['files'].items() if sha(root/'source'/p)!=h]
assert not diff
save('SOURCE_EQUALITY.json',{'commit':identity['commit'],'checked':len(identity['files']),'differences':diff})
# Inherited third-party content must still equal the actual Task128 dependency tree.
prev=Path('/home/vick/rvdbt-host512-task128/source/dbt/third_party')
deps={str(p.relative_to(prev)):sha(p) for p in prev.rglob('*') if p.is_file()}
assert all(sha(root/'source/dbt/third_party'/p)==h for p,h in deps.items())
save('DEPENDENCY_EQUALITY.json',{'against':str(prev),'checked':len(deps),'differences':[], 'sha256':deps})
cache=(root/'build/CMakeCache.txt').read_text()
assert 'RVV_HOST_CHUNK_BITS:STRING=512' in cache
flags={str(p.relative_to(root)):p.read_text() for p in (root/'build').rglob('flags.make')}
for target in ('dbtstatic','elfrun','rv32_native_memory_site_test'):
 key=next(k for k in flags if f'{target}.dir/flags.make' in k)
 assert '-DRVV_HOST_CHUNK_BITS=512' in flags[key] and '-mavx512f' in flags[key] and '-mavx512bw' in flags[key]
save('FLAGS_AUDIT.json',{'host_chunk_bits':512,'configure_cache':cache,'actual_compiled_flags':flags})
tests=['rv32_native_memory_site_test','vle32v_typedchunk_route_test','vse32v_typedchunk_route_test','rv32_unit_memory_fault_test']
assert all((root/(t+'.rc')).read_text().strip()=='0' for t in tests)
save('FOCUSED_RESULTS.json',{t:{'rc':0,'last_stdout_line':(root/(t+'.stdout')).read_text().splitlines()[-1],'stdout_sha256':sha(root/(t+'.stdout')),'stderr_sha256':sha(root/(t+'.stderr'))} for t in tests})
assert (root/'external.rc').read_text().strip()=='0'
assert (root/'BUILD_SHA256.txt').read_bytes()==(root/'BUILD_SHA256.attempt1.txt').read_bytes()
q=json.loads((root/'external/QUEUE.json').read_text())
original=json.loads(Path('/home/vick/act-current121/QUEUE.json').read_text())
assert len(q['calls'])==3 and all(c in original['calls'] for c in q['calls'])
assert all(r['status']=='PASS' for r in json.loads((root/'external/RESULTS.json').read_text()))
assert all(sha(Path(p))==h for p,h in json.loads((root/'external/INPUTS.json').read_text()).items())
save('EXTERNAL_AUDIT.json',{'unchanged_original_calls':3,'whole_file_pass':3,'predicate':q['predicate'],'final_build_equals_external_build':True,'reference_calls':0,'input_differences':[]})
receipts=root/'receipts';receipts.mkdir(exist_ok=True)
import shutil
for p in root.iterdir():
 if p.is_file() and p.suffix not in ('.gz',):shutil.copy2(p,receipts/p.name)
shutil.copytree(root/'external',receipts/'external',ignore=shutil.ignore_patterns('work','cache'),dirs_exist_ok=True)
manifest={str(p.relative_to(receipts)):sha(p) for p in receipts.rglob('*') if p.is_file()}
(receipts/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['tar','-czf',str(root/'receipts.tar.gz'),'-C',str(receipts),'.'],check=True)
print('RECEIPTS',len(manifest),'archive',sha(root/'receipts.tar.gz'))
