#!/bin/bash
cd /home/vick/rvdbt-native-memory-task130
ulimit -c 0
uptime > load.initial.txt
lscpu > cpu.txt
clang++-22 --version > compiler.txt
timeout 180 nice -n 10 taskset -c 28-31 cmake -S source -B build -DCMAKE_C_COMPILER=clang-22 -DCMAKE_CXX_COMPILER=clang++-22 -DCMAKE_BUILD_TYPE=Release -DLLVM_DIR=/usr/lib/llvm-22/lib/cmake/llvm -DRVV_HOST_CHUNK_BITS=512 > configure.stdout 2> configure.stderr
rc=$?; echo "$rc" > configure.rc
if [ "$rc" != 0 ]; then exit "$rc"; fi
timeout 900 nice -n 10 taskset -c 28-31 cmake --build build --target elfrun dbtjitshared rv32_native_memory_site_test vle32v_typedchunk_route_test vse32v_typedchunk_route_test rv32_unit_memory_fault_test -j4 > build.stdout 2> build.stderr
rc=$?; echo "$rc" > build.rc
exit "$rc"
