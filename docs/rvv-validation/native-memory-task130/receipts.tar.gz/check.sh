#!/bin/bash
cd /home/vick/rvdbt-native-memory-task130
ulimit -c 0
for test in rv32_native_memory_site_test vle32v_typedchunk_route_test vse32v_typedchunk_route_test rv32_unit_memory_fault_test; do
 timeout 60 nice -n 10 taskset -c 28 build/bin/$test > $test.stdout 2> $test.stderr
 echo $? > $test.rc
done
uptime > load.final.txt
sha256sum build/bin/elfrun build/lib/libdbtjitshared.so > BUILD_SHA256.txt
ldd -r build/bin/elfrun > ldd.txt 2>&1
