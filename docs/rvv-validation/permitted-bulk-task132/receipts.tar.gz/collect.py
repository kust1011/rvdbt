from pathlib import Path
import hashlib,json,subprocess,shutil,re
root=Path('/home/vick/rvdbt-permitted-bulk-task132')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(root/n).write_text(json.dumps(d,indent=2)+'\n')
identity=json.loads((root/'SOURCE_IDENTITY.json').read_text())
diff=[p for p,h in identity['files'].items() if sha(root/'source'/p)!=h]
assert not diff,diff
save('SOURCE_EQUALITY.json',{'commit':identity['commit'],'checked':len(identity['files']),'differences':diff})
prev=Path('/home/vick/rvdbt-native-memory-task131/source/dbt/third_party')
deps={str(p.relative_to(prev)):sha(p) for p in prev.rglob('*') if p.is_file()}
assert all(sha(root/'source/dbt/third_party'/p)==h for p,h in deps.items())
save('DEPENDENCY_EQUALITY.json',{'against':str(prev),'checked':len(deps),'differences':[],'files':deps})
cache=(root/'build/CMakeCache.txt').read_text()
flags={str(p.relative_to(root)):p.read_text() for p in (root/'build').rglob('flags.make')}
assert 'RVV_HOST_CHUNK_BITS:STRING=512' in cache
for t in ['dbtstatic','elfrun','rv32_permitted_bulk_fault_test']:
 f=next(v for k,v in flags.items() if f'{t}.dir/flags.make' in k)
 assert '-DRVV_HOST_CHUNK_BITS=512' in f and '-mavx512f' in f and '-mavx512bw' in f
save('FLAGS_AUDIT.json',{'cache':cache,'actual_flags':flags})
tests=['rv32_permitted_bulk_fault_test','rv32_native_memory_fault_test','rv32_unit_memory_fault_test','rv32_special_memory_fault_test','rv32_llvm_memory_admission_test','vle32v_typedchunk_route_test','vse32v_typedchunk_route_test']
for name in ['configure','build','build.refine','build.final','build.admission','admission']:
 assert (root/(name+'.rc')).read_text().strip()=='0'
results={}
for t in tests:
 assert (root/(t+'.rc')).read_text().strip()=='0'
 results[t]={'rc':0,'stdout':t+'.stdout','stderr':t+'.stderr','last_line':(root/(t+'.stdout')).read_text().splitlines()[-1]}
results['rv32_permitted_bulk_fault_test'].update({'first_batch_captured':135,'resumed_skip':135,'second_batch_bulk_captured':131,'fof_checks':2,'first_batch_rc':2,'cause':'next short whole transfer ended before denied page; completed normally; fixture boundary corrected, captured cells not repeated','stdout':'concatenated first/resume captures; separate original streams retained'})
results['rv32_llvm_memory_admission_test']['label_note']='native=8 in original execution stream counts normal completions; all whole native hits assert zero. Later output-only source label is normal=8; no additional execution.'
results['admission_only']={'rc':0,'guest_accesses':0,'checks':8,'stdout':'admission.stdout','actual_checks':'page-contained permitted regular file refused; anonymous fixed replacement admitted; unmap clears bitmap'}
results['rv32_permitted_bulk_fault_test']['post_capture_refinement']='page-contained file assertion and separate admission-only mode added; only the latter executed afterward; no terminal cell repeated'
save('FOCUSED_RESULTS.json',results)
production={p:sha(root/p) for p in ['build/bin/elfrun','build/lib/libdbtjitshared.so']}
recorded={path:h for h,path in (l.split() for l in (root/'BUILD_SHA256.txt').read_text().splitlines())}
assert production==recorded
save('FINAL_PRODUCTION_EQUALITY.json',{'after_comment_and_test_label_build':True,'differences':[],'production':production})
q=json.loads((root/'external/QUEUE.json').read_text());original=json.loads(Path('/home/vick/act-current121/QUEUE.json').read_text())
assert len(q['calls'])==9 and all(c in original['calls'] for c in q['calls'])
assert all(r['status']=='PASS' for r in json.loads((root/'external/RESULTS.json').read_text()))
inputs=json.loads((root/'external/INPUTS.json').read_text())
assert all(sha(Path(p))==h for p,h in inputs.items())
save('EXTERNAL_AUDIT.json',{'unchanged_original_calls':9,'whole_file_pass':9,'reference_calls':0,'predicate':q['predicate'],'input_differences':[],'final_production_equal':True,'production':production})
syms=subprocess.check_output(['nm',str(root/'build/bin/elfrun')],text=True)
for ns,name in [('rvv_host_copy','CHECKED_CALLBACK'),('rvv_native_fault','NATIVE_CALLBACK')]:
 sym=next(line.split()[-1] for line in syms.splitlines() if ns in line and 'HandleSignal' in line)
 dis=subprocess.check_output(['objdump','-d','--disassemble='+sym,str(root/'build/bin/elfrun')],text=True)
 (root/(name+'.disasm')).write_text(dis)
 assert not re.search(r'\tcall\s',dis)
 save(name+'_AUDIT.json',{'symbol':sym,'sha256':sha(root/(name+'.disasm')),'calls':0})
(root/'CHECKED_BULK_LEAVES.disasm').write_text(subprocess.check_output(['objdump','-d','--disassemble=rvv_bulk_read_dword',str(root/'build/bin/elfrun')],text=True)+subprocess.check_output(['objdump','-d','--disassemble=rvv_bulk_write_dword',str(root/'build/bin/elfrun')],text=True))
save('BUILD_TEST_SHA256.json',{t:sha(root/'build/bin'/t) for t in tests})
receipts=root/'receipts';receipts.mkdir(exist_ok=True)
for p in root.iterdir():
 if p.is_file() and p.suffix not in ('.gz','.tar'):shutil.copy2(p,receipts/p.name)
for d in ['external','focused']:
 shutil.copytree(root/d,receipts/d,ignore=shutil.ignore_patterns('work','cache'),dirs_exist_ok=True)
manifest={str(p.relative_to(receipts)):sha(p) for p in receipts.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
(receipts/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['tar','-czf',str(root/'receipts.tar.gz'),'-C',str(receipts),'.'],check=True)
print(json.dumps({'files':len(manifest),'archive_sha256':sha(root/'receipts.tar.gz'),'source_files':len(identity['files']),'dependency_files':len(deps)}))
