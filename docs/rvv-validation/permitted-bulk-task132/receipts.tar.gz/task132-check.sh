#!/bin/bash
cd /home/vick/rvdbt-permitted-bulk-task132
ulimit -c 0
mkdir -p focused/native
sha256sum build/bin/elfrun build/lib/libdbtjitshared.so > BUILD_SHA256.txt
ldd -r build/bin/elfrun > ldd.txt 2>&1
for t in rv32_native_memory_fault_test rv32_unit_memory_fault_test rv32_special_memory_fault_test rv32_llvm_memory_admission_test vle32v_typedchunk_route_test vse32v_typedchunk_route_test; do
  if [ "$t" = rv32_native_memory_fault_test ]; then
    (cd focused/native && timeout 60 nice -n 10 taskset -c 28 ../../build/bin/$t) > $t.stdout 2> $t.stderr
  else
    timeout 60 nice -n 10 taskset -c 28 build/bin/$t > $t.stdout 2> $t.stderr
  fi
  rc=$?; echo "$rc" > $t.rc
  if [ "$rc" != 0 ]; then exit "$rc"; fi
done
timeout 900 nice -n 10 taskset -c 28 python3 replay_permitted_bulk_task132.py /home/vick/rvdbt-permitted-bulk-task132 > external.stdout 2> external.stderr
rc=$?; echo "$rc" > external.rc
sha256sum build/bin/elfrun build/lib/libdbtjitshared.so > BUILD_SHA256.final.txt
uptime > load.final.txt
exit "$rc"
