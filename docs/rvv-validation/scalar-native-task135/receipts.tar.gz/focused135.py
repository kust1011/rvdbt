import subprocess,pathlib,hashlib,json,sys,resource
r=pathlib.Path('/home/vick/rvdbt-scalar-native-task135');resource.setrlimit(resource.RLIMIT_CORE,(0,0))
assert (r/'build.rc').read_text()=='0'
pins=json.loads((r/'BUILD_IDENTITY.json').read_text())
def identity():
 assert all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h for p,h in pins.items())
name=sys.argv[1];binary=sys.argv[2];args=sys.argv[3:]
identity();d=r/'focused'/name;d.mkdir(parents=True)
cmd=['taskset','-c','28','timeout','60',str(r/'build/bin'/binary),*args]
(d/'command.json').write_text(json.dumps(cmd,indent=2));(d/'IDENTITY.pre.json').write_text(json.dumps(pins,indent=2))
with (d/'stdout').open('w') as out,(d/'stderr').open('w') as err:p=subprocess.run(cmd,stdout=out,stderr=err,cwd=d)
(d/'rc').write_text(str(p.returncode));identity();(d/'IDENTITY.post.json').write_text(json.dumps(pins,indent=2))
print(name,p.returncode);print((d/'stdout').read_text()[-1000:]);print((d/'stderr').read_text()[-2000:]);sys.exit(p.returncode)
