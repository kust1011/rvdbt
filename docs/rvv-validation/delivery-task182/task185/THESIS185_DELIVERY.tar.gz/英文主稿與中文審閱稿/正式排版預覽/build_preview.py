"""Typeset the current review manuscripts without replacing the submitted thesis."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
THESIS = ROOT.parent
OUT = HERE / 'generated'
OUT.mkdir(exist_ok=True)
PANDOC = os.environ.get('PANDOC', '/tmp/pandoc-3.6.4/bin/pandoc')
sources = {}

def read(path):
    text = path.read_text()
    sources[str(path.relative_to(THESIS))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return text

def run(args, **kwargs):
    return subprocess.run(args, check=True, text=True, capture_output=True, **kwargs).stdout

def tex(markdown, table_widths=None):
    ast = json.loads(run([PANDOC, '-f', 'markdown+raw_tex+tex_math_single_backslash+autolink_bare_uris',
                          '-t', 'json'], input=markdown))
    for block in ast['blocks']:
        if block['t'] == 'Table':
            columns = block['c'][2]
            if table_widths is not None and len(columns) == len(table_widths):
                for column, width in zip(columns, table_widths):
                    column[1] = {'t': 'ColWidth', 'c': width}
            elif len(columns) == 7:
                widths = [.18] + [.82 / 6] * 6
                for column, width in zip(columns, widths):
                    column[1] = {'t': 'ColWidth', 'c': width}
            elif len(columns) == 6:
                widths = [.25] + [.75 / 5] * 5
                for column, width in zip(columns, widths):
                    column[1] = {'t': 'ColWidth', 'c': width}
    return run([PANDOC, '-f', 'json', '-t', 'latex', '--top-level-division=chapter',
                '--listings', '--wrap=none'], input=json.dumps(ast))

refs = read(ROOT / 'en/07_References/01_References.md')
entries = re.findall(r'^- \[([^]]+)\] (.+)$', refs, re.M)
keys = {key for key, _ in entries}
cited = set()

def citations(text):
    def sub(match):
        group = [k.strip() for k in match[1].split(',')]
        if all(k in keys for k in group):
            cited.update(group)
            return '\\cite{' + ','.join(group) + '}'
        return match[0]
    return re.sub(r'\[([A-Za-z][A-Za-z0-9, -]*)\]', sub, text)

table_titles = {
    1: ['Element groups processed by successive RISC-V iterations'],
    2: ['RVV execution paths in the compared systems'],
    5: ['Workload computations and evaluation roles',
        'Microkernel elapsed times and width speedups',
        'Width scaling in numerical and application workloads',
        'Complete VLEN-1024 ablation: mean elapsed time in seconds',
        'Execution time at VLEN 1024',
        'Execution time at VLEN 256',
        'Supported-width comparison: mean process time in seconds',
        'Functional simulator reference paths: mean process time in seconds',
        'External target/result-checked instruction forms',
        'Primary CHIPS executions on the clean correctness build'],
}

def chapter(path, chapter_no=None, appendix=False):
    text = citations(read(path))
    text = text.replace('](../../../artifacts/', '](../../artifacts/')
    text = re.sub(r'^(#{1,6}) \d+(?:\.\d+)*\.?\s+', r'\1 ', text, flags=re.M)
    text = text.replace('# Appendix A. Complete Reported Results', '# Complete Reported Results')
    text = text.replace('# Appendix B. Instruction-Form Scope', '# Instruction-Form Scope')
    # Convert figure+caption together; preserve the actual vector PDF, not a bitmap.
    pattern = r'!\[([^\]]*)\]\(([^)]+)\)\s*\n\nFigure (\d+\.\d+)\. ([\s\S]*?)(?=\n\n|\Z)'
    def figure(match):
        alt, image, number, caption = match.groups()
        name = Path(image).with_suffix('.pdf').name
        image_path = ROOT / 'figures' / name
        if not image_path.exists():
            raise FileNotFoundError(image_path)
        sources[str(image_path.relative_to(THESIS))] = hashlib.sha256(image_path.read_bytes()).hexdigest()
        short = tex(alt).strip()
        full = tex(caption).strip()
        return ('\\begin{figure}[htbp]\n\\centering\n'
                '\\includegraphics[max width=\\linewidth,max height=.68\\textheight]{../figures/' + name + '}\n'
                '\\caption[' + short + ']{' + full + '}\\label{fig:' + number + '}\n'
                '\\end{figure}')
    text = re.sub(pattern, figure, text)
    # Pandoc's Markdown parser handles inline syntax and tables; only metadata is supplied here.
    lines = text.splitlines()
    new = []
    i = 0
    table_idx = 0
    current_section = ''
    while i < len(lines):
        line = lines[i]
        if line.startswith('## '):
            current_section = line[3:]
            if appendix:
                # The table caption carries the workload name; avoid orphan headings.
                i += 1
                continue
        if line.startswith('|'):
            block = []
            while i < len(lines) and lines[i].startswith('|'):
                block.append(lines[i]); i += 1
            title = (current_section + ': mean elapsed time (seconds)') if appendix else table_titles[chapter_no][table_idx]
            table_idx += 1
            new += ['\\begingroup', '\\small\\setstretch{1.1}', '\\setlength{\\tabcolsep}{4pt}',
                    '\\needspace{9\\baselineskip}', '', *block, '', 'Table: ' + title, '', '\\endgroup', '']
            continue
        new.append(line); i += 1
    widths = [.17, .37, .46] if chapter_no == 2 else ([.42, .28, .30] if chapter_no == 5 else None)
    result = tex('\n'.join(new), table_widths=widths)
    # These are short tables: keep the caption, header and body together.
    def short_table(match):
        table = match[0]
        caption = re.search(r'\\caption\{([^\n]+)\}\\tabularnewline', table)
        table = re.sub(r'\\caption\{[^\n]+\}\\tabularnewline\n', '', table, count=1)
        table = re.sub(r'\\endfirsthead[\s\S]*?\\endhead\n', '', table)
        table = re.sub(r'\\bottomrule\\noalign\{\}\n\\endlastfoot\n', '', table)
        table = table.replace('\\begin{longtable}[]', '\\begin{tabular}')
        table = table.replace('\\end{longtable}', '\\bottomrule\n\\end{tabular}')
        return '\\begin{table}[H]\n\\centering\n\\caption{' + caption[1] + '}\n' + table + '\n\\end{table}'
    result = re.sub(r'\\begin\{longtable\}[\s\S]*?\\end\{longtable\}', short_table, result)
    # Preserve the alignment of the existing ASCII illustration without line wrapping.
    def listing(match):
        body = match[1]
        if 'RVV iteration 1:' in body or max(map(len, body.splitlines()), default=0) > 85:
            return '\\begin{lstlisting}[basicstyle=\\ttfamily\\fontsize{8.5}{11}\\selectfont,breaklines=false,columns=fixed,basewidth=4.6pt]\n' + body + '\\end{lstlisting}'
        return match[0]
    result = re.sub(r'\\begin\{lstlisting\}\n([\s\S]*?)\\end\{lstlisting\}', listing, result)
    result = re.sub(r'(\\begin\{lstlisting\}[\s\S]*?\\end\{lstlisting\})',
                    r'\\par\\noindent\\begin{minipage}{\\linewidth}\n\1\n\\end{minipage}\\par', result)
    if chapter_no in table_titles and table_idx != len(table_titles[chapter_no]):
        raise ValueError(f'Unexpected table count in chapter {chapter_no}: {table_idx}')
    return result

parts = []
for number in range(1, 7):
    path = next((ROOT / 'en').glob(f'{number:02d}_*/*.md'))
    name = f'{number:02d}.tex'
    (OUT / name).write_text(chapter(path, number))
    parts.append('\\input{generated/' + name + '}')

for lang, heading, name in [('zh-TW', '摘要', 'abstract-zh'), ('en', 'Abstract', 'abstract-en')]:
    content = read(ROOT / lang / '00_Abstract.md').split('\n## ', 1)[1].split('\n', 1)[1]
    (OUT / (name + '.tex')).write_text('\\chapter*{' + heading + '}\n'
        '\\phantomsection\\addcontentsline{toc}{chapter}{' + heading + '}\n' + tex(content))

bib = ['\\clearpage', '\\phantomsection\\addcontentsline{toc}{chapter}{References}',
       '\\begin{spacing}{1.2}', '\\begin{thebibliography}{99}']
for key, entry in entries:
    entry = re.sub(r'`([^`]+)`', lambda m: '\\path{' + m[1] + '}', entry)
    bib += ['\\bibitem{' + key + '}', tex(entry)]
bib += ['\\end{thebibliography}', '\\end{spacing}']
(OUT / 'references.tex').write_text('\n'.join(bib))
(OUT / 'appendix.tex').write_text(chapter(ROOT / 'en/08_Appendix/01_Complete_Results.md', appendix=True))
form_inventory = chapter(ROOT / 'en/08_Appendix/02_Instruction_Forms.md')
# Keep each mnemonic intact; allow wrapping only between comma-separated forms.
form_inventory = re.sub(r'\\passthrough\{\\lstinline!([a-z0-9.]+)!\}',
                        lambda m: '\\mbox{\\texttt{' + m[1] + '}}', form_inventory)
(OUT / 'appendix-forms.tex').write_text('\\begingroup\n\\raggedright\n' +
    form_inventory + '\n\\par\\endgroup\n')

# Retain the existing thesis's cover, typefaces, margins and transparent watermark.
template = read(THESIS / 'main.tex')
preamble, rest = template.split('\\begin{document}', 1)
# The review manuscript owns its title; the inherited template supplies layout.
for lang, macro in [('zh-TW', 'zhtitle'), ('en', 'entitle')]:
    title = read(ROOT / lang / '00_Abstract.md').splitlines()[0].removeprefix('# ')
    preamble = re.sub(r'\\newcommand\{\\' + macro + r'\}\{[^\n]*\}',
                      lambda _: '\\newcommand{\\' + macro + '}{' + title + '}', preamble)
preamble = preamble.replace('Path=fonts/', 'Path=../../fonts/')
preamble = preamble.replace('{watermark-color-transparent.png}', '{../../watermark-color-transparent.png}')
preamble = re.sub(r'\\input\{artifacts/[^}]+\}\n', '', preamble)
preamble += r'''
\usepackage[export]{adjustbox}
\usepackage{calc}
\usepackage{xurl}
\providecommand{\tightlist}{\setlength{\itemsep}{0pt}\setlength{\parskip}{0pt}}
\providecommand{\passthrough}[1]{#1}
\providecommand{\pandocbounded}[1]{#1}
\renewcommand{\bibname}{References}
\setcounter{tocdepth}{2}
\setcounter{secnumdepth}{2}
\lstset{numbers=none,xleftmargin=0pt,basicstyle=\ttfamily\footnotesize,
  breaklines=true,breakatwhitespace=false}
\AtBeginEnvironment{lstlisting}{\setstretch{1}}
'''
cover = rest.split('\\pagenumbering{roman}', 1)[0]
cover = cover.replace('115 年 9 月', '115 年 10 月').replace('September 2026', 'October 2026')
front = r'''
\pagenumbering{roman}
\setstretch{1.6}
\input{generated/abstract-zh}
\input{generated/abstract-en}
\clearpage\phantomsection\addcontentsline{toc}{chapter}{Contents}
\tableofcontents
\clearpage\phantomsection\addcontentsline{toc}{chapter}{List of Figures}
\listoffigures
\clearpage\phantomsection\addcontentsline{toc}{chapter}{List of Tables}
\listoftables
\clearpage\pagenumbering{arabic}
\fontsize{12}{18}\selectfont
'''
end = '\n\\input{generated/references}\n\\appendix\n\\input{generated/appendix}\n\\input{generated/appendix-forms}\n\\end{document}\n'
(HERE / 'main.tex').write_text(preamble + '\\begin{document}' + cover + front + '\n'.join(parts) + end)
(HERE / 'SOURCE_MANIFEST.json').write_text(json.dumps({
    'status': 'Layout preview only; manuscript not approved',
    'sources_sha256': sources,
    'citation_keys': sorted(keys), 'cited_keys': sorted(cited),
    'changes': ['Formal typesetting only', 'October 2026 cover date',
                'Existing citation keys converted to numbered references',
                'Existing tables given descriptive captions',
                'No new results or runtime changes'],
}, indent=2, ensure_ascii=False) + '\n')
print('Generated six chapters, bilingual abstracts, bibliography and full appendix.')
build = HERE / '.build'
build.mkdir(exist_ok=True)
for iteration in range(3):
    result = subprocess.run(['xelatex', '-interaction=nonstopmode', '-halt-on-error',
        '-output-directory=.build', '-jobname=RVV_Thesis_Layout_Preview', 'main.tex'],
        cwd=HERE, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (build / f'pass-{iteration+1}.log').write_text(result.stdout)
    if result.returncode:
        raise RuntimeError(result.stdout[-6000:])
shutil.copyfile(build / 'RVV_Thesis_Layout_Preview.pdf', HERE / 'RVV_Thesis_Layout_Preview.pdf')
print('Built RVV_Thesis_Layout_Preview.pdf (three XeLaTeX passes).')
