# 附錄 B. 指令形式範圍

下列 627 個形式包含 595 個適用形式與 32 個配置排除項。適用集合等於第 5.7 節的目標／結果受檢聯集；固定正確性 build另有 595 個受檢形式聯集。包含直接與 helper 執行。集合記錄有界的目標／輸出檢查，不宣稱完整配置覆蓋或普遍 M1/M2 准入。

[實作與驗證表](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-current-scope.md)及[機器可讀形式清單](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/current-scope/forms.csv)逐形式列出實作路徑、外部結果檢查與剩餘限制。[範圍紀錄](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/current-scope/README.md)保留套件涵蓋集合、受測版本，以及來源與 assertion 的對應。[套件執行摘要](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/suite-execution-summary.md)分別列出程式執行、參考模型執行、失敗控制及來源排除項。[Ara 審閱包](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/ara-review-task91/README.md)包含原始來源、適配案例、原始輸出與解析它們的 checker，也保留失敗及排除案例。資料包可離線審閱；重新執行的命令另行提供。[CHIPS 審閱指引](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/chips-review-task93/README.md)及[ACT 審閱指引](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/act-primary-task99/README.md)說明保留的來源、參考結果及輸出對應。[驗證資料下載](https://github.com/kust1011/rvdbt/releases/tag/rvv-validation-20261012)提供兩套資料包及固定下載清單，可依指引離線檢查。歷史驗證與效能測試的 build 各自保留版本身份。

RIF 有 125 個耦合終點形式，與操作結果檢查分開；初始化回報沒有檢查結果。接受的集合包含 1,500 個 root 與 6,000 次 DUT 呼叫。543 個 O2 衍生 ELF 及其 2,172 次 DUT 觀察屬於診斷紀錄，不列入接受結果。第 5.7 節說明歸約衍生案例及純量 oracle 限制。操作至產碼的 binding 區分 174 個 lowering 缺失、6 個受檢複合序列及 8 個真正的搬移 checker 缺口；來源中的名義操作本身不足以建立受檢產碼形式。

ATG 保留 9 個 producer contract 與 2 個 reserved source-overlap 輸出。Ara 保留舊版／缺失 macro、過短或不完整 store 與配置缺口；CHIPS 保留 8 個不安全原始 store 輸出；ACT 保留 form／profile 及 privileged-signature 缺口。這些來源與 checker 限制仍對應其原始案例，與接受的衍生結果分開。

RVISmith 保留 34 個 compiler-error 項目與原始正規化規則。rv32emu 維持 whole-test 失敗：到達8 個檢查，7 個通過，1 個失敗，296 個未到達，沒有 data-vector 結果覆蓋。RiESCUE 的 RV32 runtime／address／high-half contract、FORCE 未完成建置的平台／ELF64 writer 及 model-only assertion、CTK 的 RV64 入口，以及 Tenstorrent 的 1,056 個 privileged RV64 案例，仍屬來源／平台排除項或阻塞，不算正向 RVV 檢查。這些裁決與 observer 限制可由[來源摘要](../../../artifacts/external_suite_coverage_20261007/JSERV_VERIFICATION_SUMMARY.md)及不可變 ledger 連結查閱。

[歷史外部逐形式結果](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/host512-task142/combined/FORMS.md)列出保留之外部批次執行檔的 CHIPS、ACT 與 Ara 檢查。[離線審閱指引](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/host512-task142/README.md)將可下載的實際輸出連接至原始來源與 checker。Fault handling 另見[實作導讀](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-qcg.md)：受控 helper 及符合條件的單一 QCG 記憶體指令可保留已完成結果，並將 fault 交回 dispatcher。原始 signal 測試的失敗與後續有限範圍的修正均保留紀錄。Guest handler 返回與 restart、完整狀態、agnostic 寫入歷史、存取抑制及逐 PC 方法准入，在第 5.7 節描述的測試之外仍不完整。

兩個 ATG 與兩個 Ara source-overlap 案例依 ISA manual revision `6b45f5c6` 分類：同一道指令以不同來源 EEW 讀取同一向量暫存器屬 reserved encoding，其中 mask 來源的 EEW 為 1 [RVV]。封存的 2021 年 V 1.0 原文未明列這項規則，因此這些裁定須標明所採規範版本，不能將兩版原文視為相同。

專案自撰的 directed matrix 另為 595 個適用形式索引已接受案例、觀察維度、oracle 範圍、歷史 family 收據及最終同版實際結果。第 5.7 節分列 12,069,048 次一般正向 DUT 檢查、2,256 次 focused 正向檢查與 592 次 focused 拒絕控制。已完成的序列矩陣在相同固定正確性執行檔上檢查實際最佳化路徑，不增加指令形式數。外部原始判定、directed 架構比較及效能量測各自保留證據身份。

## 向量配置 (3)

`vsetivli`, `vsetvl`, `vsetvli`.

## 同寬度整數運算 (98)

`vadc.vim`, `vadc.vvm`, `vadc.vxm`, `vadd.vi`, `vadd.vv`, `vadd.vx`, `vand.vi`, `vand.vv`, `vand.vx`, `vdiv.vv`, `vdiv.vx`, `vdivu.vv`, `vdivu.vx`, `vmacc.vv`, `vmacc.vx`, `vmadc.vi`, `vmadc.vim`, `vmadc.vv`, `vmadc.vvm`, `vmadc.vx`, `vmadc.vxm`, `vmadd.vv`, `vmadd.vx`, `vmax.vv`, `vmax.vx`, `vmaxu.vv`, `vmaxu.vx`, `vmerge.vim`, `vmerge.vvm`, `vmerge.vxm`, `vmin.vv`, `vmin.vx`, `vminu.vv`, `vminu.vx`, `vmsbc.vv`, `vmsbc.vvm`, `vmsbc.vx`, `vmsbc.vxm`, `vmseq.vi`, `vmseq.vv`, `vmseq.vx`, `vmsgt.vi`, `vmsgt.vx`, `vmsgtu.vi`, `vmsgtu.vx`, `vmsle.vi`, `vmsle.vv`, `vmsle.vx`, `vmsleu.vi`, `vmsleu.vv`, `vmsleu.vx`, `vmslt.vv`, `vmslt.vx`, `vmsltu.vv`, `vmsltu.vx`, `vmsne.vi`, `vmsne.vv`, `vmsne.vx`, `vmul.vv`, `vmul.vx`, `vmulh.vv`, `vmulh.vx`, `vmulhsu.vv`, `vmulhsu.vx`, `vmulhu.vv`, `vmulhu.vx`, `vmv.v.i`, `vmv.v.v`, `vmv.v.x`, `vnmsac.vv`, `vnmsac.vx`, `vnmsub.vv`, `vnmsub.vx`, `vor.vi`, `vor.vv`, `vor.vx`, `vrem.vv`, `vrem.vx`, `vremu.vv`, `vremu.vx`, `vrsub.vi`, `vrsub.vx`, `vsbc.vvm`, `vsbc.vxm`, `vsll.vi`, `vsll.vv`, `vsll.vx`, `vsra.vi`, `vsra.vv`, `vsra.vx`, `vsrl.vi`, `vsrl.vv`, `vsrl.vx`, `vsub.vv`, `vsub.vx`, `vxor.vi`, `vxor.vv`, `vxor.vx`.

## 整數擴寬運算 (31)

`vwadd.vv`, `vwadd.vx`, `vwadd.wv`, `vwadd.wx`, `vwaddu.vv`, `vwaddu.vx`, `vwaddu.wv`, `vwaddu.wx`, `vwmacc.vv`, `vwmacc.vx`, `vwmaccsu.vv`, `vwmaccsu.vx`, `vwmaccu.vv`, `vwmaccu.vx`, `vwmaccus.vx`, `vwmul.vv`, `vwmul.vx`, `vwmulsu.vv`, `vwmulsu.vx`, `vwmulu.vv`, `vwmulu.vx`, `vwredsum.vs`, `vwredsumu.vs`, `vwsub.vv`, `vwsub.vx`, `vwsub.wv`, `vwsub.wx`, `vwsubu.vv`, `vwsubu.vx`, `vwsubu.wv`, `vwsubu.wx`.

## 整數窄化運算 (12)

`vnclip.wi`, `vnclip.wv`, `vnclip.wx`, `vnclipu.wi`, `vnclipu.wv`, `vnclipu.wx`, `vnsra.wi`, `vnsra.wv`, `vnsra.wx`, `vnsrl.wi`, `vnsrl.wv`, `vnsrl.wx`.

## 整數延伸 (6)

`vsext.vf2`, `vsext.vf4`, `vsext.vf8`, `vzext.vf2`, `vzext.vf4`, `vzext.vf8`.

## 整數歸約 (8)

`vredand.vs`, `vredmax.vs`, `vredmaxu.vs`, `vredmin.vs`, `vredminu.vs`, `vredor.vs`, `vredsum.vs`, `vredxor.vs`.

## 定點運算 (26)

`vaadd.vv`, `vaadd.vx`, `vaaddu.vv`, `vaaddu.vx`, `vasub.vv`, `vasub.vx`, `vasubu.vv`, `vasubu.vx`, `vsadd.vi`, `vsadd.vv`, `vsadd.vx`, `vsaddu.vi`, `vsaddu.vv`, `vsaddu.vx`, `vsmul.vv`, `vsmul.vx`, `vssra.vi`, `vssra.vv`, `vssra.vx`, `vssrl.vi`, `vssrl.vv`, `vssrl.vx`, `vssub.vv`, `vssub.vx`, `vssubu.vv`, `vssubu.vx`.

## 浮點運算 (101)

`vfadd.vf`, `vfadd.vv`, `vfclass.v`, `vfcvt.f.x.v`, `vfcvt.f.xu.v`, `vfcvt.rtz.x.f.v`, `vfcvt.rtz.xu.f.v`, `vfcvt.x.f.v`, `vfcvt.xu.f.v`, `vfdiv.vf`, `vfdiv.vv`, `vfmacc.vf`, `vfmacc.vv`, `vfmadd.vf`, `vfmadd.vv`, `vfmax.vf`, `vfmax.vv`, `vfmerge.vfm`, `vfmin.vf`, `vfmin.vv`, `vfmsac.vf`, `vfmsac.vv`, `vfmsub.vf`, `vfmsub.vv`, `vfmul.vf`, `vfmul.vv`, `vfmv.f.s`, `vfmv.s.f`, `vfmv.v.f`, `vfncvt.f.f.w`, `vfncvt.f.x.w`, `vfncvt.f.xu.w`, `vfncvt.rod.f.f.w`, `vfncvt.rtz.x.f.w`, `vfncvt.rtz.xu.f.w`, `vfncvt.x.f.w`, `vfncvt.xu.f.w`, `vfnmacc.vf`, `vfnmacc.vv`, `vfnmadd.vf`, `vfnmadd.vv`, `vfnmsac.vf`, `vfnmsac.vv`, `vfnmsub.vf`, `vfnmsub.vv`, `vfrdiv.vf`, `vfrec7.v`, `vfredmax.vs`, `vfredmin.vs`, `vfredosum.vs`, `vfredusum.vs`, `vfrsqrt7.v`, `vfrsub.vf`, `vfsgnj.vf`, `vfsgnj.vv`, `vfsgnjn.vf`, `vfsgnjn.vv`, `vfsgnjx.vf`, `vfsgnjx.vv`, `vfslide1down.vf`, `vfslide1up.vf`, `vfsqrt.v`, `vfsub.vf`, `vfsub.vv`, `vfwadd.vf`, `vfwadd.vv`, `vfwadd.wf`, `vfwadd.wv`, `vfwcvt.f.f.v`, `vfwcvt.f.x.v`, `vfwcvt.f.xu.v`, `vfwcvt.rtz.x.f.v`, `vfwcvt.rtz.xu.f.v`, `vfwcvt.x.f.v`, `vfwcvt.xu.f.v`, `vfwmacc.vf`, `vfwmacc.vv`, `vfwmsac.vf`, `vfwmsac.vv`, `vfwmul.vf`, `vfwmul.vv`, `vfwnmacc.vf`, `vfwnmacc.vv`, `vfwnmsac.vf`, `vfwnmsac.vv`, `vfwredosum.vs`, `vfwredusum.vs`, `vfwsub.vf`, `vfwsub.vv`, `vfwsub.wf`, `vfwsub.wv`, `vmfeq.vf`, `vmfeq.vv`, `vmfge.vf`, `vmfgt.vf`, `vmfle.vf`, `vmfle.vv`, `vmflt.vf`, `vmflt.vv`, `vmfne.vf`, `vmfne.vv`.

## 遮罩位元運算 (13)

`vcpop.m`, `vfirst.m`, `vmand.mm`, `vmandn.mm`, `vmnand.mm`, `vmnor.mm`, `vmor.mm`, `vmorn.mm`, `vmsbf.m`, `vmsif.m`, `vmsof.m`, `vmxnor.mm`, `vmxor.mm`.

## 遮罩至整數運算 (2)

`vid.v`, `viota.m`.

## 元素排列與搬移 (13)

`vcompress.vm`, `vmv.s.x`, `vmv.x.s`, `vrgather.vi`, `vrgather.vv`, `vrgather.vx`, `vrgatherei16.vv`, `vslide1down.vx`, `vslide1up.vx`, `vslidedown.vi`, `vslidedown.vx`, `vslideup.vi`, `vslideup.vx`.

## 整暫存器搬移 (4)

`vmv1r.v`, `vmv2r.v`, `vmv4r.v`, `vmv8r.v`.

## 單位跨距、指定跨距與分段記憶體操作 (160)

`vle16.v`, `vle16ff.v`, `vle32.v`, `vle32ff.v`, `vle64.v`, `vle64ff.v`, `vle8.v`, `vle8ff.v`, `vlse16.v`, `vlse32.v`, `vlse64.v`, `vlse8.v`, `vlseg2e16.v`, `vlseg2e16ff.v`, `vlseg2e32.v`, `vlseg2e32ff.v`, `vlseg2e64.v`, `vlseg2e64ff.v`, `vlseg2e8.v`, `vlseg2e8ff.v`, `vlseg3e16.v`, `vlseg3e16ff.v`, `vlseg3e32.v`, `vlseg3e32ff.v`, `vlseg3e64.v`, `vlseg3e64ff.v`, `vlseg3e8.v`, `vlseg3e8ff.v`, `vlseg4e16.v`, `vlseg4e16ff.v`, `vlseg4e32.v`, `vlseg4e32ff.v`, `vlseg4e64.v`, `vlseg4e64ff.v`, `vlseg4e8.v`, `vlseg4e8ff.v`, `vlseg5e16.v`, `vlseg5e16ff.v`, `vlseg5e32.v`, `vlseg5e32ff.v`, `vlseg5e64.v`, `vlseg5e64ff.v`, `vlseg5e8.v`, `vlseg5e8ff.v`, `vlseg6e16.v`, `vlseg6e16ff.v`, `vlseg6e32.v`, `vlseg6e32ff.v`, `vlseg6e64.v`, `vlseg6e64ff.v`, `vlseg6e8.v`, `vlseg6e8ff.v`, `vlseg7e16.v`, `vlseg7e16ff.v`, `vlseg7e32.v`, `vlseg7e32ff.v`, `vlseg7e64.v`, `vlseg7e64ff.v`, `vlseg7e8.v`, `vlseg7e8ff.v`, `vlseg8e16.v`, `vlseg8e16ff.v`, `vlseg8e32.v`, `vlseg8e32ff.v`, `vlseg8e64.v`, `vlseg8e64ff.v`, `vlseg8e8.v`, `vlseg8e8ff.v`, `vlsseg2e16.v`, `vlsseg2e32.v`, `vlsseg2e64.v`, `vlsseg2e8.v`, `vlsseg3e16.v`, `vlsseg3e32.v`, `vlsseg3e64.v`, `vlsseg3e8.v`, `vlsseg4e16.v`, `vlsseg4e32.v`, `vlsseg4e64.v`, `vlsseg4e8.v`, `vlsseg5e16.v`, `vlsseg5e32.v`, `vlsseg5e64.v`, `vlsseg5e8.v`, `vlsseg6e16.v`, `vlsseg6e32.v`, `vlsseg6e64.v`, `vlsseg6e8.v`, `vlsseg7e16.v`, `vlsseg7e32.v`, `vlsseg7e64.v`, `vlsseg7e8.v`, `vlsseg8e16.v`, `vlsseg8e32.v`, `vlsseg8e64.v`, `vlsseg8e8.v`, `vse16.v`, `vse32.v`, `vse64.v`, `vse8.v`, `vsse16.v`, `vsse32.v`, `vsse64.v`, `vsse8.v`, `vsseg2e16.v`, `vsseg2e32.v`, `vsseg2e64.v`, `vsseg2e8.v`, `vsseg3e16.v`, `vsseg3e32.v`, `vsseg3e64.v`, `vsseg3e8.v`, `vsseg4e16.v`, `vsseg4e32.v`, `vsseg4e64.v`, `vsseg4e8.v`, `vsseg5e16.v`, `vsseg5e32.v`, `vsseg5e64.v`, `vsseg5e8.v`, `vsseg6e16.v`, `vsseg6e32.v`, `vsseg6e64.v`, `vsseg6e8.v`, `vsseg7e16.v`, `vsseg7e32.v`, `vsseg7e64.v`, `vsseg7e8.v`, `vsseg8e16.v`, `vsseg8e32.v`, `vsseg8e64.v`, `vsseg8e8.v`, `vssseg2e16.v`, `vssseg2e32.v`, `vssseg2e64.v`, `vssseg2e8.v`, `vssseg3e16.v`, `vssseg3e32.v`, `vssseg3e64.v`, `vssseg3e8.v`, `vssseg4e16.v`, `vssseg4e32.v`, `vssseg4e64.v`, `vssseg4e8.v`, `vssseg5e16.v`, `vssseg5e32.v`, `vssseg5e64.v`, `vssseg5e8.v`, `vssseg6e16.v`, `vssseg6e32.v`, `vssseg6e64.v`, `vssseg6e8.v`, `vssseg7e16.v`, `vssseg7e32.v`, `vssseg7e64.v`, `vssseg7e8.v`, `vssseg8e16.v`, `vssseg8e32.v`, `vssseg8e64.v`, `vssseg8e8.v`.

## 索引記憶體操作 (96)

`vloxei16.v`, `vloxei32.v`, `vloxei8.v`, `vloxseg2ei16.v`, `vloxseg2ei32.v`, `vloxseg2ei8.v`, `vloxseg3ei16.v`, `vloxseg3ei32.v`, `vloxseg3ei8.v`, `vloxseg4ei16.v`, `vloxseg4ei32.v`, `vloxseg4ei8.v`, `vloxseg5ei16.v`, `vloxseg5ei32.v`, `vloxseg5ei8.v`, `vloxseg6ei16.v`, `vloxseg6ei32.v`, `vloxseg6ei8.v`, `vloxseg7ei16.v`, `vloxseg7ei32.v`, `vloxseg7ei8.v`, `vloxseg8ei16.v`, `vloxseg8ei32.v`, `vloxseg8ei8.v`, `vluxei16.v`, `vluxei32.v`, `vluxei8.v`, `vluxseg2ei16.v`, `vluxseg2ei32.v`, `vluxseg2ei8.v`, `vluxseg3ei16.v`, `vluxseg3ei32.v`, `vluxseg3ei8.v`, `vluxseg4ei16.v`, `vluxseg4ei32.v`, `vluxseg4ei8.v`, `vluxseg5ei16.v`, `vluxseg5ei32.v`, `vluxseg5ei8.v`, `vluxseg6ei16.v`, `vluxseg6ei32.v`, `vluxseg6ei8.v`, `vluxseg7ei16.v`, `vluxseg7ei32.v`, `vluxseg7ei8.v`, `vluxseg8ei16.v`, `vluxseg8ei32.v`, `vluxseg8ei8.v`, `vsoxei16.v`, `vsoxei32.v`, `vsoxei8.v`, `vsoxseg2ei16.v`, `vsoxseg2ei32.v`, `vsoxseg2ei8.v`, `vsoxseg3ei16.v`, `vsoxseg3ei32.v`, `vsoxseg3ei8.v`, `vsoxseg4ei16.v`, `vsoxseg4ei32.v`, `vsoxseg4ei8.v`, `vsoxseg5ei16.v`, `vsoxseg5ei32.v`, `vsoxseg5ei8.v`, `vsoxseg6ei16.v`, `vsoxseg6ei32.v`, `vsoxseg6ei8.v`, `vsoxseg7ei16.v`, `vsoxseg7ei32.v`, `vsoxseg7ei8.v`, `vsoxseg8ei16.v`, `vsoxseg8ei32.v`, `vsoxseg8ei8.v`, `vsuxei16.v`, `vsuxei32.v`, `vsuxei8.v`, `vsuxseg2ei16.v`, `vsuxseg2ei32.v`, `vsuxseg2ei8.v`, `vsuxseg3ei16.v`, `vsuxseg3ei32.v`, `vsuxseg3ei8.v`, `vsuxseg4ei16.v`, `vsuxseg4ei32.v`, `vsuxseg4ei8.v`, `vsuxseg5ei16.v`, `vsuxseg5ei32.v`, `vsuxseg5ei8.v`, `vsuxseg6ei16.v`, `vsuxseg6ei32.v`, `vsuxseg6ei8.v`, `vsuxseg7ei16.v`, `vsuxseg7ei32.v`, `vsuxseg7ei8.v`, `vsuxseg8ei16.v`, `vsuxseg8ei32.v`, `vsuxseg8ei8.v`.

## 遮罩記憶體操作 (2)

`vlm.v`, `vsm.v`.

## 整暫存器記憶體操作 (20)

`vl1re16.v`, `vl1re32.v`, `vl1re64.v`, `vl1re8.v`, `vl2re16.v`, `vl2re32.v`, `vl2re64.v`, `vl2re8.v`, `vl4re16.v`, `vl4re32.v`, `vl4re64.v`, `vl4re8.v`, `vl8re16.v`, `vl8re32.v`, `vl8re64.v`, `vl8re8.v`, `vs1r.v`, `vs2r.v`, `vs4r.v`, `vs8r.v`.

## 配置範圍外的形式（32）

以下索引記憶體形式使用 64-bit 索引，不屬於本研究 RV32 配置的必要支援範圍 [RVV]。

`vloxei64.v`, `vloxseg2ei64.v`, `vloxseg3ei64.v`, `vloxseg4ei64.v`, `vloxseg5ei64.v`, `vloxseg6ei64.v`, `vloxseg7ei64.v`, `vloxseg8ei64.v`, `vluxei64.v`, `vluxseg2ei64.v`, `vluxseg3ei64.v`, `vluxseg4ei64.v`, `vluxseg5ei64.v`, `vluxseg6ei64.v`, `vluxseg7ei64.v`, `vluxseg8ei64.v`, `vsoxei64.v`, `vsoxseg2ei64.v`, `vsoxseg3ei64.v`, `vsoxseg4ei64.v`, `vsoxseg5ei64.v`, `vsoxseg6ei64.v`, `vsoxseg7ei64.v`, `vsoxseg8ei64.v`, `vsuxei64.v`, `vsuxseg2ei64.v`, `vsuxseg3ei64.v`, `vsuxseg4ei64.v`, `vsuxseg5ei64.v`, `vsuxseg6ei64.v`, `vsuxseg7ei64.v`, `vsuxseg8ei64.v`.
