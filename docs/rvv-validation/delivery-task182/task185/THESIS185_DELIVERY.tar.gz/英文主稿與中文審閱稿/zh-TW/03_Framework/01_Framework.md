# 3. 系統架構

本章沿著 RVV 指令從 RISC-V 執行檔轉成 x86-64 機器碼的路徑，介紹各部件的作用。RVV 擴充在 rvdbt 既有的輕量 JIT 中加入向量狀態與運算，保留原有的 dispatcher、translation cache 與區塊鏈結機制。圖 3.1 顯示這些部件的關係。第 3.2--3.4 節依圖中的轉譯路徑，介紹 RISC-V frontend、QIR 與 CPU state，以及 x86-64 backend。

## 3.1 系統架構

rvdbt 結合輕量級 JIT 與 profile 導引的 AOT 編譯。在 Lin 所描述的工作流程中，第一次執行會蒐集 profile，離線的 LLVM 編譯器產生最佳化後的區域，後續執行則載入該產物，並在其他部分保留 JIT 執行 [Lin2025]。本論文擴充並評估圖 3.1 所示的輕量級路徑。

![RVV extension within the rvdbt JIT architecture](../../figures/rvdbt_rvv_framework.svg)

圖 3.1：rvdbt 的輕量級執行路徑，依 Lin 所描述的系統組織改繪 [Lin2025]。(a) Runtime 執行：快取未命中時呼叫輕量 JIT，將產生的機器碼放入 translation cache。(b) 同一個 JIT 的內部階段：RISC-V frontend（第 3.2 節）、QIR（第 3.3 節），以及包含三個階段的 QCG backend（第 3.4 節）。CPU state 於第 3.3 節說明。實線箭頭表示控制或程式碼轉移，虛線箭頭表示 runtime 資料存取；有底色的元件包含 RVV 擴充。

ELF 載入器映射 RISC-V 執行檔，並設定初始程式計數器。分派器在轉譯快取中查詢該位址。若未命中，RISC-V 前端會為該區塊建構 QIR，再由 QCG 後端產生其 x86-64 實作。runtime 將此程式碼安裝至快取，並透過 trampoline 進入；trampoline 是一段進入用的 stub，負責提供 CPU 狀態指標與程式記憶體基底位址。

轉譯後的分支可直接跳至已鏈結的區塊。若目標尚未解析，則回到分派器，由其取得目標區塊並修補鏈結。RVV 指令同樣使用此執行迴圈。其產生的機器碼自 CPU 狀態讀取架構暫存器、執行向量運算，並將所需結果寫回。對 RISC-V 程式陣列的存取則使用另一個獨立的程式記憶體映射。

## 3.2 RISC-V 前端

圖 3.1 中的 frontend 解碼每道指令並建構 QIR。處理 RVV 時，它根據運算元形式，以及元素寬度、暫存器分組與 VLEN 等組態，決定轉譯方式。有適用的直接實作時，便將運算元拆成 host 向量值；沒有直接實作的形式則在 QIR 中表示為 helper 呼叫。

以未使用遮罩的指令 `vadd.vv v10, v8, v9` 為例，其 VLEN 為 1024、SEW 為 32、LMUL 為 1。每個來源含有 32 個整數。在 512 位元路徑上，前端將每個運算元切分為兩組連續的 16 個元素。我們將每一組稱為一個*分量*。圖 3.2 將這兩組元素、共用的 QIR 至 x86 對應，以及部分更新分支實際寫入的目的元素對齊呈現。在此階段，分量是編譯器中的值，而非已指派的 ZMM 暫存器。

![One RVV addition represented by two vector components](../../figures/rvv_translation.svg)

圖 3.2：以兩個 512-bit 分量執行 RVV 加法。(a) 每格是 CPU-state 暫存器儲存空間中的一個 32-bit 元素；16 的邊界分隔兩個分量。(b) 完整更新對應套用到兩個分量，共四次載入、兩次加法、兩次儲存。對應符號表示 lowering，而非執行順序；所有來源載入先於加法與儲存。(c) 啟用 QCG 部分更新分支時，兩個 `vchunkpartialalu` 節點更新元素 0--19。底色表示寫入元素；元素 20--31 在此實作中保留原值。即使 RVV 指令未使用遮罩，AVX-512 store opmask 仍分別選取 16 與 4 個元素。圖中省略 guard、遮罩建構及完成指令。

同一個 RISC-V 位址可能在不同的向量組態下執行。快取未命中時，runtime 傳入目前的 `vtype` 作為轉譯提示；frontend 也追蹤區塊內的組態指令。執行時，guard 檢查直接轉譯路徑所需的條件。條件成立便執行向量主體；否則，以原始指令編碼呼叫語意 helper，再繼續執行該區塊。因此，快取中的機器碼不依賴編譯時的組態持續不變。

長向量分解也取決於運算種類。一般的逐元素加法使用相同的來源與目的元素寬度。加寬或縮窄指令會改變元素寬度，因此前端會分別記錄各運算元的範圍。reduction 或跨元素 permutation 無法以對等切片上的獨立加法取代。每種形式都保留各自的語意實作，而非沿用加法範例的分解規則。

## 3.3 向量 QIR 與 CPU 狀態

QIR 是 rvdbt 的中間表示。其向量擴充記錄元素型別、分量寬度，以及來源與目的運算元。圖 3.2 的完整更新路徑使用三個具體運算：`vstatechunkload` 從 CPU state 讀取一個分量，`vchunkadd` 計算加法，`vstatechunkstore` 寫回結果。QIR 也表示 guard、helper 呼叫與控制流程匯合點，因此 backend 收到的不只是向量計算，還包含選擇其執行路徑的條件。

CPU 狀態（於圖 3.1 中另行繪出）是轉譯區塊與 helper 所共用的持久性儲存空間。RVV 擴充新增 32 個向量暫存器槽位，以及包括 `vl`、`vtype`、`vstart` 與 `vlenb` 在內的控制欄位。各槽位皆預留所支援的最大大小，因此改變所設定的 VLEN 不會改變其他暫存器的位移。以圖 3.2 的加法為例，`v8` 的分量 0 起始於該槽位的基底；分量 1 則起始於其後 64 個位元組處。

QIR 暫存值與架構暫存器槽位具有不同的生命週期。暫存值可在區塊執行期間持續保留於 host 暫存器中。當後續區塊或 helper 需要時，最終的架構值必須已存在於 CPU 狀態中。這些明確的狀態儲存並非 register spill：spill 是因配置器缺乏暫存器而儲存暫存值。第 4 章會改變哪些中間狀態的儲存與重新載入是必要的，同時保留最終的架構值。

元素選擇同樣是明確的。對於一般的逐元素運算，令分量 j 含有 q 個元素，並令 i 為該分量中的一個 lane。其元素索引為 e=jq+i。當下式成立時，該 lane 會被更新：

\[
vstart \leq e < vl
\quad\text{and}\quad
(vm=1\ \text{or}\ v0[e]=1).
\]

其中 `vm=1` 表示未使用遮罩的指令。在 `vl=20` 且 `vstart=0` 時，範例的第一個分量會更新全部 16 個元素；第二個分量則更新四個。指令遮罩可再停用其他元素。tail-undisturbed 或 mask-undisturbed 的目的地會保留對應的舊值。對整數加法而言，此要求可透過對狀態儲存施加遮罩來實作。浮點與記憶體運算還必須考量例外與存取的副作用，因此其執行遮罩與 fallback 條件依運算而異。

## 3.4 x86-64 後端

QCG 是 rvdbt 的輕量 code generator，執行圖 3.1 中的三個 backend 階段，不呼叫 LLVM。Instruction selection 決定 host 指令對運算元的要求；register allocation 為 QIR 值配置實體暫存器；code emission 則使用 AsmJit，將所選指令編碼成機器碼。

就圖 3.2 而言，指令選擇將 32 位元整數加法對應至 `vpaddd`，並將 512 位元分量型別對應至 ZMM 運算元。配置器為每個分量指派個別的 host 值。狀態載入與儲存則成為位於其所記錄之 CPU 狀態位移處的向量記憶體運算。以下的算術主體說明 `vl=32` 與 `vstart=0` 時的結果；暫存器名稱僅供示意，並省略進入時的 guard。

```asm
vmovdqu64 zmm0, [state_v8  + 0]
vmovdqu64 zmm1, [state_v9  + 0]
vmovdqu64 zmm2, [state_v8  + 64]
vmovdqu64 zmm3, [state_v9  + 64]
vpaddd    zmm4, zmm0, zmm1
vpaddd    zmm5, zmm2, zmm3
vmovdqu64 [state_v10 + 0], zmm4
vmovdqu64 [state_v10 + 64], zmm5
```

完整更新路徑先讀取來源再寫回目的暫存器，避免來源與目的重疊時破壞輸入。啟用 QCG 的部分更新分支時，前端改為對每個分量產生一個 `vchunkpartialalu`。其 emitter 建構元素範圍遮罩，並使用帶遮罩的 `vmovdqu32` 寫回，每個 opmask 位元控制一個 32 位元目的元素。即使 RVV 指令本身沒有使用遮罩，這個 host 遮罩仍會保留不用更新的元素。完整狀態搬移不需逐元素選擇，因此可使用 `vmovdqu64`。兩個分量值仍分別對應不同的元素群組。

helper 分支也會限制暫存器配置。跨越可能之 helper 呼叫仍需使用的值，必須在 guard 之前保存。當 fallback 會略過 guard 保護之主體內的 spill 時，配置器便無法在其中任意插入 spill。因此，前端會限制分組直接主體所保留的向量值數量，詳見第 4 章。

產生的機器碼會存入 translation cache，透過第 3.1 節的 runtime 執行。這條路徑已能執行長向量算術，但逐指令轉譯仍有兩類重複工作：後續指令重新載入剛寫回 CPU state 的中間值，以及固定容量展開對超出 `vl` 的分量進行準備。下一章在 QIR 建構階段處理這些成本，位置在實體暫存器配置與機器碼產生之前。

## 3.5 實作變更

Patchset 擴充既有執行流程，沒有另建一套向量執行引擎。Lin 的 runtime、純量轉譯、translation cache 與 block linking 是其基礎 [Lin2025]。RVV 新增部分分為三項職責。

**執行支援。** Frontend 解碼向量運算元形式，維護架構向量暫存器與控制狀態。向量 QIR 攜帶元素型別、分量範圍、guard 與目的值更新要求。x86 backend 為直接路徑選擇 SIMD 運算與 opmask；不符合該路徑的指令形式或 runtime 條件則由 helper 處理。

**跨指令重用。** 序列建構器將來源對應到目前定義，記錄被修改架構暫存器的最終值，並估計暫存器需求。建構 QIR 時載入外部輸入，在受限批次內重用結果，再於釋放批次前寫回最終值。這些變更在實體暫存器配置之前進行。

**執行範圍控制。** 共用分量規劃依目的元素範圍推導邊界，包含 widening 與 narrowing。產生程式碼時，在可略過的尾端之前加入比較或沿用 mask 比較，並由完成區塊保留必要狀態更新。整合路徑將各分量的運算及最終 stores 放在一起，使分支不會跳過必要工作。

實作 artifact 提供從上游版本到擴充版本的 patchset，以及這些邊界的程式碼摘錄 [rvdbt-impl]。主要變更位於 RVV 解碼與 CPU state、向量 QIR 建構、序列分析、共用分量範圍規劃，以及 x86 指令產生。這些變更支援第 5 章評估的輕量執行路徑，並未取代原有 LLVM 流程；如何將向量表示整合進最佳化層，於第 5.6 節討論。

## 3.6 執行配置與語意邊界

本實作以 RV32 user-space 程式為目標，ELEN 為 64，VLEN 是 128 至 4096 bits 的二次方。VLEN 決定 register 容量，`vtype` 與 `vl` 決定如何使用。轉譯時的配置提示引導特化，產生的 guard 在進入直接 body 前檢查即時狀態。固定正確性 build 使用 512-bit QCG host component；獨立的 256-bit selector 不屬於此 build 配置。

CPU state 為每個向量 register 保留 512 bytes，邏輯長度則為 VLEN/8 bytes（第 3.3 節）。Register-group 定址遵循此實體間距。Widening 與 narrowing 在 register allocation 前，於不同來源及目的寬度間保留相同元素索引。

准入的直接 body 使用向量 QIR 與 host SIMD 指令；其餘情況由 RVV helper 存取相同架構狀態。兩條路徑都必須實作適用的 mask、目的 policy、rounding 與狀態更新。因此 helper 執行屬於語意支援，直接產碼與最佳化准入則各有條件。

驗證依這些路徑邊界進行。外部套件保留原始輸出判定；專案自撰的 directed matrix 則初始化架構狀態、執行目標指令，再擷取狀態交由 DUT 外的 checker 比較。最終 directed 與外部重跑使用同一固定正確性執行檔。序列驗證另將 target PC 接合至產生碼與實際執行的 frame，確認 register promotion 與 inactive component 省略（第 5.7 節）。

各操作的規則限制拆分方式。Reduction 合併元素，gather 可能讀取更新範圍以外的元素，整暫存器傳輸依 register 數決定範圍，不使用一般 `vl` 邊界。這些操作保留必要工作，不承接 element-wise 省略規則 [RVV]。

第 5.7 節區分指令形式覆蓋、最佳化路徑准入及 fault handling。具備存取檢查的向量記憶體 helper 保留已完成元素，並以 `vstart` 記錄發生 fault 的元素。存取被拒絕時，helper 記錄指令位址、記憶體位址與讀寫方向，再回到 dispatcher。若 host fault 發生於受控 copy 內，host handler 以精確指令位址辨識該存取，經由該操作的失敗出口返回。Dispatcher 隨後根據保存的狀態建立 RV32 signal frame，進入已註冊的同步 SIGSEGV 或 SIGBUS handler。Frame 在 helper 返回後建立，不在 host signal callback 內建立。

QCG 的記憶體指令各自在獨立的 instruction frame 中執行。兩側的算術序列仍可使用 register promotion，但後續指令不能在前一條記憶體指令完成前寫回結果。當連續指令覆寫相同 register 時，這個邊界保留前一條指令的目的值；只記錄最後 live-out 值，無法在 fault 後還原該值。

每個准入的記憶體 frame 都記錄精確的 host 存取位置，並產生 fault exit。一般 unit-stride 或 whole-register SIMD load 在存取下一個 chunk 前，先寫回已完成的 chunk。其 fault 邊界要求每個 active chunk 位於同一個匿名映射頁面內；跨頁 chunk 與不支援的 backing 改走 checked helper。發生符合捕捉條件的 user data page fault 時，runtime 回報被拒絕 chunk 的第一個元素。Whole-register 操作依編碼中的元素寬度與傳輸範圍計算此位置，不依賴一般 `vl`。

純量記憶體迴圈在每條存取 guest memory 的指令處，記錄目前元素與 segment field；已完成的 load field 在後續存取前寫回。位於同一頁內的純量存取可透過此邊界處理同步 SIGSEGV 及支援的 SIGBUS 事件；跨頁 field，以及可能改變後續 index 的 indexed-load overlap，改走 checked helper。Fault exit 保留先前狀態並回到 dispatcher。此契約涵蓋上述 QCG instruction frames；選用的 gather 路徑、LLVM native-memory 恢復，以及完整 guest handler 返回與 restart，仍須分別處理。
