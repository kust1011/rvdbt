# 5. 評估

本章評估執行效率與功能行為。第 5.1--5.6 節量測相同 binary 與輸入的寬度擴展、固定 VLEN 下各最佳化方法的貢獻，以及與其他執行系統的效能差異。第 5.7 節透過外部測試檢查指令涵蓋與狀態保存。Microkernel 與應用程式用於衡量效能；指令層級檢查則說明實際執行並比對了哪些行為。

## 5.1 實驗設定

主要 host 為支援 AVX-512 的 AMD Ryzen 9 9950X3D。受測行程固定於邏輯 CPU 6，其同步多執行緒的兄弟核心 CPU 22 則維持閒置。最低與最高頻率策略皆設為 4.3 GHz，並停用 boost。程式碼大型分頁一律停用。

主要指標為全新行程的牆鐘經過時間，涵蓋啟動、轉譯、程式執行、輸入／輸出，以及程式內部執行的檢查。host 端的輸出比對不在計時的行程內。行程啟動時不存在既有的 AOT 產物。因此，此指標評估的是輕量 JIT 的首次執行，而不僅是已轉譯完成的迴圈。

共評估四種組態：B 為逐指令的 RVV baseline；M1 啟用向量 register promotion 與有限大小的分批處理；M2 啟用逐指令的 runtime 向量範圍檢查；Both 同時啟用這兩組選項，包括符合條件的整數序列範圍檢查。第 4.3 節另述的一般浮點序列 component-first 路徑，在此矩陣中停用。模擬 VLEN 取值為 128、256、512、1024、2048 與 4096 位元。主要 host 路徑使用最多 512 位元的向量運算。每種組態執行 26 個完整回合，並輪替組態順序、交替寬度順序。每個報告組態的所有樣本皆予以保留。

令 T(X,V) 為方法 X 在 VLEN V 下的算術平均經過時間。寬度擴展以 T(X,512)/T(X,1024) 衡量。方法在固定 VLEN 下的時間縮減為 100(1 - T(X,V)/T(B,V))。所有比值皆由未經四捨五入的平均值計算。表格顯示以秒為單位、經四捨五入的時間。寬度擴展與方法改進使用不同的分母，並分開報告。

### 工作負載角色

評測分為受控相依鏈、抽取的數值 kernel，以及完整應用程式三個層次。Microkernel 隔離算術結構；數值 kernel 檢驗既有計算中的這些結構；應用程式則衡量局部改善能否縮短完整行程的執行時間。多媒體應用另外檢驗：當 runtime 處理的元素範圍仍短時，增加暫存器容量會帶來多少成本。

| Workload 與來源 | 受測計算 | 評測用途 |
|---|---|---|
| 自製整數加法；FP32 減法 | 固定工作量的算術鏈 | 受控的寬度擴展與狀態重用 |
| Livermore Loops K1；K3 | 抽取的流體力學運算式；內積 | Element-wise 算術鏈與 reduction 的差異 |
| LINPACK 衍生 kernel | 抽取的 LU 分解 | 線性代數計算中的重用 |
| TSVC s3251；vbor | 抽取的向量化測試迴圈 | 不同的運算元與中間值模式 |
| PolyBench/C ATAX；Doitgen | 抽取的矩陣—向量與張量 kernel | 結構化數值迴圈中的重用 |
| PARSEC 衍生 Blackscholes | 選擇權定價應用 | 算術改善對完整行程時間的影響 |
| Rodinia 衍生 LavaMD | 粒子交互作用應用 | 應用中的重複浮點運算式 |
| PARSEC 衍生 Streamcluster | 分群應用 | 寬度擴展是否也帶來 promotion 收益 |
| 封存的 JPEG encoder 與 decoder | 影像壓縮與重建 | 較大 VLEN 下的短向量工作 |
| 封存的 H.264 decoder：CABA3 與 crew | 同一解碼應用的兩種輸入 | 不同影片輸入下的邊界省略效果 |

報告包含 16 個 workload／輸入案例，並非 16 種獨立應用。例如 CABA3 與 crew 是 H.264 decoder 的兩種輸入。抽取的 kernel 衡量指定計算，而非整個套件。這樣的分類能分別檢驗寬度擴展、中間值重用，以及 runtime 短向量的影響。固定寬度的 ablation 呈現全部 16 個案例，也保留改善有限的結果。附錄 A 列出全部 384 個 workload／寬度／方法組合的平均時間；每項比較均固定 binary 與輸入。

### 硬體計數器

Case study 使用處理器的效能監控單元（PMU）量化實際執行工作量的變化。Linux `perf stat` 收集受測行程在使用者空間執行時的 `instructions:u` 與 `cycles:u`。前者計算退役指令數，後者計算使用者空間的處理器週期；執行時間則涵蓋完整行程的起訖區間。

原始資料的稽核涵蓋 11,232 筆受測組態記錄，包含附錄 A 所述的額外案例。每筆均包含兩種事件的正值計數，事件執行時間比例為 100%，且同次量測內的事件執行時間一致。正式量測在同一次 perf 執行中要求這兩種事件，但不將它們放入同一 event group。另一項校準將它們放在同一 event group，並將四指令組合語言迴圈從一千萬次迭代增加至兩千萬次。相對於預期增加的四千萬個退役指令，五組配對的最大差異為 52 個指令。此校準檢查指令計數的尺度；case study 的指令數與週期數縮減取自正式量測。

## 5.2 模擬向量長度

### 相依算術 microkernel

兩個 microkernel 都使用 SEW 32、LMUL 1，處理 4096 個元素。每個元素群組先載入輸入向量，再對 v8 執行 256 條前後相依的算術指令，最後保存結果。外層迴圈重複走訪陣列 R 次：整數加法 R=131072，FP32 減法 R=16384。每次重複都重新讀取原始輸入，不會接續前一次的算術鏈。以下控制結構省略計數紀錄與輸出格式化。

```text
for r = 0 .. R-1:
    src = input; dst = output; remaining = 4096
    while remaining > 0:
        execute RVV body below; obtain vl
        src += vl; dst += vl; remaining -= vl
```

下列 RVV 主體呈現 FP32 減法；以符號名稱代替 inline assembly 的運算元綁定。`.rept 256` 表示原始碼巨集展開成 256 條指令，不是執行時迴圈。常數陣列各元素為 -0.25f。整數加法改用 `vmv.v.x v9, increment` 設定常數，並在相依鏈中使用 `vadd.vv v8, v8, v9`，increment 是固定的 32-bit 加數。

```asm
# FP32 subtract: one element group
vsetvli vl, remaining, e32, m1, ta, ma
vle32.v v9, (constants)
vle32.v v8, (src)
.rept 256
    vfsub.vv v8, v8, v9
.endr
vse32.v v8, (dst)
```

每條算術指令都讀取前一條寫入的 v8，不同元素群組之間則互不相依。VLEN 512 的完整群組包含 16 個元素；VLEN 1024 則包含 32 個，轉成兩個 512-bit 分量。因此走訪一次陣列分別需要 256 或 128 個群組，但都執行 4096 × 256 次元素運算。所有重複結束後才驗證一次，且驗證包含在全新行程的計時內。每種 VLEN 使用同一個 binary 與相同重複次數。

| Microkernel | B，VLEN 512 | B，VLEN 1024 | 寬度加速倍數 | M1，VLEN 512 | M1，VLEN 1024 | 寬度加速倍數 |
|---|---:|---:|---:|---:|---:|---:|
| 整數加法 | 23.864 | 12.568 | 1.90 | 3.048 | 1.924 | 1.58 |
| FP32 減法 | 16.240 | 8.880 | 1.83 | 3.240 | 1.773 | 1.83 |

當 VLEN 從 512 增加至 1024 時，baseline 大幅改善。register promotion 則進一步降低兩種寬度下的絕對執行時間。整數加法說明了為何這些比較必須分開看待：經 promotion 後，其寬度加速倍數較小，但兩種 promotion 組態都遠快於 baseline。因此，單憑較大的寬度比值並不足以衡量轉譯品質。

增加 VLEN 同時改變算術指令的組織與周圍的迴圈工作：元素群組變少，分支與向量長度更新次數也隨之減少。此處的執行時間比值衡量這些變化的合計效果。

### 數值與應用案例

| Workload | B，VLEN 512（秒） | B，VLEN 1024（秒） | 寬度加速倍數 |
|---|---:|---:|---:|
| Livermore K1 | 20.851 | 11.239 | 1.86 |
| Livermore K3 | 4.500 | 2.553 | 1.76 |
| LINPACK | 0.289 | 0.265 | 1.09 |
| TSVC s3251 | 0.110 | 0.108 | 1.02 |
| TSVC vbor | 0.061 | 0.057 | 1.07 |
| PolyBench ATAX | 0.096 | 0.084 | 1.14 |
| PolyBench Doitgen | 0.089 | 0.078 | 1.14 |
| Blackscholes | 2.529 | 2.088 | 1.21 |
| LavaMD | 0.483 | 0.328 | 1.48 |
| Streamcluster | 5.315 | 3.683 | 1.44 |
| JPEG encode | 0.617 | 0.652 | 0.95 |
| JPEG decode | 0.302 | 0.342 | 0.88 |
| H.264 CABA3 | 0.443 | 0.499 | 0.89 |
| H.264 crew | 1.695 | 1.987 | 0.85 |

效益延伸到合成鏈之外，但隨計算性質而異。K1 具有一個在各元素群組間複製的算術相依圖。K3 包含 reduction，因此其分解與合併工作有所不同。應用案例則包含額外的記憶體與控制工作。這些觀察顯示這些程式中存在有用的寬度擴展，但並未對每個案例賦予相同的算術解釋或預期倍數。

圖 5.1 與圖 5.2 列出每個 workload／輸入案例的 B 曲線。每個子圖只改變模擬 VLEN，固定 binary、輸入及轉譯方法。橫軸按二的冪次排列；縱軸為線性時間，越低越好。後續方法比較對同一 workload 沿用相同縱軸範圍。

![Baseline 寬度變化: 1](../../figures/evaluation_width_baseline_1.pdf)

圖 5.1：六種 VLEN 的 baseline 執行時間，依 workload 清單列出第 1–8 個案例。每個子圖是一個 workload／輸入案例，每點是 26 輪平均。越低越好；各子圖使用獨立時間尺度。

![Baseline 寬度變化: 2](../../figures/evaluation_width_baseline_2.pdf)

圖 5.2：六種 VLEN 的 baseline 執行時間，依 workload 清單列出第 9–16 個案例。每個子圖是一個 workload／輸入案例，每點是 26 輪平均。越低越好；各子圖使用獨立時間尺度。

K1 隨 VLEN 增加持續受益，多媒體程式的 baseline 卻隨容量增加而更耗時。這兩種趨勢促使我們分別評估狀態重用及 runtime 邊界：更多暫存器容量能呈現更多獨立工作，也可能增加分量轉譯與執行的成本。

## 5.3 方法 ablation

### 個別方法

圖 5.3 每次只在 B 上加入一種方法。上排以狀態存取分析的兩個應用比較 M1 與 B；下排以略過工作量診斷的兩個 H.264 輸入比較 M2 與 B。在相同 VLEN 比較曲線的差距，衡量的是方法的淨效果，而非模擬寬度改變的效果。

![個別方法的寬度比較](../../figures/evaluation_method_width.pdf)

圖 5.3：六種 VLEN 下的個別方法比較：Blackscholes 與 LavaMD 比較 B 與 M1，H.264 crew 與 CABA3 比較 B 與 M2。各子圖沿用對應 baseline 圖的尺度，越低越好。

### 完整 ablation

下表依第 5.1 節的來源分類順序，列出全部 16 個 workload／輸入案例在 VLEN 1024 下的執行時間，每格為 26 次完整行程量測的平均值。圖 5.6 呈現對應的相對 B 時間減少比例；附錄 A 保留全部六種寬度。

| Workload | B（秒） | M1（秒） | M2（秒） | Both（秒） |
|---|---:|---:|---:|---:|
| Integer add | 12.568 | 1.924 | 12.667 | 1.928 |
| FP32 subtract | 8.880 | 1.773 | 8.873 | 1.821 |
| Livermore K1 | 11.239 | 3.005 | 11.308 | 3.002 |
| Livermore K3 | 2.553 | 2.549 | 2.528 | 2.528 |
| LINPACK | 0.265 | 0.265 | 0.266 | 0.266 |
| TSVC s3251 | 0.108 | 0.105 | 0.105 | 0.104 |
| TSVC vbor | 0.057 | 0.050 | 0.057 | 0.050 |
| PolyBench ATAX | 0.084 | 0.084 | 0.084 | 0.084 |
| PolyBench Doitgen | 0.078 | 0.079 | 0.078 | 0.078 |
| Blackscholes | 2.088 | 1.786 | 2.082 | 1.774 |
| LavaMD | 0.328 | 0.198 | 0.330 | 0.197 |
| Streamcluster | 3.683 | 3.683 | 3.727 | 3.725 |
| JPEG encode | 0.652 | 0.655 | 0.629 | 0.626 |
| JPEG decode | 0.342 | 0.328 | 0.322 | 0.302 |
| H.264 CABA3 | 0.499 | 0.498 | 0.440 | 0.441 |
| H.264 crew | 1.987 | 1.980 | 1.692 | 1.701 |

圖 5.4 與圖 5.5 列出每個案例的四種組態。沿同一條線比較，是固定方法後改變 VLEN；在同一個 VLEN 比較不同線，則是切換方法組態。完整 ablation 保留改善很小或退步的案例。

![完整四方法寬度比較: 1](../../figures/evaluation_width_all_1.pdf)

圖 5.4：六種 VLEN 下的 B、M1、M2 與 Both，清單第 1–8 個案例。子圖排列及各 workload 座標範圍與圖 5.1 相同，每點為 26 輪平均，越低越好。

![完整四方法寬度比較: 2](../../figures/evaluation_width_all_2.pdf)

圖 5.5：六種 VLEN 下的 B、M1、M2 與 Both，清單第 9–16 個案例。子圖排列及各 workload 座標範圍與圖 5.2 相同，每點為 26 輪平均，越低越好。

![VLEN 1024 的完整方法消融](../../figures/evaluation_ablation.pdf)

圖 5.6：VLEN 1024 下全部 16 個 workload／輸入案例的時間減少比例。每個柱的數值為 100(1 - T(X,1024)/T(B,1024))，使用 26 輪的算術平均時間。正值表示比 B 省時，負值表示比 B 耗時；B 對應零基準線。顏色與填充線型區分 M1、M2 與 Both。

M1 使 Blackscholes 與 LavaMD 的時間分別縮減 14.5% 與 39.7%。在這些設定下，單獨的 M2 對其平均經過時間的淨影響很小。H.264 則呈現相反的模式：M2 使 crew 與 CABA3 的時間分別縮減 14.8% 與 11.9%，而 M1 帶來的變化很小。JPEG 解碼從整合組態獲得的效益多於任一單獨組態。

Both 並非一律快於每個單獨方法。以 crew 而言，其平均值高出 M2 約 0.6%。整合實作會同時改變值的保留方式以及分量／控制流程的組織；其效果並非各自獨立節省之百分比的加總。較小的平均差異即如實報告，而不視為穩定的排序。

### Blackscholes：重用算術中間值

Blackscholes 透過浮點運算及基本函數的近似計算選擇權價格。週期取樣顯示，向量化的選擇權定價函數占有顯著的執行活動。以下連續指令出現在起始位址為 0x105a0 的熱點區塊：

```asm
vfmul.vf v31, v7, fa4
vfadd.vv v20, v20, v31
vfmul.vv v31, v22, v24
vfmul.vv v25, v23, v25
vfmul.vv v23, v23, v23
```

第一條乘法產生加法所需的值，下一條乘法隨後重新定義 v31。在 VLEN 1024、FP32 元素及 LMUL 1 下，每條指令處理兩個 512 位元分量。Baseline 將第一個乘積的兩個分量寫回向量暫存器狀態，再於加法時載回。擷取的 x86 程式碼中，這些 store 存取 CPU-state 指標起算的 0x3ed0 與 0x3f10 位移；加法隨後從相同位置重新載入。

M1 改將乘積保留在 zmm15 與 zmm16。兩個加法直接使用這些暫存器，對應指令為 `vaddps zmm17{k1},zmm4,zmm15` 與 `vaddps zmm18{k2},zmm5,zmm16`。由於後續乘法會覆寫 v31，前一個乘積在最後一次使用後不必再寫回；run 邊界仍會寫回必須保留的最終定義。省去的是中間狀態搬移，而不是乘法或加法本身。

在 VLEN 1024 下，M1 將完整行程時間從 2.088 秒降至 1.786 秒，減少 14.5%。退役指令減少 6.9%，計數週期減少 14.7%。反組譯指出一個具體的工作縮減來源；行程層級計數仍包含其他算術、控制流程及轉譯。此案例的 M2 執行時間變化不大，M1 則直接作用於算術序列內的資料重用。

### LavaMD：保留累加過程的中間值

LavaMD 計算粒子交互作用。其向量 kernel 結合粒子座標、計算交互作用因子，並累加貢獻。起始位址為 0x10bac 的熱點區塊包含以下序列：

```asm
vfadd.vf  v15, v15, fa2
vfmul.vf  v19, v16, fa1
vfmacc.vf v19, fa0, v17
vfmacc.vf v19, ft4, v18
vfsub.vv  v15, v15, v19
vfmul.vf  v15, v15, fa3
```

此處 v19 是累加值：乘法定義它，兩條融合乘加更新它，減法再使用它。v15 的值也依序經過加法、減法與乘法。Baseline 在這些 RISC-V 指令的邊界，對各個分量反覆寫回及載入狀態。M1 在符合條件的 run 內以主機暫存器傳遞中間值。擷取的 x86 序列保留 packed 加法、乘法及 `vfmadd231ps`，但以暫存器串接運算元，不再逐一寫回中間值。

相較於單一產生者與使用者，這種較長的重用鏈提供更多可省去的狀態存取。它不會使累加更新彼此獨立；算術相依仍然存在。在 VLEN 1024 下，M1 使時間由 0.328 秒降至 0.198 秒，減少 39.7%。退役指令減少 27.5%，計數週期減少 43.7%。這些觀察支持的方法效果是降低相依算術鏈上的狀態搬移成本，而非增加獨立算術運算的數量。

### H.264 crew：限制 Widening 運算的執行範圍

crew 輸入呈現另一種改善機會。週期取樣指出亮度去區塊濾波函數 `ff_h264_loop_filter_luma_8_rvv` 是熱點。去區塊濾波處理重建影像區塊邊界附近的像素。呼叫端設定較短的元素範圍，函數以 widening 算術計算像素差與總和。以下片段分別列出呼叫端的設定及被呼叫函數的算術：

```asm
# Caller configuration before the filter call
vsetivli zero, 16, e8, m1, ta, ma

# Arithmetic in ff_h264_loop_filter_luma_8_rvv
vaaddu.vv v14, v10, v11
vwsubu.vv v16, v9,  v12
vwaddu.vv v18, v8,  v14
vwaddu.vv v20, v13, v14
vnsra.wi  v24, v16, 2
vnsrl.wi  v14, v18, 1
vnsrl.wi  v15, v20, 1
```

即使 VLEN 為 1024，設定的 vl 仍為 16。由 8 位元來源拓寬後，目的暫存器群組使用 16 位元元素，有效 LMUL 為 2。其容量為 2048 位元，拆成四個 512 位元目的分量，每個分量容納 32 個元素。只有第一個分量可能包含索引小於 vl 的元素；其餘分量起始索引為 32、64 及 96。

未啟用 M2 時，高位分量仍有產生的算術本體，儘管其結果不會貢獻到要求的元素範圍。啟用 M2 後，與 vl 的比較會跳過這些分量。擷取的 x86 程式碼包含低位分量的 `vpsubw`，隨後透過邊界檢查略過高位分量的減法本體。第一個分量中的部分更新仍由逐元素遮罩處理。因此，M2 省去的是多餘的分量執行，而不是拓寬實際需要的像素計算。

在 crew 上，M2 使時間由 1.987 秒降至 1.692 秒，減少 14.8%；退役指令及計數週期分別減少 10.9% 與 15.2%。單獨啟用 M1 的改善很小。這個案例說明，依容量拆分後，仍須以運算的 runtime 元素範圍限制實際工作。

### H.264 CABA3：另一個輸入上的相同機制

CABA3 使用相同的解碼器二進位檔，也執行上述亮度去區塊濾波函數。取樣亦指出色度去區塊濾波函數，其拓寬差值與窄化操作具有相同的短範圍改善機會。這是同一實作的另一個輸入，不是不同的濾波演算法。

在 VLEN 1024 下，M2 將 CABA3 時間由 0.499 秒降至 0.440 秒，減少 11.9%。退役指令減少 8.8%，計數週期減少 13.1%。改善方向與 crew 相同，但幅度不同。兩個輸入均執行受元素範圍限制的 widening 算術，完整行程時間則包含不同比例的其他解碼工作。這些量測並未把所有省下的週期都歸因於單一濾波函數。

這四個案例的程式碼擷取使用與計時實驗相同的轉譯器執行檔及工作負載二進位檔。各案例的 baseline 與對應方法共八次診斷執行，輸出皆符合參考結果。週期取樣用於選擇分析的程式區塊；所報告的時間及指令與週期縮減仍取自 26 回合實驗，而非診斷執行。

## 5.4 外部系統

外部比較回答兩個問題：相同模擬 VLEN 下的執行效率，以及系統能使用較長 RVV 向量時的額外收益。同 VLEN 的結果來自獨立的四回合實驗，各項比較在指定的模擬 VLEN 下固定 RISC-V 二進位檔與輸入。計時包含受測行程內的轉譯或編譯；編譯器子行程共用相同的單核心配置，libriscv 不跨次執行重用已編譯的產物。這些平均值與 26 回合消融、以及下方的支援寬度實驗分開計算。

### 相同 VLEN 的系統比較

| Workload | rvdbt B (s) | rvdbt Both (s) | QEMU (s) | rv32emu (s) |
|---|---:|---:|---:|---:|
| Integer add | 12.569 | 1.921 | 4.117 | 240.626 |
| FP32 subtract | 8.873 | 1.770 | 103.433 | 82.211 |
| Livermore K1 | 11.244 | 3.012 | 39.041 | Error |
| Livermore K3 | 2.550 | 2.525 | 9.340 | Error |
| LINPACK | 0.265 | 0.265 | 1.487 | Error |
| TSVC s3251 | 0.109 | 0.103 | 0.347 | Error |
| TSVC vbor | 0.057 | 0.052 | 0.098 | Error |
| PolyBench ATAX | 0.086 | 0.084 | 0.273 | Error |
| PolyBench Doitgen | 0.079 | 0.078 | 0.195 | Error |
| Blackscholes | 2.094 | 1.777 | 6.167 | Error |
| LavaMD | 0.327 | 0.201 | 2.162 | Error |
| Streamcluster | 3.687 | 3.731 | 17.258 | Timeout |
| JPEG encode | 0.658 | 0.632 | 1.189 | Error |
| JPEG decode | 0.342 | 0.310 | 0.936 | Error |
| H.264 CABA3 | 0.497 | 0.453 | 1.175 | Error |
| H.264 crew | 1.985 | 1.701 | 5.806 | Error |

rv32emu 啟用第一層 JIT。Error 表示執行錯誤或未產生通過驗證的輸出；Timeout 表示在 120 秒預檢內未完成。兩者皆不是執行時間量測值。

在 VLEN 1024 下，rvdbt Both 在所列 16 個案例的平均時間均低於 QEMU。應用程式的加速包含 Blackscholes 的 3.47 倍、H.264 crew 的 3.41 倍，以及 JPEG 編碼的 1.88 倍。逐指令 baseline 在這些應用上已比 QEMU 快；第 5.3 節的固定 VLEN 消融則辨識兩項方法額外帶來的改善。

整數加法說明了執行路徑的重要性。QEMU 比 rvdbt B 快，但比 Both 慢。擷取的 VLEN 1024 QEMU 轉譯中，第一條 RVV 加法展開為四條 YMM 加法，並載入及存回狀態。下一條 RVV 加法直接沿用 YMM 值、不再重載，卻仍存回四份結果。因此，觀察到的差異不是 QEMU 缺少值轉送：rvdbt 准入的 promotion 序列還能延後中間結果的存回，且主要路徑使用更寬的 host 運算。相較之下，受測 QEMU 浮點減法轉譯呼叫 RVV helper，而非直接產生 packed 減法 [QEMU-RVV]。這些是不同的系統成本來源。

rv32emu 的兩個時間數值皆為四次執行平均。RVV 區塊使用直譯器，純量區塊則可使用第一層 JIT。

rv32emu 比較啟用 RVV 與第一層 JIT，停用 LLVM 第二層。受測版本缺少第二層向量 handler，包括 `t2c_vsetvli`；同時啟用 EXT_V、JIT 與 T2C 會導致建置失敗。因此，量測採用可用的第一層 JIT 啟用組態。

應用程式相容性同時取決於 ISA 與執行環境。Blackscholes 與 H.264 遇到未支援的系統呼叫或區塊轉譯錯誤。修正程式參數傳遞後，LavaMD 仍遇到這類錯誤；JPEG 編碼及解碼則觸發模擬器 assertion。Livermore K3 要求 SEW 64，rv32emu 的受測 build 將其判定為不支援，設置 vill 並將 vl 歸零。除錯器記錄到反覆的非法指令 trap 與未改變的剩餘元素數，解釋了先前的逾時。Streamcluster 也超過 120 秒預檢上限，其 log 出現未支援的 mmap 與 writev 呼叫。兩者都不是正常完成但較慢的執行。QEMU 的直接向量路徑也使用不同於 rvdbt 主路徑的最大 host 寬度；這些是完整系統比較，而非控制 host 寬度的 ablation。

libriscv 以受測的 256 位元 RVV 組態評估。表格包含本文工作負載集中，在三種執行模式下皆通過輸出驗證的 11 個案例，時間單位為秒。其餘五個案例遇到尚未實作的整數向量形式：Blackscholes 的 `vsub.vx`，以及 JPEG 與兩個 H.264 輸入的 `vmax.vx`。除錯器追蹤確認了受測執行檔中首先失敗的指令，因此這些案例沒有有效的執行時間結果。

| Workload | rvdbt Both (s) | QEMU (s) | libriscv interpreter (s) | TinyCC (s) | System C (s) |
|---|---:|---:|---:|---:|---:|
| Integer add | 5.892 | 10.732 | 170.349 | 162.734 | 153.083 |
| FP32 subtract | 5.498 | 107.550 | 10.730 | 20.271 | 2.032 |
| Livermore K1 | 10.010 | 78.283 | 26.631 | 12.127 | 3.064 |
| Livermore K3 | 8.587 | 18.135 | 6.653 | 4.310 | 2.020 |
| LINPACK | 0.361 | 1.586 | 1.166 | 0.584 | 1.517 |
| TSVC s3251 | 0.113 | 0.385 | 0.334 | 0.158 | 9.512 |
| TSVC vbor | 0.054 | 0.107 | 0.071 | 0.082 | 9.875 |
| PolyBench ATAX | 0.129 | 0.318 | 0.238 | 0.168 | 1.049 |
| PolyBench Doitgen | 0.115 | 0.227 | 0.164 | 0.118 | 1.011 |
| LavaMD | 0.386 | 2.376 | 1.181 | 1.017 | 4.086 |
| Streamcluster | 8.834 | 23.287 | 10.273 | 6.748 | 47.837 |

即使計入編譯時間，系統 C 編譯器在數個浮點案例中仍最快。FP32 減法的編譯區間約為 1.234 秒，包含在 2.032 秒的行程時間內。擷取的 host 程式碼包含 256 條相依的 YMM `vsubps`，鏈內沒有載入、存回、呼叫或分支，結果在鏈末才存回。編譯器保留了算術工作，同時移除中間的向量狀態搬移。相較之下，擷取的整數加法路徑每次加法都呼叫 RVV handler。在這次實驗中，直接呈現浮點運算讓原生最佳化回收了編譯成本，整數的 handler 路徑則仍有高額執行成本 [libriscv]。

### 支援的向量長度

另一組四回合實驗固定各案例的二進位檔與輸入，將 rvdbt Both 的 VLEN 從 128 掃描至 4096；libriscv 的兩種 C 編譯模式維持受測的 VLEN 256 設定。由於向量長度改變可能影響浮點歸約順序，輸出依各寬度的參考結果驗證。表格列出本文工作負載集中相容的 11 個案例。Asmjit 欄來自第 2.4 節所引版本的另一組四次量測，不與任一 C 編譯模式合併計算。所有時間均包含轉譯與執行，單位為秒。

| Workload | System C 256 | TinyCC 256 | Asmjit 256 | Both 256 | Both 1024 | Both 4096 |
|---|---:|---:|---:|---:|---:|---:|
| Integer add | 153.365 | 162.503 | 168.866 | 5.898 | 1.927 | 0.829 |
| FP32 subtract | 2.034 | 19.801 | 12.425 | 5.478 | 1.776 | 0.989 |
| Livermore K1 | 3.062 | 12.124 | 18.560 | 10.019 | 3.005 | 1.688 |
| Livermore K3 | 2.018 | 4.304 | 4.692 | 8.571 | 2.524 | 1.203 |
| LINPACK | 1.514 | 0.582 | 1.216 | 0.361 | 0.265 | 0.225 |
| TSVC s3251 | 9.546 | 0.157 | 0.362 | 0.112 | 0.102 | 0.091 |
| TSVC vbor | 9.863 | 0.081 | 0.100 | 0.052 | 0.050 | 0.055 |
| PolyBench ATAX | 1.049 | 0.166 | 0.248 | 0.127 | 0.084 | 0.073 |
| PolyBench Doitgen | 1.008 | 0.118 | 0.167 | 0.116 | 0.078 | 0.076 |
| LavaMD | 4.118 | 0.988 | 0.951 | 0.382 | 0.197 | 0.201 |
| Streamcluster | 47.794 | 6.731 | 7.865 | 8.826 | 3.732 | 3.191 |

在 VLEN 256 下，系統 C 編譯器在 FP32 減法、K1、K3 比 rvdbt 快，TinyCC 則在 Streamcluster 較快。圖 5.7 顯示 rvdbt 使用較長向量後，這四項比較如何改變。FP32 減法在 VLEN 1024 時快於對應的 libriscv 參考，Streamcluster 則在 512 較快。K1 在 1024 接近相同時間，K3 在 2048 較快。到 4096，FP32 減法、K1、K3、Streamcluster 相對於較快的已測 C 編譯模式，分別加速 2.06、1.81、1.68、2.11 倍。不同寬度之間無須重新編譯 RISC-V 二進位檔。

![長向量執行與固定寬度 libriscv 設定的比較](../../figures/evaluation_external_capacity.pdf)

圖 5.7：在 VLEN 256 下，libriscv 的 C 編譯模式比 rvdbt 快的四個案例之完整行程時間。綠線表示 Both 下不同 rvdbt VLEN；各水平參考線表示固定 VLEN 256 下較快的已測 libriscv C 編譯模式。每個點或參考值均為支援寬度實驗的四次平均；參考線不是 libriscv 的寬度掃描。越低越好。

這個反轉顯示，除了改善單個 host 向量運算，支援較長 RVV 執行也能帶來實際收益。此處比較各系統可用的向量長度設定，前面的表格則固定相同 VLEN。4096 設定在所列 11 個案例的均值都低於三種已測編譯模式，但 4096 並非 rvdbt 一律最佳的寬度：LavaMD 與 TSVC vbor 在 1024 更快。較長向量同時改變迴圈處理元素的分組與 host 分量數，取捨因計算而異。第 5.3 節另以固定 VLEN，衡量狀態重用與 runtime 邊界對此取捨的影響。

### 比較範圍

外部計時涵蓋能執行相同 RV32 二進位檔、且輸出通過驗證的系統。HQEMU 提供相關 SIMD 轉換技術，但其公開版本沒有 RISC-V 前端。PasRISCV 與 Berberis 面向 RV64 環境，因此第 2.4 節介紹其原始碼所具備的能力，不為不相容的二進位檔填入執行時間。這些比較建立受測設定下的效能結果；實作分析則說明指令涵蓋，以及 inline SIMD 與 handler 路徑的選擇，為何與結果有關。

### 功能模擬器的參考結果

Whisper 與 Spike 也能在 x86-64 執行長 RVV。其功能模擬路徑提供有別於前述 JIT 比較的參照。下列每組比較使用相同的封存 RV32 ELF、輸入、VLEN 與實體核心，量測四次完整行程。Spike 另執行 proxy kernel，包含其啟動與系統呼叫處理。各 rvdbt 均值來自對應的配對實驗，不合併不同批次的均值。

| Reference system | Workload | VLEN | rvdbt Both (s) | Reference (s) |
|---|---|---:|---:|---:|
| Whisper | ATAX | 1024 | 0.086637 | 2.221454 |
| Whisper | ATAX | 4096 | 0.075418 | 1.975290 |
| Whisper | LINPACK | 1024 | 0.268332 | 12.872439 |
| Whisper | LINPACK | 4096 | 0.227861 | 12.638133 |
| Whisper | s3251 | 1024 | 0.106536 | 2.664934 |
| Whisper | s3251 | 4096 | 0.095214 | 2.504711 |
| Spike + proxy kernel | ATAX | 1024 | 0.087979 | 1.052708 |
| Spike + proxy kernel | ATAX | 4096 | 0.076149 | 0.996282 |
| Spike + proxy kernel | LINPACK | 1024 | 0.268234 | 4.836920 |
| Spike + proxy kernel | LINPACK | 4096 | 0.226214 | 4.967119 |
| Spike + proxy kernel | s3251 | 1024 | 0.106129 | 0.961899 |
| Spike + proxy kernel | s3251 | 4096 | 0.093161 | 0.897359 |

時間差涵蓋直譯、架構狀態處理與執行環境服務。這些結果確認其他系統也能執行長向量，同時區分向量容量與原生 SIMD 路徑的執行效率。Renode 也通過 4096-bit 的 bare-metal 向量加法診斷，但尚未建立與應用程式相符的虛擬平台環境。Pydrofoil 通過三種 512-bit 向量加法診斷；這些是執行及 trace 檢查，不是應用程式計時，因此兩者均不列效能倍率 [Spike, Whisper, Renode, Pydrofoil]。

## 5.5 發現與範疇

結果支持三項彼此關聯的發現。第一，較長的模擬向量可以重組獨立的元素群組計算，並充分減少迴圈工作，從而在固定寬度的 host 上改善執行效能。第二，效益可能受反覆將向量狀態寫回架構狀態的成本所主導；在相容序列提供重用機會之處，register promotion 能大幅降低此成本。第三，當 runtime 元素範圍維持短小時，較大的容量反而可能有害；以邊界為基礎的省略能限制此增長。

Microkernel 呈現長算術鏈中的重複狀態搬移；應用程式量測則檢驗，減少狀態存取與無效分量工作後，是否能縮短同時包含轉譯、記憶體存取與控制流程的完整行程時間。

量化結果適用於受測的 AMD host。其他處理器在向量指令延遲、吞吐量、執行寬度與頻率行為上可能有所不同。同樣地，經最佳化的指令子集與工作負載二進位檔決定了哪些路徑會被執行。將量測延伸至其他微架構與最佳化層級，可檢驗所觀察到的重用、有用工作與編譯成本之間的平衡是否具可移植性。

## 5.6 限制與延伸方向

**最佳化範圍。** Promotion 在 translation block 內符合條件的指令序列上運作。組態變更、不相容的狀態效應、跨分量相依及暫存器需求都會限制序列。因此，reduction 或 permutation 不能只因運算元是向量，就套用逐元素運算的重排規則。擴充 promotion 必須為新增形式明確定義相依與狀態更新規則。Helper 仍是一種語意實作方式；改成直接 SIMD 時，必須保留其捨入、例外、遮罩及記憶體存取行為。

**Runtime bounds。** 範圍檢查只移除確定超過 `vl` 的尾端，仍保留部分分量的 lane 選擇、最終 stores 與完成時的狀態更新。當所有分量都需要執行時，檢查可能增加工作而沒有減少算術。符合條件的全長 guard 可以省略檢查；擴充此最佳化需要 runtime 組態的依據，不能依 workload 作假設。圖 5.4 與圖 5.5 呈現包含上述成本的淨效果，也保留整合方法未優於單一方法的案例。

**最佳化編譯。** 本文結果使用輕量 JIT，而非 online LLVM tier。後續擴充應將向量運算及狀態效應傳入 LLVM，建立進出 compiled region 的共用狀態介面，並在組態假設成立時才安裝程式碼。HQEMU 的 hot-region 編譯、Instrew 的狀態介面與 Arancini 的共用表示提供相關設計 [HQEMU, Instrew, Arancini]。評估必須將編譯與安裝納入完整行程時間，並量測程式結束之前是否實際進入最佳化 region。

**硬體與量測。** 主要矩陣使用一款 AMD 處理器。暫存器容量、執行吞吐量、排程視窗與頻率行為，可能使 Intel 或其他 AMD 實作呈現不同取捨。Retired instructions 量化實際執行工作量的變化；總 cycles 與 elapsed time 量測其合計成本，但不指出哪一對向量指令同時發出。跨微架構研究應固定可比較的 binary、輸入及計時邊界，再檢查產生的指令與指令層級的硬體行為。

**涵蓋範圍。** 測試結果對應實際執行的指令形式、組態與 workload，不等同完整 RVV conformance。本文的 16 個案例包含抽取 kernel，以及同一 decoder 的多個輸入。外部系統也有指令支援及作業系統服務上的差異，因此比較區分完成的應用計時、診斷程式、執行失敗與逾時。

## 5.7 功能驗證

### 外部測試與結果檢查

本清單分別計算 mnemonic 與 operand 變體：`vadd.vv`、`vadd.vx` 與 `vadd.vi` 是三個形式，記憶體寬度及分段數也分開列舉。共 627 個形式，其中 32 個索引記憶體形式需要 64-bit 索引，超出 RV32/ELEN64 配置，留下 595 個適用形式 [RVV]。附錄 B 列出此範圍；實作 repository 提供對應的逐套件形式表與可執行的外部測例 [rvdbt-impl]。受檢形式必須將保留的目標操作對應至 checker 實際判定的輸出；來源存在、編譯及程式完成另行記錄。

驗證鏈保留外部輸入，以原始 assertion 或獨立 reference 建立預期結果，再將受測系統（device under test，DUT）rvdbt 與該結果比較。CHIPS 使用修改版 Spike 的 reference 結果產生自我檢查程式 [CHIPS-tests]。架構測試保留預期值與 signature 比較；Ara 保留具型別的向量、純量、記憶體及 CSR 判定 [ACT-tests, Ara-tests]。RVV-ATG [RVV-ATG] 將 target macro 接合至 Spike signature，再比較同一 ELF 的 QEMU 與 DUT 輸出。SiFive RIF [SiFive-RIF] 將實際產生的 operation symbol 接合至未變更的操作結果 golden。Reference 失敗及原始 DUT 失敗與接受的比較結果分開保留。

環境適配修改啟動、回報或 ABI 介面，保留外部計算與 assertion。生成幾何或配置預期值的修改另行標示：CHIPS 分開 XLEN 32 與 ELEN 64，並揭露本地配置常數；依規格增加的狀態 observer 及透過外部 API 生成的測試屬於衍生案例。衍生結果不回溯證明不安全或受阻的原測試。精確輸入、適配、checker 範圍及 reference 身份連結於附錄 B。

| 外部來源 | 目標／結果受檢形式 | 受檢輸出 |
|---|---:|---|
| CHIPS Alliance Vector Tests | 595 | 選定目的字組、store 前綴及明列的 CSR 檢查 |
| RISC-V Architectural Tests | 590 | 選定目的區域、純量結果及 flags |
| RVV-ATG | 434 | 接合目標的 signature；e64 擷取觀察 low32 |
| Ara vector tests | 422 | 原始具型別向量、純量、記憶體及 CSR 判定 |
| SiFive RIF | 200 | 實際產生的操作結果接合原始 golden |
| 聯集 | 595 | 集合重疊，不加總各列 |

不同來源補足的是具體形式的缺口。ACT 的受檢集合缺少 `vfmv.f.s`、`vfwcvt.f.f.v`、`vsetivli`、`vsetvl` 與 `vsetvli`；Ara 對這五個形式都有結果檢查。三種配置指令保留 Ara 的原始比較及同一 ELF 的 Spike 狀態觀察，不只依賴本地指定的配置常數。因此，多來源測試補足了可明確列出的形式覆蓋缺口，各 checker 的狀態與配置限制仍分別保留。

Checker 在哪裡執行也會影響驗證的獨立性。ACT 的預期 signature 來自 Sail，但其 guest 端的資料向量長度檢查使用 `vmsne.vv` 產生不符元素的 mask，再用 `vfirst.m` 找出不符的元素。這些指令由 DUT 執行，因此即使預期 signature 獨立產生，比較過程仍依賴 DUT 的比較指令實作 [ACT-tests]。

按候選版本區分的索引也建立乾淨正確性 build 的 595 個受檢形式聯集；歷史候選身份另行保留。此表計算在已記錄配置下，運算結果受到檢查的形式，包含直接與 helper 路徑。序列測試採用不同的驗證單位：RVVTS 與 RVISmith 比較已記錄的指令序列或程式輸出，分別涉及 58 與 43 個形式 [RVVTS, RVISmith]。這些數量表示參與序列的運算，不代表各條指令都受到獨立檢查，因此不計入表中的受檢形式聯集。

保留的外部 CHIPS 批次在乾淨正確性 build 上有 11,532 次通過檢查的程式執行，分布如下。在各寬度下，四種配置執行相同的登錄案例，B、M1、M2、Both 分別計數。另有 212 次失敗控制執行，均產生指定的失敗退出碼與訊息；這些控制檢查失敗是否能正確回報，不計入指令形式覆蓋。

| VLEN（bits） | 每種配置 | 四種配置合計 |
|---:|---:|---:|
| 128 | 2,364 | 9,456 |
| 256 | 27 | 108 |
| 512 | 27 | 108 |
| 1024 | 401 | 1,604 |
| 2048 | 27 | 108 |
| 4096 | 37 | 148 |
| 合計 | 2,883 | 11,532 |

這份分布不是在每種寬度下都測試全部 595 個形式。逐形式紀錄列出實際執行程式及其原始 assertion，來源位置則提供 SEW、LMUL、請求的 VL 與 mask 條件。請求的 VL、原始碼中的操作，與實際觀察到的 runtime 狀態及最佳化路徑分開記錄。歷史 build 的執行另行保存，不加進此表。

兩批 ACT 來源各自保留 Sail signature 與原始 self-checker；索引記憶體來源修訂不增加形式聯集 [ACT-db2]。兩個特權狀態 reference blocker 仍予以排除。Ara 抽取保留支援區段的常數、assertion 與初始化，包括除法及平方根所需的 round-toward-zero；接受結果屬於區段，不是完整混合精度檔案。不同寬度來源重疊的保留編碼，以及短於向量 load 範圍的來源物件，仍保留原裁決 [RVV]。

適配的 RIF 歸約保留原始輸入、歸約圖與純量判定，並以相同 ELF 比較 QEMU 與四種 DUT 配置。Host 純量求值器讀取未初始化儲存區，零 seed 也會吸收部分 AND／無號最小值結果。因此一致性只提供明列的純量終點證據，不增加獨立形式或最佳化准入的證據 [SiFive-RIF]。

具體例子是 VLEN 1024、LMUL 8 的適配 CHIPS `vadd.vv` 檔案，保留 26 個 target 與 6,656 個原始 checker 字組。目的群組 v8–v15 與來源群組 v16–v23、v24–v31 互不重疊。其中一個 masked SEW-64 target 請求 AVL 63，更新 38 個啟用 lane；原始比較檢查目的群組，包括 tu/mu 下保留的 masked-off 與 tail 值。修改版 Spike 生成、原始 self-check、同 ELF 的 QEMU reference，以及乾淨 DUT 的 B、M1、M2、Both 均通過。這檢查了明列的目的幾何與保存行為，沒有觀察每個 register，也沒有建立 promotion 准入。

### Directed Matrix 與狀態比較

外部原始套件與專案自撰的逐形式 directed matrix 用途互補：前者保留外部作者的 workload 與判定，後者在明確邊界隔離架構效果。每個 directed case 先初始化向量暫存器、純量 operand、適用的記憶體及向量／浮點控制狀態，執行編碼中的目標指令，再擷取 poststate 快照。Host 端 checker 先確認記錄的 prestate 與 packet 身份，套用獨立的規格判定，再將有明確定義的結果與固定版本 Spike 或 Sail 的實際執行結果比較。Reference 與 DUT 使用相同的 target／observer body。程式成功退出仍不足以接受結果；packet 缺失或截斷、timeout、target 對應錯誤及判定失敗均會拒絕接受。

Manifest 逐 mnemonic／operand form 索引實際選取的 SEW、LMUL、VLEN、VL/VLMAX、mask、初始 `vstart`、tail／mask policy、operand EMUL、rounding mode 及 overlap 類別。邊界案例包含零／部分／完整長度，以及來源與目的 host chunk 邊界附近的位置。各 family 的維度不同：邊際值不是 Cartesian product；有觀察到的設定會以擷取狀態核對宣告值。共用 observer 檢查全部 32 個邏輯向量暫存器與十個向量／浮點 CSR；各 family 再觀察相關純量暫存器、記憶體與序列中間值。形式索引明列缺失的觀察。

Oracle 依操作允許的結果判定。整數判定使用精確位元運算；浮點判定使用精確有理數解碼與 rounding，不以 host cast 或 DUT 產生的 golden 判定。有明確定義的 active 結果與 sticky flag 採精確比較。Inactive agnostic 元素採規格允許的舊值或全一集合；prestart 與 undisturbed 元素則保留規定的位元組。Unordered 浮點歸約只接受判定已建立每種允許歸約樹皆可精確表示的有限輸入，另檢查限定的特殊值案例。任意 inexact unordered sum 不在此 oracle 範圍內。非法 overlap、不支援的精度與保留的入口條件，不列入一般成功案例。 非零 start 的 scalar insertion 比較使用明列的 permissive Sail mode；預設模式的 trap 另列為 reference 嘗試。

### 狀態保存與最佳化路徑

已完成的序列矩陣在 Reference/B/M1/M2/Both 各檢查 2,418 個案例，合計 9,672 次 DUT 檢查。它在同一固定正確性 build 上涵蓋宣告的整數／浮點序列、初始 start、邊界長度、alias／overwrite 行為及兩種相同 PC cache 順序。原始 ELF 與已驗證的 reference packet 沿用；此次重跑沒有執行 reference，也沒有重建 ELF。完整接受結果使用關閉 trace 的配置；開啟 trace 的配置只保留已完成的局部接受結果。

最佳化准入透過 target PC、產生的 host code、實際執行的 frame 紀錄與架構快照接合確認。Audit 檢查 M1 保留的 producer-to-consumer 值、low-component consumer，以及 Both 在下一個 component bound 前寫回已完成值、在必要 store 後接合 skip 路徑的順序。相同 PC 以不同首次觀察的 vector type 進入，檢查特化與 guarded fallback。這些觀察驗證宣告序列的實際路徑；開啟 M1/M2 開關或檢查全部索引形式，不等於普遍最佳化准入。

### 驗證發現

Directed 比較發現三個語意缺陷。零與無限大的 fused multiply-add，即使 quiet-NaN addend 已決定 canonical NaN 結果，仍須累積 NV；原 x86 FMA 路徑得到正確值，卻漏掉 NV。RMM FP64-to-FP32 narrowing 在 minimum-normal 邊界得到正確 rounding 位元，卻漏掉 UF：以不受限 exponent 完成精度 rounding 後的 tininess 判定，要求 UF 與 NX 同時成立。`vmv.s.x` 或 `vfmv.s.f` 的 scalar insertion 在初始 `vstart` 非零時必須保留 element 0；原 `vstart < vl` guard 錯誤寫入該 prestart 元素。修正後只在 `vstart == 0` 且 `vl > 0` 時插入，正常完成仍清除 `vstart`。保留的原始失敗、未修改的判定及修正前後 packet 建立這些發現；各 family build 與後續整合的身份在重現紀錄中分開保留。

### 版本與限制

最終正確性批次使用同一個固定的 RV32/ELEN64 Release 執行檔，以 512-bit QCG host components 完成 directed matrix、外部重跑與序列驗證。較早的 family 與外部結果保留歷史身份。前文 384 個均值屬於原封存的效能執行檔。正確性 binding 保留執行檔、library、ELF 與完整 flags；整合原始碼重新建置後產生新的執行檔身份，不沿用既有收據的驗證資格。

完整 register／CSR／memory 狀態、記憶體存取抑制、中間 flags、考慮寫入歷史的 agnostic 選擇、任意 overlap 與 restart，在已接受 witness 之外仍不完整。RIF 使用一個 seed、長度 500 與 VLEN 128；ATG 使用固定 e32/m1 與有限 e64 延伸。RVISmith 保留 wildcard／NaN 正規化，沒有非零輸入 high32 證據。不安全原始 store 輸出等來源與 checker 阻塞保留於附錄 B。

Fault handling 與指令形式覆蓋分開評估。Runtime 可註冊同步 SIGSEGV／SIGBUS action，並投遞在受控 helper 存取位置辨識的 fault。對支援的單一記憶體指令，產生的程式碼也記錄精確的 host 存取位置，發生 fault 後退出至 dispatcher。QCG 在記憶體指令處結束 promotion 區段，使先前指令的架構結果在此邊界已可取得。本地測試檢查第一次 fault 後的 register、memory 與 exception 狀態；scalar-memory 與 memory-boundary 兩套測試分別檢查 44 及 10 份終止狀態快照。既有的 signal 投遞測試在 B、M1、M2、Both 共八次執行中，檢查首元素 fault 與後續元素 fault-only-first 行為。這些 guest handler 結束程式，不返回重試指令。Handler 返回及完整 guest 指令重新執行仍未驗證。

Signal 介面也使用受控複製處理 action、mask 與 frame buffer。本地回歸包含無法存取的頁面及遭截斷的檔案映射，共有 2,063 項介面檢查、256 次浮點狀態保存與還原，以及 192 次無效 frame 拒絕。這些測試直接呼叫 host 介面，並非執行會返回的 guest handler。

最終同版 directed 重跑完成 595 個適用形式的全部 102 個一般 entry：B/M1/M2/Both 每 arm 有 3,017,262 個案例，共 12,069,048 次正向 DUT packet 檢查。Focused witness 另有 2,256 次正向檢查，合計 12,071,304 次正向檢查；592 次 focused 拒絕控制分開計數。每個已接受正向結果均通過原規格／reference 判定及擷取輸出的獨立重讀。此次重跑沿用固定 ELF 與已驗證 reference packet，沒有新的 reference 執行或 ELF 建置。逐形式紀錄將實際結果接合至已接受 case ID、維度、固定來源與 checker binding；保留的來源宣告不納入正向分母。

同一執行檔也完成 21,316 次外部 command：CHIPS 有 11,532 次正向執行與 212 次失敗傳遞對照，ACT 有 7,668 次通過，Ara 有 1,888 次整檔通過及 16 次限定區段接受。B、M1、M2、Both 各有 5,329 次 command。Ara 的限定結果只接受 TEST_CASE1/2，保留原 TEST_CASE3/4 失敗；兩個 ACT reference blocker 仍排除。這些是在最終正確性執行檔上新執行的 DUT 結果，與歷史外部批次分開記錄。前述序列矩陣使用相同執行檔，但其 9,672 次 DUT 檢查維持獨立分母。627 個形式中的 595 個適用形式建立有限受檢矩陣，保留實際例外、trace 與 oracle 限制，不代表所有可能的 RVV 輸入。
