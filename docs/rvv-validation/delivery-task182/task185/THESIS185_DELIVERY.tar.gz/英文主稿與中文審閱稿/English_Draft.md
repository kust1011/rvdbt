# Dynamic Binary Translation and Parallelization Optimizations for Long RISC-V Vectors on x86-64

SHENG-TSUNG KU

## Abstract

RISC-V Vector (RVV) programs can process different numbers of elements per iteration without recompilation. On an x86-64 host, a dynamic binary translator must implement vector operations that exceed the host's single-instruction, multiple-data (SIMD) width using multiple shorter operations. For element-wise arithmetic, the resulting operations compute independent element groups within a translated iteration. However, decomposition also increases the number of intermediate values and the cost of maintaining architectural vector state, and an instruction may use only part of the register's capacity.

This thesis extends the lightweight just-in-time compiler in rvdbt with RVV execution support and develops two optimizations for decomposed vector operations. The first, vector register promotion, retains intermediate values across compatible instruction sequences and uses bounded component batches to control register demand. It reduces repeated loads and stores of architectural vector state. The second, runtime vector bounds, omits components beyond the instruction's runtime element range while preserving the required state updates. Together, these techniques address data movement between instructions and unnecessary work within an instruction.

Experiments execute the same RISC-V binary and input at simulated vector lengths from 128 to 4096 bits on an AMD Ryzen 9 9950X3D host. Increasing the simulated length from 512 to 1024 bits achieves speedups of 1.90 and 1.83 in integer-add and floating-point-subtract microkernels before the two optimizations. At 1024 bits, register promotion reduces elapsed time by 14.5% for Blackscholes and 39.7% for LavaMD; runtime vector bounds reduce it by 14.8% and 11.9% for two H.264 decoding inputs. Comparisons with QEMU, rv32emu, and libriscv show how translation paths and compilation costs affect first-run performance. The results identify when wider simulated vectors are useful and how a lightweight compiler can retain their benefits while reducing unused-capacity work and repeated materialization of intermediate vector state.

Keywords: dynamic binary translation; RISC-V Vector; just-in-time compilation; register promotion; instruction-level parallelism.

---

# 1. Introduction

## 1.1 Motivation

Executing RVV software on x86-64 lets developers run and evaluate vector binaries without a RISC-V processor for each vector length. A useful execution system must implement the required instruction semantics and translate enough of the computation into host SIMD operations to make repeated testing practical. Existing systems provide different combinations of vector capacity, inline SIMD translation, and optimizing compilation [QEMU-RVV, rv32emu-impl, libriscv]. This thesis develops a lightweight JIT for this setting, with particular attention to vectors longer than the host instructions.

RVV provides an additional opportunity because a vector-length-agnostic binary adjusts its loop step to the runtime vector length. VLEN denotes the architectural vector-register capacity in bits; the instruction-selected length, `vl`, determines how many elements a loop processes before advancing [RVV]. On an x86-64 host with 512-bit vector operations, a 1024-bit element-wise operation is decomposed into two operations on disjoint element groups. For a full-length loop with sufficient input, the wider setting groups the work of two VLEN-512 iterations into one translated iteration. This can place independent arithmetic chains within reach of the processor while reducing loop-control work.

### Independent Vector Chains Within One Iteration

Consider a loop that repeatedly subtracts a constant from a vector of single-precision values. Every subtraction uses the preceding vector result. The loop finishes this chain, stores the result, and advances to the next group of elements. The relevant RVV instructions are:

```asm
# v8 holds the current vector; fa0 holds the constant.
vfsub.vf v8, v8, fa0
vfsub.vf v8, v8, fa0
vfsub.vf v8, v8, fa0
# ... continue the dependent chain, then store and advance.
```

Each line subtracts from all elements selected for that iteration. With 32-bit elements and a register-group multiplier of one, a full VLEN-512 iteration processes 16 elements; a full VLEN-1024 iteration processes 32. The loop obtains this count from `vsetvli` and advances by the returned `vl`. The same binary therefore organizes the first 32 elements as follows:

| Simulated VLEN | First RISC-V iteration | Second RISC-V iteration |
|---|---|---|
| 512 | Run the subtraction chain on elements 0--15 | Run the same chain on elements 16--31 |
| 1024 | Run the chain on elements 0--31 | These elements are already complete |

The host has 512-bit vector instructions in both cases. At VLEN 1024, the translator implements each RVV subtraction with two AVX-512 subtractions: one for elements 0--15 and one for elements 16--31. Figure 1.1 compares three dependent subtractions. Each box denotes a 512-bit vector operation, not a scalar operation. Vertical links indicate data dependencies; in the wider case, emission proceeds across each row before the next row.

![Independent vector chains across RISC-V iterations](figures/iteration_chains.svg)

Figure 1.1. Three dependent 512-bit vector subtractions for the same 32 elements. VLEN 512 uses two successive RISC-V iterations; VLEN 1024 places two independent chains in one iteration. Solid arrows denote data dependence; the dashed arrow advances to the next iteration. Emission in (b) proceeds left to right within each row. The layout is not a cycle schedule.

For the right-hand sequence, instructions are generated across each row before proceeding to the next row. Thus the second group's first subtraction appears between the first group's first and second subtractions. In x86 notation, the beginning of the arithmetic sequence is:

```asm
# zmm0: elements 0--15; zmm1: elements 16--31
# zmm2: the subtraction constant replicated across all lanes
vsubps zmm0, zmm0, zmm2       # first subtraction, first group
vsubps zmm1, zmm1, zmm2       # first subtraction, second group
vsubps zmm0, zmm0, zmm2       # second subtraction, first group
vsubps zmm1, zmm1, zmm2       # second subtraction, second group
```

The second instruction can execute without waiting for the first instruction's result. The third must wait for the first, but does not depend on the second. The processor can therefore continue one vector chain while the other waits. Both VLEN configurations perform the same arithmetic on the same elements; the wider configuration places the independent chains next to each other within one translated iteration.

This organization has an effect similar to loop unrolling: it exposes more independent work within an iteration and reduces the frequency of loop-control operations. Decomposition does not remove a true dependence or create independence between elements. An out-of-order processor can also overlap independent work from separate iterations, but only after that work enters its finite scheduling window. A long dependent chain can delay that visibility; interleaving element groups places independent operations near the start of the chain [Wall, Fog]. Chapter 5 measures the resulting benefit with dependent-chain microkernels and applications, keeping width scaling separate from the effects of the two translation optimizations.

### Costs of Long-Vector Execution

Existing systems already execute RVV on x86-64, but expose its arithmetic to different optimization stages. QEMU expands eligible integer operations through its generic vector IR, while other forms use runtime helpers. libriscv translates selected floating-point forms into C expressions that a native compiler can optimize across instruction boundaries. HQEMU's SIMD work similarly demonstrates the value of retaining vector operations before host code generation [QEMU-RVV, libriscv, HQEMU-SIMD]. These approaches make the representation and optimization scope important design choices in addition to supported vector length.

Longer vectors also increase implementation costs. An architectural vector register may require several host registers, and independently translated RVV instructions may exchange intermediate results through memory. Retaining those values in host registers reduces memory traffic but increases register demand. Moreover, an image or video kernel may request a short runtime vector length even when much greater register capacity is available. Expanding every instruction to that capacity then generates work for components that contain no elements to update.

The design problem is therefore to expose independent element-group computations without letting state transfers, register demand, or unused capacity erase their benefit. We address it with explicit SIMD translation, bounded reuse of intermediate vector values, and runtime checks that skip components outside the required element range.

## 1.2 Approach and Contributions

The implementation builds on rvdbt's existing lightweight compiler and the profile-guided compilation workflow studied by Lin [Lin2025]. The lightweight compiler translates RISC-V code during execution and caches the resulting x86-64 instructions. This thesis extends that execution path rather than replacing it with an offline compiler.

The first contribution is a lightweight RVV JIT integrated into rvdbt. It maps eligible vector operations directly to x86 SIMD and uses semantic helpers for the remaining execution paths. Long operands are decomposed into host-sized components, retaining element widths, runtime configuration, and destination-update requirements. The existing dispatcher and code cache execute the generated blocks. This representation also supplies the dependencies and element ranges used by the following optimizations. The execution profile and instruction-form validation are specified in Sections 3.6 and 5.7.

The second contribution is an adaptation of vector register promotion to this representation. Compatible instructions share intermediate vector values instead of repeatedly communicating through the in-memory architectural state. The method preserves the final value of every modified architectural register and bounds the number of resident components. Its design addresses the interaction between value reuse, runtime guards, and the limited host register file.

The third contribution is runtime elimination of vector components outside the instruction's element range. The method places bounds checks before the work they can bypass and integrates their control flow with state publication. Its benefit is particularly relevant when simulated register capacity grows but the program continues to use short vectors.

The evaluation separates three comparisons: changing simulated vector length, enabling each optimization at a fixed length, and comparing complete execution systems on compatible binaries. This separation connects each result to the design choice it tests. Register promotion is useful even when one architectural vector fits in one host register; decomposition increases its scope and resource demands, rather than being its sole source of benefit.

## 1.3 Thesis Organization

Chapter 2 introduces binary translation, RVV execution, host SIMD execution, and existing translation systems. Chapter 3 describes the inherited rvdbt framework, the added RVV execution path, and its execution profile. Chapter 4 presents optimizations for the state traffic and unused work introduced by vector decomposition. Chapter 5 evaluates width scaling, fixed-width ablation, instruction behavior, external systems, and functional validation. Chapter 6 summarizes the findings and identifies the requirements for extending the work to an optimizing compilation tier.

---

# 2. Background

## 2.1 Binary Translation and Compilation Cost

A binary translator converts a program's machine instructions into host instructions, either within one instruction set or across different instruction sets. Dynamic binary translation generates code during execution; ahead-of-time (AOT) translation prepares it before execution. A lightweight just-in-time (JIT) compiler favors low translation latency, whereas an optimizing compiler spends more time analyzing larger regions. A tiered system initially executes inexpensive translations and optimizes frequently executed code later. Within a DBT, the JIT implements translation by constructing an IR and generating host machine code.

Compilation time and execution time determine the cost of a single run. A more expensive optimization can reduce total time when the compiled region executes often enough to recover its compilation cost. Profile-guided approaches use observed execution frequencies to select such regions; Lin applies this approach to rvdbt's AOT compilation [Lin2025].

LLVM-based binary translation exposes machine instructions to compiler analysis through an intermediate representation (IR). LLBT translates binaries through LLVM IR for static compilation; rev.ng recovers control-flow graphs and function boundaries for binary analysis [LLBT, revng]. Recovering these structures gives analyses a scope beyond isolated instructions. In an online compiler, obtaining that scope must also fit the compilation budget.

### Translation Blocks, Intermediate Representation, and Helpers

A translation block (TB) is a sequence of machine instructions translated as one unit. Control transfers and implementation limits determine its boundary; it need not coincide with a basic block chosen by the original compiler. A translation cache associates an instruction address with the corresponding host code. Block chaining connects translated successors directly, avoiding a return to the runtime dispatcher at every block boundary [QEMU, Lin2025].

An intermediate representation (IR) describes operations and their operands between decoding and machine-code generation. Lowering replaces an operation with operations supported by a later representation or the target architecture. For a vector wider than the target supports, this may involve splitting it into narrower vectors. LLVM calls the process of making unsupported types and operations representable on the target legalization [LLVM]. A helper is a runtime function called by generated code to implement an operation; it is different from an IR operation compiled inline. Helpers can themselves contain scalar or SIMD code. Whether a helper is used therefore describes a compilation boundary, not by itself the instruction-level parallelism of its implementation.

### Optimizing and Hybrid Compilation

Instrew lifts code at approximately function granularity and applies LLVM optimizations. Its register-based calling convention replaces selected CPU-state loads and stores with register arguments and results, allowing state to remain in registers across translated calls. Enlarging the optimization scope can improve execution but also increases translation time; the evaluation reports cases where that cost outweighs the benefit [Instrew]. This tradeoff motivates measuring translation and execution together when evaluating an online compiler.

Arancini shares a frontend and intermediate representation between static and dynamic translation. Its static path lowers to LLVM and produces a hybrid executable containing original code, translated code, and address mappings. Its runtime uses those mappings and a translation cache, invoking a direct-code-generation backend for unresolved targets [Arancini]. Although its translation direction is x86 to Arm or RISC-V, its integration strategy is relevant to extending rvdbt: a shared vector representation must be accompanied by compatible state boundaries and entry/exit mappings. The lightweight RVV path evaluated here supplies the initial execution path; an optimizing tier must also recover its compilation cost.

## 2.2 RISC-V Vector Execution

The RISC-V Vector extension (RVV) defines 32 architectural vector registers, named `v0` through `v31`. VLEN is the number of bits in one register. The selected element width (SEW) and the vector register length multiplier (LMUL) determine the maximum element count for an operation:

\[
VLMAX = LMUL \cdot VLEN / SEW.
\]

For example, SEW 32 and LMUL 1 give 16 elements at VLEN 512 and 32 elements at VLEN 1024. The runtime `vl` specifies the upper end of the operation's body range. It can be smaller than VLMAX when fewer elements remain or when the algorithm processes a fixed-size block. Instructions such as `vsetvli` select the configuration and return the chosen `vl`, allowing the loop to advance without assuming a fixed register length [RVV].

The `vtype` control register records SEW, LMUL, and the destination mask and tail policies. Increasing LMUL groups architectural registers into a larger operand; it does not change VLEN. A vector-length-agnostic (VLA) loop uses the returned `vl` to advance its pointers and remaining count, as in Section 1.1. Vector-length-specific (VLS) code instead relies on a chosen vector length. These are programming and compilation strategies for RVV, not separate instruction-set extensions.

The elements below `vl` are not necessarily all updated. Elements before `vstart` are prestart elements. A masked instruction additionally selects body elements using the mask register. For an ordinary masked element-wise operation, the active-element condition is

\[
vstart \leq i < vl \quad\land\quad mask[i].
\]

An unmasked operation omits the final condition. Tail elements lie beyond the body range. Mask and tail policies determine whether old destination values must be preserved or whether the specification permits an agnostic result. Normal completion resets `vstart`. Whole-register transfers and other special operations have rules that cannot be reduced to this ordinary element-wise predicate [RVV].

This distinction between capacity and runtime element range is central to the implementation. VLEN determines how much state must be representable; `vl`, `vstart`, masks, and the instruction's semantics determine which updates are required in a particular execution.

For VLEN 1024, SEW 32, LMUL 1, `vl=20`, and `vstart=0`, the register contains 32 elements but only elements 0--19 belong to the body. In a masked instruction, `v0` selects which of those elements are updated:

![RVV body and host component boundaries](figures/element_ranges.svg)

Figure 2.1. Element selection at VLEN 1024, SEW 32, LMUL 1, vl=20, and vstart=0. The component boundary at 16 differs from the body boundary at 20. Shading denotes body elements, not the active elements of a masked instruction; those additionally depend on the corresponding v0 bits.

The partition boundary is a host implementation choice; the body boundary is set by `vl`. They need not coincide. This difference explains why a partially used host vector still requires lane selection even when entire unused host vectors can be omitted.

## 2.3 SIMD Width and Instruction-Level Parallelism

On x86-64, XMM, YMM, and ZMM name vector registers with 128-, 256-, and 512-bit views. AVX-512 supplies operations on 512-bit vectors and opmask registers for selecting lanes in eligible instructions. A 512-bit vector holds 16 elements of 32 bits or eight elements of 64 bits. When RVV state is wider, the translator must represent one architectural vector using several such host values; masked RVV updates additionally require translating the element-selection conditions [Fog, RVV].

Single-instruction, multiple-data (SIMD) execution processes several elements with one instruction. Instruction-level parallelism (ILP) instead concerns overlap among separate instructions. Decomposing one RVV operation into two AVX-512 operations preserves SIMD within each operation and can expose ILP between them.

An out-of-order processor tracks whether an instruction's operands are ready. It can issue independent ready instructions while another instruction waits for a result, subject to execution-unit throughput, scheduling-window capacity, and other resources. Register renaming removes false dependencies caused by reuse of architectural register names; it does not remove the true dependency between a producer and its consumer [Wall, Fog].

Suppose each element group executes a long chain of identical operations. Each operation has a dependency latency of L cycles, and the relevant execution resources can accept R such operations per cycle. With d independent chains, an idealized steady-state lower bound on cycles per operation is

\[
c \geq \max(L/d,\;1/R).
\]

The first term describes dependency-limited execution; the second describes throughput-limited execution. Increasing the number of independent chains helps until another resource becomes limiting. This model concerns a homogeneous arithmetic stream, not an entire translated application. Loads, branches, mixed instructions, and finite queues introduce additional constraints. Instruction-characterization work such as uops.info distinguishes latency, throughput, and port usage, while AMD documents the resources of the host microarchitecture separately [uops, AMD].

The architectural width does not specify how many operations a processor can execute per cycle. Intel and AMD implementations can differ in internal execution width, dependency latency, execution-unit throughput, and frequency behavior. Thus AVX-512 support alone is insufficient to predict the benefit of an additional independent chain. The latency and throughput used in a model must correspond to the instruction and microarchitecture being evaluated [Fog, AMD, uops].

The Linux crypto discussion provides a concrete example. In a 2024 AES-XTS patch, Biggers reported that replacing the 256-bit implementation with a 512-bit implementation increased AES-256-XTS decryption throughput by 13% on AMD Zen 4 but 2% on Intel Sapphire Rapids for 4096-byte inputs. The patch also reduced the default priority of the 512-bit path on selected older Intel models to avoid downclocking [LinuxAES]. This choice changes the host instruction width. In this thesis, increasing simulated VLEN from 512 to 1024 instead increases the number of 512-bit host operations. The relevant scheduling question is how much additional independent work those operations expose within the host's execution resources.

## 2.4 Translation Systems

The following systems use different compilation units and representations to execute machine code. Their RVV support is described for the source revisions identified in the references.

### QEMU

QEMU translates code on demand in translation blocks. When execution reaches an uncached block, the instruction-set frontend decodes its instructions into Tiny Code Generator (TCG) IR. TCG performs local optimization and liveness analysis, allocates host registers, and emits machine code through a host-specific backend. Translated blocks remain in a translation cache; direct block chaining connects eligible successors without returning to the dispatcher. Separating instruction-set frontends from host backends supports multiple architecture pairs within the same compilation infrastructure [QEMU].

The RISC-V frontend stores architectural vector registers and control state in the emulated CPU state. Vector configuration contributes to the translation-block flags used to select a compatible translation. Configuration-changing instructions end the current block, so subsequent translation can use the updated state. Simulated VLEN is selected when configuring the CPU; QEMU supports RVV execution at VLENs from 128 through 1024 bits [QEMU-RVV].

RVV instructions use either inline TCG operations or runtime helpers. For eligible full-length, unmasked integer operations, the frontend uses the generic vector-generation interface, GVec. GVec selects a host-vector expansion, scalar expansion, or out-of-line helper according to the operation, width, and backend capabilities. The x86 backend supports TCG vector widths up to 256 bits with AVX2. The helper routes include floating-point arithmetic, fixed-point operations, reductions, most permutations, and ordinary vector memory operations. Masked or partial-length integer add and subtract also use helpers. This distinction concerns how the supported semantics are executed, not whether the instruction exists [QEMU-RVV].

### HQEMU

HQEMU combines QEMU's fast block translator with an LLVM-based optimizing trace translator. Execution initially uses cached TCG blocks. Runtime profiling identifies frequently executed block sequences and forms traces, each with one entry and potentially several exits. In the multithreaded configuration, compilation workers optimize these traces while the application continues executing the fast translations. Completed traces are installed in a separate cache, and execution is redirected to their optimized entry points. The original design also uses hardware performance sampling to identify frequently connected regions for merging [HQEMU].

The LLVM tier provides an optimization scope larger than a single translation block. The trace builder reconstructs TCG IR for the constituent blocks, converts it to LLVM IR, optimizes the region, and generates host code. Compilation modes determine whether this work is synchronous or queued for background workers [HQEMU-impl].

The subsequent SIMD extension preserves vector operations in the representation passed to LLVM, including their element types and widths. This allows vector liveness analysis and state-store forwarding before host code generation. The ARM frontend enables this representation on the LLVM compilation path [HQEMU-SIMD, HQEMU-impl].

Hong et al. further use HQEMU to rewrite short-SIMD loops for longer host vectors. Their transformation widens LLVM vector types, adjusts induction-variable steps and loop bounds, and checks memory dependences when they cannot be resolved during translation. Loop peeling handles alignment, while a short-vector loop processes remaining iterations. The NEON-to-AVX2 evaluation reports an average speedup of 1.41 times from loop transformation and 1.45 times when also using fused multiply-add. The AVX-512 evaluation uses Intel SDE instruction counts rather than hardware execution times [HQEMU-Wide]. This work increases the width of the host operation. Our setting instead allows an RVV operation to exceed the host width and represents it with several host operations. Both address vector-width mismatch, but merging short operations and splitting long operations impose different code-generation costs. The public HQEMU implementation has no RISC-V frontend and cannot execute the RVV binaries used here [HQEMU-impl].

### rv32emu

rv32emu uses a tiered execution architecture. Its initial tier decodes RISC-V instructions into a cached internal representation and executes them with a tail-call-threaded interpreter. Instruction handlers transfer control directly to successor handlers. The decoded representation supports local constant folding and instruction fusion, reducing interpretation work before native compilation [rv32emu, rv32emu-impl].

The first JIT tier translates eligible hot blocks and linked paths using instruction-specific native-code generators and a host-register mapping. The second tier follows block successors to construct a larger region, translates its operations into LLVM IR, and applies optimizing compilation in a worker thread. Runtime dispatch selects the compiled region after its entry point has been published. This hierarchy trades increasing compilation cost for reduced execution cost in frequently executed code [rv32emu, rv32emu-impl].

RVV instructions are marked as non-translatable; a block containing a vector instruction remains on the interpreter path. Vector handlers implement configuration changes, register-group access, element selection, arithmetic, and destination updates. Floating-point vector subtraction uses per-element SoftFloat operations. VLEN is selected at build time, with builds at 128, 256, 512, and 1024 bits checked in this study; the vector configuration accepts SEW 8, 16, and 32. These RVV handlers are distinct from the native-code generators and LLVM translation available for scalar instructions [rv32emu-impl].

A later revision also executes integer add and FP32 subtract at VLEN 4096 through the interpreter [rv32emu-wide]. These operations use per-element instruction handlers, whereas rvdbt translates them into native SIMD.

### libriscv

libriscv provides a decoded-instruction interpreter and an optional binary-to-C translation path. When preparing an executable segment, the translator scans instruction boundaries and control-flow targets and constructs C functions containing RISC-V operations and internal branches. A C compiler produces a native module. The runtime maps translated entry addresses to its functions and dispatches execution to them, returning to interpretation where necessary. Translation is organized around executable segments rather than triggered solely by a hot-loop counter [libriscv].

The C compilation path can use embedded TinyCC or a system C compiler. These are alternative compiler choices, not successive optimization tiers. TinyCC favors low compilation latency; the system compiler applies its native optimization passes to the generated C. Register state is represented through a CPU-state structure and, where supported, cached C variables. The compiler therefore determines both native instruction selection and the optimizations performed across the generated statements [libriscv].

The RVV build used in the evaluation fixes VLEN at 256 bits. Vector configuration instructions update the runtime element width and length. Selected full-length, unmasked floating-point forms with LMUL 1 expand into C expressions for the vector elements; the C compiler may combine these expressions into SIMD instructions. Vector memory operations have separate checks for their element widths, register groups, and addresses. Arithmetic forms outside the inline path and configurations that fail its guards call runtime handlers. The resulting SIMD width depends on the compiler and target configuration, rather than a dedicated RVV-to-x86 vector backend [libriscv].

libriscv also provides an asmjit backend that emits native code without invoking a C compiler. Its general RVV arithmetic dispatch calls the instruction handler, whereas selected memory transfers have native implementations [libriscv-AJ].

### Other RISC-V-to-x86 Systems

Long-vector semantics are also available outside Linux-user JITs. Spike executes RVV through its ISA model and can host static application ELFs through a proxy kernel. Whisper provides a functional RISC-V simulator with a Linux system-call mode. Renode uses tlib dynamic translation within a virtual platform; its vector-add translation calls an element-processing helper. These systems can represent vector lengths greater than the host SIMD width, but differ in operating-system services and execution overhead [Spike, Whisper, Renode]. Chapter 5 distinguishes application timing from successful architectural probes and does not equate a supported VLEN with a particular host SIMD implementation.

Pydrofoil takes another route: a Sail ISA model is compiled into an interpreter from which a meta-tracing JIT specializes frequently executed paths. This permits optimization of interpreter operations across instruction boundaries without a handwritten native emitter for every guest instruction. In our integer and floating-point vector-add probes, the optimized outer traces retained calls to vector execution functions. The existence of a JIT therefore does not by itself establish inline SIMD arithmetic for every RVV form [Pydrofoil].

PasRISCV includes an RV64-to-x86 JIT with XMM and YMM implementations of selected RVV operations at VLEN 128 and 256. Its vector paths check the runtime configuration and include register-mapping and writeback machinery. Berberis targets RV64 Android execution on x86-64. Its interpreter supports vector operations at VLEN 128, while the lightweight and optimizing translator frontends reject the general vector-operation entry point. These systems demonstrate different combinations of vector semantics and native translation; neither provides a drop-in runner for the RV32 Linux binaries evaluated in Chapter 5 [PasRISCV, Berberis].

| System | Execution organization | RVV execution |
|---|---|---|
| QEMU | On-demand TCG translation blocks | Runtime VLEN 128--1024; on x86, eligible GVec operations use host vectors up to 256 bits, scalar expansion, or helpers |
| HQEMU | Fast TCG blocks and optimizing LLVM traces | Fixed-width source SIMD support; no RISC-V frontend |
| rv32emu | Decoded interpreter, native-code JIT, and LLVM tier | Build-time VLEN; RVV uses the interpreter; add/subtract also execute at VLEN 4096 in a later revision |
| libriscv | Decoded interpreter, binary-to-C compilation, and asmjit backend | VLEN 256 in the evaluation configuration; selected forms expand into C; asmjit arithmetic calls handlers |
| PasRISCV | RV64 interpreter and x86 JIT | VLEN 128/256; selected operations use XMM/YMM code, with runtime configuration checks |
| Berberis | RV64 Android interpreter and two translator tiers | VLEN 128 interpreter; general vector operations remain on the interpreter path |
| Spike | ISA interpreter with proxy-kernel application services | RV32 applications execute at VLEN 1024/4096; element-processing semantics |
| Whisper | Functional simulator with Linux system-call emulation | RV32 applications execute at VLEN 1024/4096; no native-code JIT |
| Renode | Virtual platform with tlib dynamic translation | VLEN 4096 vector-add probe passes; vector add calls an element-processing helper |
| Pydrofoil | Sail-derived interpreter with meta-tracing JIT | VLEN 512 add probes pass; optimized outer traces retain vector-function calls |

## 2.5 Vector Representation and State Optimization

Width adaptation predates RVV binary translation. Vector LLVA separates vector semantics from a particular hardware vector length; Vapor SIMD divides vectorization work between a target-independent stage and target-specific dynamic compilation [VectorLLVA, VaporSIMD]. LLVM legalization decomposes operations that a target does not support directly, and MLIR represents vector shapes and subvector transformations explicitly [LLVM, MLIR]. These approaches establish long-to-short vector decomposition as a compiler technique. A binary translator must additionally preserve the architectural state and runtime configuration of the translated instruction set.

Register promotion replaces memory-based communication with register values when the compiler can identify the relevant definitions and uses. In binary translation, this requires distinguishing temporary values from architectural values that subsequent execution may observe. A value retained in a host register may still need to be written back at an execution boundary. These requirements apply to scalar and vector state alike [LLVM, HQEMU-SIMD].

Width adaptation also involves resource tradeoffs. ARM-to-x86 SIMD asymmetry research considers combining narrower operations into wider host operations and the associated data-reorganization and register costs [saSLP]. Dr.avx studies the opposite width mismatch within x86: dynamically executing vector instructions that the host hardware does not support [Dravx]. These approaches address the mapping between source operations and available host vector resources.

These systems expose two distinct optimization boundaries. The first is between an RVV operation and its implementation: an explicit vector operation allows the backend to select SIMD instructions, whereas an opaque call leaves that selection to the helper's implementation. The second is between consecutive RVV instructions: generating SIMD for each instruction still leaves the question of whether intermediate state is stored and reloaded. HQEMU's vector IR and state forwarding address both boundaries in its optimizing path; libriscv's inline C forms let a native compiler optimize across the generated expressions [HQEMU-SIMD, libriscv].

rvdbt applies cross-instruction value reuse within its lightweight JIT. Longer architectural vectors multiply the host values associated with each live architectural value. The design must therefore choose both which values to retain and how many vector components to process together. Chapter 4 bounds this working set while preserving the architectural values required after the sequence. Register promotion reduces state traffic; limiting the batch size controls the additional register demand.

Runtime element selection creates a separate decision. QEMU's partial-length arithmetic helpers and Renode's vector-add helper already bound element processing by the runtime length [QEMU-RVV, Renode]. Our bounds address a different implementation cost: an inline SIMD expansion can still prepare masks and values for an empty suffix of host components. Chapter 4 places a bound before that preparation, retains lane selection within partially used components, and preserves the completion updates at the exit. Chapter 5 separates its effect from value reuse and from increasing simulated VLEN.

## 2.6 Implications for Long-Vector Translation

The comparison separates vector capacity from the implementation of arithmetic. Spike, Whisper, and Renode demonstrate that representing vectors longer than the host SIMD width is not unique to a native SIMD JIT. Conversely, PasRISCV provides selected native vector operations at shorter lengths, and libriscv's fixed VLEN still permits runtime `vl` changes. Supporting a fixed capacity does not preclude vector-length-agnostic code. The design pursued here combines configurable long-vector execution with explicit SIMD operations in the lightweight translation path [Spike, Whisper, Renode, PasRISCV, libriscv].

Value reuse and state writeback are also separate decisions. TCG can forward a previously stored value to a subsequent load. In the captured QEMU integer-add sequence, the next instruction reuses the host values but still writes each component back to vector state. HQEMU's SIMD representation and libriscv's generated floating-point code show that optimization across vector instructions can retain intermediate values and defer state stores [QEMU-RVV, HQEMU-SIMD, libriscv]. This motivates treating architectural writeback as an explicit boundary in our design. With long vectors, that boundary must also respect the register budget: retaining more components increases live values even when it removes memory traffic.

Finally, the compilation strategy determines when those optimizations can repay their cost. HQEMU optimizes hot traces, Instrew uses an LLVM-based translation path with a register-based state interface, and Arancini shares a representation between static and dynamic translation [HQEMU, Instrew, Arancini]. These designs inform a future optimizing tier for rvdbt: preserve vector operations and state boundaries when passing regions to LLVM, then measure the complete cost of profiling, compilation, installation, and subsequent execution. The present evaluation isolates the lightweight path before adding that tier.

---

# 3. Framework

This chapter follows the path from an RVV instruction in a RISC-V binary to executable x86-64 code. The extension adds vector state and operations to rvdbt's existing lightweight JIT; it retains the dispatcher, translation cache, and block-linking mechanism. Figure 3.1 identifies the components used along this path. Sections 3.2--3.4 follow its translation pipeline from the RISC-V frontend, through QIR and CPU state, to the x86-64 backend.

## 3.1 System Architecture

rvdbt combines a lightweight JIT with profile-guided AOT compilation. In the workflow described by Lin, a first execution collects a profile, an offline LLVM compiler generates optimized regions, and a subsequent execution loads the artifact while retaining JIT execution elsewhere [Lin2025]. This thesis extends and evaluates the lightweight path shown in Figure 3.1.

![RVV extension within the rvdbt JIT architecture](figures/rvdbt_rvv_framework.svg)

Figure 3.1. rvdbt's lightweight execution path, adapted from the organization described by Lin [Lin2025]. (a) Runtime execution: a cache miss invokes the lightweight JIT, which installs the generated code in the translation cache. (b) Internal stages of the same JIT: the RISC-V frontend (Section 3.2), QIR (Section 3.3), and the three-stage QCG backend (Section 3.4). CPU state is described in Section 3.3. Solid arrows denote control or code transfer; dashed arrows denote runtime data access. Shaded components contain RVV extensions.

The ELF loader maps the RISC-V binary and establishes the initial program counter. The dispatcher looks up that address in the translation cache. On a miss, the RISC-V frontend constructs QIR for the block, and the QCG backend generates its x86-64 implementation. The runtime installs this code in the cache and enters it through a trampoline, an entry stub that provides the CPU-state pointer and program-memory base.

A translated branch can jump directly to a linked block. An unresolved target returns to the dispatcher, which obtains the target block and patches the link. RVV instructions use this same execution loop. Their generated code reads architectural registers from CPU state, performs vector operations, and writes the required results back. Accesses to the RISC-V program's arrays use a separate program-memory mapping.

## 3.2 RISC-V Frontend

The frontend in Figure 3.1 decodes each instruction and constructs its QIR operations. For RVV, it combines the instruction's operand form with the vector configuration: element width, register grouping, and the configured VLEN. For an applicable direct implementation, it determines how the operands are divided into host vector values; a form without a direct implementation is represented by a helper call in QIR.

Consider the unmasked instruction `vadd.vv v10, v8, v9`, with VLEN 1024, SEW 32, and LMUL 1. Each source contains 32 integers. On the 512-bit path, the frontend divides each operand into two contiguous groups of 16 elements. We call each such group a *component*. Figure 3.2 aligns these groups with a shared QIR-to-x86 mapping and the destination elements written by the partial-update branch. Components are compiler values at this stage, not assigned ZMM registers.

![One RVV addition represented by two vector components](figures/rvv_translation.svg)

Figure 3.2. RVV addition on two 512-bit components. (a) Each cell is a 32-bit element in a CPU-state register slot; the boundary at 16 separates the components. (b) The full-update mapping applies to both components: four loads, two additions, and two stores. The mapping symbol denotes lowering, not execution order; all source loads precede the additions and stores. (c) With the QCG partial branch enabled, two `vchunkpartialalu` nodes update elements 0--19. Shading denotes written elements; elements 20--31 retain their previous values in this implementation. The AVX-512 store opmasks select 16 and 4 elements even though the RVV instruction is unmasked. Guard, mask-construction, and completion instructions are omitted.

The same RISC-V address may execute under different vector configurations. At a cache miss, the runtime passes the current `vtype` as a translation hint; the frontend also tracks configuration instructions within the block. A runtime guard checks the conditions required by the generated direct body. If those conditions hold, execution enters that body. Otherwise, the emitted code calls the semantic helper with the original instruction encoding and then resumes the block. Thus the cached translation does not silently assume that the configuration observed during translation remains unchanged.

Long-vector decomposition also depends on the operation. An ordinary element-wise addition uses matching source and destination element widths. A widening or narrowing instruction changes them, so the frontend records the operand ranges separately. A reduction or cross-element permutation cannot be replaced by independent additions on equal slices. Each form retains its own semantic implementation rather than inheriting the addition example's decomposition rule.

## 3.3 Vector QIR and CPU State

QIR is rvdbt's intermediate representation. Its vector extension records an operation's element type, component width, operands, and destination. The full-update body in Figure 3.2 uses three concrete operations: `vstatechunkload` reads a component from CPU state, `vchunkadd` computes its sum, and `vstatechunkstore` writes the result. QIR also represents the guard, helper call, and control-flow join. The backend therefore receives both the vector calculation and the conditions under which it executes.

CPU state, shown separately in Figure 3.1, is the persistent storage shared by translated blocks and helpers. The RVV extension adds 32 vector-register slots and control fields including `vl`, `vtype`, `vstart`, and `vlenb`. Slots reserve the supported maximum size, so changing the configured VLEN does not change other registers' offsets. For the addition in Figure 3.2, component 0 of `v8` begins at that slot's base; component 1 begins 64 bytes later.

A QIR temporary and an architectural register slot have different lifetimes. A temporary may remain in a host register while the block executes. The final architectural value must be available in CPU state when a later block or helper needs it. These explicit state stores are not register spills: a spill saves a temporary because the allocator lacks registers. Chapter 4 changes which intermediate state stores and reloads are necessary, while preserving the final architectural values.

Element selection is also explicit. For ordinary element-wise operations, let component j contain q elements and let i be a lane within that component. Its element index is e=jq+i. The lane is updated when

\[
vstart \leq e < vl
\quad\text{and}\quad
(vm=1\ \text{or}\ v0[e]=1).
\]

Here `vm=1` denotes an instruction without masking. With `vl=20` and `vstart=0`, the first component of the example updates all 16 elements; the second updates four. An instruction mask can disable additional elements. A tail-undisturbed or mask-undisturbed destination preserves the corresponding old values. This requirement can be implemented by masking the state store for the integer addition. Floating-point and memory operations must also account for exception and access side effects, so their execution masks and fallback conditions are operation-specific.

## 3.4 x86-64 Backend

QCG, rvdbt's lightweight code generator, implements the three backend stages in Figure 3.1. It does not invoke LLVM. Instruction selection assigns host operand requirements; register allocation assigns physical registers to QIR values; code emission uses AsmJit to encode the selected instructions.

For Figure 3.2, instruction selection maps 32-bit integer addition to `vpaddd` and the 512-bit component type to ZMM operands. The allocator assigns a separate host value to each component. State loads and stores become vector memory operations at their recorded CPU-state offsets. The following arithmetic body illustrates the result for `vl=32` and `vstart=0`; register names are illustrative and the entry guard is omitted.

```asm
vmovdqu64 zmm0, [state_v8  + 0]
vmovdqu64 zmm1, [state_v9  + 0]
vmovdqu64 zmm2, [state_v8  + 64]
vmovdqu64 zmm3, [state_v9  + 64]
vpaddd    zmm4, zmm0, zmm1
vpaddd    zmm5, zmm2, zmm3
vmovdqu64 [state_v10 + 0], zmm4
vmovdqu64 [state_v10 + 64], zmm5
```

The full-update body reads the sources before writing the destination, so source--destination overlap does not destroy an input. With the QCG partial branch enabled, the frontend instead emits one `vchunkpartialalu` per component. Its emitter constructs an element-range mask and uses masked `vmovdqu32` stores: each opmask bit controls a 32-bit destination element. The mask preserves other elements even though the RVV instruction itself is unmasked. Full-state transfers can use `vmovdqu64` because no per-element selection is needed. The two component values still represent separate element groups.

The helper branch also constrains allocation. Values needed across a possible helper call must be preserved before the guard. The allocator cannot insert arbitrary spills inside the guarded body when the fallback would bypass them. The frontend consequently bounds the vector values retained by a grouped direct body, as developed in Chapter 4.

Once emitted, the block is installed in the translation cache and executes through the runtime in Section 3.1. The complete path supports long-vector arithmetic, but its per-instruction organization repeats two kinds of work: a consumer reloads an intermediate value just written to CPU state, and a fixed-capacity expansion can prepare components beyond `vl`. The next chapter addresses these costs at QIR construction, before physical register allocation and code emission.

## 3.5 Implementation Changes

The patchset extends the existing execution pipeline rather than adding a separate vector engine. Lin's runtime, scalar translation, translation cache, and block linking form the base [Lin2025]. The RVV additions have three responsibilities.

**Execution support.** The frontend decodes vector operand forms and maintains architectural vector registers and control state. Vector QIR carries element types, component ranges, guards, and destination-update requirements. The x86 backend selects SIMD operations and opmasks for the direct path; helpers implement forms or runtime conditions outside that path.

**Cross-instruction reuse.** The sequence builder resolves sources to their current definitions, records the final modified architectural values, and estimates register demand. QIR construction loads incoming values, reuses results inside a bounded batch, and writes the final values before releasing the batch. The changes precede physical register allocation.

**Bounded execution.** A shared component plan derives element boundaries from destination geometry, including widening and narrowing. Code emission places a comparison or reuses a mask comparison before a skippable suffix, while the completion block retains required state updates. The integrated path groups each component's operations and final stores so that the branch cannot bypass required work.

The implementation artifact provides the upstream-to-extension patchset and source extracts for these boundaries [rvdbt-impl]. The principal code changes are in the RVV decoder and CPU state, vector QIR construction, sequence analysis, the shared active-component plan, and x86 instruction emission. These changes support the lightweight execution path evaluated in Chapter 5. They do not replace the inherited LLVM workflow; integrating the vector representation with an optimizing tier is discussed in Section 5.6.

## 3.6 Execution Profile and Semantic Boundaries

The implementation targets RV32 user-space programs with ELEN 64 and a power-of-two VLEN from 128 through 4096 bits. VLEN determines register capacity; `vtype` and `vl` determine its use. Translation-time configuration hints guide specialization, while generated guards check the live state before entering a direct body. The fixed correctness build uses 512-bit QCG host components; an independent 256-bit selector is outside this build profile.

CPU state reserves 512 bytes for each vector register, while its logical length is VLEN/8 bytes (Section 3.3). Register-group addressing respects this physical stride. Widening and narrowing preserve element indices across different source and destination widths before register allocation.

An admitted direct body uses vector QIR and host SIMD instructions; otherwise, an RVV helper accesses the same architectural state. Both routes must implement the applicable mask, destination policy, rounding and state updates. Thus helper execution contributes to semantic support, while direct code generation and optimization admission have their own conditions.

Validation follows these route boundaries. External suites retain their original output predicates, while project-authored directed matrices initialize architectural state, execute a target and capture state for comparison outside the DUT. The directed and external final replay share one frozen correctness executable. Sequence validation separately joins target PCs to generated code and executed frames to establish register promotion and inactive-component omission (Section 5.7).

Operation-specific rules constrain decomposition. Reductions combine elements; gathers may read outside the updated range; whole-register transfers use a register-count-based extent rather than ordinary `vl`. These operations retain their required work instead of inheriting the element-wise omission rule [RVV].

Section 5.7 distinguishes instruction-form coverage, optimization admission and fault handling. Checked vector-memory helpers preserve completed elements and record the faulting element in `vstart`. A denied access records its instruction address, memory address and access direction before returning to the dispatcher. For an unexpected host fault inside a checked copy, exact instruction-address matching identifies the owned memory operation; the host handler returns through that operation's failure exit. The dispatcher then constructs the RV32 signal frame from the saved state and enters the registered synchronous SIGSEGV or SIGBUS handler. Frame construction occurs after the helper has returned, not inside the host signal callback.

QCG memory instructions execute in separate instruction frames. Arithmetic sequences on either side can still use register promotion, but a later instruction cannot publish its result before the preceding memory instruction completes. This boundary preserves the previous destination value when successive instructions overwrite the same register; a final-live-out map alone would not recover that value after a fault.

Each admitted memory frame records exact host access sites and an emitted fault exit. An ordinary unit-stride or whole-register SIMD load publishes each completed chunk before accessing the next. Its fault boundary requires each active chunk to remain within one anonymously mapped page; crossing chunks and unsupported backing use checked helpers. For an owned user data page fault, the runtime reports the first element of the denied chunk. Whole-register operations derive this position from encoded element width and transfer extent, independently of ordinary `vl`.

The scalar memory loop records the current element and segment field at each guest-memory instruction. Completed load fields are published before subsequent accesses. Page-contained scalar accesses can use this boundary for synchronous SIGSEGV and supported SIGBUS events; split fields and indexed-load overlap requiring changing source indices use checked helpers. The fault exit preserves prior state and returns to the dispatcher. These contracts cover the stated QCG instruction frames; optional gather paths, LLVM native-memory recovery and complete guest-handler return/restart require separate treatment.

---

# 4. Methodology

Chapter 3 establishes how rvdbt executes a long RVV operation as several host vector operations. Two costs grow with this decomposition: each instruction transfers more components to and from CPU state, and a fixed expansion can prepare components that contain no elements below `vl`. This chapter addresses the two costs during QIR construction. Vector register promotion reuses intermediate values under a register budget; runtime execution bounds omit unused components. Their integration coordinates when values are stored with where execution may leave the sequence.

## 4.1 Vector Register Promotion

Consider three unmasked FP32 instructions that update all elements with round-to-nearest, ties-to-even:

```asm
vfadd.vv v8, v2, v3
vfmul.vv v8, v8, v4
vfsub.vv v8, v8, v5
```

They compute `v8 = (v2 + v3) * v4 - v5`. At VLEN 1024, SEW 32, and LMUL 1, each instruction operates on two 512-bit components. Figure 4.1(a) follows one component. The addition stores its result in CPU state; the multiplication reloads it, computes a new value, and stores that value for the subtraction. These accesses transfer architectural register values, not array elements requested by the RISC-V program.

![Vector state transfers before and after promotion, with bounded batching](figures/vector_promotion.svg)

Figure 4.1. Promotion for one component of the FP32 ADD--MUL--SUB sequence, with identical CPU-state geometry in (a) and (b). State traffic falls from six loads and three stores to four loads and one store; arithmetic is unchanged. The final value of v8 is stored in this example. (c) At VLEN 4096, the resource bound selects two batches of four components. Within each batch, emission proceeds across all components of a row before the next instruction. Final stores complete before the next batch reuses the host-register resources. Columns denote components, not physical registers.

Promotion replaces the intermediate store/reload pairs with QIR value dependencies, as in Figure 4.1(b). For each component, the implementation loads `v2`, `v3`, `v4`, and `v5`, performs the three operations, and stores the final `v8`. State accesses fall from six loads and three stores to four loads and one store; the three arithmetic operations are unchanged. VLEN 1024 repeats this saving for two components. Longer vectors increase the absolute number of removable accesses, but also the number of values that must remain live.

The transformation changes QIR values and state accesses before register allocation, rather than rewriting emitted x86 instructions. The following x86-64 schematic shows one component of the same sequence. `V2_j` denotes the byte offset of component j of `v2` in CPU state; the other offsets follow the same convention. The example assumes full-length unmasked execution and zero `vstart`. Register names are illustrative, not a measured allocation; guards, floating-point state handling, NaN canonicalization, and other components are omitted.

```asm
; Without promotion: component j
vmovdqu64 zmm0, [state + V2_j]
vmovdqu64 zmm1, [state + V3_j]
vaddps    zmm2, zmm0, zmm1
vmovdqu64 [state + V8_j], zmm2
vmovdqu64 zmm0, [state + V8_j]
vmovdqu64 zmm1, [state + V4_j]
vmulps   zmm2, zmm0, zmm1
vmovdqu64 [state + V8_j], zmm2
vmovdqu64 zmm0, [state + V8_j]
vmovdqu64 zmm1, [state + V5_j]
vsubps    zmm2, zmm0, zmm1
vmovdqu64 [state + V8_j], zmm2
```

```asm
; With promotion: component j
vmovdqu64 zmm0, [state + V2_j]
vmovdqu64 zmm1, [state + V3_j]
vmovdqu64 zmm2, [state + V4_j]
vmovdqu64 zmm3, [state + V5_j]
vaddps    zmm4, zmm0, zmm1
vmulps   zmm5, zmm4, zmm2
vsubps    zmm6, zmm5, zmm3
vmovdqu64 [state + V8_j], zmm6
```

The arithmetic remains unchanged. Without promotion, multiplication and subtraction obtain their input through `[state + V8_j]`; with promotion, their QIR operands refer to preceding results retained in vector registers. Two stores and two loads disappear per component. The final store remains because subsequent RISC-V instructions can read `v8`.

These eliminated transfers are architectural-state materialization, not register spills: they occur even when host registers are available. Spilling instead results from insufficient physical registers for simultaneously live values. Promotion can increase register pressure by retaining inputs and intermediates across instructions, and decomposition multiplies the component values. Resource-bounded batching limits this additional demand while preserving reuse within each batch.

The compiler forms a sequence within one translation block. It scans consecutive instructions, checks each against its existing direct-translation conditions, and checks that their component widths, counts, and state effects permit a shared implementation. It stops before a configuration change, control-flow boundary, incompatible instruction, or resource overflow. The accepted prefix remains usable. A shared runtime guard protects the sequence; its fallback executes the original instructions through architectural state.

Within the sequence, a map associates each RISC-V register and component with its current QIR value. A source not yet defined by the sequence is an initial input. Each instruction reads its sources from the map, computes a result, and updates the destination entry. At the sequence exit, the JIT emits stores for the final value of every modified architectural register. For example, if the multiplication instead writes `v9` and the sequence ends there, both `v8` and `v9` must be stored. A value consumed inside the sequence may still be read after it.

This rule must preserve partial updates as well. When inactive or tail elements must remain unchanged, the admitted path either retains the old destination as an input or masks the state store. Sequence formation also checks restart behavior: `vstart` cannot be reused as an unchanged mask for all instructions because normal completion of the first instruction clears it. A path requiring zero `vstart` enforces that condition in its guard; other supported paths preserve the required instruction order.

Retaining every component at once is unnecessary. At VLEN 4096, each register in this example has eight components. The JIT emits code for one bounded batch at a time: loads of its initial values, each instruction's operations over that batch, and stores of the final values. The next batch reuses the same register resources. Figure 4.1(c) shows this organization. Within a batch, the independent components of an instruction remain adjacent in the generated order.

The batch size follows the backend's register budget. Let k be the total component count, R(n) the conservative register requirement for n components, G the available vector-register count, and K the mask-resource limit. The compiler selects

\[
n^*=\max\{n:1\leq n\leq\min(k,K),\ R(n)\leq G\},
\qquad
p=\lceil k/n^*\rceil,
\qquad
b=\lceil k/p\rceil.
\]

Here p is the number of batches and b their maximum size. For this FP32 sequence, the implementation reserves n values for each of the five accessed register groups and n result temporaries, giving R(n)=6n. The evaluated backend supplies 30 allocatable vector registers. With eight components, five fit the estimate, so the balanced partition uses two batches of four. This avoids retaining all eight components, whose estimate would require 48 registers. Other admitted operations add their broadcast and operand requirements to the estimate.

The following summarizes QIR construction for an eligible batched sequence. Batch iteration occurs in the compiler; the resulting component operations are emitted into the block.

```text
for each batch of components:
    load register values read before their first definition
    for each RISC-V instruction, in program order:
        obtain its source values from the current-value map
        emit the instruction for every component in the batch
        update the map with the destination values
    store the final value of every modified register in the batch
```

Batching requires independent components. The floating-point batched route admits unmasked, element-wise sequences with matching component geometry, compatible integral LMUL groups, and no program-memory or scalar side effects. It does not move operations across reductions or cross-component permutations. Larger batches keep more independent work adjacent, while smaller batches reduce register demand. The resource test and emission order are selected together so that admission does not underestimate the body actually generated.

## 4.2 Runtime Execution Bounds

Promotion reduces transfers between instructions, but cannot by itself remove components outside the current element range. Figure 4.2(a) uses VLEN 2048, SEW 32, and LMUL 1. Four 512-bit components represent 64 elements. At `vl=20`, component 0 contains 16 body elements, component 1 contains four, and components 2 and 3 contain none. Lane masks can preserve the unused destination elements, yet deriving these masks and preparing the unused components still costs instructions.

![Element ranges and bounded execution of a vector sequence](figures/vector_bounds.svg)

Figure 4.2. Runtime bounds at VLEN 2048, SEW 32, LMUL 1, vl=20, vstart=0, with a tail-undisturbed update. (a) The body ends inside component 1. (b) This example path completes the ADD--MUL--SUB sequence and final store for each included component before testing the next. The False branch at vl > 32 reaches Completion, bypassing the remaining component masks, loads, arithmetic, and stores. Dashed code remains emitted but is not executed. Only the vl=20 path and the second test's untaken branch are shown, not the complete control-flow graph.

The method places a range check before a component's preparation. Let D be the number of destination bytes produced by one work unit and E the destination element size in bytes. For elements occupying a whole number of bytes and an integral span, q=D/E elements belong to that unit. Unit j starts at element jq, so the emitted code skips it and the remaining suffix when

\[
vl \leq jq.
\]

The check uses element indices, not the width of a source register. A widening unit producing 64 bytes of 32-bit results covers 16 elements. A narrowing unit producing 32 bytes of 16-bit results also covers 16. Deriving the check and the lane-mask base from the same destination range keeps both consistent despite different source and destination widths.

A unit below the bound still uses the instruction's lane-selection rules. For `vl=20`, component 1 stores only its four required elements; `v0` or `vstart` may further restrict the update. The range check does not inspect every mask bit. Its purpose is to reject a contiguous suffix known to contain no body elements before paying for its preparation.

The exit target is the instruction's completion block, not the next instruction directly. This block performs any required `vstart` update and, for floating-point paths, exception-flag accumulation and restoration of the host floating-point control state. Results are stored only for components that execute. A path whose completion block owns all final state updates can also skip component 0 when `vl=0`; paths retaining a first-component requirement keep that component and bound the later ones.

The compiler omits these checks when a guard or block-local configuration analysis already establishes full-length execution. It also excludes whole-register transfers, whose effective length is not the ordinary `vl`, and paths lacking the required element mapping or completion structure. Otherwise, the generated bound executes whenever control reaches that component. In the per-instruction path, this can occur for several RVV instructions in the same loop iteration; it is not a single loop-wide check. The emitter reuses a mask-building comparison when the selected path provides one, or emits a comparison and conditional branch otherwise. The net overhead must therefore be measured against the baseline's existing mask and control instructions.

## 4.3 Integration of Promotion and Execution Bounds

Adding an early exit changes which operations are reachable. Consider unmasked FP32 ADD followed by MUL, with VLEN 1024, SEW 32, LMUL 1, `vl=16`, and `vstart=0`. Component 0 covers elements 0--15 and must execute; component 1 covers elements 16--31 and has no body elements. Instruction-first emission orders the operations as follows:

```text
ADD[0] -> ADD[1] -> MUL[0] -> MUL[1] -> final stores -> completion
```

Inserting `if vl <= 16: goto completion` before `ADD[1]` skips not only the unused component but also the required `MUL[0]` and final stores. The bound is numerically correct, but its exit target is unsafe for this order.

The integrated path instead completes a component's instruction sequence and stores its final architectural values before testing the next component:

```text
ADD[0] -> MUL[0] -> store[0] -> test vl > 16
    false: completion
    true:  ADD[1] -> MUL[1] -> store[1] -> completion
```

At `vl=16`, the exit skips only component 1. Completion still performs the required state updates. Figure 4.2(b) applies the same rule to the longer ADD--MUL--SUB sequence: each included component is finished and stored before the following component is tested.

This order requires component independence and compatible state updates. Sequence formation verifies those conditions and checks the register demand for the selected order. The JIT chooses that order when generating the block; runtime `vl` controls which suffix branches are taken. The body does not switch from instruction-first to component-first only on the last loop iteration. A separately admitted full-length path can omit bounds, while instructions that cannot join a sequence retain their per-instruction implementation.

Component-first emission preserves independence between element groups, but places the next group's arithmetic later in the instruction stream. The processor may still overlap independent ready instructions; a longer first-component sequence can delay visibility of the next group. In return, completing and storing one component gives the bound a safe exit and shortens value lifetimes. Section 5.7 checks this exit behavior using instruction sequences with partial vector lengths.

The performance configuration called Both enables promotion and the per-instruction bounds policies. Eligible integer sequences can also use component-first bounds. The general floating-point sequence path illustrated above is separately selectable and is not enabled in the performance matrix. Promoted floating-point sequences therefore retain their batching order, while eligible instructions outside those sequences can use the per-instruction bounds. This distinction separates the implemented integration rule from the paths exercised by the reported timings.

The methods overlap in the state accesses they eliminate. Consider a sequence eligible for both transformations, holding its arithmetic and component geometry fixed. Let \(J\) contain all components, and \(A\) contain the prefix retained by the runtime bounds. Let \(b_j\) and \(r_j\) count CPU-state vector loads and stores for component \(j\) before and after promotion, respectively. Holding each component's update semantics fixed, the state-access counts are

\[
C_B=\sum_{j\in J}b_j,\qquad
C_{M1}=\sum_{j\in J}r_j,\qquad
C_{M2}=\sum_{j\in A}b_j,\qquad
C_{\mathrm{Both}}=\sum_{j\in A}r_j.
\]

The amount by which promotion reduces the state-access saving available to bounds is therefore

\[
(C_B-C_{M2})-(C_{M1}-C_{\mathrm{Both}})
=\sum_{j\in J\setminus A}(b_j-r_j).
\]

The right-hand side counts transfers that either method would remove from the omitted suffix. Promotion removes intermediate transfers there; bounds remove the entire suffix, so the same transfers are saved only once. On the retained prefix, promotion still removes intermediate transfers. Bounds additionally omit arithmetic and component preparation outside \(A\). These equations count state accesses; the implementation also changes guard placement, value lifetimes, and instruction order. Chapter 5 evaluates their combined effect on elapsed time.

---

# 5. Evaluation

This chapter evaluates execution efficiency and functional behavior. Sections 5.1--5.6 measure width scaling for the same binary and input, the contribution of each optimization at a fixed VLEN, and performance relative to other execution systems. Section 5.7 examines instruction coverage and state preservation using external tests. Microkernels and applications measure performance; instruction-level checks establish which behaviors were exercised and compared.

## 5.1 Experimental Setup

The main host is an AMD Ryzen 9 9950X3D with AVX-512 support. The measured process is pinned to logical CPU 6, and its simultaneous-multithreading sibling, CPU 22, is kept idle. The minimum and maximum frequency policy is set to 4.3 GHz, with boost disabled. Code huge pages are disabled consistently.

The primary metric is process wall-clock elapsed time, including startup, translation, program execution, input/output, and checks performed within the program. Host-side output comparison is outside the timed process. The process starts without an existing AOT artifact. Thus the metric evaluates the first execution of the lightweight JIT, not only an already-translated loop.

Four configurations are evaluated: B is the per-instruction RVV baseline; M1 enables vector register promotion and bounded batches; M2 enables the per-instruction runtime vector bounds; Both enables both sets of options, including bounds on eligible integer sequences. The separately selectable component-first floating-point sequence path is disabled in this matrix, as distinguished in Section 4.3. Simulated VLEN takes the values 128, 256, 512, 1024, 2048, and 4096 bits. The main host path uses vector operations up to 512 bits. Each configuration has 26 complete rounds, with configuration order rotated and width order alternated. All samples for each reported configuration are retained.

Let T(X,V) be the arithmetic mean elapsed time for method X at VLEN V. Width scaling is measured as T(X,512)/T(X,1024). The time reduction of a method at a fixed VLEN is 100(1 - T(X,V)/T(B,V)). All ratios are calculated from unrounded means. Tables display rounded times in seconds. Width scaling and method improvements use different denominators and are reported separately.

### Workload Roles

The evaluation separates controlled dependency chains, extracted numerical kernels, and application processes. These levels answer different questions: the microkernels isolate arithmetic structure; the numerical kernels place that structure in established computations; and the applications measure whether local improvements reduce complete-process time. Media applications additionally test the cost of increasing register capacity when the runtime element range remains short.

| Workload and source | Measured computation | Evaluation purpose |
|---|---|---|
| Synthetic integer add; FP32 subtract | Fixed-work arithmetic chains | Controlled width scaling and state reuse |
| Livermore Loops K1; K3 | Extracted hydrodynamics expression; inner product | Element-wise chains versus reduction |
| LINPACK-derived kernel | Extracted LU factorization | Reuse within a linear-algebra computation |
| TSVC s3251; vbor | Extracted vectorization-suite loops | Different operand and intermediate-value patterns |
| PolyBench/C ATAX; Doitgen | Extracted matrix-vector and tensor kernels | Reuse within structured numerical loops |
| PARSEC-derived Blackscholes | Option-pricing application | Arithmetic improvement in complete-process time |
| Rodinia-derived LavaMD | Particle-interaction application | Repeated floating-point expressions in an application |
| PARSEC-derived Streamcluster | Clustering application | Whether width scaling also yields promotion benefits |
| Archived JPEG encoder and decoder | Image compression and reconstruction | Short-vector work at larger configured VLEN |
| Archived H.264 decoder: CABA3 and crew | Same decoding application, two inputs | Bounds omission under different video inputs |

The reported set contains 16 workload/input cases, not 16 independent applications. For example, CABA3 and crew are two inputs to the H.264 decoder. Extracted kernels measure the indicated computation, not an entire suite. This division lets the evaluation distinguish width scaling from the availability of reusable intermediate values and short runtime vectors. All 16 cases appear in the fixed-width ablation, including cases with little improvement. Appendix A gives all 384 workload/width/method means; binaries and inputs remain fixed within each comparison.

### Hardware Counters

The case studies use the processor's Performance Monitoring Unit (PMU) to quantify changes in executed work. Linux `perf stat` collects `instructions:u` and `cycles:u` for user-space execution of the measured process. The former counts retired instructions and the latter counts processor cycles in user space; elapsed time covers the complete process interval.

The archive audit covers 11,232 measured configuration records, including the additional cases listed in Appendix A. Every record contains positive counts for both events, with 100% running time and matching event runtimes within each measurement. Formal measurements request both events in the same perf invocation without an event group. A separate calibration groups them and increases a four-instruction assembly loop from ten million to twenty million iterations. Against the expected increment of forty million retired instructions, the maximum discrepancy across five pairs is 52 instructions. This calibration checks the instruction-count scale; case-study instruction and cycle reductions are taken from the formal measurements.

## 5.2 Simulated Vector Length

### Dependent Arithmetic Microkernels

The two microkernels process 4096 elements at SEW 32 and LMUL 1. For each element group, the RVV body loads an input vector, applies 256 dependent arithmetic instructions to v8, and stores the result. An outer loop repeats this traversal R times: R=131072 for integer add and R=16384 for FP32 subtract. Each repetition rereads the original input; it does not extend the preceding repetition's arithmetic chain. The following control skeleton omits counter bookkeeping and output formatting.

```text
for r = 0 .. R-1:
    src = input; dst = output; remaining = 4096
    while remaining > 0:
        execute RVV body below; obtain vl
        src += vl; dst += vl; remaining -= vl
```

The RVV body below shows the FP32-subtract case. Symbolic operand names replace the inline-assembly bindings; `.rept 256` represents the source's macro expansion into 256 instructions, not a runtime loop. The constant array contains -0.25f. Integer add uses `vmv.v.x v9, increment` in place of the constant load and `vadd.vv v8, v8, v9` in the chain, where increment is a fixed 32-bit addend.

```asm
# FP32 subtract: one element group
vsetvli vl, remaining, e32, m1, ta, ma
vle32.v v9, (constants)
vle32.v v8, (src)
.rept 256
    vfsub.vv v8, v8, v9
.endr
vse32.v v8, (dst)
```

Each instruction reads the v8 written by its predecessor, while different element groups remain independent. At VLEN 512, a full group contains 16 elements; at VLEN 1024, it contains 32 and is translated into two 512-bit components. One traversal therefore requires 256 or 128 groups, respectively, but both perform 4096 × 256 element operations. Verification runs once after all repetitions and is included in the fresh-process timing. The same binary and repetition count are used at every VLEN.

| Microkernel | B, VLEN 512 | B, VLEN 1024 | Width speedup | M1, VLEN 512 | M1, VLEN 1024 | Width speedup |
|---|---:|---:|---:|---:|---:|---:|
| Integer add | 23.864 | 12.568 | 1.90 | 3.048 | 1.924 | 1.58 |
| FP32 subtract | 16.240 | 8.880 | 1.83 | 3.240 | 1.773 | 1.83 |

The baseline improves substantially when VLEN increases from 512 to 1024. Register promotion then lowers the absolute execution times at both widths. Integer addition illustrates why these comparisons must remain separate: after promotion, its width speedup is smaller, yet both promoted configurations are much faster than the baseline. A larger width ratio alone is therefore not a sufficient measure of translation quality.

Increasing VLEN changes both the arithmetic organization and the surrounding loop work: fewer element groups require fewer branches and vector-length updates. The elapsed-time ratios quantify their combined effect.

### Numerical and Application Cases

| Workload | B, VLEN 512 (s) | B, VLEN 1024 (s) | Width speedup |
|---|---:|---:|---:|
| Livermore K1 | 20.851 | 11.239 | 1.86 |
| Livermore K3 | 4.500 | 2.553 | 1.76 |
| LINPACK | 0.289 | 0.265 | 1.09 |
| TSVC s3251 | 0.110 | 0.108 | 1.02 |
| TSVC vbor | 0.061 | 0.057 | 1.07 |
| PolyBench ATAX | 0.096 | 0.084 | 1.14 |
| PolyBench Doitgen | 0.089 | 0.078 | 1.14 |
| Blackscholes | 2.529 | 2.088 | 1.21 |
| LavaMD | 0.483 | 0.328 | 1.48 |
| Streamcluster | 5.315 | 3.683 | 1.44 |
| JPEG encode | 0.617 | 0.652 | 0.95 |
| JPEG decode | 0.302 | 0.342 | 0.88 |
| H.264 CABA3 | 0.443 | 0.499 | 0.89 |
| H.264 crew | 1.695 | 1.987 | 0.85 |

Benefits extend beyond the synthetic chains, but vary with the computation. K1 offers an arithmetic dependency graph replicated across element groups. K3 includes a reduction, so its decomposition and combination work differ. The application cases include additional memory and control work. The observations show useful width scaling in these programs without assigning the same arithmetic explanation or expected factor to every case.

Figures 5.1 and 5.2 show B for every workload/input case. Within each panel, only simulated VLEN changes: the binary, input, and translation method remain fixed. The horizontal axis uses powers of two; elapsed time is linear and lower is better. Each workload retains the same vertical scale in the later method comparisons.

![Baseline width scaling: 1](figures/evaluation_width_baseline_1.pdf)

Figure 5.1. Baseline elapsed time across six VLENs, cases 1–8 of the workload list. Each panel represents one workload/input case; each point is the mean of 26 runs. Lower is better. Panels use separate time scales.

![Baseline width scaling: 2](figures/evaluation_width_baseline_2.pdf)

Figure 5.2. Baseline elapsed time across six VLENs, cases 9–16 of the workload list. Each panel represents one workload/input case; each point is the mean of 26 runs. Lower is better. Panels use separate time scales.

K1 continues to benefit from increasing VLEN, whereas the media baselines become more expensive as capacity grows. These contrasting curves motivate separate evaluations of state reuse and runtime bounds: more register capacity can expose additional independent work, but it can also increase the cost of translating and executing components.

## 5.3 Method Ablation

### Individual Methods

Figure 5.3 adds one method at a time to B. Its upper panels compare M1 with B in the applications used for state-access analysis; the lower panels compare M2 with B for the two H.264 inputs used in the skipped-work diagnostic. Comparisons are made at the same VLEN, so the gap between curves measures the method's net effect rather than a change in simulated width.

![Individual-method width comparisons](figures/evaluation_method_width.pdf)

Figure 5.3. Isolated method comparisons over six VLENs: B versus M1 for Blackscholes and LavaMD, and B versus M2 for H.264 crew and CABA3. Each panel preserves the corresponding baseline-view scale. Lower is better.

### Complete Ablation

The table gives the VLEN-1024 elapsed times for all 16 workload/input cases introduced in Section 5.1, in the same source-family order. Each entry is the mean of 26 complete-process measurements. Figure 5.6 presents the corresponding reductions relative to B; Appendix A retains all six widths.

| Workload | B (s) | M1 (s) | M2 (s) | Both (s) |
|---|---:|---:|---:|---:|
| Integer add | 12.568 | 1.924 | 12.667 | 1.928 |
| FP32 subtract | 8.880 | 1.773 | 8.873 | 1.821 |
| Livermore K1 | 11.239 | 3.005 | 11.308 | 3.002 |
| Livermore K3 | 2.553 | 2.549 | 2.528 | 2.528 |
| LINPACK | 0.265 | 0.265 | 0.266 | 0.266 |
| TSVC s3251 | 0.108 | 0.105 | 0.105 | 0.104 |
| TSVC vbor | 0.057 | 0.050 | 0.057 | 0.050 |
| PolyBench ATAX | 0.084 | 0.084 | 0.084 | 0.084 |
| PolyBench Doitgen | 0.078 | 0.079 | 0.078 | 0.078 |
| Blackscholes | 2.088 | 1.786 | 2.082 | 1.774 |
| LavaMD | 0.328 | 0.198 | 0.330 | 0.197 |
| Streamcluster | 3.683 | 3.683 | 3.727 | 3.725 |
| JPEG encode | 0.652 | 0.655 | 0.629 | 0.626 |
| JPEG decode | 0.342 | 0.328 | 0.322 | 0.302 |
| H.264 CABA3 | 0.499 | 0.498 | 0.440 | 0.441 |
| H.264 crew | 1.987 | 1.980 | 1.692 | 1.701 |

Figures 5.4 and 5.5 include all four configurations for every case. Following one line compares VLENs under a fixed method; comparing lines at one VLEN isolates the configuration change. The full ablation retains cases with small or negative improvements.

![Complete four-method width comparison: 1](figures/evaluation_width_all_1.pdf)

Figure 5.4. B, M1, M2, and Both across six VLENs, cases 1–8. Panel order and per-workload axis limits match Figure 5.1. Each point is the mean of 26 runs. Lower is better.

![Complete four-method width comparison: 2](figures/evaluation_width_all_2.pdf)

Figure 5.5. B, M1, M2, and Both across six VLENs, cases 9–16. Panel order and per-workload axis limits match Figure 5.2. Each point is the mean of 26 runs. Lower is better.

![Complete method ablation at VLEN 1024](figures/evaluation_ablation.pdf)

Figure 5.6. Elapsed-time reductions for all 16 workload/input cases at VLEN 1024. Each bar is 100(1 - T(X,1024)/T(B,1024)), using the arithmetic means of 26 rounds. Positive values denote less time than B; negative values denote more time. B is the zero reference. Colors and hatching identify M1, M2, and Both.

M1 reduces Blackscholes and LavaMD time by 14.5% and 39.7%, respectively. M2 alone has little net effect on their mean elapsed times under these settings. H.264 shows the reverse pattern: M2 reduces crew and CABA3 time by 14.8% and 11.9%, while M1 changes are small. JPEG decoding benefits from the integrated configuration more than either isolated configuration.

Both is not uniformly faster than each individual method. For crew, its mean is about 0.6% above M2. The integrated implementation changes value retention and component/control-flow organization together; its effect is not an additive combination of independently saved percentages. Small mean differences are reported as such rather than treated as a stable ranking.

### Blackscholes: Reusing Arithmetic Intermediates

Blackscholes computes option prices through floating-point arithmetic and approximations to elementary functions. Cycle sampling locates substantial activity in the vector option-pricing function. The following consecutive instructions occur at its hot block starting at address 0x105a0:

```asm
vfmul.vf v31, v7, fa4
vfadd.vv v20, v20, v31
vfmul.vv v31, v22, v24
vfmul.vv v25, v23, v25
vfmul.vv v23, v23, v23
```

The first multiplication produces a value consumed by the addition; the next multiplication then defines a new value of v31. At VLEN 1024 with FP32 elements and LMUL 1, each instruction operates on two 512-bit components. The baseline stores both components of the first product to vector-register state and loads them again for the addition. In the captured x86 code, these stores address offsets 0x3ed0 and 0x3f10 from the CPU-state pointer. The addition subsequently reloads those same locations.

M1 instead retains the products in zmm15 and zmm16. Its two additions directly consume these registers, using `vaddps zmm17{k1},zmm4,zmm15` and `vaddps zmm18{k2},zmm5,zmm16`. The earlier products need not be published after their last use because the following multiplication overwrites v31; the final required definitions are published at the run boundary. This is removal of intermediate state transfers, not removal of the multiplications or additions.

At VLEN 1024, M1 reduces complete-process time from 2.088 to 1.786 seconds, or 14.5%. Retired instructions decrease by 6.9% and counted cycles by 14.7%. The disassembly identifies a concrete source of eliminated work; the process-wide counters include other arithmetic, control flow, and translation. M2 changes the elapsed time little in this case, whereas M1 addresses reuse within its arithmetic sequences.

### LavaMD: Retaining Accumulated Values

LavaMD evaluates particle interactions. Its vector kernel combines particle coordinates, evaluates an interaction factor, and accumulates contributions. The hot block starting at address 0x10bac includes the following sequence:

```asm
vfadd.vf  v15, v15, fa2
vfmul.vf  v19, v16, fa1
vfmacc.vf v19, fa0, v17
vfmacc.vf v19, ft4, v18
vfsub.vv  v15, v15, v19
vfmul.vf  v15, v15, fa3
```

Here v19 is an accumulator: the multiplication defines it, both fused multiply-adds update it, and the subtraction consumes it. The value of v15 also passes from addition to subtraction and multiplication. In the baseline, the boundaries between these RISC-V instructions incur repeated state stores and reloads for each component. M1 carries the intermediate values through host registers within an admitted run. The captured x86 sequence retains packed additions, multiplications, and `vfmadd231ps` operations; it connects their operands through registers instead of publishing each intermediate value.

This longer reuse chain offers more removable state traffic than a single producer-consumer pair. It does not make the accumulator updates independent: their arithmetic dependency remains. At VLEN 1024, elapsed time falls from 0.328 to 0.198 seconds under M1, a 39.7% reduction. Retired instructions decrease by 27.5% and counted cycles by 43.7%. These observations support reducing state-transfer overhead along dependent arithmetic chains, rather than attributing the improvement to additional independent arithmetic.

### H.264 crew: Bounding Widening Operations

The crew input exercises a different opportunity. Cycle sampling identifies the luma deblocking routine, `ff_h264_loop_filter_luma_8_rvv`, as a hot routine. Deblocking filters reconstructed pixels around block boundaries. Its caller sets a short element range, and the routine uses widening arithmetic for pixel differences and sums. The excerpts below separate the caller's configuration from the callee's arithmetic:

```asm
# Caller configuration before the filter call
vsetivli zero, 16, e8, m1, ta, ma

# Arithmetic in ff_h264_loop_filter_luma_8_rvv
vaaddu.vv v14, v10, v11
vwsubu.vv v16, v9,  v12
vwaddu.vv v18, v8,  v14
vwaddu.vv v20, v13, v14
vnsra.wi  v24, v16, 2
vnsrl.wi  v14, v18, 1
vnsrl.wi  v15, v20, 1
```

The configured vl is 16, even when VLEN is 1024. Widening from 8-bit sources produces a 16-bit destination register group with effective LMUL 2. Its capacity is 2048 bits, or four 512-bit destination components containing 32 elements each. Only the first can contain elements below vl; the others begin at element indices 32, 64, and 96.

Without M2, these high components still have emitted arithmetic bodies, although their results do not contribute to the requested element range. With M2, comparisons against vl branch past them. The captured x86 code contains the low-component `vpsubw`, followed by bounds checks that bypass the high-component subtraction bodies. Per-element masking still handles the partial first component. Thus M2 removes unnecessary component execution, rather than widening the useful pixel calculation.

For crew, M2 reduces time from 1.987 to 1.692 seconds, or 14.8%; retired instructions and counted cycles decrease by 10.9% and 15.2%. M1 alone gives little improvement. This case shows why capacity-based decomposition must be bounded by the operation's runtime element range.

### H.264 CABA3: The Same Mechanism on Another Input

CABA3 uses the same decoder binary and reaches the same luma deblocking routine shown above. Sampling also identifies the chroma deblocking routine, whose widening difference and narrowing operations have the same short-range opportunity. It is a second input to the same implementation, not a different filtering algorithm.

At VLEN 1024, M2 reduces CABA3 time from 0.499 to 0.440 seconds, or 11.9%. Retired instructions decrease by 8.8% and counted cycles by 13.1%. The improvement has the same direction as crew but a different magnitude. Both inputs exercise bounded widening arithmetic; their complete-process times include different amounts of other decoding work. The measurements do not assign all saved cycles to a single filter.

The code captures for these four cases use the timing campaign's translator executable and workload binaries. All eight diagnostic executions, comprising the baseline and the relevant method for each case, match their reference outputs. Cycle sampling selects the code to inspect; the reported times and instruction/cycle reductions remain those of the 26-round campaign, not the diagnostic runs.

## 5.4 External Systems

External comparisons address two questions: execution efficiency at the same simulated VLEN, and the additional benefit available when a system can use longer RVV vectors. The same-VLEN results use a separate four-round campaign. Each comparison holds the RISC-V binary and input fixed at the stated simulated VLEN. Translation or compilation during the measured process is included; compiler children share the same one-core allocation, and libriscv does not reuse compiled artifacts across runs. These means are kept separate from the 26-round ablation and the supported-width experiment below.

### Same-VLEN System Comparison

| Workload | rvdbt B (s) | rvdbt Both (s) | QEMU (s) | rv32emu (s) |
|---|---:|---:|---:|---:|
| Integer add | 12.569 | 1.921 | 4.117 | 240.626 |
| FP32 subtract | 8.873 | 1.770 | 103.433 | 82.211 |
| Livermore K1 | 11.244 | 3.012 | 39.041 | Error |
| Livermore K3 | 2.550 | 2.525 | 9.340 | Error |
| LINPACK | 0.265 | 0.265 | 1.487 | Error |
| TSVC s3251 | 0.109 | 0.103 | 0.347 | Error |
| TSVC vbor | 0.057 | 0.052 | 0.098 | Error |
| PolyBench ATAX | 0.086 | 0.084 | 0.273 | Error |
| PolyBench Doitgen | 0.079 | 0.078 | 0.195 | Error |
| Blackscholes | 2.094 | 1.777 | 6.167 | Error |
| LavaMD | 0.327 | 0.201 | 2.162 | Error |
| Streamcluster | 3.687 | 3.731 | 17.258 | Timeout |
| JPEG encode | 0.658 | 0.632 | 1.189 | Error |
| JPEG decode | 0.342 | 0.310 | 0.936 | Error |
| H.264 CABA3 | 0.497 | 0.453 | 1.175 | Error |
| H.264 crew | 1.985 | 1.701 | 5.806 | Error |

rv32emu has its first JIT tier enabled. Error denotes an execution error or failure to produce a validated output; Timeout denotes no completion within the 120-second probe. Neither entry is an elapsed-time measurement.

At VLEN 1024, rvdbt Both has a lower mean elapsed time than QEMU in all 16 reported cases. Among applications, the speedups include 3.47 times for Blackscholes, 3.41 times for H.264 crew, and 1.88 times for JPEG encoding. The per-instruction baseline is already faster than QEMU on these applications; the fixed-VLEN ablation in Section 5.3 identifies the additional contribution of the two methods.

Integer add illustrates why the execution path matters. QEMU is faster than rvdbt B but slower than Both. In the captured QEMU translation at VLEN 1024, the first RVV add expands into four YMM additions with state loads and stores. The next RVV add reuses the YMM values without reloading them, but still stores all four results. Thus the observed difference is not the absence of value forwarding in QEMU: rvdbt's admitted promotion sequence can also defer intermediate stores, and its main path uses wider host operations. In contrast, the measured QEMU floating-point-subtract translation calls an RVV helper rather than emitting packed subtraction inline [QEMU-RVV]. These are distinct sources of system-level overhead.

The two numeric rv32emu entries are four-run means. RVV blocks use the interpreter; scalar blocks can use the first JIT tier.

The rv32emu comparison enables RVV and the first JIT tier, with the LLVM second tier disabled. The tested revision lacks the second-tier vector handlers, including `t2c_vsetvli`; enabling EXT_V, JIT, and T2C together causes a build failure. The measurements therefore use the available first-tier-enabled configuration.

Application compatibility depends on both the ISA and the execution environment. Blackscholes and H.264 encounter unsupported system-call or block-translation errors. LavaMD still encounters such errors after correcting guest-argument forwarding; JPEG encode and decode reach an emulator assertion. Livermore K3 requests SEW 64, which the rv32emu build rejects by setting vill and vl to zero. A debugger trace records repeated illegal-instruction traps and an unchanged remaining-element count, explaining its earlier timeout. Streamcluster also exceeds the 120-second probe; its log reports unsupported mmap and writev calls. Neither is a valid slow execution of the workload. QEMU's direct vector path also uses a different maximum host width from rvdbt's main path; these are complete-system comparisons, not controlled host-width ablations.

libriscv is evaluated at its tested 256-bit RVV configuration. The table includes the 11 cases from the workload set with validated outputs in all three execution modes; all times are in seconds. The remaining five cases encounter unimplemented integer vector forms: `vsub.vx` in Blackscholes and `vmax.vx` in JPEG and both H.264 inputs. Debugger traces identify these first failing instructions in the measured executable. Those cases therefore contribute no elapsed-time results.

| Workload | rvdbt Both (s) | QEMU (s) | libriscv interpreter (s) | TinyCC (s) | System C (s) |
|---|---:|---:|---:|---:|---:|
| Integer add | 5.892 | 10.732 | 170.349 | 162.734 | 153.083 |
| FP32 subtract | 5.498 | 107.550 | 10.730 | 20.271 | 2.032 |
| Livermore K1 | 10.010 | 78.283 | 26.631 | 12.127 | 3.064 |
| Livermore K3 | 8.587 | 18.135 | 6.653 | 4.310 | 2.020 |
| LINPACK | 0.361 | 1.586 | 1.166 | 0.584 | 1.517 |
| TSVC s3251 | 0.113 | 0.385 | 0.334 | 0.158 | 9.512 |
| TSVC vbor | 0.054 | 0.107 | 0.071 | 0.082 | 9.875 |
| PolyBench ATAX | 0.129 | 0.318 | 0.238 | 0.168 | 1.049 |
| PolyBench Doitgen | 0.115 | 0.227 | 0.164 | 0.118 | 1.011 |
| LavaMD | 0.386 | 2.376 | 1.181 | 1.017 | 4.086 |
| Streamcluster | 8.834 | 23.287 | 10.273 | 6.748 | 47.837 |

The system C compiler produces the fastest result in several floating-point cases even with compilation included. For FP32 subtract, compilation takes approximately 1.234 seconds within the 2.032-second process time. The captured host code contains 256 dependent YMM `vsubps` operations without intervening loads, stores, calls, or branches; the result is stored after the chain. The compiler preserves the arithmetic while removing intermediate vector-state transfers. By contrast, the captured integer-add path calls an RVV handler for each add. Exposing the floating-point operations to native optimization repays compilation cost in this experiment, whereas the handler-based integer path remains expensive [libriscv].

### Supported Vector Lengths

A second four-round experiment keeps each binary and input fixed while sweeping rvdbt Both from VLEN 128 through 4096. The two libriscv C-compilation modes retain their tested VLEN 256 configuration. Output validation uses the reference for each width, since a change in vector length can change floating-point reduction order. The table reports the 11 compatible cases from the thesis workload set. The asmjit column comes from a separate four-run campaign on the revision cited in Section 2.4; it is not pooled with either C-compilation mode. Every time includes translation and execution, in seconds.

| Workload | System C 256 | TinyCC 256 | Asmjit 256 | Both 256 | Both 1024 | Both 4096 |
|---|---:|---:|---:|---:|---:|---:|
| Integer add | 153.365 | 162.503 | 168.866 | 5.898 | 1.927 | 0.829 |
| FP32 subtract | 2.034 | 19.801 | 12.425 | 5.478 | 1.776 | 0.989 |
| Livermore K1 | 3.062 | 12.124 | 18.560 | 10.019 | 3.005 | 1.688 |
| Livermore K3 | 2.018 | 4.304 | 4.692 | 8.571 | 2.524 | 1.203 |
| LINPACK | 1.514 | 0.582 | 1.216 | 0.361 | 0.265 | 0.225 |
| TSVC s3251 | 9.546 | 0.157 | 0.362 | 0.112 | 0.102 | 0.091 |
| TSVC vbor | 9.863 | 0.081 | 0.100 | 0.052 | 0.050 | 0.055 |
| PolyBench ATAX | 1.049 | 0.166 | 0.248 | 0.127 | 0.084 | 0.073 |
| PolyBench Doitgen | 1.008 | 0.118 | 0.167 | 0.116 | 0.078 | 0.076 |
| LavaMD | 4.118 | 0.988 | 0.951 | 0.382 | 0.197 | 0.201 |
| Streamcluster | 47.794 | 6.731 | 7.865 | 8.826 | 3.732 | 3.191 |

At VLEN 256, system C outperforms rvdbt on FP32 subtract, K1, and K3, while TinyCC is faster on Streamcluster. Figure 5.7 shows how these four comparisons change as rvdbt uses longer vectors. FP32 subtract becomes faster than the corresponding libriscv reference at VLEN 1024, and Streamcluster at 512. K1 reaches approximately the same time at 1024, and K3 becomes faster at 2048. At 4096, the speedups over the faster measured C-compilation mode are 2.06, 1.81, 1.68, and 2.11 times for FP32 subtract, K1, K3, and Streamcluster, respectively. No recompilation of the RISC-V binary is required between widths.

![Long-vector execution relative to fixed-width libriscv configurations](figures/evaluation_external_capacity.pdf)

Figure 5.7. Complete-process times for the four cases in which a libriscv C-compilation mode is faster than rvdbt at VLEN 256. The green curve varies rvdbt VLEN under Both; each horizontal reference is the faster measured libriscv C-compilation mode at its fixed VLEN 256. Each point or reference averages four runs from the supported-width experiment. The reference is not a libriscv width sweep. Lower is better.

This reversal demonstrates a benefit of supporting longer RVV execution in addition to optimizing each host-vector operation. It is a comparison of available vector-length configurations, whereas the preceding tables compare systems at equal VLEN. The 4096 configuration has a lower mean time than the three measured compiling modes in all 11 reported cases, but 4096 is not always rvdbt's best width: LavaMD and TSVC vbor are faster at 1024. Longer vectors change loop grouping as well as the number of host components; the resulting balance depends on the computation. Section 5.3 separately measures how state reuse and runtime bounds affect that balance at a fixed VLEN.

### Comparison Coverage

The external timing set comprises systems that execute the same RV32 binaries with validated outputs. HQEMU supplies relevant SIMD transformation techniques but has no RISC-V frontend in its public release. PasRISCV and Berberis target RV64 environments, so their source-level capabilities are discussed in Section 2.4 rather than assigned times for incompatible binaries. The comparisons establish performance for the tested configurations; the implementation analysis explains why instruction coverage and the choice between inline SIMD and handlers matter to those results.

### Functional Simulator Reference Paths

Whisper and Spike also execute long RVV on x86-64. Their functional-simulation paths provide a separate reference from the preceding JIT comparisons. The following measurements use the same archived RV32 ELF, input, VLEN and physical core within each pair, with four complete-process runs. Spike additionally executes a proxy kernel, including its startup and system-call handling. Each rvdbt mean comes from its corresponding paired campaign; means from different campaigns are not pooled.

| Reference system | Workload | VLEN | rvdbt Both (s) | Reference (s) |
|---|---|---:|---:|---:|
| Whisper | ATAX | 1024 | 0.086637 | 2.221454 |
| Whisper | ATAX | 4096 | 0.075418 | 1.975290 |
| Whisper | LINPACK | 1024 | 0.268332 | 12.872439 |
| Whisper | LINPACK | 4096 | 0.227861 | 12.638133 |
| Whisper | s3251 | 1024 | 0.106536 | 2.664934 |
| Whisper | s3251 | 4096 | 0.095214 | 2.504711 |
| Spike + proxy kernel | ATAX | 1024 | 0.087979 | 1.052708 |
| Spike + proxy kernel | ATAX | 4096 | 0.076149 | 0.996282 |
| Spike + proxy kernel | LINPACK | 1024 | 0.268234 | 4.836920 |
| Spike + proxy kernel | LINPACK | 4096 | 0.226214 | 4.967119 |
| Spike + proxy kernel | s3251 | 1024 | 0.106129 | 0.961899 |
| Spike + proxy kernel | s3251 | 4096 | 0.093161 | 0.897359 |

The differences encompass interpretation, architectural-state processing and execution-environment services. They establish that long-vector capacity is available in other systems while separating that capability from the execution efficiency of a native SIMD path. Renode also passes a 4096-bit bare-metal vector-add diagnostic, but its virtual-platform setup has not been matched to the application environment. Pydrofoil passes three 512-bit vector-add probes; these are execution and trace checks rather than application timings. Neither is assigned a performance ratio [Spike, Whisper, Renode, Pydrofoil].

## 5.5 Findings and Scope

The results support three connected findings. First, a longer simulated vector can reorganize independent element-group computations and reduce loop work enough to improve execution on a fixed-width host. Second, the benefit can be dominated by the cost of repeatedly materializing vector state; register promotion substantially reduces that cost where compatible sequences offer reuse. Third, larger capacity can be harmful when the runtime element range stays short; bounds-based omission limits that growth.

The microkernels expose repeated state transfers along long arithmetic chains. The application measurements show whether reducing state traffic and unused component work improves complete-process time, which also includes translation, memory access, and control flow.

The quantitative results apply to the measured AMD host. Other processors can differ in vector instruction latency, throughput, execution width, and frequency behavior. Likewise, the optimized instruction subset and workload binaries determine which paths are exercised. Extending the measurements to another microarchitecture and an optimizing tier would test the portability of the observed balance between reuse, useful work, and compilation cost.

## 5.6 Limitations and Extensions

**Optimization scope.** Promotion operates within an admitted instruction sequence in a translation block. Configuration changes, incompatible state effects, cross-component dependencies, and register demand constrain that sequence. A reduction or permutation therefore cannot inherit the element-wise reordering rule merely because its operands are vectors. Extending promotion requires explicit dependence and state-update rules for the additional forms. Helpers remain a semantic implementation option; replacing a helper with inline SIMD requires preserving its rounding, exception, masking, and memory-access behavior.

**Runtime bounds.** Bounds remove only the suffix known to lie beyond `vl`. They retain partial-component lane selection, final stores, and completion updates. When all components are needed, the checks can add work without removing arithmetic. Full-length guards can avoid checks on eligible paths; extending that optimization requires facts about runtime configuration, not workload-specific assumptions. Figure 5.4 and Figure 5.5 report the net effect, including cases where the integrated method does not beat an individual method.

**Optimizing compilation.** The reported results use the lightweight JIT, not the online LLVM tier. An extension should pass vector operations and their state effects to LLVM, establish a common state interface for entering and leaving compiled regions, and install code only when its configuration assumptions hold. HQEMU's hot-region compilation, Instrew's state interface, and Arancini's shared representation provide relevant designs [HQEMU, Instrew, Arancini]. Evaluation must include compilation and installation in total process time and measure whether execution reaches the optimized region before the program finishes.

**Hardware and measurement.** The main matrix uses one AMD processor. Register capacity, execution throughput, scheduling-window size, and frequency behavior can change the tradeoff on Intel or another AMD implementation. Retired instructions quantify changes in executed work; total cycles and elapsed time measure their aggregate cost. They do not identify which pair of vector instructions issued together. A cross-microarchitecture study should keep binaries, inputs, and timing boundaries comparable while inspecting the generated instructions and instruction-specific hardware behavior.

**Coverage.** The tests establish behavior for the exercised instruction forms, configurations, and workloads, rather than complete RVV conformance. The 16 reported cases include extracted kernels and multiple inputs to one decoder. External systems also differ in instruction support and operating-system services. The comparison therefore separates completed application timings from diagnostic probes, execution failures, and timeouts.

## 5.7 Functional Validation

### External Tests and Result Checking

The inventory counts mnemonic and operand variants separately: `vadd.vv`, `vadd.vx`, and `vadd.vi` are three forms, and memory widths and segment counts are enumerated. It contains 627 forms, of which 32 indexed-memory forms require 64-bit indices outside the RV32/ELEN64 profile, leaving 595 applicable forms [RVV]. Appendix B lists this scope; the implementation repository provides the corresponding per-suite form table and runnable external fixtures [rvdbt-impl]. A checked form requires a binding between the retained target operation and the output assessed by its checker. Source presence, compilation and program completion are recorded separately.

The validation chain retains the external input, establishes its expected result through the original assertion or an independent reference, and compares the device under test (DUT), rvdbt, against that result. CHIPS generates self-checking programs using modified Spike reference results [CHIPS-tests]. Architectural tests retain expected values and signature comparisons; Ara retains typed vector, scalar, memory and CSR predicates [ACT-tests, Ara-tests]. RVV-ATG binds target macros to Spike signatures and compares the same ELF's QEMU and DUT output [RVV-ATG]. SiFive RIF binds emitted operation symbols to unchanged operation-result goldens [SiFive-RIF]. Reference failures and original DUT failures remain distinct from accepted comparisons.

Environment adaptations change startup, reporting or ABI interfaces while retaining the external calculation and assertions. Changes to generation geometry or configuration expectations are labeled separately: CHIPS separates XLEN 32 from ELEN 64, with disclosed local configuration constants; specification-based state observers and tests generated through external APIs are derivatives. Their results do not retroactively validate an unsafe or blocked original test. Exact inputs, adaptations, checker scopes and reference identities are linked in Appendix B.

| External source | Target/result-checked forms | Checked output |
|---|---:|---|
| CHIPS Alliance Vector Tests | 595 | Selected destination words, store prefixes and explicit CSR checks |
| RISC-V Architectural Tests | 590 | Selected destination regions, scalar results and flags |
| RVV-ATG | 434 | Target-bound signatures; e64 extraction observes low32 |
| Ara vector tests | 422 | Original typed vector, scalar, memory and CSR predicates |
| SiFive RIF | 200 | Emitted operation results bound to original goldens |
| Union | 595 | Overlapping sets; counts are not added |

The sources complement one another at specific forms. The ACT checked set lacks `vfmv.f.s`, `vfwcvt.f.f.v`, `vsetivli`, `vsetvl` and `vsetvli`; Ara supplies result checks for all five. The three configuration forms retain Ara's original comparisons and same-ELF Spike state observations, rather than relying only on locally specified configuration constants. Combining these sources therefore closes identifiable form-level gaps, while each checker retains its own state and configuration limits.

Checker execution also matters. ACT obtains expected signatures from Sail, but its guest-side data-vector length checker uses `vmsne.vv` to construct a mismatch mask and `vfirst.m` to find a mismatching element. Those instructions execute on the DUT. The independent expected signature therefore does not eliminate dependence on the DUT's comparison instructions [ACT-tests].

The candidate-specific index also establishes a 595-form checked union for the clean correctness build. Historical candidates remain separately identified. The table counts forms whose results are checked at the recorded configurations, including direct and helper routes. Sequence tests use a different unit of verification: RVVTS and RVISmith compare recorded sequence or program outputs involving 58 and 43 forms, respectively [RVVTS, RVISmith]. These counts describe the operations participating in those sequences, not individually checked instructions, and are excluded from the table's checked-form union.

The retained external CHIPS campaign provides 11,532 accepted program executions on the clean correctness build, distributed as follows. Each configuration executes the same registered cases at the indicated width; B, M1, M2 and Both are counted separately. An additional 212 failure-control executions produce the required failure exit and message. These controls check failure propagation and are excluded from instruction-form coverage.

| VLEN (bits) | Per configuration | Four configurations |
|---:|---:|---:|
| 128 | 2,364 | 9,456 |
| 256 | 27 | 108 |
| 512 | 27 | 108 |
| 1024 | 401 | 1,604 |
| 2048 | 27 | 108 |
| 4096 | 37 | 148 |
| Total | 2,883 | 11,532 |

This distribution is not a sweep of all 595 forms at every width. The per-form records identify the executed programs and their original assertions; source locations provide the SEW, LMUL, requested VL and mask context. Requested VL and source presence are distinguished from observed runtime state and optimized-path admission. Historical-build executions have separate records and are not added to this table.

The two ACT source campaigns retain separate Sail signatures and original self-checkers; the indexed-memory revision does not increase the form union [ACT-db2]. Two privileged-state reference blockers remain excluded. Ara extraction retains each supported block's literals, assertions and initialization, including round-toward-zero for division and square root; these are block acceptances, not complete mixed-precision file passes. Reserved different-width source overlap and source objects shorter than vector loads retain their original dispositions [RVV].

The adapted RIF reductions preserve the original inputs, reduction graph and scalar predicates, and compare the same ELF with QEMU and all four DUT configurations. The host scalar evaluator reads uninitialized storage, and a zero seed absorbs some AND/unsigned-min results. Agreement therefore supplies only the stated scalar endpoint evidence, without additional independent-form or optimization-admission credit [SiFive-RIF].

A concrete example is the adapted CHIPS `vadd.vv` file at VLEN 1024 and LMUL 8. It retains 26 targets and 6,656 original checker words. The disjoint destination and source groups are v8–v15, v16–v23 and v24–v31. One masked SEW-64 target requests AVL 63 and updates 38 enabled lanes, while the original comparisons check the destination group, including preserved masked-off and tail values under tu/mu. The modified-Spike generation, original self-check, same-ELF QEMU reference and clean DUT B, M1, M2 and Both runs all pass. This checks the stated destination geometry and preservation; it does not observe every register or establish promotion admission.

### Directed Matrices and State Comparison

External original suites and project-authored per-form directed matrices serve complementary purposes: the former retain independently authored workloads and predicates; the latter isolate architectural effects at explicit boundaries. Each directed case initializes vector registers, scalar operands, memory where applicable and vector/FP control state; executes the encoded target; then captures a poststate snapshot. A host-side checker first validates the recorded prestate and packet identity, applies an independent specification predicate, and compares defined results with a pinned executed Spike or Sail reference. The same target/observer body is used for the reference and DUT. Successful process exit alone is insufficient; missing/truncated packets, timeouts, wrong target bindings or predicate failures reject acceptance.

The manifest indexes each mnemonic/operand form and its actual selected SEW, LMUL, VLEN, VL/VLMAX, mask, initialized `vstart`, tail/mask policies, operand EMUL, rounding mode and overlap class. Boundary cases include zero/partial/full lengths and positions around source and destination host chunks. Dimensions vary by family: marginal values are not a Cartesian product, and declared values are checked against captured state where observed. The common observer checks all 32 logical vector registers and ten vector/FP CSRs; family observers add the relevant scalar registers, memory and intermediate sequence values. Missing observations remain explicit in the form index.

Oracles follow the operation's permitted outcomes. Integer predicates use exact bit arithmetic; floating-point predicates use exact rational decoding and rounding rather than host casts or DUT-generated goldens. Defined active results and sticky flags are compared exactly. Inactive agnostic elements use the permitted old-or-all-ones set, while prestart and undisturbed elements preserve their required bytes. Unordered floating-point reductions admit finite inputs only when the predicate establishes exact representability for every permitted reduction tree, together with separately bounded special-value cases. Arbitrary inexact unordered sums are outside that oracle. Illegal overlap, unsupported precision and reserved entry conditions remain separate from ordinary successful cases. Scalar-insertion comparisons with nonzero starts use the disclosed permissive Sail mode; default-mode traps remain separate reference attempts.

### State Preservation and Optimized Paths

The completed sequence matrix checks 2,418 cases per Reference/B/M1/M2/Both arm, comprising 9,672 DUT checks. It covers declared integer/FP sequences, initialized starts, boundary lengths, alias/overwrite behavior and both same-PC cache orders on one frozen correctness build. Original ELFs and validated reference packets are reused; this replay performs no reference executions or ELF rebuilds. Full acceptance uses the trace-disabled configuration; the trace-enabled configuration has only its retained focused acceptance.

Optimization admission is established by joining target PCs, generated host code and executed frame records to architectural snapshots. The audit checks retained producer-to-consumer values for M1, low-component consumers, and Both's publication of completed values before the next component bound and its skip join after required stores. Same-PC visits with different first observed vector types test specialization and guarded fallback. These observations verify actual paths in the declared sequences; enabling M1/M2 switches or checking all indexed forms does not establish universal optimization admission.

### Validation Findings

Directed comparisons exposed three semantic defects. Fused multiply-add of zero and infinity must accrue NV even when a quiet-NaN addend already determines the canonical NaN result; the old x86 FMA-based route produced the correct value but missed NV. RMM FP64-to-FP32 narrowing at a minimum-normal boundary produced the correct rounded bits but omitted UF: tininess after precision rounding with an unbounded exponent requires UF together with NX. Scalar insertion by `vmv.s.x` or `vfmv.s.f` must preserve element 0 whenever initial `vstart` is nonzero; the old `vstart < vl` guard incorrectly wrote that prestart element. The corrected insertion requires `vstart == 0` and `vl > 0`, and still clears `vstart` on normal completion. Retained original failures, unchanged predicates and before/after packets establish these findings; their family builds and later integration remain separately identified in the reproduction records.

### Versions and Limits

The final correctness campaign uses one frozen RV32/ELEN64 Release executable with 512-bit QCG host components for directed matrices, external replay and sequence validation. Earlier family and external results retain their historical identities. The 384 means reported earlier belong to the original frozen performance executable. Correctness bindings retain executable, library, ELF and complete flags; rebuilding the integrated source creates a new executable identity with no inherited receipt credit.

Full register/CSR/memory state, memory-access suppression, intermediate flags, write-history-aware agnostic choices, arbitrary overlap and restart remain incomplete outside the accepted witnesses. RIF uses one seed, length 500 and VLEN 128; ATG uses frozen e32/m1 and limited e64 extensions. RVISmith retains wildcard/NaN normalization and no nonzero input high32 evidence. Source and checker blockers, including unsafe original store outputs, are retained in Appendix B.

Fault handling is evaluated separately from instruction-form coverage. The runtime registers synchronous SIGSEGV/SIGBUS actions and delivers faults identified at checked-helper accesses. For supported singleton memory instructions, the generated code also records the exact host access sites and exits to the dispatcher after a fault. QCG ends a promoted sequence at a memory instruction so that preceding architectural results are available at this boundary. Local tests inspect register, memory and exception state after the first fault; the scalar-memory and memory-boundary suites check 44 and 10 terminal snapshots, respectively. Eight retained signal-delivery executions across B, M1, M2 and Both check first-element faults and later fault-only-first behavior. These guest handlers exit without returning to retry the instruction. Handler return and complete guest instruction restart remain unverified.

The signal interface also uses checked copies for action, mask and frame buffers. Local regressions include inaccessible pages and truncated file backing, with 2,063 interface checks, 256 floating-point-state roundtrips and 192 invalid-frame rejections. These tests invoke the host interface directly; they do not execute a returning guest handler.

The final same-build directed replay completes all 102 ordinary entries for the 595 applicable forms: 3,017,262 cases per B/M1/M2/Both arm and 12,069,048 positive DUT packet checks. Focused witnesses add 2,256 positive checks, giving 12,071,304 positives in total; 592 focused denial controls are counted separately. Every accepted positive passes the original specification/reference predicates and an independent reread of the captured outputs. The replay reuses frozen ELFs and validated reference packets, with no new reference executions or ELF builds. Per-form records join actual results to accepted case IDs, dimensions, pinned sources and checker bindings; reserved source declarations remain outside the positive denominator.

The same executable also completes 21,316 external commands: 11,532 positive CHIPS executions and 212 failure controls, 7,668 ACT passes, and 1,888 whole-file Ara passes plus 16 scoped acceptances. Each of B, M1, M2 and Both accounts for 5,329 commands. Ara's scoped results accept only TEST_CASE1/2 and retain the original TEST_CASE3/4 failures; two ACT reference blockers remain excluded. These are new DUT executions on the final correctness executable, separately recorded from the historical external campaign. The sequence matrix above uses that same executable, while its 9,672 DUT checks remain a separate denominator. The 595 applicable forms within the 627-form inventory establish finite checked matrices, with actual exception, trace and oracle limits retained, rather than all possible RVV inputs.

---

# 6. Conclusion

This thesis implements a lightweight RVV JIT in rvdbt, mapping long vector operations to fixed-width x86 SIMD. Increasing simulated VLEN can group independent element computations within one translated loop iteration, providing an opportunity for instruction-level parallelism and reducing loop-control work. The two optimizations address costs that can offset this benefit: repeated architectural-state transfers and work on unused vector components.

Vector register promotion retains values across compatible instructions while preserving the architectural results required at the sequence boundary. Bounded component batches control the associated register demand. Runtime vector bounds omit suffix components outside the operation's runtime body range and preserve the required completion behavior. The integrated implementation separates what the architecture can represent from what must remain resident and what must actually be computed.

On the evaluation host, the same binary benefits from larger simulated VLEN in dependent microkernels and several numerical and application cases. At VLEN 1024, promotion reduces elapsed time by 14.5% for Blackscholes and 39.7% for LavaMD, while runtime bounds reduce two H.264 decoding times by 14.8% and 11.9%. The full width sweep also shows why the two methods are complementary: numerical computation can continue benefiting from wider vectors, whereas short-vector media operations principally need protection against unused-capacity overhead.

Functional validation binds external targets to their checked outputs for 595 applicable forms, including a separately indexed 595-form union on the clean correctness candidate. Selected state and sequence witnesses examine preservation and actual optimization admission. Section 5.7 distinguishes these bounded checks from configuration coverage and the remaining guest-signal, precise fault-recovery and restart gaps. The correctness candidates remain separate from the performance campaign.

External performance results show that semantic representation and compilation strategy both matter. A lightweight path can deliver strong first-run performance, while a system C compiler can outperform it when the generated vector code repays compilation. An optimizing RVV tier should therefore preserve vector semantics and state boundaries rather than merely compile opaque helper calls.

Future work can extend the RVV representation to LLVM-based region compilation, evaluate when the remaining execution justifies compilation by that tier, and compare additional x86 microarchitectures. The present lightweight path demonstrates a practical division of responsibility: decomposition exposes element-group computations, register promotion retains their reusable values, and runtime bounds exclude unused component work.

---

# References

- [CHIPS-tests] CHIPS Alliance. *RISC-V Vector Tests Generator*. Source revision `f76bff121dce91b6b23e1d37be77a5e44af914c3`. https://github.com/chipsalliance/riscv-vector-tests/tree/f76bff121dce91b6b23e1d37be77a5e44af914c3
- [ACT-tests] RISC-V International. *RISC-V Architectural Tests*. Source revision `c3e04e698e4ab753df41655d418edd95620c6c19`. https://github.com/riscv-non-isa/riscv-arch-test/tree/c3e04e698e4ab753df41655d418edd95620c6c19
- [ACT-db2] RISC-V International. *RISC-V Architectural Tests*. Source revision `db2b9fd7aa71a6e669417f711379988541f1464c`, vector test generators and signature checking. https://github.com/riscv/riscv-arch-test/tree/db2b9fd7aa71a6e669417f711379988541f1464c
- [Ara-tests] PULP Platform. *Ara*, vector instruction tests. Source revision `34bd3bc152421b4601a7bf3d6e8e91ffb545c99e`. https://github.com/pulp-platform/ara/tree/34bd3bc152421b4601a7bf3d6e8e91ffb545c99e
- [RVVTS] Institute for Complex Systems, Johannes Kepler University Linz. *RVVTS: The RISC-V Vector Test Framework*. Source revision `ed9a96e74f9c8367ce42da5b6526b9727a18a293`. https://github.com/ics-jku/RVVTS/tree/ed9a96e74f9c8367ce42da5b6526b9727a18a293

- [RVV-ATG] RVV-ATG project. *RISC-V Vector Automatic Tests Generator*. Source revision `490714595cc6c44bc9fe31dc85a3c2bedb1cd99b`. https://github.com/hushenwei2000/rvv-atg/tree/490714595cc6c44bc9fe31dc85a3c2bedb1cd99b
- [SiFive-RIF] SiFive. *RVV Intrinsic Fuzzing (RIF)*. Source revision `30a75c61b4678b3f3b029f77b104ca39ddbe7f8c`. https://github.com/sifive/riscv-vector-intrinsic-fuzzing/tree/30a75c61b4678b3f3b029f77b104ca39ddbe7f8c
- [RVISmith] RVISmith project. *RVISmith*. Source revision `599e005ec564a723107bc3c114dce12130947837`. https://github.com/yibo2000/RVISmith/tree/599e005ec564a723107bc3c114dce12130947837

- [rvdbt-impl] Sheng-Tsung Ku. RVV implementation in rvdbt. Evaluated implementation: https://github.com/kust1011/rvdbt/tree/903ce48b093a07b60c3d6f4003dc856126bd0890 . Correctness candidate, validation tools and form index: https://github.com/kust1011/rvdbt/tree/d4af8fb2cc7d635d6976a4ddf12adda8c2adde45 . Both retain upstream rvdbt history; their validation and performance records are identified separately.

- [Instrew] A. Engelke, D. Okwieka, and M. Schulz. “Efficient LLVM-Based Dynamic Binary Translation.” VEE, 2021. https://doi.org/10.1145/3453933.3454022
- [Arancini] S. Reimers et al. “Arancini: A Hybrid Binary Translator for Weak Memory Model Architectures.” ASPLOS, 2026. https://doi.org/10.1145/3779212.3790127
- [Spike] RISC-V Software Source. Spike ISA simulator, source revision `609dbe0b9994154833039209fa37151e7c05e9d4`; proxy kernel revision `9c61d29846d8521d9487a57739330f9682d5b542`. https://github.com/riscv-software-src/riscv-isa-sim/tree/609dbe0b9994154833039209fa37151e7c05e9d4 and https://github.com/riscv-software-src/riscv-pk/tree/9c61d29846d8521d9487a57739330f9682d5b542
- [Whisper] Tenstorrent. Whisper RISC-V simulator, source revision `79575107156ca5c19b570e60c894605bcb18b4f8`. https://github.com/tenstorrent/whisper/tree/79575107156ca5c19b570e60c894605bcb18b4f8
- [Renode] Antmicro. Renode 1.17.0; tlib revision `167decf9129758829762e582939128c0694e90d6`, RISC-V vector translation and helpers. https://github.com/renode/renode/releases/tag/v1.17.0 and https://github.com/antmicro/tlib/tree/167decf9129758829762e582939128c0694e90d6
- [Pydrofoil] Pydrofoil project. Sail-based RISC-V simulator and meta-tracing JIT, source revision `9c1692c43f900d2cb16ef0a1aae94ec3d19675e9`. https://github.com/pydrofoil/pydrofoil/tree/9c1692c43f900d2cb16ef0a1aae94ec3d19675e9
- [RVV] RISC-V International. *The RISC-V Instruction Set Manual, Volume I: Unprivileged Architecture*, V extension, version 1.0. Manual source revision `6b45f5c61aeaa6055b5422cdeb085f1cd055a8b5`. https://github.com/riscv/riscv-isa-manual/tree/6b45f5c61aeaa6055b5422cdeb085f1cd055a8b5
- [Lin2025] You-Wen Lin. *Profile-Guided Hot Spot Optimization for RISC-V Hybrid Binary Translation Systems*. Master's thesis, National Taiwan University, July 2025. The locally supplied post-defense revision is the source used for the rvdbt architecture discussion.
- [HQEMU] D.-Y. Hong et al. “HQEMU: A Multi-threaded and Retargetable Dynamic Binary Translator on Multicores.” CGO, 2012. https://doi.org/10.1145/2259016.2259030
- [HQEMU-SIMD] S.-Y. Fu, D.-Y. Hong, J.-J. Wu, P. Liu, and W.-C. Hsu. “SIMD Code Translation in an Enhanced HQEMU.” ICPADS, 2015. https://doi.org/10.1109/ICPADS.2015.70
- [HQEMU-Wide] D.-Y. Hong, S.-Y. Fu, Y.-P. Liu, J.-J. Wu, and W.-C. Hsu. “Exploiting Longer SIMD Lanes in Dynamic Binary Translation.” 2016. Author-hosted full text. https://homepage.iis.sinica.edu.tw/papers/dyhong/20698-F.pdf
- [HQEMU-impl] Computer System Lab. HQEMU source revision `72986169d9261963834e34867db2bf46fb2b8099`: `target-arm/translate.c`, `target-arm/simd_helper.h`, `llvm/llvm-translator.cpp`, and `llvm/llvm-opc-vector.cpp`. https://github.com/ComputerSystemLab/hqemu/tree/72986169d9261963834e34867db2bf46fb2b8099
- [LLBT] B.-Y. Shen, J.-Y. Chen, W.-C. Hsu, and W. Yang. “LLBT: An LLVM-based Static Binary Translator.” CASES, 2012. https://doi.org/10.1145/2380403.2380419
- [revng] A. Di Federico, M. Payer, and G. Agosta. “rev.ng: A Unified Binary Analysis Framework to Recover CFGs and Function Boundaries.” CC, 2017. https://rev.ng/downloads/cc-2017-paper.pdf
- [QEMU] QEMU Project. *TCG Intermediate Representation*. https://www.qemu.org/docs/master/devel/tcg-ops.html
- [QEMU-RVV] QEMU Project. RISC-V vector translation, generic vector expansion, and TCG load/store optimization. Source revision `81ce3a87737aa50716c42db8886082d12783e0a1`: `target/riscv/tcg/insn_trans/trans_rvv.c.inc`, `tcg/tcg-op-gvec.c`, `tcg/optimize.c`, and `tcg/x86_64/tcg-target-has.h`. https://github.com/qemu/qemu/tree/81ce3a87737aa50716c42db8886082d12783e0a1
- [rv32emu] Y.-F. Chen, M.-H. Chen, C.-C. Huang, and C.-H. Tu. “Accelerate RISC-V Instruction Set Simulation by Tiered JIT Compilation.” VMIL, 2024. https://doi.org/10.1145/3689490.3690399
- [rv32emu-impl] rv32emu Project. *Code Generation* and vector execution implementation. Source revision `e111bc0e8a27923e9973df7d75484d5709c9723b`: `docs/codegen.md`, `src/decode.c`, `src/rv32_v_template.c`, and `src/t2c.c`. https://github.com/sysprog21/rv32emu/tree/e111bc0e8a27923e9973df7d75484d5709c9723b
- [rv32emu-wide] rv32emu Project. Vector interpreter and JIT instruction eligibility, source revision `68d6c748408635de4cd3683d1c93724eb5a26406`. https://github.com/sysprog21/rv32emu/tree/68d6c748408635de4cd3683d1c93724eb5a26406
- [libriscv] libriscv project. Source revision `e121610a7b88bb902e9d2a33b4cdfc14847003e5`. https://github.com/libriscv/libriscv/tree/e121610a7b88bb902e9d2a33b4cdfc14847003e5
- [libriscv-AJ] libriscv project. Asmjit backend, source revision `2925e570d7a7926c0401fafcb499ba73df6d0be8`. https://github.com/libriscv/libriscv/tree/2925e570d7a7926c0401fafcb499ba73df6d0be8
- [PasRISCV] PasRISCV project. Vector JIT and register mapping, source revision `b20eea8121ee2c02868621e4f64b537c9dd6aa71`, `src/PasRISCV.pas`. https://github.com/BeRo1985/pasriscv/tree/b20eea8121ee2c02868621e4f64b537c9dd6aa71
- [Berberis] Android Open Source Project. Berberis interpreter and RISC-V translator frontends, source revision `a88c2a7a2d39b0c26caed425b8e9c1a100157881`. https://android.googlesource.com/platform/frameworks/libs/binary_translation/+/a88c2a7a2d39b0c26caed425b8e9c1a100157881/
- [VectorLLVA] R. L. Bocchino Jr. and V. S. Adve. “Vector LLVA: A Virtual Vector Instruction Set for Media Processing.” VEE, 2006. https://llvm.org/pubs/2006-06-15-VEE-VectorLLVA.html
- [VaporSIMD] D. Nuzman et al. “Vapor SIMD: Auto-vectorize Once, Run Everywhere.” CGO, 2011. https://research.ibm.com/publications/vapor-simd-auto-vectorize-once-run-everywhere
- [LLVM] LLVM Project. *The LLVM Target-Independent Code Generator*. https://llvm.org/docs/CodeGenerator.html
- [MLIR] LLVM Project. *Vector Dialect*. https://mlir.llvm.org/docs/Dialects/Vector/
- [saSLP] Y.-P. Liu, D.-Y. Hong, J.-J. Wu, S.-Y. Fu, and W.-C. Hsu. “Exploiting SIMD Asymmetry in ARM-to-x86 Dynamic Binary Translation.” ACM TACO, 2019. https://doi.org/10.1145/3301488
- [Dravx] Y. Tang et al. “Dr.avx: A Dynamic Compilation System for Seamlessly Executing Hardware-Unsupported Vectorization Instructions.” CGO, 2026. https://2026.cgo.org/details/cgo-2026-papers/19/Dr-avx-A-Dynamic-Compilation-System-for-Seamlessly-Executing-Hardware-Unsupported-Ve
- [Wall] D. W. Wall. *Limits of Instruction-Level Parallelism*. WRL Technical Note TN-15, 1990. https://www.davidwall.info/papers/WRL-TN-15.pdf
- [Fog] A. Fog. *Optimizing Subroutines in Assembly Language*, sections on out-of-order execution and dependencies. https://www.agner.org/optimize/optimizing_assembly.pdf
- [uops] A. Abel and J. Reineke. “uops.info: Characterizing Latency, Throughput, and Port Usage of Instructions on Intel Microarchitectures.” ASPLOS, 2019. https://doi.org/10.1145/3297858.3304062
- [AMD] Advanced Micro Devices. *Software Optimization Guide for the AMD Zen5 Microarchitecture*. Publication 58455, revision 1.00, August 2024. https://docs.amd.com/v/u/en-US/58455_1.00
- [LinuxAES] E. Biggers. “[PATCH v2 6/6] crypto: x86/aes-xts - wire up VAES + AVX10/512 implementation.” Linux crypto mailing-list patch and discussion, March–April 2024. https://patchew.org/linux/20240329080355.2871-1-ebiggers@kernel.org/20240329080355.2871-7-ebiggers@kernel.org/

---

# Appendix A. Complete Reported Results

Times are arithmetic means in seconds over 26 rounds. Each workload uses the same binary and input across widths and methods. B, M1, M2, and Both are defined in Section 5.1. Lower elapsed time is better. Ratios and percentage reductions in the text use unrounded means.

The tables cover the 16 cases selected for the thesis presentation. The archived campaign also retains GEMM and TSVC s2275; those two cases are outside this presented set, and their observations have not been deleted or pooled into these means.

## Integer add

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 80.211461 | 11.736639 | 81.087482 | 11.738545 |
| 256 | 40.519561 | 5.890130 | 40.119381 | 5.890834 |
| 512 | 23.863936 | 3.048038 | 23.928669 | 3.048503 |
| 1024 | 12.567559 | 1.924027 | 12.667241 | 1.928142 |
| 2048 | 8.178309 | 1.166444 | 8.137948 | 1.167524 |
| 4096 | 6.254145 | 0.845272 | 6.147258 | 0.828849 |

## FP32 subtract

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 64.655965 | 10.025402 | 64.635565 | 10.031510 |
| 256 | 32.367908 | 5.480772 | 32.350148 | 5.481674 |
| 512 | 16.240421 | 3.239859 | 16.213705 | 3.239660 |
| 1024 | 8.879708 | 1.773384 | 8.872681 | 1.821305 |
| 2048 | 5.202470 | 1.101491 | 5.309855 | 1.020303 |
| 4096 | 4.197527 | 1.015099 | 4.123102 | 0.999597 |

## Livermore K1

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 91.227587 | 19.867206 | 91.433711 | 19.887143 |
| 256 | 42.627247 | 9.986430 | 42.667790 | 9.980364 |
| 512 | 20.851464 | 5.173933 | 20.929248 | 5.175515 |
| 1024 | 11.239172 | 3.004523 | 11.308134 | 3.002369 |
| 2048 | 6.697518 | 1.924375 | 6.673388 | 1.923902 |
| 4096 | 4.390623 | 1.646782 | 4.395098 | 1.647148 |

## Livermore K3

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 16.718745 | 16.713845 | 16.727183 | 16.731665 |
| 256 | 8.554938 | 8.560484 | 8.564914 | 8.562263 |
| 512 | 4.500355 | 4.506114 | 4.580578 | 4.580883 |
| 1024 | 2.552656 | 2.548698 | 2.527884 | 2.527729 |
| 2048 | 1.595701 | 1.595159 | 1.595175 | 1.594136 |
| 4096 | 1.213889 | 1.201019 | 1.200978 | 1.200873 |

## LINPACK

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.546596 | 0.546812 | 0.546654 | 0.547391 |
| 256 | 0.356616 | 0.357247 | 0.359724 | 0.360077 |
| 512 | 0.288909 | 0.288593 | 0.289145 | 0.288810 |
| 1024 | 0.265413 | 0.265094 | 0.265815 | 0.266192 |
| 2048 | 0.257781 | 0.257896 | 0.259099 | 0.259335 |
| 4096 | 0.222353 | 0.222595 | 0.224349 | 0.227359 |

## TSVC s3251

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.147711 | 0.131177 | 0.147038 | 0.130296 |
| 256 | 0.120786 | 0.113090 | 0.119814 | 0.111803 |
| 512 | 0.109870 | 0.105363 | 0.108845 | 0.104666 |
| 1024 | 0.108072 | 0.105049 | 0.105430 | 0.103732 |
| 2048 | 0.111643 | 0.108705 | 0.109692 | 0.106562 |
| 4096 | 0.097710 | 0.099182 | 0.091967 | 0.091419 |

## TSVC vbor

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.096749 | 0.055951 | 0.096972 | 0.055928 |
| 256 | 0.073004 | 0.052022 | 0.072646 | 0.052214 |
| 512 | 0.060620 | 0.050275 | 0.060617 | 0.050273 |
| 1024 | 0.056917 | 0.050417 | 0.056806 | 0.050304 |
| 2048 | 0.056932 | 0.051721 | 0.057028 | 0.051588 |
| 4096 | 0.056717 | 0.056597 | 0.056262 | 0.056488 |

## PolyBench ATAX

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.193910 | 0.193379 | 0.192642 | 0.191766 |
| 256 | 0.126070 | 0.126060 | 0.125357 | 0.125721 |
| 512 | 0.096024 | 0.095677 | 0.095365 | 0.095295 |
| 1024 | 0.084130 | 0.084190 | 0.084037 | 0.083772 |
| 2048 | 0.079688 | 0.079807 | 0.079246 | 0.079222 |
| 4096 | 0.074337 | 0.074438 | 0.072854 | 0.072949 |

## PolyBench Doitgen

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.163706 | 0.163556 | 0.162566 | 0.162492 |
| 256 | 0.115324 | 0.115361 | 0.114419 | 0.114858 |
| 512 | 0.089460 | 0.089488 | 0.089016 | 0.088790 |
| 1024 | 0.078352 | 0.078544 | 0.078000 | 0.078063 |
| 2048 | 0.075981 | 0.075846 | 0.073858 | 0.074079 |
| 4096 | 0.077689 | 0.077403 | 0.076124 | 0.076248 |

## Blackscholes

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 5.421327 | 3.115784 | 5.433192 | 3.096993 |
| 256 | 3.490354 | 2.350052 | 3.479906 | 2.338164 |
| 512 | 2.528748 | 1.946940 | 2.523336 | 1.948458 |
| 1024 | 2.087663 | 1.785864 | 2.082246 | 1.773771 |
| 2048 | 1.884560 | 1.711209 | 1.870796 | 1.700901 |
| 4096 | 1.811188 | 1.699483 | 1.812989 | 1.701548 |

## LavaMD

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 1.579655 | 0.647933 | 1.581311 | 0.648929 |
| 256 | 0.848179 | 0.383522 | 0.855122 | 0.382789 |
| 512 | 0.483343 | 0.255080 | 0.485427 | 0.256020 |
| 1024 | 0.327667 | 0.197724 | 0.330129 | 0.197350 |
| 2048 | 0.295972 | 0.197039 | 0.282315 | 0.194782 |
| 4096 | 0.273908 | 0.204485 | 0.268128 | 0.199998 |

## Streamcluster

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 17.082038 | 17.080069 | 17.057334 | 17.056539 |
| 256 | 8.816898 | 8.821780 | 8.825760 | 8.820937 |
| 512 | 5.314954 | 5.308992 | 5.259556 | 5.256131 |
| 1024 | 3.683445 | 3.683447 | 3.727436 | 3.725466 |
| 2048 | 3.109659 | 3.100043 | 3.106079 | 3.102122 |
| 4096 | 3.186276 | 3.190000 | 3.178464 | 3.182769 |

## JPEG encode

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.683559 | 0.683939 | 0.650781 | 0.649638 |
| 256 | 0.618066 | 0.616202 | 0.628393 | 0.621311 |
| 512 | 0.617137 | 0.616682 | 0.609855 | 0.609264 |
| 1024 | 0.651639 | 0.654987 | 0.628656 | 0.626018 |
| 2048 | 0.733079 | 0.730260 | 0.639628 | 0.640822 |
| 4096 | 0.859120 | 0.863673 | 0.617398 | 0.619363 |

## JPEG decode

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.359827 | 0.360961 | 0.347498 | 0.347273 |
| 256 | 0.302267 | 0.294658 | 0.295832 | 0.286669 |
| 512 | 0.301584 | 0.287588 | 0.306777 | 0.288279 |
| 1024 | 0.341555 | 0.327838 | 0.321744 | 0.301987 |
| 2048 | 0.402680 | 0.393292 | 0.326769 | 0.315969 |
| 4096 | 0.517102 | 0.517588 | 0.315976 | 0.317569 |

## H.264 CABA3

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 0.450141 | 0.449652 | 0.443150 | 0.443892 |
| 256 | 0.436426 | 0.436667 | 0.426619 | 0.427851 |
| 512 | 0.442502 | 0.443674 | 0.430097 | 0.431323 |
| 1024 | 0.498978 | 0.497855 | 0.439733 | 0.441113 |
| 2048 | 0.618276 | 0.620423 | 0.457224 | 0.458454 |
| 4096 | 0.880810 | 0.885685 | 0.474032 | 0.475220 |

## H.264 crew

| VLEN | B | M1 | M2 | Both |
|---|---:|---:|---:|---:|
| 128 | 1.723185 | 1.722336 | 1.678816 | 1.688051 |
| 256 | 1.672296 | 1.671924 | 1.613827 | 1.611594 |
| 512 | 1.694724 | 1.702107 | 1.633731 | 1.627135 |
| 1024 | 1.987023 | 1.979760 | 1.692092 | 1.701429 |
| 2048 | 2.695937 | 2.693628 | 1.794832 | 1.805627 |
| 4096 | 4.403370 | 4.397548 | 1.891825 | 1.878230 |

---

# Appendix B. Instruction-Form Scope

The 627-form inventory below contains 595 applicable forms and 32 profile exclusions. The applicable set equals the target/result-checked union in Section 5.7; the fixed correctness build separately has a 595-form checked union. Direct and helper execution are included. The sets record bounded target/output checks, without asserting full configuration coverage or universal M1/M2 admission.

The [implementation and validation table](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-current-scope.md) and [machine-readable form list](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/current-scope/forms.csv) identify the implementation route, external result checks and remaining limitations for each form. The [scope records](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/current-scope/README.md) retain suite membership, candidate identities and source/assertion bindings. The [suite execution summary](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/suite-execution-summary.md) separates program executions, reference runs, failure controls and source exclusions. The [Ara review package](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/ara-review-task91/README.md) contains original sources, adapted cases, raw outputs and the checkers that read them, including failed and excluded cases. It can be inspected offline; replay commands are provided separately. The [CHIPS inspection guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/chips-review-task93/README.md) and [ACT inspection guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/act-primary-task99/README.md) describe their retained source, reference and result chains. The [archived evidence release](https://github.com/kust1011/rvdbt/releases/tag/rvv-validation-20261012) provides both packages and fixed download manifests for offline inspection. Historical validation and performance builds remain separately identified.

RIF has 125 coupled endpoint forms, separate from operation-result checks; its initialization reports do not test a result. The accepted corpus contains 1,500 roots and 6,000 DUT calls. The 543 O2 derivative ELFs and their 2,172 DUT observations are diagnostic records excluded from acceptance. Section 5.7 explains the reduction derivatives and scalar-oracle limits. Operation-to-emission bindings distinguish 174 lowering absences, 6 checked compound sequences and 8 genuine move-checker gaps; a nominal source operation alone does not establish a checked emitted form.

ATG retains 9 producer contracts and 2 reserved source-overlap outputs. Ara retains legacy/missing macros, short or incomplete stores and profile gaps; CHIPS retains 8 unsafe original store outputs; ACT retains form/profile and privileged-signature gaps. These source and checker limits remain associated with their original cases, separately from accepted derivatives.

RVISmith retains 34 compiler-error entries and the original normalization rules. rv32emu retains whole-test failure: 8 checks reached, 7 passed, 1 failed and 296 unreached, with no data-vector result coverage. RiESCUE's RV32 runtime/address/high-half contracts, FORCE's unbuilt platform/ELF64 writer and model-only assertions, CTK's RV64 entry and Tenstorrent's 1,056 privileged RV64 cases remain source/platform exclusions or blockers, rather than positive RVV checks. These dispositions and observer limits are available in the [source summary](../artifacts/external_suite_coverage_20261007/JSERV_VERIFICATION_SUMMARY.md) and immutable ledger links.

The [historical external per-form results](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/host512-task142/combined/FORMS.md) identify the retained external-campaign executable's CHIPS, ACT and Ara checks. The [offline inspection guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/host512-task142/README.md) connects the downloadable current outputs to their original sources and checkers. Fault handling is documented separately in the [implementation guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-qcg.md): checked helpers and admitted singleton QCG memory bodies preserve completed results and return faults to the dispatcher. Original failed signal tests remain archived alongside the later bounded corrections. Guest-handler return/restart, full state, agnostic write history, access suppression and per-PC method admission remain incomplete beyond the tests described in Section 5.7.

The two ATG and two Ara source-overlap cases are classified using ISA-manual revision `6b45f5c6`, which reserves reading one vector register with different source EEWs in a single instruction, including EEW 1 for a mask source [RVV]. The archived 2021 V 1.0 text does not explicitly state this rule. These dispositions therefore identify the manual revision rather than treating the two texts as interchangeable.

Project-authored directed matrices separately index accepted cases, observed dimensions, oracle scope, historical family receipts and actual final same-build results for the 595 applicable forms. Section 5.7 separates 12,069,048 ordinary positive DUT checks, 2,256 focused positives and 592 focused denial controls. The completed sequence matrix checks actual optimization paths on that same frozen correctness executable; it adds no instruction-form credit. External original predicates, directed architectural comparisons and performance measurements retain separate evidence identities.

## Vector configuration (3)

`vsetivli`, `vsetvl`, `vsetvli`.

## Same-width integer operations (98)

`vadc.vim`, `vadc.vvm`, `vadc.vxm`, `vadd.vi`, `vadd.vv`, `vadd.vx`, `vand.vi`, `vand.vv`, `vand.vx`, `vdiv.vv`, `vdiv.vx`, `vdivu.vv`, `vdivu.vx`, `vmacc.vv`, `vmacc.vx`, `vmadc.vi`, `vmadc.vim`, `vmadc.vv`, `vmadc.vvm`, `vmadc.vx`, `vmadc.vxm`, `vmadd.vv`, `vmadd.vx`, `vmax.vv`, `vmax.vx`, `vmaxu.vv`, `vmaxu.vx`, `vmerge.vim`, `vmerge.vvm`, `vmerge.vxm`, `vmin.vv`, `vmin.vx`, `vminu.vv`, `vminu.vx`, `vmsbc.vv`, `vmsbc.vvm`, `vmsbc.vx`, `vmsbc.vxm`, `vmseq.vi`, `vmseq.vv`, `vmseq.vx`, `vmsgt.vi`, `vmsgt.vx`, `vmsgtu.vi`, `vmsgtu.vx`, `vmsle.vi`, `vmsle.vv`, `vmsle.vx`, `vmsleu.vi`, `vmsleu.vv`, `vmsleu.vx`, `vmslt.vv`, `vmslt.vx`, `vmsltu.vv`, `vmsltu.vx`, `vmsne.vi`, `vmsne.vv`, `vmsne.vx`, `vmul.vv`, `vmul.vx`, `vmulh.vv`, `vmulh.vx`, `vmulhsu.vv`, `vmulhsu.vx`, `vmulhu.vv`, `vmulhu.vx`, `vmv.v.i`, `vmv.v.v`, `vmv.v.x`, `vnmsac.vv`, `vnmsac.vx`, `vnmsub.vv`, `vnmsub.vx`, `vor.vi`, `vor.vv`, `vor.vx`, `vrem.vv`, `vrem.vx`, `vremu.vv`, `vremu.vx`, `vrsub.vi`, `vrsub.vx`, `vsbc.vvm`, `vsbc.vxm`, `vsll.vi`, `vsll.vv`, `vsll.vx`, `vsra.vi`, `vsra.vv`, `vsra.vx`, `vsrl.vi`, `vsrl.vv`, `vsrl.vx`, `vsub.vv`, `vsub.vx`, `vxor.vi`, `vxor.vv`, `vxor.vx`.

## Widening integer operations (31)

`vwadd.vv`, `vwadd.vx`, `vwadd.wv`, `vwadd.wx`, `vwaddu.vv`, `vwaddu.vx`, `vwaddu.wv`, `vwaddu.wx`, `vwmacc.vv`, `vwmacc.vx`, `vwmaccsu.vv`, `vwmaccsu.vx`, `vwmaccu.vv`, `vwmaccu.vx`, `vwmaccus.vx`, `vwmul.vv`, `vwmul.vx`, `vwmulsu.vv`, `vwmulsu.vx`, `vwmulu.vv`, `vwmulu.vx`, `vwredsum.vs`, `vwredsumu.vs`, `vwsub.vv`, `vwsub.vx`, `vwsub.wv`, `vwsub.wx`, `vwsubu.vv`, `vwsubu.vx`, `vwsubu.wv`, `vwsubu.wx`.

## Narrowing integer operations (12)

`vnclip.wi`, `vnclip.wv`, `vnclip.wx`, `vnclipu.wi`, `vnclipu.wv`, `vnclipu.wx`, `vnsra.wi`, `vnsra.wv`, `vnsra.wx`, `vnsrl.wi`, `vnsrl.wv`, `vnsrl.wx`.

## Integer extension (6)

`vsext.vf2`, `vsext.vf4`, `vsext.vf8`, `vzext.vf2`, `vzext.vf4`, `vzext.vf8`.

## Integer reduction (8)

`vredand.vs`, `vredmax.vs`, `vredmaxu.vs`, `vredmin.vs`, `vredminu.vs`, `vredor.vs`, `vredsum.vs`, `vredxor.vs`.

## Fixed-point operations (26)

`vaadd.vv`, `vaadd.vx`, `vaaddu.vv`, `vaaddu.vx`, `vasub.vv`, `vasub.vx`, `vasubu.vv`, `vasubu.vx`, `vsadd.vi`, `vsadd.vv`, `vsadd.vx`, `vsaddu.vi`, `vsaddu.vv`, `vsaddu.vx`, `vsmul.vv`, `vsmul.vx`, `vssra.vi`, `vssra.vv`, `vssra.vx`, `vssrl.vi`, `vssrl.vv`, `vssrl.vx`, `vssub.vv`, `vssub.vx`, `vssubu.vv`, `vssubu.vx`.

## Floating-point operations (101)

`vfadd.vf`, `vfadd.vv`, `vfclass.v`, `vfcvt.f.x.v`, `vfcvt.f.xu.v`, `vfcvt.rtz.x.f.v`, `vfcvt.rtz.xu.f.v`, `vfcvt.x.f.v`, `vfcvt.xu.f.v`, `vfdiv.vf`, `vfdiv.vv`, `vfmacc.vf`, `vfmacc.vv`, `vfmadd.vf`, `vfmadd.vv`, `vfmax.vf`, `vfmax.vv`, `vfmerge.vfm`, `vfmin.vf`, `vfmin.vv`, `vfmsac.vf`, `vfmsac.vv`, `vfmsub.vf`, `vfmsub.vv`, `vfmul.vf`, `vfmul.vv`, `vfmv.f.s`, `vfmv.s.f`, `vfmv.v.f`, `vfncvt.f.f.w`, `vfncvt.f.x.w`, `vfncvt.f.xu.w`, `vfncvt.rod.f.f.w`, `vfncvt.rtz.x.f.w`, `vfncvt.rtz.xu.f.w`, `vfncvt.x.f.w`, `vfncvt.xu.f.w`, `vfnmacc.vf`, `vfnmacc.vv`, `vfnmadd.vf`, `vfnmadd.vv`, `vfnmsac.vf`, `vfnmsac.vv`, `vfnmsub.vf`, `vfnmsub.vv`, `vfrdiv.vf`, `vfrec7.v`, `vfredmax.vs`, `vfredmin.vs`, `vfredosum.vs`, `vfredusum.vs`, `vfrsqrt7.v`, `vfrsub.vf`, `vfsgnj.vf`, `vfsgnj.vv`, `vfsgnjn.vf`, `vfsgnjn.vv`, `vfsgnjx.vf`, `vfsgnjx.vv`, `vfslide1down.vf`, `vfslide1up.vf`, `vfsqrt.v`, `vfsub.vf`, `vfsub.vv`, `vfwadd.vf`, `vfwadd.vv`, `vfwadd.wf`, `vfwadd.wv`, `vfwcvt.f.f.v`, `vfwcvt.f.x.v`, `vfwcvt.f.xu.v`, `vfwcvt.rtz.x.f.v`, `vfwcvt.rtz.xu.f.v`, `vfwcvt.x.f.v`, `vfwcvt.xu.f.v`, `vfwmacc.vf`, `vfwmacc.vv`, `vfwmsac.vf`, `vfwmsac.vv`, `vfwmul.vf`, `vfwmul.vv`, `vfwnmacc.vf`, `vfwnmacc.vv`, `vfwnmsac.vf`, `vfwnmsac.vv`, `vfwredosum.vs`, `vfwredusum.vs`, `vfwsub.vf`, `vfwsub.vv`, `vfwsub.wf`, `vfwsub.wv`, `vmfeq.vf`, `vmfeq.vv`, `vmfge.vf`, `vmfgt.vf`, `vmfle.vf`, `vmfle.vv`, `vmflt.vf`, `vmflt.vv`, `vmfne.vf`, `vmfne.vv`.

## Mask-bit operations (13)

`vcpop.m`, `vfirst.m`, `vmand.mm`, `vmandn.mm`, `vmnand.mm`, `vmnor.mm`, `vmor.mm`, `vmorn.mm`, `vmsbf.m`, `vmsif.m`, `vmsof.m`, `vmxnor.mm`, `vmxor.mm`.

## Mask-to-integer operations (2)

`vid.v`, `viota.m`.

## Permutation and element movement (13)

`vcompress.vm`, `vmv.s.x`, `vmv.x.s`, `vrgather.vi`, `vrgather.vv`, `vrgather.vx`, `vrgatherei16.vv`, `vslide1down.vx`, `vslide1up.vx`, `vslidedown.vi`, `vslidedown.vx`, `vslideup.vi`, `vslideup.vx`.

## Whole-register movement (4)

`vmv1r.v`, `vmv2r.v`, `vmv4r.v`, `vmv8r.v`.

## Unit-stride, strided and segment memory operations (160)

`vle16.v`, `vle16ff.v`, `vle32.v`, `vle32ff.v`, `vle64.v`, `vle64ff.v`, `vle8.v`, `vle8ff.v`, `vlse16.v`, `vlse32.v`, `vlse64.v`, `vlse8.v`, `vlseg2e16.v`, `vlseg2e16ff.v`, `vlseg2e32.v`, `vlseg2e32ff.v`, `vlseg2e64.v`, `vlseg2e64ff.v`, `vlseg2e8.v`, `vlseg2e8ff.v`, `vlseg3e16.v`, `vlseg3e16ff.v`, `vlseg3e32.v`, `vlseg3e32ff.v`, `vlseg3e64.v`, `vlseg3e64ff.v`, `vlseg3e8.v`, `vlseg3e8ff.v`, `vlseg4e16.v`, `vlseg4e16ff.v`, `vlseg4e32.v`, `vlseg4e32ff.v`, `vlseg4e64.v`, `vlseg4e64ff.v`, `vlseg4e8.v`, `vlseg4e8ff.v`, `vlseg5e16.v`, `vlseg5e16ff.v`, `vlseg5e32.v`, `vlseg5e32ff.v`, `vlseg5e64.v`, `vlseg5e64ff.v`, `vlseg5e8.v`, `vlseg5e8ff.v`, `vlseg6e16.v`, `vlseg6e16ff.v`, `vlseg6e32.v`, `vlseg6e32ff.v`, `vlseg6e64.v`, `vlseg6e64ff.v`, `vlseg6e8.v`, `vlseg6e8ff.v`, `vlseg7e16.v`, `vlseg7e16ff.v`, `vlseg7e32.v`, `vlseg7e32ff.v`, `vlseg7e64.v`, `vlseg7e64ff.v`, `vlseg7e8.v`, `vlseg7e8ff.v`, `vlseg8e16.v`, `vlseg8e16ff.v`, `vlseg8e32.v`, `vlseg8e32ff.v`, `vlseg8e64.v`, `vlseg8e64ff.v`, `vlseg8e8.v`, `vlseg8e8ff.v`, `vlsseg2e16.v`, `vlsseg2e32.v`, `vlsseg2e64.v`, `vlsseg2e8.v`, `vlsseg3e16.v`, `vlsseg3e32.v`, `vlsseg3e64.v`, `vlsseg3e8.v`, `vlsseg4e16.v`, `vlsseg4e32.v`, `vlsseg4e64.v`, `vlsseg4e8.v`, `vlsseg5e16.v`, `vlsseg5e32.v`, `vlsseg5e64.v`, `vlsseg5e8.v`, `vlsseg6e16.v`, `vlsseg6e32.v`, `vlsseg6e64.v`, `vlsseg6e8.v`, `vlsseg7e16.v`, `vlsseg7e32.v`, `vlsseg7e64.v`, `vlsseg7e8.v`, `vlsseg8e16.v`, `vlsseg8e32.v`, `vlsseg8e64.v`, `vlsseg8e8.v`, `vse16.v`, `vse32.v`, `vse64.v`, `vse8.v`, `vsse16.v`, `vsse32.v`, `vsse64.v`, `vsse8.v`, `vsseg2e16.v`, `vsseg2e32.v`, `vsseg2e64.v`, `vsseg2e8.v`, `vsseg3e16.v`, `vsseg3e32.v`, `vsseg3e64.v`, `vsseg3e8.v`, `vsseg4e16.v`, `vsseg4e32.v`, `vsseg4e64.v`, `vsseg4e8.v`, `vsseg5e16.v`, `vsseg5e32.v`, `vsseg5e64.v`, `vsseg5e8.v`, `vsseg6e16.v`, `vsseg6e32.v`, `vsseg6e64.v`, `vsseg6e8.v`, `vsseg7e16.v`, `vsseg7e32.v`, `vsseg7e64.v`, `vsseg7e8.v`, `vsseg8e16.v`, `vsseg8e32.v`, `vsseg8e64.v`, `vsseg8e8.v`, `vssseg2e16.v`, `vssseg2e32.v`, `vssseg2e64.v`, `vssseg2e8.v`, `vssseg3e16.v`, `vssseg3e32.v`, `vssseg3e64.v`, `vssseg3e8.v`, `vssseg4e16.v`, `vssseg4e32.v`, `vssseg4e64.v`, `vssseg4e8.v`, `vssseg5e16.v`, `vssseg5e32.v`, `vssseg5e64.v`, `vssseg5e8.v`, `vssseg6e16.v`, `vssseg6e32.v`, `vssseg6e64.v`, `vssseg6e8.v`, `vssseg7e16.v`, `vssseg7e32.v`, `vssseg7e64.v`, `vssseg7e8.v`, `vssseg8e16.v`, `vssseg8e32.v`, `vssseg8e64.v`, `vssseg8e8.v`.

## Indexed memory operations (96)

`vloxei16.v`, `vloxei32.v`, `vloxei8.v`, `vloxseg2ei16.v`, `vloxseg2ei32.v`, `vloxseg2ei8.v`, `vloxseg3ei16.v`, `vloxseg3ei32.v`, `vloxseg3ei8.v`, `vloxseg4ei16.v`, `vloxseg4ei32.v`, `vloxseg4ei8.v`, `vloxseg5ei16.v`, `vloxseg5ei32.v`, `vloxseg5ei8.v`, `vloxseg6ei16.v`, `vloxseg6ei32.v`, `vloxseg6ei8.v`, `vloxseg7ei16.v`, `vloxseg7ei32.v`, `vloxseg7ei8.v`, `vloxseg8ei16.v`, `vloxseg8ei32.v`, `vloxseg8ei8.v`, `vluxei16.v`, `vluxei32.v`, `vluxei8.v`, `vluxseg2ei16.v`, `vluxseg2ei32.v`, `vluxseg2ei8.v`, `vluxseg3ei16.v`, `vluxseg3ei32.v`, `vluxseg3ei8.v`, `vluxseg4ei16.v`, `vluxseg4ei32.v`, `vluxseg4ei8.v`, `vluxseg5ei16.v`, `vluxseg5ei32.v`, `vluxseg5ei8.v`, `vluxseg6ei16.v`, `vluxseg6ei32.v`, `vluxseg6ei8.v`, `vluxseg7ei16.v`, `vluxseg7ei32.v`, `vluxseg7ei8.v`, `vluxseg8ei16.v`, `vluxseg8ei32.v`, `vluxseg8ei8.v`, `vsoxei16.v`, `vsoxei32.v`, `vsoxei8.v`, `vsoxseg2ei16.v`, `vsoxseg2ei32.v`, `vsoxseg2ei8.v`, `vsoxseg3ei16.v`, `vsoxseg3ei32.v`, `vsoxseg3ei8.v`, `vsoxseg4ei16.v`, `vsoxseg4ei32.v`, `vsoxseg4ei8.v`, `vsoxseg5ei16.v`, `vsoxseg5ei32.v`, `vsoxseg5ei8.v`, `vsoxseg6ei16.v`, `vsoxseg6ei32.v`, `vsoxseg6ei8.v`, `vsoxseg7ei16.v`, `vsoxseg7ei32.v`, `vsoxseg7ei8.v`, `vsoxseg8ei16.v`, `vsoxseg8ei32.v`, `vsoxseg8ei8.v`, `vsuxei16.v`, `vsuxei32.v`, `vsuxei8.v`, `vsuxseg2ei16.v`, `vsuxseg2ei32.v`, `vsuxseg2ei8.v`, `vsuxseg3ei16.v`, `vsuxseg3ei32.v`, `vsuxseg3ei8.v`, `vsuxseg4ei16.v`, `vsuxseg4ei32.v`, `vsuxseg4ei8.v`, `vsuxseg5ei16.v`, `vsuxseg5ei32.v`, `vsuxseg5ei8.v`, `vsuxseg6ei16.v`, `vsuxseg6ei32.v`, `vsuxseg6ei8.v`, `vsuxseg7ei16.v`, `vsuxseg7ei32.v`, `vsuxseg7ei8.v`, `vsuxseg8ei16.v`, `vsuxseg8ei32.v`, `vsuxseg8ei8.v`.

## Mask memory operations (2)

`vlm.v`, `vsm.v`.

## Whole-register memory operations (20)

`vl1re16.v`, `vl1re32.v`, `vl1re64.v`, `vl1re8.v`, `vl2re16.v`, `vl2re32.v`, `vl2re64.v`, `vl2re8.v`, `vl4re16.v`, `vl4re32.v`, `vl4re64.v`, `vl4re8.v`, `vl8re16.v`, `vl8re32.v`, `vl8re64.v`, `vl8re8.v`, `vs1r.v`, `vs2r.v`, `vs4r.v`, `vs8r.v`.

## Forms Outside the Profile (32)

These indexed-memory forms use 64-bit indices and are not required by the evaluated RV32 profile [RVV].

`vloxei64.v`, `vloxseg2ei64.v`, `vloxseg3ei64.v`, `vloxseg4ei64.v`, `vloxseg5ei64.v`, `vloxseg6ei64.v`, `vloxseg7ei64.v`, `vloxseg8ei64.v`, `vluxei64.v`, `vluxseg2ei64.v`, `vluxseg3ei64.v`, `vluxseg4ei64.v`, `vluxseg5ei64.v`, `vluxseg6ei64.v`, `vluxseg7ei64.v`, `vluxseg8ei64.v`, `vsoxei64.v`, `vsoxseg2ei64.v`, `vsoxseg3ei64.v`, `vsoxseg4ei64.v`, `vsoxseg5ei64.v`, `vsoxseg6ei64.v`, `vsoxseg7ei64.v`, `vsoxseg8ei64.v`, `vsuxei64.v`, `vsuxseg2ei64.v`, `vsuxseg3ei64.v`, `vsuxseg4ei64.v`, `vsuxseg5ei64.v`, `vsuxseg6ei64.v`, `vsuxseg7ei64.v`, `vsuxseg8ei64.v`.
