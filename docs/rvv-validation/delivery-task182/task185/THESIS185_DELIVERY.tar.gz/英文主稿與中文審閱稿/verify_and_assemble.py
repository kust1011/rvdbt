"""Check bilingual invariants and assemble the two review copies."""

from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def digits(text):
    return re.findall(r"(?<![A-Za-z_])\d+(?:[.,]\d+)*", text)


def invariants(source, target):
    fences = r"```[^\n]*\n.*?```"
    equations = r"\\\[.*?\\\]"
    rows = lambda text: [digits(line) for line in text.splitlines() if line.startswith("|")]
    return {
        "numbers": Counter(digits(source)) == Counter(digits(target)),
        "table_numbers_by_row": rows(source) == rows(target),
        "heading_levels": re.findall(r"^#+(?= )", source, re.M) == re.findall(r"^#+(?= )", target, re.M),
        "code_blocks": re.findall(fences, source, re.S) == re.findall(fences, target, re.S),
        "display_math": re.findall(equations, source, re.S) == re.findall(equations, target, re.S),
        "image_paths": re.findall(r"!\[[^\]]*\]\(([^)]+)\)", source) == re.findall(r"!\[[^\]]*\]\(([^)]+)\)", target),
        "paragraph_blocks": len(re.split(r"\n\s*\n", source.strip())) == len(re.split(r"\n\s*\n", target.strip())),
        "no_translation_scaffolding": not re.search(r"@@KEEP_|</?think>|</?analysis>", target),
    }


def generate_form_appendix():
    """Generate the same enumerated form scope in both review languages."""
    evidence = ROOT.parent / "artifacts/external_suite_coverage_20261007/task87/COMPLETE_FORM_SUITE_INVENTORY.csv"
    # The named-form catalog is unchanged; the accepted suite sets use the current edition.
    summary_path = ROOT.parent / "artifacts/external_suite_coverage_20261007/task90/ACTUAL_FORM_VALIDATION_SUMMARY.json"
    summary = json.loads(summary_path.read_text())
    csv.field_size_limit(10_000_000)
    with evidence.open(newline="") as handle:
        forms = [{"form": row["form"], "family": row["family"],
                  "rv32_elen64_applicability": row["RV32_ELEN64適用性"]}
                 for row in csv.DictReader(handle)]
    required = [row for row in forms if row["rv32_elen64_applicability"] == "REQUIRED"]
    excluded = [row for row in forms if row["rv32_elen64_applicability"] == "NOT_APPLICABLE"]
    assert len(forms) == len({row["form"] for row in forms}) == 627
    assert len(required) == 595 and len(excluded) == 32
    assert set(summary["union_result_checked_forms"]) == {row["form"] for row in required}
    expected_counts = {"CHIPS": 595, "ACT": 590, "RVV-ATG": 434, "Ara": 422, "SiFive RIF": 200}
    clean_checked = set()
    for suite in summary["suites"]:
        if suite["suite"] in expected_counts:
            assert suite["counts"]["result_checked"] == expected_counts[suite["suite"]]
        for candidate in suite["candidates"]:
            if "961" in candidate["candidate"]:
                clean_checked.update(candidate["forms"].get("result_checked") or [])
    assert len(clean_checked) == 595
    assert summary["quarantined_RIF_O2_ELFs"] == 543
    families = [
        ("configuration", "Vector configuration", "向量配置"),
        ("integer_single_width", "Same-width integer operations", "同寬度整數運算"),
        ("integer_widening", "Widening integer operations", "整數擴寬運算"),
        ("integer_narrowing", "Narrowing integer operations", "整數窄化運算"),
        ("integer_extension", "Integer extension", "整數延伸"),
        ("integer_reduction", "Integer reduction", "整數歸約"),
        ("fixed_point", "Fixed-point operations", "定點運算"),
        ("floating_point", "Floating-point operations", "浮點運算"),
        ("mask_bits", "Mask-bit operations", "遮罩位元運算"),
        ("mask_to_integer", "Mask-to-integer operations", "遮罩至整數運算"),
        ("permutation", "Permutation and element movement", "元素排列與搬移"),
        ("whole_register_move", "Whole-register movement", "整暫存器搬移"),
        ("data_memory", "Unit-stride, strided and segment memory operations", "單位跨距、指定跨距與分段記憶體操作"),
        ("indexed_memory", "Indexed memory operations", "索引記憶體操作"),
        ("mask_memory", "Mask memory operations", "遮罩記憶體操作"),
        ("whole_register_memory", "Whole-register memory operations", "整暫存器記憶體操作"),
    ]
    assert {row["family"] for row in required} == {family[0] for family in families}
    introductions = {'en': ['# Appendix B. Instruction-Form Scope', '', 'The 627-form inventory below contains 595 applicable forms and 32 profile exclusions. The applicable set equals the target/result-checked union in Section 5.7; the fixed correctness build separately has a 595-form checked union. Direct and helper execution are included. The sets record bounded target/output checks, without asserting full configuration coverage or universal M1/M2 admission.', '', 'The [canonical form table](../../../artifacts/external_suite_coverage_20261007/COMPLETE_FORM_INVENTORY_ZH.md), [exact suite lists](../../../artifacts/external_suite_coverage_20261007/ACTUAL_SUITE_FORM_LISTS.md) and [candidate-specific summary](../../../artifacts/external_suite_coverage_20261007/ACTUAL_FORM_VALIDATION_SUMMARY.json) distinguish source, compiled/emitted, program-associated, checked, coupled, diagnostic and failed stages. The [bindings](../../../artifacts/external_suite_coverage_20261007/ACTUAL_FORM_VALIDATION_BINDINGS.csv) retain source/assertion, adaptations, runtime dimensions, reference, raw result, executable/library/ELF and flags. Missing operation-to-emission joins remain explicit. The historical broad regression, performance executable and fixed correctness build retain separate candidate identities; performance measurements belong to their own campaign.', '', 'RIF has 125 coupled endpoint forms, separate from operation-result checks; its initialization reports do not test a result. The accepted corpus contains 1,500 roots and 6,000 DUT calls. The 543 O2 derivative ELFs and their 2,172 DUT observations are diagnostic records excluded from acceptance. Section 5.7 explains the reduction derivatives and scalar-oracle limits. Operation-to-emission bindings distinguish 174 lowering absences, 6 checked compound sequences and 8 genuine move-checker gaps; a nominal source operation alone does not establish a checked emitted form.', '', 'ATG retains 9 producer contracts and 2 reserved source-overlap outputs. Ara retains legacy/missing macros, short or incomplete stores and profile gaps; CHIPS retains 8 unsafe original store outputs; ACT retains form/profile and privileged-signature gaps. These source and checker limits remain associated with their original cases, separately from accepted derivatives.', '', "RVISmith retains 34 compiler-error entries and the original normalization rules. rv32emu retains whole-test failure: 8 checks reached, 7 passed, 1 failed and 296 unreached, with no data-vector result coverage. RiESCUE's RV32 runtime/address/high-half contracts, FORCE's unbuilt platform/ELF64 writer and model-only assertions, CTK's RV64 entry and Tenstorrent's 1,056 privileged RV64 cases remain source/platform exclusions or blockers, rather than positive RVV checks. These dispositions and observer limits are available in the [source summary](../../../artifacts/external_suite_coverage_20261007/JSERV_VERIFICATION_SUMMARY.md) and immutable ledger links.", '', 'The worked CHIPS example in Section 5.7 has its complete [source, checker and comparison chain](../../../artifacts/rvv_validation_delivery_20261009/vadd-m8-1024-external/README.md). The [guest-signal outcome](../../../artifacts/rvv_validation_delivery_20261009/SESSION0_RESULT_58.md) records the original failed predicate. General precise fault/restart, full state, agnostic write history, access suppression and per-PC method admission remain incomplete beyond scoped witnesses.', ''], 'zh-TW': ['# 附錄 B. 指令形式範圍', '', '下列 627 個形式包含 595 個適用形式與 32 個配置排除項。適用集合等於第 5.7 節的目標／結果受檢聯集；固定正確性 build另有 595 個受檢形式聯集。包含直接與 helper 執行。集合記錄有界的目標／輸出檢查，不宣稱完整配置覆蓋或普遍 M1/M2 准入。', '', '[標準逐形式表](../../../artifacts/external_suite_coverage_20261007/COMPLETE_FORM_INVENTORY_ZH.md)、[精確套件清單](../../../artifacts/external_suite_coverage_20261007/ACTUAL_SUITE_FORM_LISTS.md)與[按候選區分的摘要](../../../artifacts/external_suite_coverage_20261007/ACTUAL_FORM_VALIDATION_SUMMARY.json)分開來源、編譯／產碼、程式關聯、受檢、耦合、診斷及失敗階段。[Binding](../../../artifacts/external_suite_coverage_20261007/ACTUAL_FORM_VALIDATION_BINDINGS.csv)保留來源／assertion、適配、runtime 維度、reference、原始結果、執行檔／library／ELF 及 flags。操作至產碼的缺失接合明列。歷史廣泛回歸、效能執行檔與固定正確性 build 各自保留候選身份；效能量測屬於獨立批次。', '', 'RIF 有 125 個耦合終點形式，與操作結果檢查分開；初始化回報沒有檢查結果。接受的集合包含 1,500 個 root 與 6,000 次 DUT 呼叫。543 個 O2 衍生 ELF 及其 2,172 次 DUT 觀察屬於診斷紀錄，不列入接受結果。第 5.7 節說明歸約衍生案例及純量 oracle 限制。操作至產碼的 binding 區分 174 個 lowering 缺失、6 個受檢複合序列及 8 個真正的搬移 checker 缺口；來源中的名義操作本身不足以建立受檢產碼形式。', '', 'ATG 保留 9 個 producer contract 與 2 個 reserved source-overlap 輸出。Ara 保留舊版／缺失 macro、過短或不完整 store 與配置缺口；CHIPS 保留 8 個不安全原始 store 輸出；ACT 保留 form／profile 及 privileged-signature 缺口。這些來源與 checker 限制仍對應其原始案例，與接受的衍生結果分開。', '', 'RVISmith 保留 34 個 compiler-error 項目與原始正規化規則。rv32emu 維持 whole-test 失敗：到達8 個檢查，7 個通過，1 個失敗，296 個未到達，沒有 data-vector 結果覆蓋。RiESCUE 的 RV32 runtime／address／high-half contract、FORCE 未完成建置的平台／ELF64 writer 及 model-only assertion、CTK 的 RV64 入口，以及 Tenstorrent 的 1,056 個 privileged RV64 案例，仍屬來源／平台排除項或阻塞，不算正向 RVV 檢查。這些裁決與 observer 限制可由[來源摘要](../../../artifacts/external_suite_coverage_20261007/JSERV_VERIFICATION_SUMMARY.md)及不可變 ledger 連結查閱。', '', '第 5.7 節 CHIPS 範例的完整[來源、checker 與比較鏈](../../../artifacts/rvv_validation_delivery_20261009/vadd-m8-1024-external/README.md)已保留。[Guest signal 結果](../../../artifacts/rvv_validation_delivery_20261009/SESSION0_RESULT_58.md)記錄原始失敗判定。一般精確 fault／restart、完整狀態、agnostic 寫入歷史、存取抑制及逐 PC 方法准入，在限定 witness 之外仍不完整。', '']}
    introductions['en'].extend([
        'The two ATG and two Ara source-overlap cases are classified using ISA-manual revision `6b45f5c6`, which reserves reading one vector register with different source EEWs in a single instruction, including EEW 1 for a mask source [RVV]. The archived 2021 V 1.0 text does not explicitly state this rule. These dispositions therefore identify the manual revision rather than treating the two texts as interchangeable.', ''])
    introductions['zh-TW'].extend([
        '兩個 ATG 與兩個 Ara source-overlap 案例依 ISA manual revision `6b45f5c6` 分類：同一道指令以不同來源 EEW 讀取同一向量暫存器屬 reserved encoding，其中 mask 來源的 EEW 為 1 [RVV]。封存的 2021 年 V 1.0 原文未明列這項規則，因此這些裁定須標明所採規範版本，不能將兩版原文視為相同。', ''])
    relative = Path("08_Appendix/02_Instruction_Forms.md")
    review_base = "https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7"
    introductions['en'][4] = (
        f'The [implementation and validation table]({review_base}/docs/rvv-current-scope.md) '
        f'and [machine-readable form list]({review_base}/docs/rvv-validation/current-scope/forms.csv) '
        'identify the implementation route, external result checks and remaining limitations for each form. '
        f'The [scope records]({review_base}/docs/rvv-validation/current-scope/README.md) '
        'retain suite membership, candidate identities and source/assertion bindings. '
        f'The [suite execution summary]({review_base}/docs/rvv-validation/suite-execution-summary.md) '
        'separates program executions, reference runs, failure controls and source exclusions. '
        f'The [Ara review package]({review_base}/docs/rvv-validation/ara-review-task91/README.md) '
        'contains original sources, adapted cases, raw outputs and the checkers that read them, including failed and excluded cases. '
        'It can be inspected offline; replay commands are provided separately. '
        f'The [CHIPS inspection guide]({review_base}/docs/rvv-validation/chips-review-task93/README.md) '
        f'and [ACT inspection guide]({review_base}/docs/rvv-validation/act-primary-task99/README.md) '
        'describe their retained source, reference and result chains. '
        'The [archived evidence release](https://github.com/kust1011/rvdbt/releases/tag/rvv-validation-20261012) '
        'provides both packages and fixed download manifests for offline inspection. '
        'Historical validation and performance builds remain separately identified.')
    introductions['zh-TW'][4] = (
        f'[實作與驗證表]({review_base}/docs/rvv-current-scope.md)'
        f'及[機器可讀形式清單]({review_base}/docs/rvv-validation/current-scope/forms.csv)'
        '逐形式列出實作路徑、外部結果檢查與剩餘限制。'
        f'[範圍紀錄]({review_base}/docs/rvv-validation/current-scope/README.md)'
        '保留套件涵蓋集合、受測版本，以及來源與 assertion 的對應。'
        f'[套件執行摘要]({review_base}/docs/rvv-validation/suite-execution-summary.md)'
        '分別列出程式執行、參考模型執行、失敗控制及來源排除項。'
        f'[Ara 審閱包]({review_base}/docs/rvv-validation/ara-review-task91/README.md)'
        '包含原始來源、適配案例、原始輸出與解析它們的 checker，也保留失敗及排除案例。'
        '資料包可離線審閱；重新執行的命令另行提供。'
        f'[CHIPS 審閱指引]({review_base}/docs/rvv-validation/chips-review-task93/README.md)'
        f'及[ACT 審閱指引]({review_base}/docs/rvv-validation/act-primary-task99/README.md)'
        '說明保留的來源、參考結果及輸出對應。'
        '[驗證資料下載](https://github.com/kust1011/rvdbt/releases/tag/rvv-validation-20261012)'
        '提供兩套資料包及固定下載清單，可依指引離線檢查。'
        '歷史驗證與效能測試的 build 各自保留版本身份。')
    introductions['en'][12] = (
        f'The [historical external per-form results]({review_base}/docs/rvv-validation/host512-task142/combined/FORMS.md) '
        'identify the retained external-campaign executable\'s CHIPS, ACT and Ara checks. '
        f'The [offline inspection guide]({review_base}/docs/rvv-validation/host512-task142/README.md) '
        'connects the downloadable current outputs to their original sources and checkers. '
        f'Fault handling is documented separately in the [implementation guide]({review_base}/docs/rvv-qcg.md): '
        'checked helpers and admitted singleton QCG memory bodies preserve completed results and return faults to the dispatcher. '
        'Original failed signal tests remain archived alongside the later bounded corrections. '
        'Guest-handler return/restart, full state, agnostic write history, access suppression and per-PC method admission '
        'remain incomplete beyond the tests described in Section 5.7.')
    introductions['zh-TW'][12] = (
        f'[歷史外部逐形式結果]({review_base}/docs/rvv-validation/host512-task142/combined/FORMS.md)'
        '列出保留之外部批次執行檔的 CHIPS、ACT 與 Ara 檢查。'
        f'[離線審閱指引]({review_base}/docs/rvv-validation/host512-task142/README.md)'
        '將可下載的實際輸出連接至原始來源與 checker。'
        f'Fault handling 另見[實作導讀]({review_base}/docs/rvv-qcg.md)：'
        '受控 helper 及符合條件的單一 QCG 記憶體指令可保留已完成結果，並將 fault 交回 dispatcher。'
        '原始 signal 測試的失敗與後續有限範圍的修正均保留紀錄。'
        'Guest handler 返回與 restart、完整狀態、agnostic 寫入歷史、存取抑制及逐 PC 方法准入，'
        '在第 5.7 節描述的測試之外仍不完整。')
    introductions['en'].extend([
        'Project-authored directed matrices separately index accepted cases, observed dimensions, oracle scope, historical family receipts and actual final same-build results for the 595 applicable forms. Section 5.7 separates 12,069,048 ordinary positive DUT checks, 2,256 focused positives and 592 focused denial controls. The completed sequence matrix checks actual optimization paths on that same frozen correctness executable; it adds no instruction-form credit. External original predicates, directed architectural comparisons and performance measurements retain separate evidence identities.', ''])
    introductions['zh-TW'].extend([
        '專案自撰的 directed matrix 另為 595 個適用形式索引已接受案例、觀察維度、oracle 範圍、歷史 family 收據及最終同版實際結果。第 5.7 節分列 12,069,048 次一般正向 DUT 檢查、2,256 次 focused 正向檢查與 592 次 focused 拒絕控制。已完成的序列矩陣在相同固定正確性執行檔上檢查實際最佳化路徑，不增加指令形式數。外部原始判定、directed 架構比較及效能量測各自保留證據身份。', ''])
    texts = {}
    for language, heading_index in (("en", 1), ("zh-TW", 2)):
        lines = list(introductions[language])
        for family in families:
            group = [row["form"] for row in required if row["family"] == family[0]]
            lines += [f"## {family[heading_index]} ({len(group)})", "",
                      ", ".join(f"`{name}`" for name in group) + ".", ""]
        lines += ["## Forms Outside the Profile (32)" if language == "en" else "## 配置範圍外的形式（32）", "",
                  "These indexed-memory forms use 64-bit indices and are not required by the evaluated RV32 profile [RVV]." if language == "en" else "以下索引記憶體形式使用 64-bit 索引，不屬於本研究 RV32 配置的必要支援範圍 [RVV]。", "",
                  ", ".join(f"`{row['form']}`" for row in excluded) + ".", ""]
        texts[language] = "\n".join(lines)
        (ROOT / language / relative).write_text(texts[language])
    receipt = {"source": str(relative), "source_sha256": sha(texts["en"]),
               "output_sha256": sha(texts["zh-TW"]),
               "generation": "Task90 accepted suite sets with unchanged Task87 named-form catalog; explicit bilingual headings; no new execution by this generator",
               "evidence_sha256": hashlib.sha256(evidence.read_bytes()).hexdigest(),
               "summary_sha256": hashlib.sha256(summary_path.read_bytes()).hexdigest()}
    (ROOT / "translation_records" / relative.with_suffix(".json")).write_text(json.dumps(receipt, indent=2) + "\n")


def main():
    generate_form_appendix()
    sources = sorted((ROOT / "en").rglob("*.md"))
    report = {}
    for source in sources:
        relative = source.relative_to(ROOT / "en")
        target = ROOT / "zh-TW" / relative
        receipt_path = ROOT / "translation_records" / relative.with_suffix(".json")
        en, zh = source.read_text(), target.read_text()
        receipt = json.loads(receipt_path.read_text())
        checks = invariants(en, zh)
        if relative.parts[0] == "02_Background":
            checks["background_title"] = all(
                text.splitlines()[0] == "# 2. Background" for text in (en, zh)
            )
        checks["source_version"] = receipt["source_sha256"] == sha(en)
        checks["translation_version"] = receipt["output_sha256"] == sha(zh)
        report[str(relative)] = checks
    (ROOT / "translation_records" / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    failures = [(name, key) for name, checks in report.items() for key, passed in checks.items() if not passed]
    if failures:
        raise SystemExit(f"Review required before assembly: {failures}")

    # Verify every appendix value against the source CSV, not against a rounded text table.
    artifact = ROOT.parent / "artifacts" / "v16_results_20260930"
    manifest = json.loads((artifact / "manifest.json").read_text())
    with (artifact / "means.csv").open(newline="") as handle:
        rows = {(r["workload"], int(r["vlen"]), r["method"]): r for r in csv.DictReader(handle)}
    appendix = (ROOT / "en" / "08_Appendix" / "01_Complete_Results.md").read_text()
    observed = [line for line in appendix.splitlines() if re.match(r"\| \d+ \|", line)]
    expected = []
    for workload in manifest["reported_workloads"]:
        for width in [128, 256, 512, 1024, 2048, 4096]:
            values = [f"{float(rows[workload, width, method]['mean_seconds']):.6f}"
                      for method in ["B", "M1", "M2", "BOTH"]]
            expected.append(f"| {width} | " + " | ".join(values) + " |")
    assert observed == expected, "Appendix source mismatch"
    for language, destination in [("en", "English_Draft.md"), ("zh-TW", "中文審閱稿.md")]:
        parts = [(ROOT / language / path.relative_to(ROOT / "en")).read_text().strip() for path in sources]
        combined = "\n\n---\n\n".join(parts) + "\n"
        combined = combined.replace("](../../figures/", "](figures/")
        combined = combined.replace("](../../../artifacts/", "](../artifacts/")
        (ROOT / destination).write_text(combined)
    print(f"PASS: {len(sources)} paired files; 384 appendix means; two assembled drafts")
    print("Mechanical invariants do not establish semantic equivalence; prose review remains separate.")


if __name__ == "__main__":
    main()
