# 5. Evaluation

This chapter evaluates execution efficiency and functional behavior. Sections 5.1--5.6 measure width scaling for the same binary and input, the contribution of each optimization at a fixed VLEN, and performance relative to other execution systems. Section 5.7 examines instruction coverage and state preservation using external tests. Microkernels and applications measure performance; instruction-level checks establish which behaviors were exercised and compared.

## 5.1 Experimental Setup

The main host is an AMD Ryzen 9 9950X3D with AVX-512 support. The measured process is pinned to logical CPU 6, and its simultaneous-multithreading sibling, CPU 22, is kept idle. The minimum and maximum frequency policy is set to 4.3 GHz, with boost disabled. Code huge pages are disabled consistently.

The primary metric is process wall-clock elapsed time, including startup, translation, program execution, input/output, and checks performed within the program. Host-side output comparison is outside the timed process. The process starts without an existing AOT artifact. Thus the metric evaluates the first execution of the lightweight JIT, not only an already-translated loop.

Four configurations are evaluated: B is the per-instruction RVV baseline; M1 enables vector register promotion and bounded batches; M2 enables the per-instruction runtime vector bounds; Both enables both sets of options, including bounds on eligible integer sequences. The separately selectable component-first floating-point sequence path is disabled in this matrix, as distinguished in Section 4.3. Simulated VLEN takes the values 128, 256, 512, 1024, 2048, and 4096 bits. The main host path uses vector operations up to 512 bits. Each configuration has 26 complete rounds, with configuration order rotated and width order alternated. All samples for each reported configuration are retained.

Let T(X,V) be the arithmetic mean elapsed time for method X at VLEN V. Width scaling is measured as T(X,512)/T(X,1024). The time reduction of a method at a fixed VLEN is 100(1 - T(X,V)/T(B,V)). All ratios are calculated from unrounded means. Tables display rounded times in seconds. Width scaling and method improvements use different denominators and are reported separately.

### Workload Roles

The evaluation separates controlled dependency chains, extracted numerical kernels, and application processes. These levels answer different questions: the microkernels isolate arithmetic structure; the numerical kernels place that structure in established computations; and the applications measure whether local improvements reduce complete-process time. Media applications additionally test the cost of increasing register capacity when the runtime element range remains short.

| Workload and source | Measured computation | Evaluation purpose |
|---|---|---|
| Synthetic integer add; FP32 subtract | Fixed-work arithmetic chains | Controlled width scaling and state reuse |
| Livermore Loops K1; K3 | Extracted hydrodynamics expression; inner product | Element-wise chains versus reduction |
| LINPACK-derived kernel | Extracted LU factorization | Reuse within a linear-algebra computation |
| TSVC s3251; vbor | Extracted vectorization-suite loops | Different operand and intermediate-value patterns |
| PolyBench/C ATAX; Doitgen | Extracted matrix-vector and tensor kernels | Reuse within structured numerical loops |
| PARSEC-derived Blackscholes | Option-pricing application | Arithmetic improvement in complete-process time |
| Rodinia-derived LavaMD | Particle-interaction application | Repeated floating-point expressions in an application |
| PARSEC-derived Streamcluster | Clustering application | Whether width scaling also yields promotion benefits |
| Archived JPEG encoder and decoder | Image compression and reconstruction | Short-vector work at larger configured VLEN |
| Archived H.264 decoder: CABA3 and crew | Same decoding application, two inputs | Bounds omission under different video inputs |

The reported set contains 16 workload/input cases, not 16 independent applications. For example, CABA3 and crew are two inputs to the H.264 decoder. Extracted kernels measure the indicated computation, not an entire suite. This division lets the evaluation distinguish width scaling from the availability of reusable intermediate values and short runtime vectors. All 16 cases appear in the fixed-width ablation, including cases with little improvement. Appendix A gives all 384 workload/width/method means; binaries and inputs remain fixed within each comparison.

### Hardware Counters

The case studies use the processor's Performance Monitoring Unit (PMU) to quantify changes in executed work. Linux `perf stat` collects `instructions:u` and `cycles:u` for user-space execution of the measured process. The former counts retired instructions and the latter counts processor cycles in user space; elapsed time covers the complete process interval.

The archive audit covers 11,232 measured configuration records, including the additional cases listed in Appendix A. Every record contains positive counts for both events, with 100% running time and matching event runtimes within each measurement. Formal measurements request both events in the same perf invocation without an event group. A separate calibration groups them and increases a four-instruction assembly loop from ten million to twenty million iterations. Against the expected increment of forty million retired instructions, the maximum discrepancy across five pairs is 52 instructions. This calibration checks the instruction-count scale; case-study instruction and cycle reductions are taken from the formal measurements.

## 5.2 Simulated Vector Length

### Dependent Arithmetic Microkernels

The two microkernels process 4096 elements at SEW 32 and LMUL 1. For each element group, the RVV body loads an input vector, applies 256 dependent arithmetic instructions to v8, and stores the result. An outer loop repeats this traversal R times: R=131072 for integer add and R=16384 for FP32 subtract. Each repetition rereads the original input; it does not extend the preceding repetition's arithmetic chain. The following control skeleton omits counter bookkeeping and output formatting.

```text
for r = 0 .. R-1:
    src = input; dst = output; remaining = 4096
    while remaining > 0:
        execute RVV body below; obtain vl
        src += vl; dst += vl; remaining -= vl
```

The RVV body below shows the FP32-subtract case. Symbolic operand names replace the inline-assembly bindings; `.rept 256` represents the source's macro expansion into 256 instructions, not a runtime loop. The constant array contains -0.25f. Integer add uses `vmv.v.x v9, increment` in place of the constant load and `vadd.vv v8, v8, v9` in the chain, where increment is a fixed 32-bit addend.

```asm
# FP32 subtract: one element group
vsetvli vl, remaining, e32, m1, ta, ma
vle32.v v9, (constants)
vle32.v v8, (src)
.rept 256
    vfsub.vv v8, v8, v9
.endr
vse32.v v8, (dst)
```

Each instruction reads the v8 written by its predecessor, while different element groups remain independent. At VLEN 512, a full group contains 16 elements; at VLEN 1024, it contains 32 and is translated into two 512-bit components. One traversal therefore requires 256 or 128 groups, respectively, but both perform 4096 × 256 element operations. Verification runs once after all repetitions and is included in the fresh-process timing. The same binary and repetition count are used at every VLEN.

| Microkernel | B, VLEN 512 | B, VLEN 1024 | Width speedup | M1, VLEN 512 | M1, VLEN 1024 | Width speedup |
|---|---:|---:|---:|---:|---:|---:|
| Integer add | 23.864 | 12.568 | 1.90 | 3.048 | 1.924 | 1.58 |
| FP32 subtract | 16.240 | 8.880 | 1.83 | 3.240 | 1.773 | 1.83 |

The baseline improves substantially when VLEN increases from 512 to 1024. Register promotion then lowers the absolute execution times at both widths. Integer addition illustrates why these comparisons must remain separate: after promotion, its width speedup is smaller, yet both promoted configurations are much faster than the baseline. A larger width ratio alone is therefore not a sufficient measure of translation quality.

Increasing VLEN changes both the arithmetic organization and the surrounding loop work: fewer element groups require fewer branches and vector-length updates. The elapsed-time ratios quantify their combined effect.

### Numerical and Application Cases

| Workload | B, VLEN 512 (s) | B, VLEN 1024 (s) | Width speedup |
|---|---:|---:|---:|
| Livermore K1 | 20.851 | 11.239 | 1.86 |
| Livermore K3 | 4.500 | 2.553 | 1.76 |
| LINPACK | 0.289 | 0.265 | 1.09 |
| TSVC s3251 | 0.110 | 0.108 | 1.02 |
| TSVC vbor | 0.061 | 0.057 | 1.07 |
| PolyBench ATAX | 0.096 | 0.084 | 1.14 |
| PolyBench Doitgen | 0.089 | 0.078 | 1.14 |
| Blackscholes | 2.529 | 2.088 | 1.21 |
| LavaMD | 0.483 | 0.328 | 1.48 |
| Streamcluster | 5.315 | 3.683 | 1.44 |
| JPEG encode | 0.617 | 0.652 | 0.95 |
| JPEG decode | 0.302 | 0.342 | 0.88 |
| H.264 CABA3 | 0.443 | 0.499 | 0.89 |
| H.264 crew | 1.695 | 1.987 | 0.85 |

Benefits extend beyond the synthetic chains, but vary with the computation. K1 offers an arithmetic dependency graph replicated across element groups. K3 includes a reduction, so its decomposition and combination work differ. The application cases include additional memory and control work. The observations show useful width scaling in these programs without assigning the same arithmetic explanation or expected factor to every case.

Figures 5.1 and 5.2 show B for every workload/input case. Within each panel, only simulated VLEN changes: the binary, input, and translation method remain fixed. The horizontal axis uses powers of two; elapsed time is linear and lower is better. Each workload retains the same vertical scale in the later method comparisons.

![Baseline width scaling: 1](../../figures/evaluation_width_baseline_1.pdf)

Figure 5.1. Baseline elapsed time across six VLENs, cases 1–8 of the workload list. Each panel represents one workload/input case; each point is the mean of 26 runs. Lower is better. Panels use separate time scales.

![Baseline width scaling: 2](../../figures/evaluation_width_baseline_2.pdf)

Figure 5.2. Baseline elapsed time across six VLENs, cases 9–16 of the workload list. Each panel represents one workload/input case; each point is the mean of 26 runs. Lower is better. Panels use separate time scales.

K1 continues to benefit from increasing VLEN, whereas the media baselines become more expensive as capacity grows. These contrasting curves motivate separate evaluations of state reuse and runtime bounds: more register capacity can expose additional independent work, but it can also increase the cost of translating and executing components.

## 5.3 Method Ablation

### Individual Methods

Figure 5.3 adds one method at a time to B. Its upper panels compare M1 with B in the applications used for state-access analysis; the lower panels compare M2 with B for the two H.264 inputs used in the skipped-work diagnostic. Comparisons are made at the same VLEN, so the gap between curves measures the method's net effect rather than a change in simulated width.

![Individual-method width comparisons](../../figures/evaluation_method_width.pdf)

Figure 5.3. Isolated method comparisons over six VLENs: B versus M1 for Blackscholes and LavaMD, and B versus M2 for H.264 crew and CABA3. Each panel preserves the corresponding baseline-view scale. Lower is better.

### Complete Ablation

The table gives the VLEN-1024 elapsed times for all 16 workload/input cases introduced in Section 5.1, in the same source-family order. Each entry is the mean of 26 complete-process measurements. Figure 5.6 presents the corresponding reductions relative to B; Appendix A retains all six widths.

| Workload | B (s) | M1 (s) | M2 (s) | Both (s) |
|---|---:|---:|---:|---:|
| Integer add | 12.568 | 1.924 | 12.667 | 1.928 |
| FP32 subtract | 8.880 | 1.773 | 8.873 | 1.821 |
| Livermore K1 | 11.239 | 3.005 | 11.308 | 3.002 |
| Livermore K3 | 2.553 | 2.549 | 2.528 | 2.528 |
| LINPACK | 0.265 | 0.265 | 0.266 | 0.266 |
| TSVC s3251 | 0.108 | 0.105 | 0.105 | 0.104 |
| TSVC vbor | 0.057 | 0.050 | 0.057 | 0.050 |
| PolyBench ATAX | 0.084 | 0.084 | 0.084 | 0.084 |
| PolyBench Doitgen | 0.078 | 0.079 | 0.078 | 0.078 |
| Blackscholes | 2.088 | 1.786 | 2.082 | 1.774 |
| LavaMD | 0.328 | 0.198 | 0.330 | 0.197 |
| Streamcluster | 3.683 | 3.683 | 3.727 | 3.725 |
| JPEG encode | 0.652 | 0.655 | 0.629 | 0.626 |
| JPEG decode | 0.342 | 0.328 | 0.322 | 0.302 |
| H.264 CABA3 | 0.499 | 0.498 | 0.440 | 0.441 |
| H.264 crew | 1.987 | 1.980 | 1.692 | 1.701 |

Figures 5.4 and 5.5 include all four configurations for every case. Following one line compares VLENs under a fixed method; comparing lines at one VLEN isolates the configuration change. The full ablation retains cases with small or negative improvements.

![Complete four-method width comparison: 1](../../figures/evaluation_width_all_1.pdf)

Figure 5.4. B, M1, M2, and Both across six VLENs, cases 1–8. Panel order and per-workload axis limits match Figure 5.1. Each point is the mean of 26 runs. Lower is better.

![Complete four-method width comparison: 2](../../figures/evaluation_width_all_2.pdf)

Figure 5.5. B, M1, M2, and Both across six VLENs, cases 9–16. Panel order and per-workload axis limits match Figure 5.2. Each point is the mean of 26 runs. Lower is better.

![Complete method ablation at VLEN 1024](../../figures/evaluation_ablation.pdf)

Figure 5.6. Elapsed-time reductions for all 16 workload/input cases at VLEN 1024. Each bar is 100(1 - T(X,1024)/T(B,1024)), using the arithmetic means of 26 rounds. Positive values denote less time than B; negative values denote more time. B is the zero reference. Colors and hatching identify M1, M2, and Both.

M1 reduces Blackscholes and LavaMD time by 14.5% and 39.7%, respectively. M2 alone has little net effect on their mean elapsed times under these settings. H.264 shows the reverse pattern: M2 reduces crew and CABA3 time by 14.8% and 11.9%, while M1 changes are small. JPEG decoding benefits from the integrated configuration more than either isolated configuration.

Both is not uniformly faster than each individual method. For crew, its mean is about 0.6% above M2. The integrated implementation changes value retention and component/control-flow organization together; its effect is not an additive combination of independently saved percentages. Small mean differences are reported as such rather than treated as a stable ranking.

### Blackscholes: Reusing Arithmetic Intermediates

Blackscholes computes option prices through floating-point arithmetic and approximations to elementary functions. Cycle sampling locates substantial activity in the vector option-pricing function. The following consecutive instructions occur at its hot block starting at address 0x105a0:

```asm
vfmul.vf v31, v7, fa4
vfadd.vv v20, v20, v31
vfmul.vv v31, v22, v24
vfmul.vv v25, v23, v25
vfmul.vv v23, v23, v23
```

The first multiplication produces a value consumed by the addition; the next multiplication then defines a new value of v31. At VLEN 1024 with FP32 elements and LMUL 1, each instruction operates on two 512-bit components. The baseline stores both components of the first product to vector-register state and loads them again for the addition. In the captured x86 code, these stores address offsets 0x3ed0 and 0x3f10 from the CPU-state pointer. The addition subsequently reloads those same locations.

M1 instead retains the products in zmm15 and zmm16. Its two additions directly consume these registers, using `vaddps zmm17{k1},zmm4,zmm15` and `vaddps zmm18{k2},zmm5,zmm16`. The earlier products need not be published after their last use because the following multiplication overwrites v31; the final required definitions are published at the run boundary. This is removal of intermediate state transfers, not removal of the multiplications or additions.

At VLEN 1024, M1 reduces complete-process time from 2.088 to 1.786 seconds, or 14.5%. Retired instructions decrease by 6.9% and counted cycles by 14.7%. The disassembly identifies a concrete source of eliminated work; the process-wide counters include other arithmetic, control flow, and translation. M2 changes the elapsed time little in this case, whereas M1 addresses reuse within its arithmetic sequences.

### LavaMD: Retaining Accumulated Values

LavaMD evaluates particle interactions. Its vector kernel combines particle coordinates, evaluates an interaction factor, and accumulates contributions. The hot block starting at address 0x10bac includes the following sequence:

```asm
vfadd.vf  v15, v15, fa2
vfmul.vf  v19, v16, fa1
vfmacc.vf v19, fa0, v17
vfmacc.vf v19, ft4, v18
vfsub.vv  v15, v15, v19
vfmul.vf  v15, v15, fa3
```

Here v19 is an accumulator: the multiplication defines it, both fused multiply-adds update it, and the subtraction consumes it. The value of v15 also passes from addition to subtraction and multiplication. In the baseline, the boundaries between these RISC-V instructions incur repeated state stores and reloads for each component. M1 carries the intermediate values through host registers within an admitted run. The captured x86 sequence retains packed additions, multiplications, and `vfmadd231ps` operations; it connects their operands through registers instead of publishing each intermediate value.

This longer reuse chain offers more removable state traffic than a single producer-consumer pair. It does not make the accumulator updates independent: their arithmetic dependency remains. At VLEN 1024, elapsed time falls from 0.328 to 0.198 seconds under M1, a 39.7% reduction. Retired instructions decrease by 27.5% and counted cycles by 43.7%. These observations support reducing state-transfer overhead along dependent arithmetic chains, rather than attributing the improvement to additional independent arithmetic.

### H.264 crew: Bounding Widening Operations

The crew input exercises a different opportunity. Cycle sampling identifies the luma deblocking routine, `ff_h264_loop_filter_luma_8_rvv`, as a hot routine. Deblocking filters reconstructed pixels around block boundaries. Its caller sets a short element range, and the routine uses widening arithmetic for pixel differences and sums. The excerpts below separate the caller's configuration from the callee's arithmetic:

```asm
# Caller configuration before the filter call
vsetivli zero, 16, e8, m1, ta, ma

# Arithmetic in ff_h264_loop_filter_luma_8_rvv
vaaddu.vv v14, v10, v11
vwsubu.vv v16, v9,  v12
vwaddu.vv v18, v8,  v14
vwaddu.vv v20, v13, v14
vnsra.wi  v24, v16, 2
vnsrl.wi  v14, v18, 1
vnsrl.wi  v15, v20, 1
```

The configured vl is 16, even when VLEN is 1024. Widening from 8-bit sources produces a 16-bit destination register group with effective LMUL 2. Its capacity is 2048 bits, or four 512-bit destination components containing 32 elements each. Only the first can contain elements below vl; the others begin at element indices 32, 64, and 96.

Without M2, these high components still have emitted arithmetic bodies, although their results do not contribute to the requested element range. With M2, comparisons against vl branch past them. The captured x86 code contains the low-component `vpsubw`, followed by bounds checks that bypass the high-component subtraction bodies. Per-element masking still handles the partial first component. Thus M2 removes unnecessary component execution, rather than widening the useful pixel calculation.

For crew, M2 reduces time from 1.987 to 1.692 seconds, or 14.8%; retired instructions and counted cycles decrease by 10.9% and 15.2%. M1 alone gives little improvement. This case shows why capacity-based decomposition must be bounded by the operation's runtime element range.

### H.264 CABA3: The Same Mechanism on Another Input

CABA3 uses the same decoder binary and reaches the same luma deblocking routine shown above. Sampling also identifies the chroma deblocking routine, whose widening difference and narrowing operations have the same short-range opportunity. It is a second input to the same implementation, not a different filtering algorithm.

At VLEN 1024, M2 reduces CABA3 time from 0.499 to 0.440 seconds, or 11.9%. Retired instructions decrease by 8.8% and counted cycles by 13.1%. The improvement has the same direction as crew but a different magnitude. Both inputs exercise bounded widening arithmetic; their complete-process times include different amounts of other decoding work. The measurements do not assign all saved cycles to a single filter.

The code captures for these four cases use the timing campaign's translator executable and workload binaries. All eight diagnostic executions, comprising the baseline and the relevant method for each case, match their reference outputs. Cycle sampling selects the code to inspect; the reported times and instruction/cycle reductions remain those of the 26-round campaign, not the diagnostic runs.

## 5.4 External Systems

External comparisons address two questions: execution efficiency at the same simulated VLEN, and the additional benefit available when a system can use longer RVV vectors. The same-VLEN results use a separate four-round campaign. Each comparison holds the RISC-V binary and input fixed at the stated simulated VLEN. Translation or compilation during the measured process is included; compiler children share the same one-core allocation, and libriscv does not reuse compiled artifacts across runs. These means are kept separate from the 26-round ablation and the supported-width experiment below.

### Same-VLEN System Comparison

| Workload | rvdbt B (s) | rvdbt Both (s) | QEMU (s) | rv32emu (s) |
|---|---:|---:|---:|---:|
| Integer add | 12.569 | 1.921 | 4.117 | 240.626 |
| FP32 subtract | 8.873 | 1.770 | 103.433 | 82.211 |
| Livermore K1 | 11.244 | 3.012 | 39.041 | Error |
| Livermore K3 | 2.550 | 2.525 | 9.340 | Error |
| LINPACK | 0.265 | 0.265 | 1.487 | Error |
| TSVC s3251 | 0.109 | 0.103 | 0.347 | Error |
| TSVC vbor | 0.057 | 0.052 | 0.098 | Error |
| PolyBench ATAX | 0.086 | 0.084 | 0.273 | Error |
| PolyBench Doitgen | 0.079 | 0.078 | 0.195 | Error |
| Blackscholes | 2.094 | 1.777 | 6.167 | Error |
| LavaMD | 0.327 | 0.201 | 2.162 | Error |
| Streamcluster | 3.687 | 3.731 | 17.258 | Timeout |
| JPEG encode | 0.658 | 0.632 | 1.189 | Error |
| JPEG decode | 0.342 | 0.310 | 0.936 | Error |
| H.264 CABA3 | 0.497 | 0.453 | 1.175 | Error |
| H.264 crew | 1.985 | 1.701 | 5.806 | Error |

rv32emu has its first JIT tier enabled. Error denotes an execution error or failure to produce a validated output; Timeout denotes no completion within the 120-second probe. Neither entry is an elapsed-time measurement.

At VLEN 1024, rvdbt Both has a lower mean elapsed time than QEMU in all 16 reported cases. Among applications, the speedups include 3.47 times for Blackscholes, 3.41 times for H.264 crew, and 1.88 times for JPEG encoding. The per-instruction baseline is already faster than QEMU on these applications; the fixed-VLEN ablation in Section 5.3 identifies the additional contribution of the two methods.

Integer add illustrates why the execution path matters. QEMU is faster than rvdbt B but slower than Both. In the captured QEMU translation at VLEN 1024, the first RVV add expands into four YMM additions with state loads and stores. The next RVV add reuses the YMM values without reloading them, but still stores all four results. Thus the observed difference is not the absence of value forwarding in QEMU: rvdbt's admitted promotion sequence can also defer intermediate stores, and its main path uses wider host operations. In contrast, the measured QEMU floating-point-subtract translation calls an RVV helper rather than emitting packed subtraction inline [QEMU-RVV]. These are distinct sources of system-level overhead.

The two numeric rv32emu entries are four-run means. RVV blocks use the interpreter; scalar blocks can use the first JIT tier.

The rv32emu comparison enables RVV and the first JIT tier, with the LLVM second tier disabled. The tested revision lacks the second-tier vector handlers, including `t2c_vsetvli`; enabling EXT_V, JIT, and T2C together causes a build failure. The measurements therefore use the available first-tier-enabled configuration.

Application compatibility depends on both the ISA and the execution environment. Blackscholes and H.264 encounter unsupported system-call or block-translation errors. LavaMD still encounters such errors after correcting guest-argument forwarding; JPEG encode and decode reach an emulator assertion. Livermore K3 requests SEW 64, which the rv32emu build rejects by setting vill and vl to zero. A debugger trace records repeated illegal-instruction traps and an unchanged remaining-element count, explaining its earlier timeout. Streamcluster also exceeds the 120-second probe; its log reports unsupported mmap and writev calls. Neither is a valid slow execution of the workload. QEMU's direct vector path also uses a different maximum host width from rvdbt's main path; these are complete-system comparisons, not controlled host-width ablations.

libriscv is evaluated at its tested 256-bit RVV configuration. The table includes the 11 cases from the workload set with validated outputs in all three execution modes; all times are in seconds. The remaining five cases encounter unimplemented integer vector forms: `vsub.vx` in Blackscholes and `vmax.vx` in JPEG and both H.264 inputs. Debugger traces identify these first failing instructions in the measured executable. Those cases therefore contribute no elapsed-time results.

| Workload | rvdbt Both (s) | QEMU (s) | libriscv interpreter (s) | TinyCC (s) | System C (s) |
|---|---:|---:|---:|---:|---:|
| Integer add | 5.892 | 10.732 | 170.349 | 162.734 | 153.083 |
| FP32 subtract | 5.498 | 107.550 | 10.730 | 20.271 | 2.032 |
| Livermore K1 | 10.010 | 78.283 | 26.631 | 12.127 | 3.064 |
| Livermore K3 | 8.587 | 18.135 | 6.653 | 4.310 | 2.020 |
| LINPACK | 0.361 | 1.586 | 1.166 | 0.584 | 1.517 |
| TSVC s3251 | 0.113 | 0.385 | 0.334 | 0.158 | 9.512 |
| TSVC vbor | 0.054 | 0.107 | 0.071 | 0.082 | 9.875 |
| PolyBench ATAX | 0.129 | 0.318 | 0.238 | 0.168 | 1.049 |
| PolyBench Doitgen | 0.115 | 0.227 | 0.164 | 0.118 | 1.011 |
| LavaMD | 0.386 | 2.376 | 1.181 | 1.017 | 4.086 |
| Streamcluster | 8.834 | 23.287 | 10.273 | 6.748 | 47.837 |

The system C compiler produces the fastest result in several floating-point cases even with compilation included. For FP32 subtract, compilation takes approximately 1.234 seconds within the 2.032-second process time. The captured host code contains 256 dependent YMM `vsubps` operations without intervening loads, stores, calls, or branches; the result is stored after the chain. The compiler preserves the arithmetic while removing intermediate vector-state transfers. By contrast, the captured integer-add path calls an RVV handler for each add. Exposing the floating-point operations to native optimization repays compilation cost in this experiment, whereas the handler-based integer path remains expensive [libriscv].

### Supported Vector Lengths

A second four-round experiment keeps each binary and input fixed while sweeping rvdbt Both from VLEN 128 through 4096. The two libriscv C-compilation modes retain their tested VLEN 256 configuration. Output validation uses the reference for each width, since a change in vector length can change floating-point reduction order. The table reports the 11 compatible cases from the thesis workload set. The asmjit column comes from a separate four-run campaign on the revision cited in Section 2.4; it is not pooled with either C-compilation mode. Every time includes translation and execution, in seconds.

| Workload | System C 256 | TinyCC 256 | Asmjit 256 | Both 256 | Both 1024 | Both 4096 |
|---|---:|---:|---:|---:|---:|---:|
| Integer add | 153.365 | 162.503 | 168.866 | 5.898 | 1.927 | 0.829 |
| FP32 subtract | 2.034 | 19.801 | 12.425 | 5.478 | 1.776 | 0.989 |
| Livermore K1 | 3.062 | 12.124 | 18.560 | 10.019 | 3.005 | 1.688 |
| Livermore K3 | 2.018 | 4.304 | 4.692 | 8.571 | 2.524 | 1.203 |
| LINPACK | 1.514 | 0.582 | 1.216 | 0.361 | 0.265 | 0.225 |
| TSVC s3251 | 9.546 | 0.157 | 0.362 | 0.112 | 0.102 | 0.091 |
| TSVC vbor | 9.863 | 0.081 | 0.100 | 0.052 | 0.050 | 0.055 |
| PolyBench ATAX | 1.049 | 0.166 | 0.248 | 0.127 | 0.084 | 0.073 |
| PolyBench Doitgen | 1.008 | 0.118 | 0.167 | 0.116 | 0.078 | 0.076 |
| LavaMD | 4.118 | 0.988 | 0.951 | 0.382 | 0.197 | 0.201 |
| Streamcluster | 47.794 | 6.731 | 7.865 | 8.826 | 3.732 | 3.191 |

At VLEN 256, system C outperforms rvdbt on FP32 subtract, K1, and K3, while TinyCC is faster on Streamcluster. Figure 5.7 shows how these four comparisons change as rvdbt uses longer vectors. FP32 subtract becomes faster than the corresponding libriscv reference at VLEN 1024, and Streamcluster at 512. K1 reaches approximately the same time at 1024, and K3 becomes faster at 2048. At 4096, the speedups over the faster measured C-compilation mode are 2.06, 1.81, 1.68, and 2.11 times for FP32 subtract, K1, K3, and Streamcluster, respectively. No recompilation of the RISC-V binary is required between widths.

![Long-vector execution relative to fixed-width libriscv configurations](../../figures/evaluation_external_capacity.pdf)

Figure 5.7. Complete-process times for the four cases in which a libriscv C-compilation mode is faster than rvdbt at VLEN 256. The green curve varies rvdbt VLEN under Both; each horizontal reference is the faster measured libriscv C-compilation mode at its fixed VLEN 256. Each point or reference averages four runs from the supported-width experiment. The reference is not a libriscv width sweep. Lower is better.

This reversal demonstrates a benefit of supporting longer RVV execution in addition to optimizing each host-vector operation. It is a comparison of available vector-length configurations, whereas the preceding tables compare systems at equal VLEN. The 4096 configuration has a lower mean time than the three measured compiling modes in all 11 reported cases, but 4096 is not always rvdbt's best width: LavaMD and TSVC vbor are faster at 1024. Longer vectors change loop grouping as well as the number of host components; the resulting balance depends on the computation. Section 5.3 separately measures how state reuse and runtime bounds affect that balance at a fixed VLEN.

### Comparison Coverage

The external timing set comprises systems that execute the same RV32 binaries with validated outputs. HQEMU supplies relevant SIMD transformation techniques but has no RISC-V frontend in its public release. PasRISCV and Berberis target RV64 environments, so their source-level capabilities are discussed in Section 2.4 rather than assigned times for incompatible binaries. The comparisons establish performance for the tested configurations; the implementation analysis explains why instruction coverage and the choice between inline SIMD and handlers matter to those results.

### Functional Simulator Reference Paths

Whisper and Spike also execute long RVV on x86-64. Their functional-simulation paths provide a separate reference from the preceding JIT comparisons. The following measurements use the same archived RV32 ELF, input, VLEN and physical core within each pair, with four complete-process runs. Spike additionally executes a proxy kernel, including its startup and system-call handling. Each rvdbt mean comes from its corresponding paired campaign; means from different campaigns are not pooled.

| Reference system | Workload | VLEN | rvdbt Both (s) | Reference (s) |
|---|---|---:|---:|---:|
| Whisper | ATAX | 1024 | 0.086637 | 2.221454 |
| Whisper | ATAX | 4096 | 0.075418 | 1.975290 |
| Whisper | LINPACK | 1024 | 0.268332 | 12.872439 |
| Whisper | LINPACK | 4096 | 0.227861 | 12.638133 |
| Whisper | s3251 | 1024 | 0.106536 | 2.664934 |
| Whisper | s3251 | 4096 | 0.095214 | 2.504711 |
| Spike + proxy kernel | ATAX | 1024 | 0.087979 | 1.052708 |
| Spike + proxy kernel | ATAX | 4096 | 0.076149 | 0.996282 |
| Spike + proxy kernel | LINPACK | 1024 | 0.268234 | 4.836920 |
| Spike + proxy kernel | LINPACK | 4096 | 0.226214 | 4.967119 |
| Spike + proxy kernel | s3251 | 1024 | 0.106129 | 0.961899 |
| Spike + proxy kernel | s3251 | 4096 | 0.093161 | 0.897359 |

The differences encompass interpretation, architectural-state processing and execution-environment services. They establish that long-vector capacity is available in other systems while separating that capability from the execution efficiency of a native SIMD path. Renode also passes a 4096-bit bare-metal vector-add diagnostic, but its virtual-platform setup has not been matched to the application environment. Pydrofoil passes three 512-bit vector-add probes; these are execution and trace checks rather than application timings. Neither is assigned a performance ratio [Spike, Whisper, Renode, Pydrofoil].

## 5.5 Findings and Scope

The results support three connected findings. First, a longer simulated vector can reorganize independent element-group computations and reduce loop work enough to improve execution on a fixed-width host. Second, the benefit can be dominated by the cost of repeatedly materializing vector state; register promotion substantially reduces that cost where compatible sequences offer reuse. Third, larger capacity can be harmful when the runtime element range stays short; bounds-based omission limits that growth.

The microkernels expose repeated state transfers along long arithmetic chains. The application measurements show whether reducing state traffic and unused component work improves complete-process time, which also includes translation, memory access, and control flow.

The quantitative results apply to the measured AMD host. Other processors can differ in vector instruction latency, throughput, execution width, and frequency behavior. Likewise, the optimized instruction subset and workload binaries determine which paths are exercised. Extending the measurements to another microarchitecture and an optimizing tier would test the portability of the observed balance between reuse, useful work, and compilation cost.

## 5.6 Limitations and Extensions

**Optimization scope.** Promotion operates within an admitted instruction sequence in a translation block. Configuration changes, incompatible state effects, cross-component dependencies, and register demand constrain that sequence. A reduction or permutation therefore cannot inherit the element-wise reordering rule merely because its operands are vectors. Extending promotion requires explicit dependence and state-update rules for the additional forms. Helpers remain a semantic implementation option; replacing a helper with inline SIMD requires preserving its rounding, exception, masking, and memory-access behavior.

**Runtime bounds.** Bounds remove only the suffix known to lie beyond `vl`. They retain partial-component lane selection, final stores, and completion updates. When all components are needed, the checks can add work without removing arithmetic. Full-length guards can avoid checks on eligible paths; extending that optimization requires facts about runtime configuration, not workload-specific assumptions. Figure 5.4 and Figure 5.5 report the net effect, including cases where the integrated method does not beat an individual method.

**Optimizing compilation.** The reported results use the lightweight JIT, not the online LLVM tier. An extension should pass vector operations and their state effects to LLVM, establish a common state interface for entering and leaving compiled regions, and install code only when its configuration assumptions hold. HQEMU's hot-region compilation, Instrew's state interface, and Arancini's shared representation provide relevant designs [HQEMU, Instrew, Arancini]. Evaluation must include compilation and installation in total process time and measure whether execution reaches the optimized region before the program finishes.

**Hardware and measurement.** The main matrix uses one AMD processor. Register capacity, execution throughput, scheduling-window size, and frequency behavior can change the tradeoff on Intel or another AMD implementation. Retired instructions quantify changes in executed work; total cycles and elapsed time measure their aggregate cost. They do not identify which pair of vector instructions issued together. A cross-microarchitecture study should keep binaries, inputs, and timing boundaries comparable while inspecting the generated instructions and instruction-specific hardware behavior.

**Coverage.** The tests establish behavior for the exercised instruction forms, configurations, and workloads, rather than complete RVV conformance. The 16 reported cases include extracted kernels and multiple inputs to one decoder. External systems also differ in instruction support and operating-system services. The comparison therefore separates completed application timings from diagnostic probes, execution failures, and timeouts.

## 5.7 Functional Validation

### External Tests and Result Checking

The inventory counts mnemonic and operand variants separately: `vadd.vv`, `vadd.vx`, and `vadd.vi` are three forms, and memory widths and segment counts are enumerated. It contains 627 forms, of which 32 indexed-memory forms require 64-bit indices outside the RV32/ELEN64 profile, leaving 595 applicable forms [RVV]. Appendix B lists this scope; the implementation repository provides the corresponding per-suite form table and runnable external fixtures [rvdbt-impl]. A checked form requires a binding between the retained target operation and the output assessed by its checker. Source presence, compilation and program completion are recorded separately.

The validation chain retains the external input, establishes its expected result through the original assertion or an independent reference, and compares the device under test (DUT), rvdbt, against that result. CHIPS generates self-checking programs using modified Spike reference results [CHIPS-tests]. Architectural tests retain expected values and signature comparisons; Ara retains typed vector, scalar, memory and CSR predicates [ACT-tests, Ara-tests]. RVV-ATG binds target macros to Spike signatures and compares the same ELF's QEMU and DUT output [RVV-ATG]. SiFive RIF binds emitted operation symbols to unchanged operation-result goldens [SiFive-RIF]. Reference failures and original DUT failures remain distinct from accepted comparisons.

Environment adaptations change startup, reporting or ABI interfaces while retaining the external calculation and assertions. Changes to generation geometry or configuration expectations are labeled separately: CHIPS separates XLEN 32 from ELEN 64, with disclosed local configuration constants; specification-based state observers and tests generated through external APIs are derivatives. Their results do not retroactively validate an unsafe or blocked original test. Exact inputs, adaptations, checker scopes and reference identities are linked in Appendix B.

| External source | Target/result-checked forms | Checked output |
|---|---:|---|
| CHIPS Alliance Vector Tests | 595 | Selected destination words, store prefixes and explicit CSR checks |
| RISC-V Architectural Tests | 590 | Selected destination regions, scalar results and flags |
| RVV-ATG | 434 | Target-bound signatures; e64 extraction observes low32 |
| Ara vector tests | 422 | Original typed vector, scalar, memory and CSR predicates |
| SiFive RIF | 200 | Emitted operation results bound to original goldens |
| Union | 595 | Overlapping sets; counts are not added |

The sources complement one another at specific forms. The ACT checked set lacks `vfmv.f.s`, `vfwcvt.f.f.v`, `vsetivli`, `vsetvl` and `vsetvli`; Ara supplies result checks for all five. The three configuration forms retain Ara's original comparisons and same-ELF Spike state observations, rather than relying only on locally specified configuration constants. Combining these sources therefore closes identifiable form-level gaps, while each checker retains its own state and configuration limits.

Checker execution also matters. ACT obtains expected signatures from Sail, but its guest-side data-vector length checker uses `vmsne.vv` to construct a mismatch mask and `vfirst.m` to find a mismatching element. Those instructions execute on the DUT. The independent expected signature therefore does not eliminate dependence on the DUT's comparison instructions [ACT-tests].

The candidate-specific index also establishes a 595-form checked union for the clean correctness build. Historical candidates remain separately identified. The table counts forms whose results are checked at the recorded configurations, including direct and helper routes. Sequence tests use a different unit of verification: RVVTS and RVISmith compare recorded sequence or program outputs involving 58 and 43 forms, respectively [RVVTS, RVISmith]. These counts describe the operations participating in those sequences, not individually checked instructions, and are excluded from the table's checked-form union.

The retained external CHIPS campaign provides 11,532 accepted program executions on the clean correctness build, distributed as follows. Each configuration executes the same registered cases at the indicated width; B, M1, M2 and Both are counted separately. An additional 212 failure-control executions produce the required failure exit and message. These controls check failure propagation and are excluded from instruction-form coverage.

| VLEN (bits) | Per configuration | Four configurations |
|---:|---:|---:|
| 128 | 2,364 | 9,456 |
| 256 | 27 | 108 |
| 512 | 27 | 108 |
| 1024 | 401 | 1,604 |
| 2048 | 27 | 108 |
| 4096 | 37 | 148 |
| Total | 2,883 | 11,532 |

This distribution is not a sweep of all 595 forms at every width. The per-form records identify the executed programs and their original assertions; source locations provide the SEW, LMUL, requested VL and mask context. Requested VL and source presence are distinguished from observed runtime state and optimized-path admission. Historical-build executions have separate records and are not added to this table.

The two ACT source campaigns retain separate Sail signatures and original self-checkers; the indexed-memory revision does not increase the form union [ACT-db2]. Two privileged-state reference blockers remain excluded. Ara extraction retains each supported block's literals, assertions and initialization, including round-toward-zero for division and square root; these are block acceptances, not complete mixed-precision file passes. Reserved different-width source overlap and source objects shorter than vector loads retain their original dispositions [RVV].

The adapted RIF reductions preserve the original inputs, reduction graph and scalar predicates, and compare the same ELF with QEMU and all four DUT configurations. The host scalar evaluator reads uninitialized storage, and a zero seed absorbs some AND/unsigned-min results. Agreement therefore supplies only the stated scalar endpoint evidence, without additional independent-form or optimization-admission credit [SiFive-RIF].

A concrete example is the adapted CHIPS `vadd.vv` file at VLEN 1024 and LMUL 8. It retains 26 targets and 6,656 original checker words. The disjoint destination and source groups are v8–v15, v16–v23 and v24–v31. One masked SEW-64 target requests AVL 63 and updates 38 enabled lanes, while the original comparisons check the destination group, including preserved masked-off and tail values under tu/mu. The modified-Spike generation, original self-check, same-ELF QEMU reference and clean DUT B, M1, M2 and Both runs all pass. This checks the stated destination geometry and preservation; it does not observe every register or establish promotion admission.

### Directed Matrices and State Comparison

External original suites and project-authored per-form directed matrices serve complementary purposes: the former retain independently authored workloads and predicates; the latter isolate architectural effects at explicit boundaries. Each directed case initializes vector registers, scalar operands, memory where applicable and vector/FP control state; executes the encoded target; then captures a poststate snapshot. A host-side checker first validates the recorded prestate and packet identity, applies an independent specification predicate, and compares defined results with a pinned executed Spike or Sail reference. The same target/observer body is used for the reference and DUT. Successful process exit alone is insufficient; missing/truncated packets, timeouts, wrong target bindings or predicate failures reject acceptance.

The manifest indexes each mnemonic/operand form and its actual selected SEW, LMUL, VLEN, VL/VLMAX, mask, initialized `vstart`, tail/mask policies, operand EMUL, rounding mode and overlap class. Boundary cases include zero/partial/full lengths and positions around source and destination host chunks. Dimensions vary by family: marginal values are not a Cartesian product, and declared values are checked against captured state where observed. The common observer checks all 32 logical vector registers and ten vector/FP CSRs; family observers add the relevant scalar registers, memory and intermediate sequence values. Missing observations remain explicit in the form index.

Oracles follow the operation's permitted outcomes. Integer predicates use exact bit arithmetic; floating-point predicates use exact rational decoding and rounding rather than host casts or DUT-generated goldens. Defined active results and sticky flags are compared exactly. Inactive agnostic elements use the permitted old-or-all-ones set, while prestart and undisturbed elements preserve their required bytes. Unordered floating-point reductions admit finite inputs only when the predicate establishes exact representability for every permitted reduction tree, together with separately bounded special-value cases. Arbitrary inexact unordered sums are outside that oracle. Illegal overlap, unsupported precision and reserved entry conditions remain separate from ordinary successful cases. Scalar-insertion comparisons with nonzero starts use the disclosed permissive Sail mode; default-mode traps remain separate reference attempts.

### State Preservation and Optimized Paths

The completed sequence matrix checks 2,418 cases per Reference/B/M1/M2/Both arm, comprising 9,672 DUT checks. It covers declared integer/FP sequences, initialized starts, boundary lengths, alias/overwrite behavior and both same-PC cache orders on one frozen correctness build. Original ELFs and validated reference packets are reused; this replay performs no reference executions or ELF rebuilds. Full acceptance uses the trace-disabled configuration; the trace-enabled configuration has only its retained focused acceptance.

Optimization admission is established by joining target PCs, generated host code and executed frame records to architectural snapshots. The audit checks retained producer-to-consumer values for M1, low-component consumers, and Both's publication of completed values before the next component bound and its skip join after required stores. Same-PC visits with different first observed vector types test specialization and guarded fallback. These observations verify actual paths in the declared sequences; enabling M1/M2 switches or checking all indexed forms does not establish universal optimization admission.

### Validation Findings

Directed comparisons exposed three semantic defects. Fused multiply-add of zero and infinity must accrue NV even when a quiet-NaN addend already determines the canonical NaN result; the old x86 FMA-based route produced the correct value but missed NV. RMM FP64-to-FP32 narrowing at a minimum-normal boundary produced the correct rounded bits but omitted UF: tininess after precision rounding with an unbounded exponent requires UF together with NX. Scalar insertion by `vmv.s.x` or `vfmv.s.f` must preserve element 0 whenever initial `vstart` is nonzero; the old `vstart < vl` guard incorrectly wrote that prestart element. The corrected insertion requires `vstart == 0` and `vl > 0`, and still clears `vstart` on normal completion. Retained original failures, unchanged predicates and before/after packets establish these findings; their family builds and later integration remain separately identified in the reproduction records.

### Versions and Limits

The final correctness campaign uses one frozen RV32/ELEN64 Release executable with 512-bit QCG host components for directed matrices, external replay and sequence validation. Earlier family and external results retain their historical identities. The 384 means reported earlier belong to the original frozen performance executable. Correctness bindings retain executable, library, ELF and complete flags; rebuilding the integrated source creates a new executable identity with no inherited receipt credit.

Full register/CSR/memory state, memory-access suppression, intermediate flags, write-history-aware agnostic choices, arbitrary overlap and restart remain incomplete outside the accepted witnesses. RIF uses one seed, length 500 and VLEN 128; ATG uses frozen e32/m1 and limited e64 extensions. RVISmith retains wildcard/NaN normalization and no nonzero input high32 evidence. Source and checker blockers, including unsafe original store outputs, are retained in Appendix B.

Fault handling is evaluated separately from instruction-form coverage. The runtime registers synchronous SIGSEGV/SIGBUS actions and delivers faults identified at checked-helper accesses. For supported singleton memory instructions, the generated code also records the exact host access sites and exits to the dispatcher after a fault. QCG ends a promoted sequence at a memory instruction so that preceding architectural results are available at this boundary. Local tests inspect register, memory and exception state after the first fault; the scalar-memory and memory-boundary suites check 44 and 10 terminal snapshots, respectively. Eight retained signal-delivery executions across B, M1, M2 and Both check first-element faults and later fault-only-first behavior. These guest handlers exit without returning to retry the instruction. Handler return and complete guest instruction restart remain unverified.

The signal interface also uses checked copies for action, mask and frame buffers. Local regressions include inaccessible pages and truncated file backing, with 2,063 interface checks, 256 floating-point-state roundtrips and 192 invalid-frame rejections. These tests invoke the host interface directly; they do not execute a returning guest handler.

The final same-build directed replay completes all 102 ordinary entries for the 595 applicable forms: 3,017,262 cases per B/M1/M2/Both arm and 12,069,048 positive DUT packet checks. Focused witnesses add 2,256 positive checks, giving 12,071,304 positives in total; 592 focused denial controls are counted separately. Every accepted positive passes the original specification/reference predicates and an independent reread of the captured outputs. The replay reuses frozen ELFs and validated reference packets, with no new reference executions or ELF builds. Per-form records join actual results to accepted case IDs, dimensions, pinned sources and checker bindings; reserved source declarations remain outside the positive denominator.

The same executable also completes 21,316 external commands: 11,532 positive CHIPS executions and 212 failure controls, 7,668 ACT passes, and 1,888 whole-file Ara passes plus 16 scoped acceptances. Each of B, M1, M2 and Both accounts for 5,329 commands. Ara's scoped results accept only TEST_CASE1/2 and retain the original TEST_CASE3/4 failures; two ACT reference blockers remain excluded. These are new DUT executions on the final correctness executable, separately recorded from the historical external campaign. The sequence matrix above uses that same executable, while its 9,672 DUT checks remain a separate denominator. The 595 applicable forms within the 627-form inventory establish finite checked matrices, with actual exception, trace and oracle limits retained, rather than all possible RVV inputs.
