# 3. Framework

This chapter follows the path from an RVV instruction in a RISC-V binary to executable x86-64 code. The extension adds vector state and operations to rvdbt's existing lightweight JIT; it retains the dispatcher, translation cache, and block-linking mechanism. Figure 3.1 identifies the components used along this path. Sections 3.2--3.4 follow its translation pipeline from the RISC-V frontend, through QIR and CPU state, to the x86-64 backend.

## 3.1 System Architecture

rvdbt combines a lightweight JIT with profile-guided AOT compilation. In the workflow described by Lin, a first execution collects a profile, an offline LLVM compiler generates optimized regions, and a subsequent execution loads the artifact while retaining JIT execution elsewhere [Lin2025]. This thesis extends and evaluates the lightweight path shown in Figure 3.1.

![RVV extension within the rvdbt JIT architecture](../../figures/rvdbt_rvv_framework.svg)

Figure 3.1. rvdbt's lightweight execution path, adapted from the organization described by Lin [Lin2025]. (a) Runtime execution: a cache miss invokes the lightweight JIT, which installs the generated code in the translation cache. (b) Internal stages of the same JIT: the RISC-V frontend (Section 3.2), QIR (Section 3.3), and the three-stage QCG backend (Section 3.4). CPU state is described in Section 3.3. Solid arrows denote control or code transfer; dashed arrows denote runtime data access. Shaded components contain RVV extensions.

The ELF loader maps the RISC-V binary and establishes the initial program counter. The dispatcher looks up that address in the translation cache. On a miss, the RISC-V frontend constructs QIR for the block, and the QCG backend generates its x86-64 implementation. The runtime installs this code in the cache and enters it through a trampoline, an entry stub that provides the CPU-state pointer and program-memory base.

A translated branch can jump directly to a linked block. An unresolved target returns to the dispatcher, which obtains the target block and patches the link. RVV instructions use this same execution loop. Their generated code reads architectural registers from CPU state, performs vector operations, and writes the required results back. Accesses to the RISC-V program's arrays use a separate program-memory mapping.

## 3.2 RISC-V Frontend

The frontend in Figure 3.1 decodes each instruction and constructs its QIR operations. For RVV, it combines the instruction's operand form with the vector configuration: element width, register grouping, and the configured VLEN. For an applicable direct implementation, it determines how the operands are divided into host vector values; a form without a direct implementation is represented by a helper call in QIR.

Consider the unmasked instruction `vadd.vv v10, v8, v9`, with VLEN 1024, SEW 32, and LMUL 1. Each source contains 32 integers. On the 512-bit path, the frontend divides each operand into two contiguous groups of 16 elements. We call each such group a *component*. Figure 3.2 aligns these groups with a shared QIR-to-x86 mapping and the destination elements written by the partial-update branch. Components are compiler values at this stage, not assigned ZMM registers.

![One RVV addition represented by two vector components](../../figures/rvv_translation.svg)

Figure 3.2. RVV addition on two 512-bit components. (a) Each cell is a 32-bit element in a CPU-state register slot; the boundary at 16 separates the components. (b) The full-update mapping applies to both components: four loads, two additions, and two stores. The mapping symbol denotes lowering, not execution order; all source loads precede the additions and stores. (c) With the QCG partial branch enabled, two `vchunkpartialalu` nodes update elements 0--19. Shading denotes written elements; elements 20--31 retain their previous values in this implementation. The AVX-512 store opmasks select 16 and 4 elements even though the RVV instruction is unmasked. Guard, mask-construction, and completion instructions are omitted.

The same RISC-V address may execute under different vector configurations. At a cache miss, the runtime passes the current `vtype` as a translation hint; the frontend also tracks configuration instructions within the block. A runtime guard checks the conditions required by the generated direct body. If those conditions hold, execution enters that body. Otherwise, the emitted code calls the semantic helper with the original instruction encoding and then resumes the block. Thus the cached translation does not silently assume that the configuration observed during translation remains unchanged.

Long-vector decomposition also depends on the operation. An ordinary element-wise addition uses matching source and destination element widths. A widening or narrowing instruction changes them, so the frontend records the operand ranges separately. A reduction or cross-element permutation cannot be replaced by independent additions on equal slices. Each form retains its own semantic implementation rather than inheriting the addition example's decomposition rule.

## 3.3 Vector QIR and CPU State

QIR is rvdbt's intermediate representation. Its vector extension records an operation's element type, component width, operands, and destination. The full-update body in Figure 3.2 uses three concrete operations: `vstatechunkload` reads a component from CPU state, `vchunkadd` computes its sum, and `vstatechunkstore` writes the result. QIR also represents the guard, helper call, and control-flow join. The backend therefore receives both the vector calculation and the conditions under which it executes.

CPU state, shown separately in Figure 3.1, is the persistent storage shared by translated blocks and helpers. The RVV extension adds 32 vector-register slots and control fields including `vl`, `vtype`, `vstart`, and `vlenb`. Slots reserve the supported maximum size, so changing the configured VLEN does not change other registers' offsets. For the addition in Figure 3.2, component 0 of `v8` begins at that slot's base; component 1 begins 64 bytes later.

A QIR temporary and an architectural register slot have different lifetimes. A temporary may remain in a host register while the block executes. The final architectural value must be available in CPU state when a later block or helper needs it. These explicit state stores are not register spills: a spill saves a temporary because the allocator lacks registers. Chapter 4 changes which intermediate state stores and reloads are necessary, while preserving the final architectural values.

Element selection is also explicit. For ordinary element-wise operations, let component j contain q elements and let i be a lane within that component. Its element index is e=jq+i. The lane is updated when

\[
vstart \leq e < vl
\quad\text{and}\quad
(vm=1\ \text{or}\ v0[e]=1).
\]

Here `vm=1` denotes an instruction without masking. With `vl=20` and `vstart=0`, the first component of the example updates all 16 elements; the second updates four. An instruction mask can disable additional elements. A tail-undisturbed or mask-undisturbed destination preserves the corresponding old values. This requirement can be implemented by masking the state store for the integer addition. Floating-point and memory operations must also account for exception and access side effects, so their execution masks and fallback conditions are operation-specific.

## 3.4 x86-64 Backend

QCG, rvdbt's lightweight code generator, implements the three backend stages in Figure 3.1. It does not invoke LLVM. Instruction selection assigns host operand requirements; register allocation assigns physical registers to QIR values; code emission uses AsmJit to encode the selected instructions.

For Figure 3.2, instruction selection maps 32-bit integer addition to `vpaddd` and the 512-bit component type to ZMM operands. The allocator assigns a separate host value to each component. State loads and stores become vector memory operations at their recorded CPU-state offsets. The following arithmetic body illustrates the result for `vl=32` and `vstart=0`; register names are illustrative and the entry guard is omitted.

```asm
vmovdqu64 zmm0, [state_v8  + 0]
vmovdqu64 zmm1, [state_v9  + 0]
vmovdqu64 zmm2, [state_v8  + 64]
vmovdqu64 zmm3, [state_v9  + 64]
vpaddd    zmm4, zmm0, zmm1
vpaddd    zmm5, zmm2, zmm3
vmovdqu64 [state_v10 + 0], zmm4
vmovdqu64 [state_v10 + 64], zmm5
```

The full-update body reads the sources before writing the destination, so source--destination overlap does not destroy an input. With the QCG partial branch enabled, the frontend instead emits one `vchunkpartialalu` per component. Its emitter constructs an element-range mask and uses masked `vmovdqu32` stores: each opmask bit controls a 32-bit destination element. The mask preserves other elements even though the RVV instruction itself is unmasked. Full-state transfers can use `vmovdqu64` because no per-element selection is needed. The two component values still represent separate element groups.

The helper branch also constrains allocation. Values needed across a possible helper call must be preserved before the guard. The allocator cannot insert arbitrary spills inside the guarded body when the fallback would bypass them. The frontend consequently bounds the vector values retained by a grouped direct body, as developed in Chapter 4.

Once emitted, the block is installed in the translation cache and executes through the runtime in Section 3.1. The complete path supports long-vector arithmetic, but its per-instruction organization repeats two kinds of work: a consumer reloads an intermediate value just written to CPU state, and a fixed-capacity expansion can prepare components beyond `vl`. The next chapter addresses these costs at QIR construction, before physical register allocation and code emission.

## 3.5 Implementation Changes

The patchset extends the existing execution pipeline rather than adding a separate vector engine. Lin's runtime, scalar translation, translation cache, and block linking form the base [Lin2025]. The RVV additions have three responsibilities.

**Execution support.** The frontend decodes vector operand forms and maintains architectural vector registers and control state. Vector QIR carries element types, component ranges, guards, and destination-update requirements. The x86 backend selects SIMD operations and opmasks for the direct path; helpers implement forms or runtime conditions outside that path.

**Cross-instruction reuse.** The sequence builder resolves sources to their current definitions, records the final modified architectural values, and estimates register demand. QIR construction loads incoming values, reuses results inside a bounded batch, and writes the final values before releasing the batch. The changes precede physical register allocation.

**Bounded execution.** A shared component plan derives element boundaries from destination geometry, including widening and narrowing. Code emission places a comparison or reuses a mask comparison before a skippable suffix, while the completion block retains required state updates. The integrated path groups each component's operations and final stores so that the branch cannot bypass required work.

The implementation artifact provides the upstream-to-extension patchset and source extracts for these boundaries [rvdbt-impl]. The principal code changes are in the RVV decoder and CPU state, vector QIR construction, sequence analysis, the shared active-component plan, and x86 instruction emission. These changes support the lightweight execution path evaluated in Chapter 5. They do not replace the inherited LLVM workflow; integrating the vector representation with an optimizing tier is discussed in Section 5.6.

## 3.6 Execution Profile and Semantic Boundaries

The implementation targets RV32 user-space programs with ELEN 64 and a power-of-two VLEN from 128 through 4096 bits. VLEN determines register capacity; `vtype` and `vl` determine its use. Translation-time configuration hints guide specialization, while generated guards check the live state before entering a direct body. The fixed correctness build uses 512-bit QCG host components; an independent 256-bit selector is outside this build profile.

CPU state reserves 512 bytes for each vector register, while its logical length is VLEN/8 bytes (Section 3.3). Register-group addressing respects this physical stride. Widening and narrowing preserve element indices across different source and destination widths before register allocation.

An admitted direct body uses vector QIR and host SIMD instructions; otherwise, an RVV helper accesses the same architectural state. Both routes must implement the applicable mask, destination policy, rounding and state updates. Thus helper execution contributes to semantic support, while direct code generation and optimization admission have their own conditions.

Validation follows these route boundaries. External suites retain their original output predicates, while project-authored directed matrices initialize architectural state, execute a target and capture state for comparison outside the DUT. The directed and external final replay share one frozen correctness executable. Sequence validation separately joins target PCs to generated code and executed frames to establish register promotion and inactive-component omission (Section 5.7).

Operation-specific rules constrain decomposition. Reductions combine elements; gathers may read outside the updated range; whole-register transfers use a register-count-based extent rather than ordinary `vl`. These operations retain their required work instead of inheriting the element-wise omission rule [RVV].

Section 5.7 distinguishes instruction-form coverage, optimization admission and fault handling. Checked vector-memory helpers preserve completed elements and record the faulting element in `vstart`. A denied access records its instruction address, memory address and access direction before returning to the dispatcher. For an unexpected host fault inside a checked copy, exact instruction-address matching identifies the owned memory operation; the host handler returns through that operation's failure exit. The dispatcher then constructs the RV32 signal frame from the saved state and enters the registered synchronous SIGSEGV or SIGBUS handler. Frame construction occurs after the helper has returned, not inside the host signal callback.

QCG memory instructions execute in separate instruction frames. Arithmetic sequences on either side can still use register promotion, but a later instruction cannot publish its result before the preceding memory instruction completes. This boundary preserves the previous destination value when successive instructions overwrite the same register; a final-live-out map alone would not recover that value after a fault.

Each admitted memory frame records exact host access sites and an emitted fault exit. An ordinary unit-stride or whole-register SIMD load publishes each completed chunk before accessing the next. Its fault boundary requires each active chunk to remain within one anonymously mapped page; crossing chunks and unsupported backing use checked helpers. For an owned user data page fault, the runtime reports the first element of the denied chunk. Whole-register operations derive this position from encoded element width and transfer extent, independently of ordinary `vl`.

The scalar memory loop records the current element and segment field at each guest-memory instruction. Completed load fields are published before subsequent accesses. Page-contained scalar accesses can use this boundary for synchronous SIGSEGV and supported SIGBUS events; split fields and indexed-load overlap requiring changing source indices use checked helpers. The fault exit preserves prior state and returns to the dispatcher. These contracts cover the stated QCG instruction frames; optional gather paths, LLVM native-memory recovery and complete guest-handler return/restart require separate treatment.
