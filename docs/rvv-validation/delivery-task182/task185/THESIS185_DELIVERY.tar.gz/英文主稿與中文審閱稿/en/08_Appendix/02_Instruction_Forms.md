# Appendix B. Instruction-Form Scope

The 627-form inventory below contains 595 applicable forms and 32 profile exclusions. The applicable set equals the target/result-checked union in Section 5.7; the fixed correctness build separately has a 595-form checked union. Direct and helper execution are included. The sets record bounded target/output checks, without asserting full configuration coverage or universal M1/M2 admission.

The [implementation and validation table](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-current-scope.md) and [machine-readable form list](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/current-scope/forms.csv) identify the implementation route, external result checks and remaining limitations for each form. The [scope records](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/current-scope/README.md) retain suite membership, candidate identities and source/assertion bindings. The [suite execution summary](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/suite-execution-summary.md) separates program executions, reference runs, failure controls and source exclusions. The [Ara review package](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/ara-review-task91/README.md) contains original sources, adapted cases, raw outputs and the checkers that read them, including failed and excluded cases. It can be inspected offline; replay commands are provided separately. The [CHIPS inspection guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/chips-review-task93/README.md) and [ACT inspection guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/act-primary-task99/README.md) describe their retained source, reference and result chains. The [archived evidence release](https://github.com/kust1011/rvdbt/releases/tag/rvv-validation-20261012) provides both packages and fixed download manifests for offline inspection. Historical validation and performance builds remain separately identified.

RIF has 125 coupled endpoint forms, separate from operation-result checks; its initialization reports do not test a result. The accepted corpus contains 1,500 roots and 6,000 DUT calls. The 543 O2 derivative ELFs and their 2,172 DUT observations are diagnostic records excluded from acceptance. Section 5.7 explains the reduction derivatives and scalar-oracle limits. Operation-to-emission bindings distinguish 174 lowering absences, 6 checked compound sequences and 8 genuine move-checker gaps; a nominal source operation alone does not establish a checked emitted form.

ATG retains 9 producer contracts and 2 reserved source-overlap outputs. Ara retains legacy/missing macros, short or incomplete stores and profile gaps; CHIPS retains 8 unsafe original store outputs; ACT retains form/profile and privileged-signature gaps. These source and checker limits remain associated with their original cases, separately from accepted derivatives.

RVISmith retains 34 compiler-error entries and the original normalization rules. rv32emu retains whole-test failure: 8 checks reached, 7 passed, 1 failed and 296 unreached, with no data-vector result coverage. RiESCUE's RV32 runtime/address/high-half contracts, FORCE's unbuilt platform/ELF64 writer and model-only assertions, CTK's RV64 entry and Tenstorrent's 1,056 privileged RV64 cases remain source/platform exclusions or blockers, rather than positive RVV checks. These dispositions and observer limits are available in the [source summary](../../../artifacts/external_suite_coverage_20261007/JSERV_VERIFICATION_SUMMARY.md) and immutable ledger links.

The [historical external per-form results](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/host512-task142/combined/FORMS.md) identify the retained external-campaign executable's CHIPS, ACT and Ara checks. The [offline inspection guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-validation/host512-task142/README.md) connects the downloadable current outputs to their original sources and checkers. Fault handling is documented separately in the [implementation guide](https://github.com/kust1011/rvdbt/blob/05db3ca51432312981e4a466b1fff56df2032fb7/docs/rvv-qcg.md): checked helpers and admitted singleton QCG memory bodies preserve completed results and return faults to the dispatcher. Original failed signal tests remain archived alongside the later bounded corrections. Guest-handler return/restart, full state, agnostic write history, access suppression and per-PC method admission remain incomplete beyond the tests described in Section 5.7.

The two ATG and two Ara source-overlap cases are classified using ISA-manual revision `6b45f5c6`, which reserves reading one vector register with different source EEWs in a single instruction, including EEW 1 for a mask source [RVV]. The archived 2021 V 1.0 text does not explicitly state this rule. These dispositions therefore identify the manual revision rather than treating the two texts as interchangeable.

Project-authored directed matrices separately index accepted cases, observed dimensions, oracle scope, historical family receipts and actual final same-build results for the 595 applicable forms. Section 5.7 separates 12,069,048 ordinary positive DUT checks, 2,256 focused positives and 592 focused denial controls. The completed sequence matrix checks actual optimization paths on that same frozen correctness executable; it adds no instruction-form credit. External original predicates, directed architectural comparisons and performance measurements retain separate evidence identities.

## Vector configuration (3)

`vsetivli`, `vsetvl`, `vsetvli`.

## Same-width integer operations (98)

`vadc.vim`, `vadc.vvm`, `vadc.vxm`, `vadd.vi`, `vadd.vv`, `vadd.vx`, `vand.vi`, `vand.vv`, `vand.vx`, `vdiv.vv`, `vdiv.vx`, `vdivu.vv`, `vdivu.vx`, `vmacc.vv`, `vmacc.vx`, `vmadc.vi`, `vmadc.vim`, `vmadc.vv`, `vmadc.vvm`, `vmadc.vx`, `vmadc.vxm`, `vmadd.vv`, `vmadd.vx`, `vmax.vv`, `vmax.vx`, `vmaxu.vv`, `vmaxu.vx`, `vmerge.vim`, `vmerge.vvm`, `vmerge.vxm`, `vmin.vv`, `vmin.vx`, `vminu.vv`, `vminu.vx`, `vmsbc.vv`, `vmsbc.vvm`, `vmsbc.vx`, `vmsbc.vxm`, `vmseq.vi`, `vmseq.vv`, `vmseq.vx`, `vmsgt.vi`, `vmsgt.vx`, `vmsgtu.vi`, `vmsgtu.vx`, `vmsle.vi`, `vmsle.vv`, `vmsle.vx`, `vmsleu.vi`, `vmsleu.vv`, `vmsleu.vx`, `vmslt.vv`, `vmslt.vx`, `vmsltu.vv`, `vmsltu.vx`, `vmsne.vi`, `vmsne.vv`, `vmsne.vx`, `vmul.vv`, `vmul.vx`, `vmulh.vv`, `vmulh.vx`, `vmulhsu.vv`, `vmulhsu.vx`, `vmulhu.vv`, `vmulhu.vx`, `vmv.v.i`, `vmv.v.v`, `vmv.v.x`, `vnmsac.vv`, `vnmsac.vx`, `vnmsub.vv`, `vnmsub.vx`, `vor.vi`, `vor.vv`, `vor.vx`, `vrem.vv`, `vrem.vx`, `vremu.vv`, `vremu.vx`, `vrsub.vi`, `vrsub.vx`, `vsbc.vvm`, `vsbc.vxm`, `vsll.vi`, `vsll.vv`, `vsll.vx`, `vsra.vi`, `vsra.vv`, `vsra.vx`, `vsrl.vi`, `vsrl.vv`, `vsrl.vx`, `vsub.vv`, `vsub.vx`, `vxor.vi`, `vxor.vv`, `vxor.vx`.

## Widening integer operations (31)

`vwadd.vv`, `vwadd.vx`, `vwadd.wv`, `vwadd.wx`, `vwaddu.vv`, `vwaddu.vx`, `vwaddu.wv`, `vwaddu.wx`, `vwmacc.vv`, `vwmacc.vx`, `vwmaccsu.vv`, `vwmaccsu.vx`, `vwmaccu.vv`, `vwmaccu.vx`, `vwmaccus.vx`, `vwmul.vv`, `vwmul.vx`, `vwmulsu.vv`, `vwmulsu.vx`, `vwmulu.vv`, `vwmulu.vx`, `vwredsum.vs`, `vwredsumu.vs`, `vwsub.vv`, `vwsub.vx`, `vwsub.wv`, `vwsub.wx`, `vwsubu.vv`, `vwsubu.vx`, `vwsubu.wv`, `vwsubu.wx`.

## Narrowing integer operations (12)

`vnclip.wi`, `vnclip.wv`, `vnclip.wx`, `vnclipu.wi`, `vnclipu.wv`, `vnclipu.wx`, `vnsra.wi`, `vnsra.wv`, `vnsra.wx`, `vnsrl.wi`, `vnsrl.wv`, `vnsrl.wx`.

## Integer extension (6)

`vsext.vf2`, `vsext.vf4`, `vsext.vf8`, `vzext.vf2`, `vzext.vf4`, `vzext.vf8`.

## Integer reduction (8)

`vredand.vs`, `vredmax.vs`, `vredmaxu.vs`, `vredmin.vs`, `vredminu.vs`, `vredor.vs`, `vredsum.vs`, `vredxor.vs`.

## Fixed-point operations (26)

`vaadd.vv`, `vaadd.vx`, `vaaddu.vv`, `vaaddu.vx`, `vasub.vv`, `vasub.vx`, `vasubu.vv`, `vasubu.vx`, `vsadd.vi`, `vsadd.vv`, `vsadd.vx`, `vsaddu.vi`, `vsaddu.vv`, `vsaddu.vx`, `vsmul.vv`, `vsmul.vx`, `vssra.vi`, `vssra.vv`, `vssra.vx`, `vssrl.vi`, `vssrl.vv`, `vssrl.vx`, `vssub.vv`, `vssub.vx`, `vssubu.vv`, `vssubu.vx`.

## Floating-point operations (101)

`vfadd.vf`, `vfadd.vv`, `vfclass.v`, `vfcvt.f.x.v`, `vfcvt.f.xu.v`, `vfcvt.rtz.x.f.v`, `vfcvt.rtz.xu.f.v`, `vfcvt.x.f.v`, `vfcvt.xu.f.v`, `vfdiv.vf`, `vfdiv.vv`, `vfmacc.vf`, `vfmacc.vv`, `vfmadd.vf`, `vfmadd.vv`, `vfmax.vf`, `vfmax.vv`, `vfmerge.vfm`, `vfmin.vf`, `vfmin.vv`, `vfmsac.vf`, `vfmsac.vv`, `vfmsub.vf`, `vfmsub.vv`, `vfmul.vf`, `vfmul.vv`, `vfmv.f.s`, `vfmv.s.f`, `vfmv.v.f`, `vfncvt.f.f.w`, `vfncvt.f.x.w`, `vfncvt.f.xu.w`, `vfncvt.rod.f.f.w`, `vfncvt.rtz.x.f.w`, `vfncvt.rtz.xu.f.w`, `vfncvt.x.f.w`, `vfncvt.xu.f.w`, `vfnmacc.vf`, `vfnmacc.vv`, `vfnmadd.vf`, `vfnmadd.vv`, `vfnmsac.vf`, `vfnmsac.vv`, `vfnmsub.vf`, `vfnmsub.vv`, `vfrdiv.vf`, `vfrec7.v`, `vfredmax.vs`, `vfredmin.vs`, `vfredosum.vs`, `vfredusum.vs`, `vfrsqrt7.v`, `vfrsub.vf`, `vfsgnj.vf`, `vfsgnj.vv`, `vfsgnjn.vf`, `vfsgnjn.vv`, `vfsgnjx.vf`, `vfsgnjx.vv`, `vfslide1down.vf`, `vfslide1up.vf`, `vfsqrt.v`, `vfsub.vf`, `vfsub.vv`, `vfwadd.vf`, `vfwadd.vv`, `vfwadd.wf`, `vfwadd.wv`, `vfwcvt.f.f.v`, `vfwcvt.f.x.v`, `vfwcvt.f.xu.v`, `vfwcvt.rtz.x.f.v`, `vfwcvt.rtz.xu.f.v`, `vfwcvt.x.f.v`, `vfwcvt.xu.f.v`, `vfwmacc.vf`, `vfwmacc.vv`, `vfwmsac.vf`, `vfwmsac.vv`, `vfwmul.vf`, `vfwmul.vv`, `vfwnmacc.vf`, `vfwnmacc.vv`, `vfwnmsac.vf`, `vfwnmsac.vv`, `vfwredosum.vs`, `vfwredusum.vs`, `vfwsub.vf`, `vfwsub.vv`, `vfwsub.wf`, `vfwsub.wv`, `vmfeq.vf`, `vmfeq.vv`, `vmfge.vf`, `vmfgt.vf`, `vmfle.vf`, `vmfle.vv`, `vmflt.vf`, `vmflt.vv`, `vmfne.vf`, `vmfne.vv`.

## Mask-bit operations (13)

`vcpop.m`, `vfirst.m`, `vmand.mm`, `vmandn.mm`, `vmnand.mm`, `vmnor.mm`, `vmor.mm`, `vmorn.mm`, `vmsbf.m`, `vmsif.m`, `vmsof.m`, `vmxnor.mm`, `vmxor.mm`.

## Mask-to-integer operations (2)

`vid.v`, `viota.m`.

## Permutation and element movement (13)

`vcompress.vm`, `vmv.s.x`, `vmv.x.s`, `vrgather.vi`, `vrgather.vv`, `vrgather.vx`, `vrgatherei16.vv`, `vslide1down.vx`, `vslide1up.vx`, `vslidedown.vi`, `vslidedown.vx`, `vslideup.vi`, `vslideup.vx`.

## Whole-register movement (4)

`vmv1r.v`, `vmv2r.v`, `vmv4r.v`, `vmv8r.v`.

## Unit-stride, strided and segment memory operations (160)

`vle16.v`, `vle16ff.v`, `vle32.v`, `vle32ff.v`, `vle64.v`, `vle64ff.v`, `vle8.v`, `vle8ff.v`, `vlse16.v`, `vlse32.v`, `vlse64.v`, `vlse8.v`, `vlseg2e16.v`, `vlseg2e16ff.v`, `vlseg2e32.v`, `vlseg2e32ff.v`, `vlseg2e64.v`, `vlseg2e64ff.v`, `vlseg2e8.v`, `vlseg2e8ff.v`, `vlseg3e16.v`, `vlseg3e16ff.v`, `vlseg3e32.v`, `vlseg3e32ff.v`, `vlseg3e64.v`, `vlseg3e64ff.v`, `vlseg3e8.v`, `vlseg3e8ff.v`, `vlseg4e16.v`, `vlseg4e16ff.v`, `vlseg4e32.v`, `vlseg4e32ff.v`, `vlseg4e64.v`, `vlseg4e64ff.v`, `vlseg4e8.v`, `vlseg4e8ff.v`, `vlseg5e16.v`, `vlseg5e16ff.v`, `vlseg5e32.v`, `vlseg5e32ff.v`, `vlseg5e64.v`, `vlseg5e64ff.v`, `vlseg5e8.v`, `vlseg5e8ff.v`, `vlseg6e16.v`, `vlseg6e16ff.v`, `vlseg6e32.v`, `vlseg6e32ff.v`, `vlseg6e64.v`, `vlseg6e64ff.v`, `vlseg6e8.v`, `vlseg6e8ff.v`, `vlseg7e16.v`, `vlseg7e16ff.v`, `vlseg7e32.v`, `vlseg7e32ff.v`, `vlseg7e64.v`, `vlseg7e64ff.v`, `vlseg7e8.v`, `vlseg7e8ff.v`, `vlseg8e16.v`, `vlseg8e16ff.v`, `vlseg8e32.v`, `vlseg8e32ff.v`, `vlseg8e64.v`, `vlseg8e64ff.v`, `vlseg8e8.v`, `vlseg8e8ff.v`, `vlsseg2e16.v`, `vlsseg2e32.v`, `vlsseg2e64.v`, `vlsseg2e8.v`, `vlsseg3e16.v`, `vlsseg3e32.v`, `vlsseg3e64.v`, `vlsseg3e8.v`, `vlsseg4e16.v`, `vlsseg4e32.v`, `vlsseg4e64.v`, `vlsseg4e8.v`, `vlsseg5e16.v`, `vlsseg5e32.v`, `vlsseg5e64.v`, `vlsseg5e8.v`, `vlsseg6e16.v`, `vlsseg6e32.v`, `vlsseg6e64.v`, `vlsseg6e8.v`, `vlsseg7e16.v`, `vlsseg7e32.v`, `vlsseg7e64.v`, `vlsseg7e8.v`, `vlsseg8e16.v`, `vlsseg8e32.v`, `vlsseg8e64.v`, `vlsseg8e8.v`, `vse16.v`, `vse32.v`, `vse64.v`, `vse8.v`, `vsse16.v`, `vsse32.v`, `vsse64.v`, `vsse8.v`, `vsseg2e16.v`, `vsseg2e32.v`, `vsseg2e64.v`, `vsseg2e8.v`, `vsseg3e16.v`, `vsseg3e32.v`, `vsseg3e64.v`, `vsseg3e8.v`, `vsseg4e16.v`, `vsseg4e32.v`, `vsseg4e64.v`, `vsseg4e8.v`, `vsseg5e16.v`, `vsseg5e32.v`, `vsseg5e64.v`, `vsseg5e8.v`, `vsseg6e16.v`, `vsseg6e32.v`, `vsseg6e64.v`, `vsseg6e8.v`, `vsseg7e16.v`, `vsseg7e32.v`, `vsseg7e64.v`, `vsseg7e8.v`, `vsseg8e16.v`, `vsseg8e32.v`, `vsseg8e64.v`, `vsseg8e8.v`, `vssseg2e16.v`, `vssseg2e32.v`, `vssseg2e64.v`, `vssseg2e8.v`, `vssseg3e16.v`, `vssseg3e32.v`, `vssseg3e64.v`, `vssseg3e8.v`, `vssseg4e16.v`, `vssseg4e32.v`, `vssseg4e64.v`, `vssseg4e8.v`, `vssseg5e16.v`, `vssseg5e32.v`, `vssseg5e64.v`, `vssseg5e8.v`, `vssseg6e16.v`, `vssseg6e32.v`, `vssseg6e64.v`, `vssseg6e8.v`, `vssseg7e16.v`, `vssseg7e32.v`, `vssseg7e64.v`, `vssseg7e8.v`, `vssseg8e16.v`, `vssseg8e32.v`, `vssseg8e64.v`, `vssseg8e8.v`.

## Indexed memory operations (96)

`vloxei16.v`, `vloxei32.v`, `vloxei8.v`, `vloxseg2ei16.v`, `vloxseg2ei32.v`, `vloxseg2ei8.v`, `vloxseg3ei16.v`, `vloxseg3ei32.v`, `vloxseg3ei8.v`, `vloxseg4ei16.v`, `vloxseg4ei32.v`, `vloxseg4ei8.v`, `vloxseg5ei16.v`, `vloxseg5ei32.v`, `vloxseg5ei8.v`, `vloxseg6ei16.v`, `vloxseg6ei32.v`, `vloxseg6ei8.v`, `vloxseg7ei16.v`, `vloxseg7ei32.v`, `vloxseg7ei8.v`, `vloxseg8ei16.v`, `vloxseg8ei32.v`, `vloxseg8ei8.v`, `vluxei16.v`, `vluxei32.v`, `vluxei8.v`, `vluxseg2ei16.v`, `vluxseg2ei32.v`, `vluxseg2ei8.v`, `vluxseg3ei16.v`, `vluxseg3ei32.v`, `vluxseg3ei8.v`, `vluxseg4ei16.v`, `vluxseg4ei32.v`, `vluxseg4ei8.v`, `vluxseg5ei16.v`, `vluxseg5ei32.v`, `vluxseg5ei8.v`, `vluxseg6ei16.v`, `vluxseg6ei32.v`, `vluxseg6ei8.v`, `vluxseg7ei16.v`, `vluxseg7ei32.v`, `vluxseg7ei8.v`, `vluxseg8ei16.v`, `vluxseg8ei32.v`, `vluxseg8ei8.v`, `vsoxei16.v`, `vsoxei32.v`, `vsoxei8.v`, `vsoxseg2ei16.v`, `vsoxseg2ei32.v`, `vsoxseg2ei8.v`, `vsoxseg3ei16.v`, `vsoxseg3ei32.v`, `vsoxseg3ei8.v`, `vsoxseg4ei16.v`, `vsoxseg4ei32.v`, `vsoxseg4ei8.v`, `vsoxseg5ei16.v`, `vsoxseg5ei32.v`, `vsoxseg5ei8.v`, `vsoxseg6ei16.v`, `vsoxseg6ei32.v`, `vsoxseg6ei8.v`, `vsoxseg7ei16.v`, `vsoxseg7ei32.v`, `vsoxseg7ei8.v`, `vsoxseg8ei16.v`, `vsoxseg8ei32.v`, `vsoxseg8ei8.v`, `vsuxei16.v`, `vsuxei32.v`, `vsuxei8.v`, `vsuxseg2ei16.v`, `vsuxseg2ei32.v`, `vsuxseg2ei8.v`, `vsuxseg3ei16.v`, `vsuxseg3ei32.v`, `vsuxseg3ei8.v`, `vsuxseg4ei16.v`, `vsuxseg4ei32.v`, `vsuxseg4ei8.v`, `vsuxseg5ei16.v`, `vsuxseg5ei32.v`, `vsuxseg5ei8.v`, `vsuxseg6ei16.v`, `vsuxseg6ei32.v`, `vsuxseg6ei8.v`, `vsuxseg7ei16.v`, `vsuxseg7ei32.v`, `vsuxseg7ei8.v`, `vsuxseg8ei16.v`, `vsuxseg8ei32.v`, `vsuxseg8ei8.v`.

## Mask memory operations (2)

`vlm.v`, `vsm.v`.

## Whole-register memory operations (20)

`vl1re16.v`, `vl1re32.v`, `vl1re64.v`, `vl1re8.v`, `vl2re16.v`, `vl2re32.v`, `vl2re64.v`, `vl2re8.v`, `vl4re16.v`, `vl4re32.v`, `vl4re64.v`, `vl4re8.v`, `vl8re16.v`, `vl8re32.v`, `vl8re64.v`, `vl8re8.v`, `vs1r.v`, `vs2r.v`, `vs4r.v`, `vs8r.v`.

## Forms Outside the Profile (32)

These indexed-memory forms use 64-bit indices and are not required by the evaluated RV32 profile [RVV].

`vloxei64.v`, `vloxseg2ei64.v`, `vloxseg3ei64.v`, `vloxseg4ei64.v`, `vloxseg5ei64.v`, `vloxseg6ei64.v`, `vloxseg7ei64.v`, `vloxseg8ei64.v`, `vluxei64.v`, `vluxseg2ei64.v`, `vluxseg3ei64.v`, `vluxseg4ei64.v`, `vluxseg5ei64.v`, `vluxseg6ei64.v`, `vluxseg7ei64.v`, `vluxseg8ei64.v`, `vsoxei64.v`, `vsoxseg2ei64.v`, `vsoxseg3ei64.v`, `vsoxseg4ei64.v`, `vsoxseg5ei64.v`, `vsoxseg6ei64.v`, `vsoxseg7ei64.v`, `vsoxseg8ei64.v`, `vsuxei64.v`, `vsuxseg2ei64.v`, `vsuxseg3ei64.v`, `vsuxseg4ei64.v`, `vsuxseg5ei64.v`, `vsuxseg6ei64.v`, `vsuxseg7ei64.v`, `vsuxseg8ei64.v`.
