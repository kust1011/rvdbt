# 英文主稿與中文審閱稿

本版依你的要求，先重寫英文，再以 **Claude Opus 5.5** 自動翻譯成繁體中文。中文是同一份論述的審閱譯稿，不是另一套獨立撰寫的內容。2026-10-02 已另外製作[完整論文排版預覽](正式排版預覽/RVV_Thesis_Layout_Preview.pdf)，供你檢視整體效果，並不表示內容已認可或定稿；原中文稿與已寄出的版本保留。

## 從這裡讀

2026-10-14：最終固定179結果已整合至§3.6／§5.7與附錄generator；595形式／102一般entries有3,017,262cases/arm、12,069,048一般正向DUTchecks，另列2,256focused正向與592拒絕控制。外部21,316commands與P3 9,672checks分列；原384效能均值與歷史build歸屬保留。PDF由既有preview流程重建，頁面檢查紀錄見下方185交付記錄。

2026-10-11 修訂：第3.6節精簡支援配置、direct/helper與實際guest-signal缺口；第5.7節以外部來源→checker/reference→DUT比較、套件受檢形式表及CHIPS具體案例交代正確性。附錄B由Task71 canonical表與summary生成627形式（595適用／32排除），保留原始來源限制及可重現性連結。結論同步；摘要、導言的既有論證與正確crossreference保留。

前版[PDF](正式排版預覽/RVV_Thesis_Layout_Preview.pdf)為113頁。10份英中配對檔、384個原效能均值、counts／candidate scopes及引用／artifact links核對通過；十一個完整修改頁與相關目錄頁已目視檢查，最後三次XeLaTeX編譯無overfull或undefined warning。正確性候選與原效能批次分開；不是全ISA／配置／fault/restart完成。[Task72收據](../artifacts/rvv_validation_delivery_20261009/SESSION0_RESULT_72.md)。下方修訂日期及較早頁數保留為歷史說明。

2026-10-06 最新修訂：中英文題名與線上口試投影片一致，重新編譯的論文預覽為 97 頁。第一章調整動機與貢獻敘事；第二章補足相關系統的發現與設計啟發；第三章交代 patchset 的實作分工；第四章釐清 promotion 的暫存器壓力與早退的正確順序；第五、六章同步整理限制與延伸方向。新段落由 Codex 同步修訂中英稿，沒有更動既有實驗數據。中英配對檢查及 384 格附錄均值核對通過，PDF 封面與五個修改頁面已目視檢查。

2026-10-05 第二、五章修訂：依本目錄《論文寫作與審稿準則》補入 HQEMU 的短向量迴圈拓寬研究、PasRISCV／Berberis 與 libriscv asmjit 的執行方式，明確區分 rv32emu 的長向量直譯能力與 SIMD JIT。第五章保留同 VLEN 比較，新增 Table 5.7 的 11 案例支援寬度比較與 Figure 5.7 的四個反轉案例。對手較快的數據保留，沒有將跨 VLEN 的勝出歸給單一方法。

新增 66 格均值由 `figures/build_external_comparison.py` 直接核對原始 CSV；capacity 與 asmjit 批次、版本分開，未更動樣本。圖沿用 Times New Roman、Both 綠色、既有線圖尺度與表格排版。新段落由 Codex 同步翻譯，原自動翻譯紀錄保留。沒有修改 runtime、既有 26 輪消融數據或啟動新效能實驗。

- [中文完整審閱稿](中文審閱稿.md)
- [英文完整主稿](English_Draft.md)

| 章節 | 英文主稿 | 中文審閱稿 |
|---|---|---|
| 摘要 | [Abstract](en/00_Abstract.md) | [摘要](zh-TW/00_Abstract.md) |
| 第一章 | [Introduction](en/01_Introduction/01_Introduction.md) | [緒論](zh-TW/01_Introduction/01_Introduction.md) |
| 第二章 | [Background](en/02_Background/01_Background.md) | [Background](zh-TW/02_Background/01_Background.md) |
| 第三章 | [Framework](en/03_Framework/01_Framework.md) | [系統架構](zh-TW/03_Framework/01_Framework.md) |
| 第四章 | [Methodology](en/04_Methodology/01_Methodology.md) | [方法](zh-TW/04_Methodology/01_Methodology.md) |
| 第五章 | [Evaluation](en/05_Evaluation/01_Evaluation.md) | [實驗評估](zh-TW/05_Evaluation/01_Evaluation.md) |
| 第六章 | [Conclusion](en/06_Conclusion/01_Conclusion.md) | [結論](zh-TW/06_Conclusion/01_Conclusion.md) |
| 參考資料 | [References](en/07_References/01_References.md) | [參考資料](zh-TW/07_References/01_References.md) |
| 完整數據 | [Appendix A](en/08_Appendix/01_Complete_Results.md) | [附錄 A](zh-TW/08_Appendix/01_Complete_Results.md) |

## 這版的閱讀順序

先說明同一份 binary 如何因 VLEN 改變，把不同元素群組的計算放進同一輪迴圈；再解釋相依鏈與 CPU 可利用的獨立工作。接著介紹支撐此行為的 rvdbt 執行路徑，指出狀態存取、暫存器需求、無效分量三項成本，最後給出方法與實驗。

方法代號只在方法介紹完後的 evaluation 定義，不要求讀者提前認識 M1、M2。正文的簡化程式與操作計數均標明用途，不拿示意例子冒充實測機器碼或排程。

2026-10-02 章節調整：緒論從 RVV 向量減法鏈開始，以元素範圍、迴圈邊界和指令排列解釋 VLEN 512／1024。第二章中英標題均為 Background，目錄為 `02_Background`；對手依架構、執行機制與 RVV 支援客觀介紹。第三章依部件分工介紹，再以一條加法串起執行路徑。第四章補入依封版實作整理的 batch 選擇規則；第五章區分原生算術、端到端計時和程式碼診斷，不以不同條件的 QEMU 診斷解釋正式數字。架構圖參考友文論文 Figure 3.2 的執行／快取組織後重繪，未直接複製原圖。摘要、第一至六章、參考資料與附錄的逐章審查結果及未解缺口，見 `../中文論文重寫稿/編輯紀錄.md`。

## 第三、四章的圖與敘事

最新重整嚴格依 `../中文論文重寫稿/01_Introduction/02_研究貢獻與論文結構.md`：第三章交代既有 runtime 與新增 RVV 路徑；第四章只展開值重用與資源限制、runtime 執行範圍及整合。第三章各節與架構圖中的部件相對應，RVV 加法範例貫穿 frontend、QIR、CPU state 和 backend。第四章沿用一組 ADD--MUL--SUB 範例，不再為每個細節另設小節。

| 圖 | 要回答的問題 | 預覽 |
|---|---|---|
| 3.1 | cache miss 後如何編譯、快取並執行 RVV block？ | [架構圖](figures/rvdbt_rvv_framework.png) |
| 3.2 | 一個 RVV 加法如何分成兩組 QIR 操作，再對應 x86 指令及部分元素寫回？ | [轉譯對照](figures/rvv_translation.png) |
| 4.1 | promotion 省掉哪些狀態搬移，寬度增加時如何控制暫存器需求？ | [值重用與批次](figures/vector_promotion.png) |
| 4.2 | `vl=20` 時執行哪些分量，哪些工作被略過，結果在哪裡保存？ | [執行範圍與整合](figures/vector_bounds.png) |

圖的可編輯來源在 `figures/*.tex`，以 TikZ 繪製。執行 `python3 figures/build_diagrams.py` 會產生 SVG、PDF 與 PNG；Markdown 使用 SVG，PNG 供快速審閱，PDF 留供日後正式排版。這不是新的正式論文 PDF。作圖依據與工具選擇記於既有編輯紀錄。

## 翻譯與修訂方式

英文是本版的內容來源。`translate_draft.py` 以無工具權限的獨立 Claude 呼叫逐章翻譯；程式碼、公式、數字、引用代號和連結受到保護。翻譯後另做語意與術語校訂，例如區分 SMT 邏輯 CPU 與實體核心，以及將 architectural-state publication 譯為寫回而非「發布」。`translation_records/` 記錄實際模型、來源與輸出版本、自動檢查及譯後校訂。數字順序可以因正常中文語序改變，數值本身與表格順序不得改變。

你可以直接針對中文章節提出修改。我會先修改對應英文，再更新中文，避免兩份稿逐漸分歧。完整閱讀檔由各章合併產生，不另外手改。

## 編輯用證據對照

下列資訊供查核，不屬於論文正文。

| 本版內容 | 使用的既有證據 |
|---|---|
| 26 輪、六種 VLEN、四配置 | `../artifacts/v16_results_20260930/manifest.json` 與 `means.csv` |
| 16 個呈現案例的完整 384 格均值 | 由上述 CSV 經 `build_result_appendix.py` 產生；原矩陣的 GEMM、s2275 紀錄未刪除 |
| PMU 與獨立鏈控制 | `../artifacts/microarchitecture_20260930/hardware_summary.json`、`formal_pmu_audit.json`、`vector_capacity.S` |
| 外部對手四輪結果 | `../artifacts/external_suite_20260930/RESULTS.md`、`LIBRISCV_COMPATIBILITY.md` |
| 正式方法原始碼 | `../artifacts/bounded_batch_20260927/source-active-work-v16/dbt/guest/rv32_qir.cpp`、`rv32_vrun.h`、`rv32_vrun.cpp`、`rv32_rvv_contract.h` |
| 功能驗證（§3.6／§5.7與附錄B） | `../artifacts/external_suite_coverage_20261007/ACTUAL_FORM_VALIDATION_SUMMARY.json`、`COMPLETE_FORM_SUITE_INVENTORY.csv`及bindings；627 forms、595適用、32排除，checked union595及clean961595分別核對；historical／clean／performance身份不合併 |
| Both配置的重要更正 | §4.3／§5.1已區分正式效能選項與另行測試的FP grouped early-exit；依xbd formal FLAGS.S0、K1原command及封存source預設／integer_grouped准入核對。未改效能數據 |
| 文獻閱讀範圍與對手 trace | `../RELATED_WORK_COMPARISON_20260930.md`、`../PRIOR_ART_IMPLEMENTATION_AUDIT_20260930.md` |
| Background 的 RVV 支援比較 | `../artifacts/external_suite_20260930/RV32EMU_COMPATIBILITY.md`、`LIBRISCV_COMPATIBILITY.md`；上列 pinned-source audit。SEW／VLEN 與 direct/helper 路徑分開敘述 |
| Framework 編譯階段與例子 | 正式快照 `dbt/qmc/qcg/qcg.cpp:29`（QSel→QRegAlloc→QEmit）、`qemit.cpp:1935`（runtime guard）、`:4584`（整數向量加法）、`:4965`／`:4991`（CPU-state 向量載入／回寫）。另對照 `../../rvdbt/docs/rvdbt.md`、`rvv-qcg.md` 與友文正文 pp.25–29 |
| Runtime、配置提示與狀態佈局 | 同一快照 `dbt/execute.cpp:329–415`（cache miss、`RvvEntryHint`、block link、trampoline）、`dbt/guest/rv32_cpu.h:47` 與 `rv32_vector.h:451`（固定大小 vector slots 與控制狀態） |
| 加法順序與 guard 邊界 | `dbt/guest/rv32_qir.cpp:16242` 起的 `RvvEmitTypedAluChunkBody` 明確先讀所有來源，再運算，最後回寫。`dbt/qmc/qcg/qra.cpp:1158` 起將 call 同步放在 guard 之前；不能把 guard 後的 spill 當成 fallback 也會執行。正文範例依這個順序修正，暫存器名稱仍是示意 |
| 寫作規則 | 本目錄 `論文寫作與審稿準則.md`；原中文重寫稿下外部 Codex 引導 |
| 長 VLEN 對外部系統 | `../artifacts/external_suite_20260930/capacity_20261004_1_1/results.csv`、`capacity_20261004_2_3/results.csv`；asmjit 三批原始 CSV 見 `figures/external_comparison_sources.json`。圖與表只選既有 16 案例中相容的 11 案，不新增 GEMM／s2275 至正文 |

本稿不新增 RVV 功能、不重跑實驗、不改變封版資料。已加入可縮放的 RVV 架構圖；正式論文整體排版仍待你確認內容後處理。現有 workload provenance 的逐個輸入細節，以及每一合法指令形式的支援表，仍以既有 artifact 為準，本稿沒有推測補齊，也沒有升級成完整 RVV 1.0 conformance 主張。

## 2026-10-14 P5 驗證方法與交接（Task184；非正文）

先修英文 §3.6／§5.7，再同步繁體中文。§5.7 保留外部原套件表、歷史 CHIPS 寬度分布與一個 CHIPS vadd.vv 範例，濃縮 ACT／Ara／RIF 批次敘事，加入 prestate → target → snapshot → DUT 外 predicate/reference 比較、逐 family 的真實維度、agnostic／unordered reduction oracle 限制、實際 M1/Both 准入及三個已確認缺陷。引用、圖與原效能值不變。附錄 B 僅改 generator 的 build 歸屬說明及 directed 索引說明，形式清單由 assembly 生成。

交付來源：`/tmp/rvv-delivery-task182`，編輯前 HEAD `23320a8`，沒有 production／ISA-suite 改動。595-form directed index 是歷史 mixed-build 有限矩陣，627 catalog 含32配置排除；不是 final179 的全形式 PASS。§5.7 最後外部批次仍為142 的21316 retained calls（CHIPS11532+212 controls、ACT7668、Ara1888+16 scoped），不改標成179。384原效能均值屬自己的封存批次。

已讀證據：交付樹 `SESSION0_RESULT_167.md`、`directed-task167/WITNESS_ROUTING_AND_BEFORE_AFTER.json` 與 `dbt/guest/rv32_vector_fma_invalid.h`／QCG FMA classification；Git `73fc8e2:SESSION3_RESULT_171.md`、`SOURCE_RESULT_EXPLANATION.md`、`evidence/ORIGINAL_BEFORE_AFTER.json`，及目前 QCG `Emit_vscalarmove`／interpreter `vmvsx`、`vfmvsf`（171未整包匯入交付樹）；`SESSION0_RESULT_172.md`、`directed-task172/{SEMANTIC_REVIEW.md,MINNORMAL_REVIEW.json,WITNESS_BEFORE_AFTER.json}` 與 `rv32_vector_fpconvert.h`。各缺陷修正用不同immutable build驗證，174整合，179為後續序列build，沒有將各family舊PASS回溯改標。

P3 completed evidence：`docs/rvv-validation/directed-task180/FINAL_TOTALS.json`、`AUDIT_main.json`、`BOTH_EARLY_EXIT.json`／`CACHE_ENTRY_COMPARISON.json`；frozen179，trace0每arm2418 cases，9672 DUT checks，660 units、2640 DUT commands（2596 new／44 reused），reference execution與ELF rebuild均0；full trace1 NOT_RUN。實際M1與Both程式／路徑核對支持宣告序列，無新增form credit。

184當時待替換項已由185以完成181收據整合；下節記錄目前交付與限制。


## 2026-10-14 最終證據整合（Task185；非正文）

交付worktree：`/home/user/research/materials/rvdbt-validation-delivery-20261014`。
匯入W3 `8c851d5` owned178/181；原production179與180 assertions保留。索引由amended181 plan及原始manifest重建，接合actual PER_FORM_RESULTS／ENTRY_RECEIPTS，focused正向／denial不混入一般分母。
固定179 executable：`8a468967852b8f16225b359fce99c0d22ab286d6314cb90a79934a7376207281`；library：`79d0ba2a9ddea24d49d7282012fdc373b92a26756bb5452c1f41c66d533887af`。Release／host512／RV32／ELEN64及各entry原flags保留。重新build不沿用這些執行收據。
兩個ACT reference blockers、Ara16 scoped TEST_CASE1/2及原TEST_CASE3/4失敗、非零start permissive Sail、bounded unordered FP oracle、full trace1未跑及guest handler return/restart未驗證仍保留。所有家族可用accepted package原API重跑；乾淨重新生成只實證bounded vadd，不宣稱所有家族fresh regeneration。新版commit／raw尚未公開；本輪不push／email。

Preview PDF：122頁，既有build_preview.py三次XeLaTeX編譯；最後pass無overfull／undefined warnings。已實際render/view完整實體頁7–8、45–47、89–98、112–114（18頁）：§3.6印刷33–35、§5.7印刷77–86、附錄B引言100–102；目錄vi–vii。無發現裁切或表格溢出，最後章末短頁保留正常chapter分頁。這是本輪局部視覺檢查，不代表作者已核准整篇內容。Render證據與PDF/source hashes記於delivery-task182/task185/THESIS_DELIVERY.json。
