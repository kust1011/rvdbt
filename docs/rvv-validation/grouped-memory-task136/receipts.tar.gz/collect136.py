import json,pathlib,subprocess,hashlib,re
r=pathlib.Path('/home/vick/rvdbt-grouped-memory-task136')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(r/n).write_text(json.dumps(x,indent=2)+'\n')
src=json.loads((r/'SOURCE_IDENTITY.json').read_text());diff=[p for p,h in src['files'].items() if sha(r/'source'/p)!=h];assert not diff
save('SOURCE_EQUALITY.json',{'commit':src['commit'],'checked':len(src['files']),'differences':diff})
pins=json.loads((r/'BUILD_IDENTITY.json').read_text());assert all(sha(pathlib.Path(p))==h for p,h in pins.items());save('FINAL_IDENTITY.json',pins)
for n,c in [('cpu.txt',['lscpu']),('compiler.txt',['clang++-22','--version']),('ldd.txt',['ldd','-r',str(r/'build/bin/elfrun')]),('load.txt',['cat','/proc/loadavg'])]:
 p=subprocess.run(c,capture_output=True,text=True,check=True);(r/n).write_text(p.stdout+p.stderr)
commands=json.loads((r/'build/compile_commands.json').read_text());prod=[x for x in commands if '/dbtstatic.dir/' in x['command'] or '/dbtjitshared.dir/' in x['command'] or '/elfrun.dir/' in x['command']]
cpp=[x for x in prod if x['file'].endswith('.cpp')];assert cpp and all(all(f in x['command'] for f in ['-DRVV_HOST_CHUNK_BITS=512','-mavx512f','-mavx512bw','-O3','-DNDEBUG']) for x in cpp)
(r/'compile_commands.json').write_text(json.dumps(commands,indent=2));(r/'CMakeCache.txt').write_bytes((r/'build/CMakeCache.txt').read_bytes())
save('FLAGS_AUDIT.json',{'production_commands':len(prod),'cpp_commands':len(cpp),'host_chunk_bits':512,'release':True,'force_emission':False,'differences':[]})
dep={p.relative_to(r/'source').as_posix():sha(p) for p in (r/'source/dbt/third_party').rglob('*') if p.is_file() and '.git' not in p.parts}
diffs=[p for p,h in dep.items() if not (pathlib.Path('/home/vick/rvdbt-scalar-native-task135/source')/p).is_file() or sha(pathlib.Path('/home/vick/rvdbt-scalar-native-task135/source')/p)!=h];assert not diffs
save('DEPENDENCY_IDENTITY.json',dep);save('DEPENDENCY_EQUALITY.json',{'checked':len(dep),'predecessor':'Task135','differences':diffs})
symbol='_ZN3dbt16rvv_native_fault12HandleSignalEiPK9siginfo_tP10ucontext_t'
p=subprocess.run(['objdump','-d','-C',str(r/'build/bin/rv32_scalar_native_fault_test')],capture_output=True,text=True,check=True)
m=re.search(r'^[0-9a-f]+ <dbt::rvv_native_fault::HandleSignal\(.*?\n(?=\n)',p.stdout,re.M|re.S);assert m
(r/'NATIVE_CALLBACK.disasm').write_text(m.group());assert not re.search(r'\bcall\w*\s',m.group())
files={p.relative_to(r).as_posix():sha(p) for p in r.rglob('*') if p.is_file() and not any(x in p.relative_to(r).parts for x in ['source','build','work','cache']) and p.name not in ['MANIFEST.json','receipts.tar.gz']}
save('MANIFEST.json',files);print('source',len(src['files']),'dependencies',len(dep),'receipts',len(files))
