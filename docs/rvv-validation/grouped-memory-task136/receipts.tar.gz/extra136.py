import subprocess,json,pathlib,sys
r=pathlib.Path('/home/vick/rvdbt-grouped-memory-task136')
cmd=['taskset','-c','28-31','nice','-n','10','cmake','--build',str(r/'build'),'-j4','--target','rvv_vector_run_admission_test','rvv_vector_run_codegen_test']
(r/'build.internal.command.json').write_text(json.dumps(cmd))
with (r/'build.internal.stdout').open('w') as out,(r/'build.internal.stderr').open('w') as err:
 p=subprocess.run(cmd,stdout=out,stderr=err,timeout=300)
(r/'build.internal.rc').write_text(str(p.returncode));print('internal build',p.returncode);sys.exit(p.returncode)
