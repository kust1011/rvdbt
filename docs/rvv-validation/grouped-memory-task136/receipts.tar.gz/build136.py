import subprocess,json,pathlib,hashlib,sys
r=pathlib.Path('/home/vick/rvdbt-grouped-memory-task136')
def run(name,cmd,limit):
 (r/(name+'.command.json')).write_text(json.dumps(cmd,indent=2))
 with (r/(name+'.stdout')).open('w') as out,(r/(name+'.stderr')).open('w') as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,timeout=limit,cwd=r)
 (r/(name+'.rc')).write_text(str(p.returncode));print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
run('configure',['cmake','-S',str(r/'source'),'-B',str(r/'build'),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=clang-22','-DCMAKE_CXX_COMPILER=clang++-22','-DLLVM_DIR=/usr/lib/llvm-22/cmake','-DRVV_HOST_CHUNK_BITS=512','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],180)
run('build',['taskset','-c','28-31','nice','-n','10','cmake','--build',str(r/'build'),'-j4','--target','elfrun','rv32_grouped_memory_fault_test','rv32_scalar_native_fault_test','rv32_native_memory_fault_test','rv32_whole_native_fault_test'],900)
ident={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'build/bin/elfrun',r/'build/lib/libdbtjitshared.so',r/'build/bin/rv32_scalar_native_fault_test',r/'build/bin/rv32_native_memory_fault_test',r/'build/bin/rv32_whole_native_fault_test']}
(r/'BUILD_IDENTITY.json').write_text(json.dumps(ident,indent=2))
