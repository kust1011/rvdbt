import ast,json,pathlib,hashlib,struct,shutil
r=pathlib.Path('/home/vick/rvdbt-grouped-memory-task136')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
q=json.loads((r/'external/QUEUE.json').read_text());original=json.loads(pathlib.Path('/home/vick/act-current121/QUEUE.json').read_text())
inputs=json.loads((r/'external/INPUTS.json').read_text());assert all(sha(pathlib.Path(p))==h for p,h in inputs.items())
src=pathlib.Path('/home/vick/rvv-task109/execute109.py').read_text();tree=ast.parse(src);expr=[n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ok' for t in n.targets)];predicate=compile(ast.Expression(expr[2]),'original-DUT-predicate','eval')
pins=json.loads((r/'BUILD_IDENTITY.json').read_text());rows=[]
for c in q['calls']:
 assert c in original['calls'];e=next(x for x in q['entries'] if x['case']==c['case']);assert e in original['entries']
 d=r/'external/raw'/c['case']/c['arm'];rr=json.loads((d/'result.json').read_text());assert rr['returncode']==0 and not rr['timeout']
 raw=(d/'stdout').read_text(errors='replace')+(d/'stderr').read_text(errors='replace');assert eval(predicate,{'__builtins__':{}},dict(rc=0,raw=raw,N=c['case'],sig=None))
 for name in ['IDENTITY.json','IDENTITY_AFTER.json']:
  assert all(pins[p]==h for p,h in json.loads((d/name).read_text()).items())
 cmd=json.loads((d/'command.json').read_text())
 def norm(cmd):return [('DUMP' if x.startswith('--dump-tbmap=') else 'CODE' if x.startswith('--dump-tbcode=') else 'FS' if x.startswith('--fsroot=') else 'CACHE' if x.startswith('--cache=') else x) for x in cmd[1:]]
 assert norm(cmd)==norm(c['original_command'])
 retained=r/'external/inputs'/c['case'];retained.mkdir(parents=True)
 for field in ['source','elf','checker','expected','capture']:
  p=pathlib.Path(e[field]);assert sha(p)==e[field+'_sha256'];shutil.copyfile(p,retained/(field+p.suffix))
 elf=pathlib.Path(e['elf']).read_bytes();assert elf[:6]==b'\x7fELF\x01\x01';assert sha(d/'work/fs/t.elf')==e['elf_sha256']
 rows.append({'case':c['case'],'arm':c['arm'],'original_full_call_equal':True,'flags_equal':True,'predicate':original['original_DUT_predicate'],'PASS':True,'ELF32_LE':True,'stdout':sha(d/'stdout'),'stderr':sha(d/'stderr')})
(r/'EXTERNAL_AUDIT.json').write_text(json.dumps({'calls':rows,'input_files':len(inputs),'differences':[],'new_reference_calls':0},indent=2)+'\n')
(r/'external.rc').write_text('0')
print('external exact originals PASS',len(rows))
