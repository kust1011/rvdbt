# Accepted Ara review bundle (Task91)

Portable inspection of accepted Ara82-86/89 additions and retained failures; zero new guests, surveys or goldens. A form, source block, binding, program and call are different units.

1. Extract ara-review-task91.tar.gz into a fresh directory.
2. Run `python3 tools/verify_rvv_ara_bundle.py .` (Python 3.9+, standard library, offline). The checker verifies all payload hashes, then calls the original parsers on raw stdout plus recorded exit codes, with exact Ara89 configurations/initialization and scoped MAC failure assertions. Archive integrity alone is not acceptance.
3. Find a canonical form in FORMS.json. Its indices select BINDINGS.json records, each with package-relative source, adapter, raw, checker, config and build paths. Consult deltas/ and records/ara*/MAIN_REVIEW.json, original failures and context audits. PATHS.json translates historical locators; absolute paths in original records are provenance.
4. Read TASK90_CORRECTION.json before interpreting FAST counters. M2 target admission is UNOBSERVED/null; RVV_ACTIVE_CHUNKS was never enabled in this batch. Functional B/M1/M2/BOTH predicates remain PASS.

This is portable inspection, not turnkey reexecution. Use the repo docs/rvv-validation/portable-external.md and scripts/rvv runner for live replay. Historical build/config/launch commands and binary identities are included, but compilers, LLVM, sysroots, newlib, Spike/pk, DUT executables/libraries, guest ELFs/objects, caches, huge TB dumps, ATG/RVISmith and unrelated suites are excluded. Assembly/disassembly text is retained; compiler IR/binaries are excluded. Original history records can name excluded files; BINDINGS.json is the navigation authority for included accepted evidence.

Licenses: read NOTICE.md and licenses/. Legal-only header restoration is documented in LEGAL_RESTORATIONS.json; original raw receipts remain byte-identical. FILES.json covers all payload files except itself.
