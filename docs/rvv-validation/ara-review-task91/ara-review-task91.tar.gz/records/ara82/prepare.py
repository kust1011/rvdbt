import json,shutil,subprocess,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52'
j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['context_original_'+x for x in ['vredsum','vwredsum','vwredsumu']];groups=[g for g in j(P/'GROUPS.json')if g['name']in names]
for d in ['bin','logs','adapter','upstream','provenance']: (R/d).mkdir(exist_ok=True)
for f in ['runner.py','checker.py','run.original.py.txt']:shutil.copy2(P/f,R/f)
records=[]
for g in groups:
 name=g['name'];shutil.copy2(P/'adapter'/(name+'.c'),R/'adapter'/(name+'.c'));shutil.copy2(P/'upstream'/(g['file']+'.c'),R/'upstream'/(g['file']+'.c'));shutil.copy2(P/'provenance'/(name+'.diff'),R/'provenance'/(name+'.diff'))
 for c in j(P/'BUILD_COMMANDS.json'):
  if not c['step'].startswith(name+'-'):continue
  cmd=[a.replace(str(P/'logs'/name),str(R/'logs'/name)).replace(str(P/'bin'/name),str(R/'bin'/name))for a in c['command']]
  # Compile original preserved adapter input in its original location; outputs isolated.
  p=subprocess.run(cmd,capture_output=True);(R/'logs'/(c['step']+'.stdout')).write_bytes(p.stdout);(R/'logs'/(c['step']+'.stderr')).write_bytes(p.stderr);records.append(dict(step=c['step'],command=cmd,returncode=p.returncode));assert p.returncode==0
 assert sha(R/'bin'/(name+'.elf'))==g['elf_sha256'], 'new build differs; cannot reuse B'
(R/'BUILD_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n');(R/'GROUPS.json').write_text(json.dumps(groups,indent=2)+'\n')
cs=j(P/'CONFIGS.json');configs=[];reuse=[]
for g in groups:
 for arm in ['B','reference']:
  folder=P/('remote-raw'if arm=='B'else'raw')/g['name']/arm;assert j(folder/'result.json')['status']=='PASS';reuse.append(dict(case=g['name'],arm=arm,result=str(folder/'result.json'),raw=str(folder/'stdout'),elf_sha256=g['elf_sha256']))
 for arm in ['M1','M2','BOTH']:
  assert not(P/'remote-raw'/g['name']/arm/'result.json').exists()
  c=dict(next(c for c in cs if c['case']=='batch01_vand'and c['arm']==arm));c.update(case=g['name'],source_row_ids=g['source_row_ids'],elf_sha256=g['elf_sha256'],VLEN=g['vlen']);configs.append(c)
(R/'CONFIGS.json').write_text(json.dumps(configs,indent=2)+'\n');(R/'REUSED.json').write_text(json.dumps(reuse,indent=2)+'\n');print('rebuilt byte-identical ELFs; 9 missing arms registered; B/reference reused')
