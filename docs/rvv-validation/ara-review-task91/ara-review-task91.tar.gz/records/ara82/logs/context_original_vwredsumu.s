	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"context_original_vwredsumu.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c" md5 0x66cdb31d00d3f3e72d818a7a9b79e244
	.file	1 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c" md5 0x66cdb31d00d3f3e72d818a7a9b79e244
	.file	2 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	3 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/upstream/dataset.h" md5 0x6e87c523f491ba527fcaa8da037d753f
	.file	4 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/vector_macros.h" md5 0xf0792279c410650ddf6b368633799e9a
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE1                      # -- Begin function TEST_CASE1
	.p2align	2
	.type	TEST_CASE1,@function
TEST_CASE1:                             # @TEST_CASE1
.Lfunc_begin0:
	.loc	1 10 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:10:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -192
	.cfi_def_cfa_offset 192
	sw	ra, 188(sp)                     # 4-byte Folded Spill
	sw	s0, 184(sp)                     # 4-byte Folded Spill
	sw	s1, 180(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 192
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 11 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:11:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp1:
	.loc	1 11 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:11:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 11
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 12 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:12:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 12 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:12:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv6)
	addi	a1, a0, %lo(.L__const.TEST_CASE1.Vv6)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -16(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a0, %lo(.L__const.TEST_CASE1.Vv6)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -28(s0)
	addi	a0, s0, -28
	#APP
	vle8.v v6, (a0)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 13 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:13:3
	j	.LBB0_5
.LBB0_5:
.Ltmp5:
	.loc	1 13 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:13:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2)
	lh	a0, %lo(.L__const.TEST_CASE1.Vv2)(a0)
	sh	a0, -30(s0)
	addi	a0, s0, -30
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 14 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:14:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp7:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	j	.LBB0_7
.LBB0_7:
.Ltmp8:
	.loc	1 15 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -36(s0)
	lw	a0, -36(s0)
	#APP
	vse16.v v4, (a0)

	#NO_APP
	sw	a0, -36(s0)
	j	.LBB0_8
.Ltmp9:
.LBB0_8:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 327
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	sh	a0, -38(s0)
	li	a0, 1
	li	a1, 1
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 1
	call	printf_
.Ltmp10:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	sw	zero, -44(s0)
	j	.LBB0_9
.LBB0_9:                                # =>This Inner Loop Header: Depth=1
.Ltmp11:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lw	a0, -44(s0)
.Ltmp12:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	bnez	a0, .LBB0_14
	j	.LBB0_10
.LBB0_10:                               #   in Loop: Header=BB0_9 Depth=1
.Ltmp13:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lw	a1, -44(s0)
	li	a0, 1
	call	ara_compare_step
.Ltmp14:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lw	a0, -44(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -44(s0)
	slli	a1, a1, 1
	addi	a2, s0, -38
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB0_12
	j	.LBB0_11
.LBB0_11:
.Ltmp15:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lw	a1, -44(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -44(s0)
	slli	a0, a0, 1
	addi	a3, s0, -38
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_43
.Ltmp16:
.LBB0_12:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	j	.LBB0_13
.Ltmp17:
.LBB0_13:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lw	a0, -44(s0)
	addi	a0, a0, 1
	sw	a0, -44(s0)
	j	.LBB0_9
.Ltmp18:
.LBB0_14:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:15:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 1
	call	ara_assert_end
.Ltmp19:
	.loc	1 17 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:17:3
	j	.LBB0_15
.LBB0_15:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp20:
	.loc	1 17 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:17:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 17
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_16
.Ltmp21:
.LBB0_16:
	.loc	1 18 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:18:3
	j	.LBB0_17
.LBB0_17:
.Ltmp22:
	.loc	1 18 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:18:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv6.3)
	addi	a1, a0, %lo(.L__const.TEST_CASE1.Vv6.3)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -48(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -52(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -60(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -64(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a0, %lo(.L__const.TEST_CASE1.Vv6.3)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -76(s0)
	addi	a0, s0, -76
	#APP
	vle16.v v6, (a0)  

	#NO_APP
	j	.LBB0_18
.Ltmp23:
.LBB0_18:
	.loc	1 19 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:19:3
	j	.LBB0_19
.LBB0_19:
.Ltmp24:
	.loc	1 19 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:19:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2.4)
	lw	a0, %lo(.L__const.TEST_CASE1.Vv2.4)(a0)
	sw	a0, -80(s0)
	addi	a0, s0, -80
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB0_20
.Ltmp25:
.LBB0_20:
	.loc	1 20 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:20:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp26:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	j	.LBB0_21
.LBB0_21:
.Ltmp27:
	.loc	1 21 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -84(s0)
	lw	a0, -84(s0)
	#APP
	vse32.v v4, (a0)

	#NO_APP
	sw	a0, -84(s0)
	j	.LBB0_22
.Ltmp28:
.LBB0_22:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 73
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	sw	a0, -88(s0)
	li	a0, 2
	li	a1, 1
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 2
	call	printf_
.Ltmp29:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	sw	zero, -92(s0)
	j	.LBB0_23
.LBB0_23:                               # =>This Inner Loop Header: Depth=1
.Ltmp30:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lw	a0, -92(s0)
.Ltmp31:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	bnez	a0, .LBB0_28
	j	.LBB0_24
.LBB0_24:                               #   in Loop: Header=BB0_23 Depth=1
.Ltmp32:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lw	a1, -92(s0)
	li	a0, 2
	call	ara_compare_step
.Ltmp33:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lw	a0, -92(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -92(s0)
	slli	a1, a1, 2
	addi	a2, s0, -88
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB0_26
	j	.LBB0_25
.LBB0_25:
.Ltmp34:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lw	a1, -92(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -92(s0)
	slli	a0, a0, 2
	addi	a3, s0, -88
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_43
.Ltmp35:
.LBB0_26:                               #   in Loop: Header=BB0_23 Depth=1
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	j	.LBB0_27
.Ltmp36:
.LBB0_27:                               #   in Loop: Header=BB0_23 Depth=1
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lw	a0, -92(s0)
	addi	a0, a0, 1
	sw	a0, -92(s0)
	j	.LBB0_23
.Ltmp37:
.LBB0_28:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:21:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 2
	call	ara_assert_end
.Ltmp38:
	.loc	1 23 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:23:3
	j	.LBB0_29
.LBB0_29:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp39:
	.loc	1 23 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:23:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 23
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_30
.Ltmp40:
.LBB0_30:
	.loc	1 24 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:24:3
	j	.LBB0_31
.LBB0_31:
.Ltmp41:
	.loc	1 24 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:24:3
	lui	a1, %hi(.L__const.TEST_CASE1.Vv6.6)
	addi	a1, a1, %lo(.L__const.TEST_CASE1.Vv6.6)
	addi	s1, s0, -156
	addi	a0, s0, -156
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v6, (s1)  

	#NO_APP
	j	.LBB0_32
.Ltmp42:
.LBB0_32:
	.loc	1 25 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:25:3
	j	.LBB0_33
.LBB0_33:
.Ltmp43:
	.loc	1 25 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:25:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2.7)
	lw	a1, %lo(.L__const.TEST_CASE1.Vv2.7+4)(a0)
	sw	a1, -164(s0)
	lw	a0, %lo(.L__const.TEST_CASE1.Vv2.7)(a0)
	sw	a0, -168(s0)
	addi	a0, s0, -168
	#APP
	vle64.v v2, (a0)  

	#NO_APP
	j	.LBB0_34
.Ltmp44:
.LBB0_34:
	.loc	1 26 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:26:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp45:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	j	.LBB0_35
.LBB0_35:
.Ltmp46:
	.loc	1 27 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -172(s0)
	lw	a0, -172(s0)
	#APP
	vse64.v v4, (a0)

	#NO_APP
	sw	a0, -172(s0)
	j	.LBB0_36
.Ltmp47:
.LBB0_36:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	sw	zero, -180(s0)
	li	a0, 73
	sw	a0, -184(s0)
	li	a0, 3
	li	a1, 1
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 3
	call	printf_
.Ltmp48:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	sw	zero, -188(s0)
	j	.LBB0_37
.LBB0_37:                               # =>This Inner Loop Header: Depth=1
.Ltmp49:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lw	a0, -188(s0)
.Ltmp50:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	bnez	a0, .LBB0_42
	j	.LBB0_38
.LBB0_38:                               #   in Loop: Header=BB0_37 Depth=1
.Ltmp51:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lw	a1, -188(s0)
	li	a0, 3
	call	ara_compare_step
.Ltmp52:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lw	a0, -188(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -188(s0)
	slli	a2, a2, 3
	addi	a3, s0, -184
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB0_40
	j	.LBB0_39
.LBB0_39:
.Ltmp53:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lw	a1, -188(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -188(s0)
	slli	a0, a0, 3
	addi	a4, s0, -184
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_43
.Ltmp54:
.LBB0_40:                               #   in Loop: Header=BB0_37 Depth=1
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	j	.LBB0_41
.Ltmp55:
.LBB0_41:                               #   in Loop: Header=BB0_37 Depth=1
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lw	a0, -188(s0)
	addi	a0, a0, 1
	sw	a0, -188(s0)
	j	.LBB0_37
.Ltmp56:
.LBB0_42:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:27:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 3
	call	ara_assert_end
.Ltmp57:
	.loc	1 28 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:28:1
	j	.LBB0_43
.LBB0_43:
	.cfi_def_cfa sp, 192
	.loc	1 28 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:28:1
	lw	ra, 188(sp)                     # 4-byte Folded Reload
	lw	s0, 184(sp)                     # 4-byte Folded Reload
	lw	s1, 180(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 192
	.cfi_def_cfa_offset 0
	ret
.Ltmp58:
.Lfunc_end0:
	.size	TEST_CASE1, .Lfunc_end0-TEST_CASE1
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE2                      # -- Begin function TEST_CASE2
	.p2align	2
	.type	TEST_CASE2,@function
TEST_CASE2:                             # @TEST_CASE2
.Lfunc_begin1:
	.loc	1 31 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:31:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -224
	.cfi_def_cfa_offset 224
	sw	ra, 220(sp)                     # 4-byte Folded Spill
	sw	s0, 216(sp)                     # 4-byte Folded Spill
	sw	s1, 212(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 224
	.cfi_def_cfa s0, 0
.Ltmp59:
	.loc	1 32 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:32:3
	j	.LBB1_1
.LBB1_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp60:
	.loc	1 32 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:32:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 32
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_2
.Ltmp61:
.LBB1_2:
	.loc	1 33 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:33:3
	j	.LBB1_3
.LBB1_3:
.Ltmp62:
	.loc	1 33 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:33:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -14(s0)
	addi	a0, s0, -14
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_4
.Ltmp63:
.LBB1_4:
	.loc	1 34 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:34:3
	j	.LBB1_5
.LBB1_5:
.Ltmp64:
	.loc	1 34 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:34:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv6)
	addi	a1, a0, %lo(.L__const.TEST_CASE2.Vv6)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -28(s0)
	lbu	a0, %lo(.L__const.TEST_CASE2.Vv6)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -32(s0)
	addi	a0, s0, -32
	#APP
	vle8.v v6, (a0)  

	#NO_APP
	j	.LBB1_6
.Ltmp65:
.LBB1_6:
	.loc	1 35 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:35:3
	j	.LBB1_7
.LBB1_7:
.Ltmp66:
	.loc	1 35 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:35:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2)
	lh	a0, %lo(.L__const.TEST_CASE2.Vv2)(a0)
	sh	a0, -34(s0)
	addi	a0, s0, -34
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB1_8
.Ltmp67:
.LBB1_8:
	.loc	1 36 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:36:3
	j	.LBB1_9
.LBB1_9:
.Ltmp68:
	.loc	1 36 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:36:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv4)
	lh	a0, %lo(.L__const.TEST_CASE2.Vv4)(a0)
	sh	a0, -36(s0)
	addi	a0, s0, -36
	#APP
	vle16.v v4, (a0)  

	#NO_APP
	j	.LBB1_10
.Ltmp69:
.LBB1_10:
	.loc	1 37 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:37:3
	#APP
	vwredsumu.vs v4, v6, v2, v0.t
	#NO_APP
.Ltmp70:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	j	.LBB1_11
.LBB1_11:
.Ltmp71:
	.loc	1 38 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -40(s0)
	lw	a0, -40(s0)
	#APP
	vse16.v v4, (a0)

	#NO_APP
	sw	a0, -40(s0)
	j	.LBB1_12
.Ltmp72:
.LBB1_12:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 291
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	sh	a0, -42(s0)
	li	a0, 4
	li	a1, 1
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 4
	call	printf_
.Ltmp73:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	sw	zero, -48(s0)
	j	.LBB1_13
.LBB1_13:                               # =>This Inner Loop Header: Depth=1
.Ltmp74:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lw	a0, -48(s0)
.Ltmp75:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	bnez	a0, .LBB1_18
	j	.LBB1_14
.LBB1_14:                               #   in Loop: Header=BB1_13 Depth=1
.Ltmp76:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lw	a1, -48(s0)
	li	a0, 4
	call	ara_compare_step
.Ltmp77:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lw	a0, -48(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -48(s0)
	slli	a1, a1, 1
	addi	a2, s0, -42
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB1_16
	j	.LBB1_15
.LBB1_15:
.Ltmp78:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lw	a1, -48(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -48(s0)
	slli	a0, a0, 1
	addi	a3, s0, -42
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_55
.Ltmp79:
.LBB1_16:                               #   in Loop: Header=BB1_13 Depth=1
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	j	.LBB1_17
.Ltmp80:
.LBB1_17:                               #   in Loop: Header=BB1_13 Depth=1
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lw	a0, -48(s0)
	addi	a0, a0, 1
	sw	a0, -48(s0)
	j	.LBB1_13
.Ltmp81:
.LBB1_18:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:38:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 4
	call	ara_assert_end
.Ltmp82:
	.loc	1 40 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:40:3
	j	.LBB1_19
.LBB1_19:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp83:
	.loc	1 40 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:40:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 40
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_20
.Ltmp84:
.LBB1_20:
	.loc	1 41 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:41:3
	j	.LBB1_21
.LBB1_21:
.Ltmp85:
	.loc	1 41 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:41:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0.9)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0.9)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0.9)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -50(s0)
	addi	a0, s0, -50
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_22
.Ltmp86:
.LBB1_22:
	.loc	1 42 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:42:3
	j	.LBB1_23
.LBB1_23:
.Ltmp87:
	.loc	1 42 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:42:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv6.10)
	addi	a1, a0, %lo(.L__const.TEST_CASE2.Vv6.10)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -60(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -64(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -76(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -80(s0)
	lhu	a0, %lo(.L__const.TEST_CASE2.Vv6.10)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -84(s0)
	addi	a0, s0, -84
	#APP
	vle16.v v6, (a0)  

	#NO_APP
	j	.LBB1_24
.Ltmp88:
.LBB1_24:
	.loc	1 43 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:43:3
	j	.LBB1_25
.LBB1_25:
.Ltmp89:
	.loc	1 43 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:43:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2.11)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv2.11)(a0)
	sw	a0, -88(s0)
	addi	a0, s0, -88
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB1_26
.Ltmp90:
.LBB1_26:
	.loc	1 44 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:44:3
	j	.LBB1_27
.LBB1_27:
.Ltmp91:
	.loc	1 44 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:44:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv4.12)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv4.12)(a0)
	sw	a0, -92(s0)
	addi	a0, s0, -92
	#APP
	vle32.v v4, (a0)  

	#NO_APP
	j	.LBB1_28
.Ltmp92:
.LBB1_28:
	.loc	1 45 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:45:3
	#APP
	vwredsumu.vs v4, v6, v2, v0.t
	#NO_APP
.Ltmp93:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	j	.LBB1_29
.LBB1_29:
.Ltmp94:
	.loc	1 46 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -96(s0)
	lw	a0, -96(s0)
	#APP
	vse32.v v4, (a0)

	#NO_APP
	sw	a0, -96(s0)
	j	.LBB1_30
.Ltmp95:
.LBB1_30:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 37
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	sw	a0, -100(s0)
	li	a0, 5
	li	a1, 1
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 5
	call	printf_
.Ltmp96:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	sw	zero, -104(s0)
	j	.LBB1_31
.LBB1_31:                               # =>This Inner Loop Header: Depth=1
.Ltmp97:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lw	a0, -104(s0)
.Ltmp98:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	bnez	a0, .LBB1_36
	j	.LBB1_32
.LBB1_32:                               #   in Loop: Header=BB1_31 Depth=1
.Ltmp99:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lw	a1, -104(s0)
	li	a0, 5
	call	ara_compare_step
.Ltmp100:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lw	a0, -104(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -104(s0)
	slli	a1, a1, 2
	addi	a2, s0, -100
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB1_34
	j	.LBB1_33
.LBB1_33:
.Ltmp101:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lw	a1, -104(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -104(s0)
	slli	a0, a0, 2
	addi	a3, s0, -100
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_55
.Ltmp102:
.LBB1_34:                               #   in Loop: Header=BB1_31 Depth=1
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	j	.LBB1_35
.Ltmp103:
.LBB1_35:                               #   in Loop: Header=BB1_31 Depth=1
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lw	a0, -104(s0)
	addi	a0, a0, 1
	sw	a0, -104(s0)
	j	.LBB1_31
.Ltmp104:
.LBB1_36:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:46:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 5
	call	ara_assert_end
.Ltmp105:
	.loc	1 48 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:48:3
	j	.LBB1_37
.LBB1_37:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp106:
	.loc	1 48 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:48:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 48
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_38
.Ltmp107:
.LBB1_38:
	.loc	1 49 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:49:3
	j	.LBB1_39
.LBB1_39:
.Ltmp108:
	.loc	1 49 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:49:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0.14)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0.14)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0.14)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -106(s0)
	addi	a0, s0, -106
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_40
.Ltmp109:
.LBB1_40:
	.loc	1 50 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:50:3
	j	.LBB1_41
.LBB1_41:
.Ltmp110:
	.loc	1 50 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:50:3
	lui	a1, %hi(.L__const.TEST_CASE2.Vv6.15)
	addi	a1, a1, %lo(.L__const.TEST_CASE2.Vv6.15)
	addi	s1, s0, -172
	addi	a0, s0, -172
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v6, (s1)  

	#NO_APP
	j	.LBB1_42
.Ltmp111:
.LBB1_42:
	.loc	1 51 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:51:3
	j	.LBB1_43
.LBB1_43:
.Ltmp112:
	.loc	1 51 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:51:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2.16)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv2.16+4)(a0)
	sw	a1, -180(s0)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv2.16)(a0)
	sw	a0, -184(s0)
	addi	a0, s0, -184
	#APP
	vle64.v v2, (a0)  

	#NO_APP
	j	.LBB1_44
.Ltmp113:
.LBB1_44:
	.loc	1 52 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:52:3
	j	.LBB1_45
.LBB1_45:
.Ltmp114:
	.loc	1 52 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:52:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv4.17)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv4.17+4)(a0)
	sw	a1, -188(s0)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv4.17)(a0)
	sw	a0, -192(s0)
	addi	a0, s0, -192
	#APP
	vle64.v v4, (a0)  

	#NO_APP
	j	.LBB1_46
.Ltmp115:
.LBB1_46:
	.loc	1 53 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:53:3
	#APP
	vwredsumu.vs v4, v6, v2, v0.t
	#NO_APP
.Ltmp116:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	j	.LBB1_47
.LBB1_47:
.Ltmp117:
	.loc	1 54 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -196(s0)
	lw	a0, -196(s0)
	#APP
	vse64.v v4, (a0)

	#NO_APP
	sw	a0, -196(s0)
	j	.LBB1_48
.Ltmp118:
.LBB1_48:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	sw	zero, -204(s0)
	li	a0, 37
	sw	a0, -208(s0)
	li	a0, 6
	li	a1, 1
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 6
	call	printf_
.Ltmp119:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	sw	zero, -212(s0)
	j	.LBB1_49
.LBB1_49:                               # =>This Inner Loop Header: Depth=1
.Ltmp120:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lw	a0, -212(s0)
.Ltmp121:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	bnez	a0, .LBB1_54
	j	.LBB1_50
.LBB1_50:                               #   in Loop: Header=BB1_49 Depth=1
.Ltmp122:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lw	a1, -212(s0)
	li	a0, 6
	call	ara_compare_step
.Ltmp123:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lw	a0, -212(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -212(s0)
	slli	a2, a2, 3
	addi	a3, s0, -208
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB1_52
	j	.LBB1_51
.LBB1_51:
.Ltmp124:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lw	a1, -212(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -212(s0)
	slli	a0, a0, 3
	addi	a4, s0, -208
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_55
.Ltmp125:
.LBB1_52:                               #   in Loop: Header=BB1_49 Depth=1
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	j	.LBB1_53
.Ltmp126:
.LBB1_53:                               #   in Loop: Header=BB1_49 Depth=1
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lw	a0, -212(s0)
	addi	a0, a0, 1
	sw	a0, -212(s0)
	j	.LBB1_49
.Ltmp127:
.LBB1_54:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:54:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 6
	call	ara_assert_end
.Ltmp128:
	.loc	1 55 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:55:1
	j	.LBB1_55
.LBB1_55:
	.cfi_def_cfa sp, 224
	.loc	1 55 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:55:1
	lw	ra, 220(sp)                     # 4-byte Folded Reload
	lw	s0, 216(sp)                     # 4-byte Folded Reload
	lw	s1, 212(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 224
	.cfi_def_cfa_offset 0
	ret
.Ltmp129:
.Lfunc_end1:
	.size	TEST_CASE2, .Lfunc_end1-TEST_CASE2
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE3                      # -- Begin function TEST_CASE3
	.p2align	2
	.type	TEST_CASE3,@function
TEST_CASE3:                             # @TEST_CASE3
.Lfunc_begin2:
	.loc	1 58 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:58:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -832
	.cfi_def_cfa_offset 832
	sw	ra, 828(sp)                     # 4-byte Folded Spill
	sw	s0, 824(sp)                     # 4-byte Folded Spill
	sw	s1, 820(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 832
	.cfi_def_cfa s0, 0
.Ltmp130:
	.loc	1 59 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:59:3
	j	.LBB2_1
.LBB2_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp131:
	.loc	1 59 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:59:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 59
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_2
.Ltmp132:
.LBB2_2:
	.loc	1 60 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:60:3
	j	.LBB2_3
.LBB2_3:
.Ltmp133:
	.loc	1 60 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:60:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv6)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv6)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -16(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a0, %lo(.L__const.TEST_CASE3.Vv6)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -28(s0)
	addi	a0, s0, -28
	#APP
	vle8.v v6, (a0)  

	#NO_APP
	j	.LBB2_4
.Ltmp134:
.LBB2_4:
	.loc	1 61 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:61:3
	j	.LBB2_5
.LBB2_5:
.Ltmp135:
	.loc	1 61 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:61:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv2)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -32(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -36(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -40(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -44(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -48(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -52(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv2)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -60(s0)
	addi	a0, s0, -60
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB2_6
.Ltmp136:
.LBB2_6:
	.loc	1 62 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:62:3
	j	.LBB2_7
.LBB2_7:
.Ltmp137:
	.loc	1 62 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:62:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv4)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv4)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -64(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -76(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -80(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -84(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -88(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv4)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -92(s0)
	addi	a0, s0, -92
	#APP
	vle16.v v4, (a0)  

	#NO_APP
	j	.LBB2_8
.Ltmp138:
.LBB2_8:
	.loc	1 63 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:63:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp139:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	j	.LBB2_9
.LBB2_9:
.Ltmp140:
	.loc	1 64 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -96(s0)
	lw	a0, -96(s0)
	#APP
	vse16.v v4, (a0)

	#NO_APP
	sw	a0, -96(s0)
	j	.LBB2_10
.Ltmp141:
.LBB2_10:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	lui	a0, 128
	addi	a0, a0, 7
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	sw	a0, -100(s0)
	lui	a1, 96
	addi	a1, a1, 5
	sw	a1, -104(s0)
	lui	a2, 64
	addi	a2, a2, 3
	sw	a2, -108(s0)
	lui	a3, 32
	addi	a4, a3, 1
	sw	a4, -112(s0)
	sw	a0, -116(s0)
	sw	a1, -120(s0)
	sw	a2, -124(s0)
	addi	a0, a3, 73
	sw	a0, -128(s0)
	li	a0, 7
	li	a1, 16
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 7
	call	printf_
.Ltmp142:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	sw	zero, -132(s0)
	j	.LBB2_11
.LBB2_11:                               # =>This Inner Loop Header: Depth=1
.Ltmp143:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lw	a0, -132(s0)
	li	a1, 15
.Ltmp144:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	bltu	a1, a0, .LBB2_16
	j	.LBB2_12
.LBB2_12:                               #   in Loop: Header=BB2_11 Depth=1
.Ltmp145:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lw	a1, -132(s0)
	li	a0, 7
	call	ara_compare_step
.Ltmp146:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lw	a0, -132(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -132(s0)
	slli	a1, a1, 1
	addi	a2, s0, -128
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB2_14
	j	.LBB2_13
.LBB2_13:
.Ltmp147:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lw	a1, -132(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -132(s0)
	slli	a0, a0, 1
	addi	a3, s0, -128
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_49
.Ltmp148:
.LBB2_14:                               #   in Loop: Header=BB2_11 Depth=1
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	j	.LBB2_15
.Ltmp149:
.LBB2_15:                               #   in Loop: Header=BB2_11 Depth=1
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lw	a0, -132(s0)
	addi	a0, a0, 1
	sw	a0, -132(s0)
	j	.LBB2_11
.Ltmp150:
.LBB2_16:
	.loc	1 64 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:64:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 7
	call	ara_assert_end
.Ltmp151:
	.loc	1 66 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:66:3
	j	.LBB2_17
.LBB2_17:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp152:
	.loc	1 66 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:66:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 66
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_18
.Ltmp153:
.LBB2_18:
	.loc	1 67 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:67:3
	j	.LBB2_19
.LBB2_19:
.Ltmp154:
	.loc	1 67 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:67:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv6.19)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv6.19)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -136(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -140(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -144(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -148(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -152(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -156(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -160(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv6.19)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -164(s0)
	addi	a0, s0, -164
	#APP
	vle16.v v6, (a0)  

	#NO_APP
	j	.LBB2_20
.Ltmp155:
.LBB2_20:
	.loc	1 68 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:68:3
	j	.LBB2_21
.LBB2_21:
.Ltmp156:
	.loc	1 68 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:68:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv2.20)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv2.20)
	addi	s1, s0, -228
	addi	a0, s0, -228
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB2_22
.Ltmp157:
.LBB2_22:
	.loc	1 69 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:69:3
	j	.LBB2_23
.LBB2_23:
.Ltmp158:
	.loc	1 69 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:69:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv4.21)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv4.21)
	addi	s1, s0, -292
	addi	a0, s0, -292
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v4, (s1)  

	#NO_APP
	j	.LBB2_24
.Ltmp159:
.LBB2_24:
	.loc	1 70 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:70:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp160:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	j	.LBB2_25
.LBB2_25:
.Ltmp161:
	.loc	1 71 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -296(s0)
	lw	a0, -296(s0)
	#APP
	vse32.v v4, (a0)

	#NO_APP
	sw	a0, -296(s0)
	j	.LBB2_26
.Ltmp162:
.LBB2_26:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lui	a1, %hi(.L__const.TEST_CASE3.vact.22)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.vact.22)
	addi	a0, s0, -360
	li	a2, 64
	call	memcpy
	li	a0, 8
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 8
	call	printf_
.Ltmp163:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	sw	zero, -364(s0)
	j	.LBB2_27
.LBB2_27:                               # =>This Inner Loop Header: Depth=1
.Ltmp164:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lw	a0, -364(s0)
	li	a1, 15
.Ltmp165:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	bltu	a1, a0, .LBB2_32
	j	.LBB2_28
.LBB2_28:                               #   in Loop: Header=BB2_27 Depth=1
.Ltmp166:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lw	a1, -364(s0)
	li	a0, 8
	call	ara_compare_step
.Ltmp167:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lw	a0, -364(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -364(s0)
	slli	a1, a1, 2
	addi	a2, s0, -360
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB2_30
	j	.LBB2_29
.LBB2_29:
.Ltmp168:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lw	a1, -364(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -364(s0)
	slli	a0, a0, 2
	addi	a3, s0, -360
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_49
.Ltmp169:
.LBB2_30:                               #   in Loop: Header=BB2_27 Depth=1
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	j	.LBB2_31
.Ltmp170:
.LBB2_31:                               #   in Loop: Header=BB2_27 Depth=1
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lw	a0, -364(s0)
	addi	a0, a0, 1
	sw	a0, -364(s0)
	j	.LBB2_27
.Ltmp171:
.LBB2_32:
	.loc	1 71 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:71:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 8
	call	ara_assert_end
.Ltmp172:
	.loc	1 73 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:73:3
	j	.LBB2_33
.LBB2_33:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp173:
	.loc	1 73 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:73:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 73
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_34
.Ltmp174:
.LBB2_34:
	.loc	1 74 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:74:3
	j	.LBB2_35
.LBB2_35:
.Ltmp175:
	.loc	1 74 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:74:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv6.23)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv6.23)
	addi	s1, s0, -428
	addi	a0, s0, -428
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v6, (s1)  

	#NO_APP
	j	.LBB2_36
.Ltmp176:
.LBB2_36:
	.loc	1 75 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:75:3
	j	.LBB2_37
.LBB2_37:
.Ltmp177:
	.loc	1 75 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:75:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv2.24)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv2.24)
	addi	s1, s0, -560
	addi	a0, s0, -560
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB2_38
.Ltmp178:
.LBB2_38:
	.loc	1 76 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:76:3
	j	.LBB2_39
.LBB2_39:
.Ltmp179:
	.loc	1 76 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:76:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv4.25)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv4.25)
	addi	s1, s0, -688
	addi	a0, s0, -688
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v4, (s1)  

	#NO_APP
	j	.LBB2_40
.Ltmp180:
.LBB2_40:
	.loc	1 77 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:77:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp181:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	j	.LBB2_41
.LBB2_41:
.Ltmp182:
	.loc	1 78 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -692(s0)
	lw	a0, -692(s0)
	#APP
	vse64.v v4, (a0)

	#NO_APP
	sw	a0, -692(s0)
	j	.LBB2_42
.Ltmp183:
.LBB2_42:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lui	a1, %hi(.L__const.TEST_CASE3.vact.26)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.vact.26)
	addi	a0, s0, -824
	li	a2, 128
	call	memcpy
	li	a0, 9
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 9
	call	printf_
.Ltmp184:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	sw	zero, -828(s0)
	j	.LBB2_43
.LBB2_43:                               # =>This Inner Loop Header: Depth=1
.Ltmp185:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lw	a0, -828(s0)
	li	a1, 15
.Ltmp186:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	bltu	a1, a0, .LBB2_48
	j	.LBB2_44
.LBB2_44:                               #   in Loop: Header=BB2_43 Depth=1
.Ltmp187:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lw	a1, -828(s0)
	li	a0, 9
	call	ara_compare_step
.Ltmp188:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lw	a0, -828(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -828(s0)
	slli	a2, a2, 3
	addi	a3, s0, -824
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB2_46
	j	.LBB2_45
.LBB2_45:
.Ltmp189:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lw	a1, -828(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -828(s0)
	slli	a0, a0, 3
	addi	a4, s0, -824
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_49
.Ltmp190:
.LBB2_46:                               #   in Loop: Header=BB2_43 Depth=1
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	j	.LBB2_47
.Ltmp191:
.LBB2_47:                               #   in Loop: Header=BB2_43 Depth=1
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lw	a0, -828(s0)
	addi	a0, a0, 1
	sw	a0, -828(s0)
	j	.LBB2_43
.Ltmp192:
.LBB2_48:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:78:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 9
	call	ara_assert_end
.Ltmp193:
	.loc	1 79 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:79:1
	j	.LBB2_49
.LBB2_49:
	.cfi_def_cfa sp, 832
	.loc	1 79 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:79:1
	lw	ra, 828(sp)                     # 4-byte Folded Reload
	lw	s0, 824(sp)                     # 4-byte Folded Reload
	lw	s1, 820(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 832
	.cfi_def_cfa_offset 0
	ret
.Ltmp194:
.Lfunc_end2:
	.size	TEST_CASE3, .Lfunc_end2-TEST_CASE3
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE4                      # -- Begin function TEST_CASE4
	.p2align	2
	.type	TEST_CASE4,@function
TEST_CASE4:                             # @TEST_CASE4
.Lfunc_begin3:
	.loc	1 82 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:82:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -832
	.cfi_def_cfa_offset 832
	sw	ra, 828(sp)                     # 4-byte Folded Spill
	sw	s0, 824(sp)                     # 4-byte Folded Spill
	sw	s1, 820(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 832
	.cfi_def_cfa s0, 0
.Ltmp195:
	.loc	1 83 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:83:3
	j	.LBB3_1
.LBB3_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 15
.Ltmp196:
	.loc	1 83 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:83:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 83
	li	a1, 15
	call	ara_trace_vset
	j	.LBB3_2
.Ltmp197:
.LBB3_2:
	.loc	1 84 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:84:3
	j	.LBB3_3
.LBB3_3:
.Ltmp198:
	.loc	1 84 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:84:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv6)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv6)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -16(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a0, %lo(.L__const.TEST_CASE4.Vv6)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -28(s0)
	addi	a0, s0, -28
	#APP
	vle8.v v6, (a0)  

	#NO_APP
	j	.LBB3_4
.Ltmp199:
.LBB3_4:
	.loc	1 85 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:85:3
	j	.LBB3_5
.LBB3_5:
.Ltmp200:
	.loc	1 85 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:85:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv2)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -32(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -36(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -40(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -44(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -48(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -52(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a0, %lo(.L__const.TEST_CASE4.Vv2)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -60(s0)
	addi	a0, s0, -60
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB3_6
.Ltmp201:
.LBB3_6:
	.loc	1 86 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:86:3
	j	.LBB3_7
.LBB3_7:
.Ltmp202:
	.loc	1 86 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:86:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv4)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv4)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -64(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -76(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -80(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -84(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -88(s0)
	lhu	a0, %lo(.L__const.TEST_CASE4.Vv4)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -92(s0)
	addi	a0, s0, -92
	#APP
	vle16.v v4, (a0)  

	#NO_APP
	j	.LBB3_8
.Ltmp203:
.LBB3_8:
	.loc	1 87 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:87:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp204:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	j	.LBB3_9
.LBB3_9:
.Ltmp205:
	.loc	1 88 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -96(s0)
	lw	a0, -96(s0)
	#APP
	vse16.v v4, (a0)

	#NO_APP
	sw	a0, -96(s0)
	j	.LBB3_10
.Ltmp206:
.LBB3_10:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	lui	a0, 128
	addi	a0, a0, 7
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	sw	a0, -100(s0)
	lui	a1, 96
	addi	a1, a1, 5
	sw	a1, -104(s0)
	lui	a2, 64
	addi	a2, a2, 3
	sw	a2, -108(s0)
	lui	a3, 32
	addi	a4, a3, 1
	sw	a4, -112(s0)
	sw	a0, -116(s0)
	sw	a1, -120(s0)
	sw	a2, -124(s0)
	addi	a0, a3, 65
	sw	a0, -128(s0)
	li	a0, 10
	li	a1, 16
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 10
	call	printf_
.Ltmp207:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	sw	zero, -132(s0)
	j	.LBB3_11
.LBB3_11:                               # =>This Inner Loop Header: Depth=1
.Ltmp208:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lw	a0, -132(s0)
	li	a1, 15
.Ltmp209:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	bltu	a1, a0, .LBB3_16
	j	.LBB3_12
.LBB3_12:                               #   in Loop: Header=BB3_11 Depth=1
.Ltmp210:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lw	a1, -132(s0)
	li	a0, 10
	call	ara_compare_step
.Ltmp211:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lw	a0, -132(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -132(s0)
	slli	a1, a1, 1
	addi	a2, s0, -128
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB3_14
	j	.LBB3_13
.LBB3_13:
.Ltmp212:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lw	a1, -132(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -132(s0)
	slli	a0, a0, 1
	addi	a3, s0, -128
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_49
.Ltmp213:
.LBB3_14:                               #   in Loop: Header=BB3_11 Depth=1
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	j	.LBB3_15
.Ltmp214:
.LBB3_15:                               #   in Loop: Header=BB3_11 Depth=1
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lw	a0, -132(s0)
	addi	a0, a0, 1
	sw	a0, -132(s0)
	j	.LBB3_11
.Ltmp215:
.LBB3_16:
	.loc	1 88 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:88:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 10
	call	ara_assert_end
.Ltmp216:
	.loc	1 90 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:90:3
	j	.LBB3_17
.LBB3_17:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 1
.Ltmp217:
	.loc	1 90 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:90:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 90
	li	a1, 1
	call	ara_trace_vset
	j	.LBB3_18
.Ltmp218:
.LBB3_18:
	.loc	1 91 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:91:3
	j	.LBB3_19
.LBB3_19:
.Ltmp219:
	.loc	1 91 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:91:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv6.27)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv6.27)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -136(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -140(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -144(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -148(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -152(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -156(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -160(s0)
	lhu	a0, %lo(.L__const.TEST_CASE4.Vv6.27)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -164(s0)
	addi	a0, s0, -164
	#APP
	vle16.v v6, (a0)  

	#NO_APP
	j	.LBB3_20
.Ltmp220:
.LBB3_20:
	.loc	1 92 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:92:3
	j	.LBB3_21
.LBB3_21:
.Ltmp221:
	.loc	1 92 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:92:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv2.28)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv2.28)
	addi	s1, s0, -228
	addi	a0, s0, -228
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB3_22
.Ltmp222:
.LBB3_22:
	.loc	1 93 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:93:3
	j	.LBB3_23
.LBB3_23:
.Ltmp223:
	.loc	1 93 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:93:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv4.29)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv4.29)
	addi	s1, s0, -292
	addi	a0, s0, -292
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v4, (s1)  

	#NO_APP
	j	.LBB3_24
.Ltmp224:
.LBB3_24:
	.loc	1 94 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:94:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp225:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	j	.LBB3_25
.LBB3_25:
.Ltmp226:
	.loc	1 95 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -296(s0)
	lw	a0, -296(s0)
	#APP
	vse32.v v4, (a0)

	#NO_APP
	sw	a0, -296(s0)
	j	.LBB3_26
.Ltmp227:
.LBB3_26:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lui	a1, %hi(.L__const.TEST_CASE4.vact.30)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.vact.30)
	addi	a0, s0, -360
	li	a2, 64
	call	memcpy
	li	a0, 11
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 11
	call	printf_
.Ltmp228:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	sw	zero, -364(s0)
	j	.LBB3_27
.LBB3_27:                               # =>This Inner Loop Header: Depth=1
.Ltmp229:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lw	a0, -364(s0)
	li	a1, 15
.Ltmp230:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	bltu	a1, a0, .LBB3_32
	j	.LBB3_28
.LBB3_28:                               #   in Loop: Header=BB3_27 Depth=1
.Ltmp231:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lw	a1, -364(s0)
	li	a0, 11
	call	ara_compare_step
.Ltmp232:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lw	a0, -364(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -364(s0)
	slli	a1, a1, 2
	addi	a2, s0, -360
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB3_30
	j	.LBB3_29
.LBB3_29:
.Ltmp233:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lw	a1, -364(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -364(s0)
	slli	a0, a0, 2
	addi	a3, s0, -360
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_49
.Ltmp234:
.LBB3_30:                               #   in Loop: Header=BB3_27 Depth=1
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	j	.LBB3_31
.Ltmp235:
.LBB3_31:                               #   in Loop: Header=BB3_27 Depth=1
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lw	a0, -364(s0)
	addi	a0, a0, 1
	sw	a0, -364(s0)
	j	.LBB3_27
.Ltmp236:
.LBB3_32:
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:95:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 11
	call	ara_assert_end
.Ltmp237:
	.loc	1 97 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:97:3
	j	.LBB3_33
.LBB3_33:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 3
.Ltmp238:
	.loc	1 97 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:97:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 97
	li	a1, 3
	call	ara_trace_vset
	j	.LBB3_34
.Ltmp239:
.LBB3_34:
	.loc	1 98 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:98:3
	j	.LBB3_35
.LBB3_35:
.Ltmp240:
	.loc	1 98 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:98:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv6.31)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv6.31)
	addi	s1, s0, -428
	addi	a0, s0, -428
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v6, (s1)  

	#NO_APP
	j	.LBB3_36
.Ltmp241:
.LBB3_36:
	.loc	1 99 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:99:3
	j	.LBB3_37
.LBB3_37:
.Ltmp242:
	.loc	1 99 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:99:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv2.32)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv2.32)
	addi	s1, s0, -560
	addi	a0, s0, -560
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB3_38
.Ltmp243:
.LBB3_38:
	.loc	1 100 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:100:3
	j	.LBB3_39
.LBB3_39:
.Ltmp244:
	.loc	1 100 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:100:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv4.33)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv4.33)
	addi	s1, s0, -688
	addi	a0, s0, -688
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v4, (s1)  

	#NO_APP
	j	.LBB3_40
.Ltmp245:
.LBB3_40:
	.loc	1 101 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:101:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp246:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	j	.LBB3_41
.LBB3_41:
.Ltmp247:
	.loc	1 102 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -692(s0)
	lw	a0, -692(s0)
	#APP
	vse64.v v4, (a0)

	#NO_APP
	sw	a0, -692(s0)
	j	.LBB3_42
.Ltmp248:
.LBB3_42:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lui	a1, %hi(.L__const.TEST_CASE4.vact.34)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.vact.34)
	addi	a0, s0, -824
	li	a2, 128
	call	memcpy
	li	a0, 12
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 12
	call	printf_
.Ltmp249:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	sw	zero, -828(s0)
	j	.LBB3_43
.LBB3_43:                               # =>This Inner Loop Header: Depth=1
.Ltmp250:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lw	a0, -828(s0)
	li	a1, 15
.Ltmp251:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	bltu	a1, a0, .LBB3_48
	j	.LBB3_44
.LBB3_44:                               #   in Loop: Header=BB3_43 Depth=1
.Ltmp252:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lw	a1, -828(s0)
	li	a0, 12
	call	ara_compare_step
.Ltmp253:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lw	a0, -828(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -828(s0)
	slli	a2, a2, 3
	addi	a3, s0, -824
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB3_46
	j	.LBB3_45
.LBB3_45:
.Ltmp254:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lw	a1, -828(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -828(s0)
	slli	a0, a0, 3
	addi	a4, s0, -824
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_49
.Ltmp255:
.LBB3_46:                               #   in Loop: Header=BB3_43 Depth=1
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	j	.LBB3_47
.Ltmp256:
.LBB3_47:                               #   in Loop: Header=BB3_43 Depth=1
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lw	a0, -828(s0)
	addi	a0, a0, 1
	sw	a0, -828(s0)
	j	.LBB3_43
.Ltmp257:
.LBB3_48:
	.loc	1 102 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:102:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 12
	call	ara_assert_end
.Ltmp258:
	.loc	1 103 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:103:1
	j	.LBB3_49
.LBB3_49:
	.cfi_def_cfa sp, 832
	.loc	1 103 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:103:1
	lw	ra, 828(sp)                     # 4-byte Folded Reload
	lw	s0, 824(sp)                     # 4-byte Folded Reload
	lw	s1, 820(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 832
	.cfi_def_cfa_offset 0
	ret
.Ltmp259:
.Lfunc_end3:
	.size	TEST_CASE4, .Lfunc_end3-TEST_CASE4
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE5                      # -- Begin function TEST_CASE5
	.p2align	2
	.type	TEST_CASE5,@function
TEST_CASE5:                             # @TEST_CASE5
.Lfunc_begin4:
	.loc	1 106 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:106:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -848
	.cfi_def_cfa_offset 848
	sw	ra, 844(sp)                     # 4-byte Folded Spill
	sw	s0, 840(sp)                     # 4-byte Folded Spill
	sw	s1, 836(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 848
	.cfi_def_cfa s0, 0
.Ltmp260:
	.loc	1 107 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:107:3
	j	.LBB4_1
.LBB4_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 15
.Ltmp261:
	.loc	1 107 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:107:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 107
	li	a1, 15
	call	ara_trace_vset
	j	.LBB4_2
.Ltmp262:
.LBB4_2:
	.loc	1 108 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:108:3
	j	.LBB4_3
.LBB4_3:
.Ltmp263:
	.loc	1 108 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:108:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv0)
	lbu	a1, %lo(.L__const.TEST_CASE5.Vv0)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv0)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -14(s0)
	addi	a0, s0, -14
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB4_4
.Ltmp264:
.LBB4_4:
	.loc	1 109 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:109:3
	j	.LBB4_5
.LBB4_5:
.Ltmp265:
	.loc	1 109 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:109:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv6)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv6)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -28(s0)
	lbu	a0, %lo(.L__const.TEST_CASE5.Vv6)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -32(s0)
	addi	a0, s0, -32
	#APP
	vle8.v v6, (a0)  

	#NO_APP
	j	.LBB4_6
.Ltmp266:
.LBB4_6:
	.loc	1 110 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:110:3
	j	.LBB4_7
.LBB4_7:
.Ltmp267:
	.loc	1 110 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:110:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv2)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -36(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -40(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -44(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -48(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -52(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -60(s0)
	lhu	a0, %lo(.L__const.TEST_CASE5.Vv2)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -64(s0)
	addi	a0, s0, -64
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB4_8
.Ltmp268:
.LBB4_8:
	.loc	1 111 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:111:3
	j	.LBB4_9
.LBB4_9:
.Ltmp269:
	.loc	1 111 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:111:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv4)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv4)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -76(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -80(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -84(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -88(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -92(s0)
	lhu	a0, %lo(.L__const.TEST_CASE5.Vv4)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -96(s0)
	addi	a0, s0, -96
	#APP
	vle16.v v4, (a0)  

	#NO_APP
	j	.LBB4_10
.Ltmp270:
.LBB4_10:
	.loc	1 112 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:112:3
	#APP
	vwredsumu.vs v4, v6, v2, v0.t
	#NO_APP
.Ltmp271:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	j	.LBB4_11
.LBB4_11:
.Ltmp272:
	.loc	1 113 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -100(s0)
	lw	a0, -100(s0)
	#APP
	vse16.v v4, (a0)

	#NO_APP
	sw	a0, -100(s0)
	j	.LBB4_12
.Ltmp273:
.LBB4_12:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	lui	a0, 128
	addi	a0, a0, 7
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	sw	a0, -104(s0)
	lui	a1, 96
	addi	a1, a1, 5
	sw	a1, -108(s0)
	lui	a2, 64
	addi	a2, a2, 3
	sw	a2, -112(s0)
	lui	a3, 32
	addi	a4, a3, 1
	sw	a4, -116(s0)
	sw	a0, -120(s0)
	sw	a1, -124(s0)
	sw	a2, -128(s0)
	addi	a0, a3, 107
	sw	a0, -132(s0)
	li	a0, 13
	li	a1, 16
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 13
	call	printf_
.Ltmp274:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	sw	zero, -136(s0)
	j	.LBB4_13
.LBB4_13:                               # =>This Inner Loop Header: Depth=1
.Ltmp275:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lw	a0, -136(s0)
	li	a1, 15
.Ltmp276:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	bltu	a1, a0, .LBB4_18
	j	.LBB4_14
.LBB4_14:                               #   in Loop: Header=BB4_13 Depth=1
.Ltmp277:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lw	a1, -136(s0)
	li	a0, 13
	call	ara_compare_step
.Ltmp278:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lw	a0, -136(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -136(s0)
	slli	a1, a1, 1
	addi	a2, s0, -132
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB4_16
	j	.LBB4_15
.LBB4_15:
.Ltmp279:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lw	a1, -136(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -136(s0)
	slli	a0, a0, 1
	addi	a3, s0, -132
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB4_55
.Ltmp280:
.LBB4_16:                               #   in Loop: Header=BB4_13 Depth=1
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	j	.LBB4_17
.Ltmp281:
.LBB4_17:                               #   in Loop: Header=BB4_13 Depth=1
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lw	a0, -136(s0)
	addi	a0, a0, 1
	sw	a0, -136(s0)
	j	.LBB4_13
.Ltmp282:
.LBB4_18:
	.loc	1 113 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:113:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 13
	call	ara_assert_end
.Ltmp283:
	.loc	1 115 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:115:3
	j	.LBB4_19
.LBB4_19:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 1
.Ltmp284:
	.loc	1 115 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:115:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 115
	li	a1, 1
	call	ara_trace_vset
	j	.LBB4_20
.Ltmp285:
.LBB4_20:
	.loc	1 116 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:116:3
	j	.LBB4_21
.LBB4_21:
.Ltmp286:
	.loc	1 116 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:116:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv0.35)
	lbu	a1, %lo(.L__const.TEST_CASE5.Vv0.35)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv0.35)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -138(s0)
	addi	a0, s0, -138
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB4_22
.Ltmp287:
.LBB4_22:
	.loc	1 117 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:117:3
	j	.LBB4_23
.LBB4_23:
.Ltmp288:
	.loc	1 117 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:117:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv6.36)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv6.36)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -144(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -148(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -152(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -156(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -160(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -164(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -168(s0)
	lhu	a0, %lo(.L__const.TEST_CASE5.Vv6.36)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -172(s0)
	addi	a0, s0, -172
	#APP
	vle16.v v6, (a0)  

	#NO_APP
	j	.LBB4_24
.Ltmp289:
.LBB4_24:
	.loc	1 118 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:118:3
	j	.LBB4_25
.LBB4_25:
.Ltmp290:
	.loc	1 118 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:118:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv2.37)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv2.37)
	addi	s1, s0, -236
	addi	a0, s0, -236
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB4_26
.Ltmp291:
.LBB4_26:
	.loc	1 119 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:119:3
	j	.LBB4_27
.LBB4_27:
.Ltmp292:
	.loc	1 119 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:119:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv4.38)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv4.38)
	addi	s1, s0, -300
	addi	a0, s0, -300
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v4, (s1)  

	#NO_APP
	j	.LBB4_28
.Ltmp293:
.LBB4_28:
	.loc	1 120 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:120:3
	#APP
	vwredsumu.vs v4, v6, v2, v0.t
	#NO_APP
.Ltmp294:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	j	.LBB4_29
.LBB4_29:
.Ltmp295:
	.loc	1 121 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -304(s0)
	lw	a0, -304(s0)
	#APP
	vse32.v v4, (a0)

	#NO_APP
	sw	a0, -304(s0)
	j	.LBB4_30
.Ltmp296:
.LBB4_30:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lui	a1, %hi(.L__const.TEST_CASE5.vact.39)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.vact.39)
	addi	a0, s0, -368
	li	a2, 64
	call	memcpy
	li	a0, 14
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 14
	call	printf_
.Ltmp297:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	sw	zero, -372(s0)
	j	.LBB4_31
.LBB4_31:                               # =>This Inner Loop Header: Depth=1
.Ltmp298:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lw	a0, -372(s0)
	li	a1, 15
.Ltmp299:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	bltu	a1, a0, .LBB4_36
	j	.LBB4_32
.LBB4_32:                               #   in Loop: Header=BB4_31 Depth=1
.Ltmp300:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lw	a1, -372(s0)
	li	a0, 14
	call	ara_compare_step
.Ltmp301:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lw	a0, -372(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -372(s0)
	slli	a1, a1, 2
	addi	a2, s0, -368
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB4_34
	j	.LBB4_33
.LBB4_33:
.Ltmp302:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lw	a1, -372(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -372(s0)
	slli	a0, a0, 2
	addi	a3, s0, -368
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB4_55
.Ltmp303:
.LBB4_34:                               #   in Loop: Header=BB4_31 Depth=1
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	j	.LBB4_35
.Ltmp304:
.LBB4_35:                               #   in Loop: Header=BB4_31 Depth=1
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lw	a0, -372(s0)
	addi	a0, a0, 1
	sw	a0, -372(s0)
	j	.LBB4_31
.Ltmp305:
.LBB4_36:
	.loc	1 121 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:121:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 14
	call	ara_assert_end
.Ltmp306:
	.loc	1 123 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:123:3
	j	.LBB4_37
.LBB4_37:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 3
.Ltmp307:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:123:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 123
	li	a1, 3
	call	ara_trace_vset
	j	.LBB4_38
.Ltmp308:
.LBB4_38:
	.loc	1 124 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:124:3
	j	.LBB4_39
.LBB4_39:
.Ltmp309:
	.loc	1 124 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:124:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv0.40)
	lbu	a1, %lo(.L__const.TEST_CASE5.Vv0.40)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv0.40)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -374(s0)
	addi	a0, s0, -374
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB4_40
.Ltmp310:
.LBB4_40:
	.loc	1 125 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:125:3
	j	.LBB4_41
.LBB4_41:
.Ltmp311:
	.loc	1 125 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:125:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv6.41)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv6.41)
	addi	s1, s0, -440
	addi	a0, s0, -440
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v6, (s1)  

	#NO_APP
	j	.LBB4_42
.Ltmp312:
.LBB4_42:
	.loc	1 126 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:126:3
	j	.LBB4_43
.LBB4_43:
.Ltmp313:
	.loc	1 126 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:126:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv2.42)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv2.42)
	addi	s1, s0, -568
	addi	a0, s0, -568
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB4_44
.Ltmp314:
.LBB4_44:
	.loc	1 127 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:127:3
	j	.LBB4_45
.LBB4_45:
.Ltmp315:
	.loc	1 127 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:127:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv4.43)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv4.43)
	addi	s1, s0, -696
	addi	a0, s0, -696
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v4, (s1)  

	#NO_APP
	j	.LBB4_46
.Ltmp316:
.LBB4_46:
	.loc	1 128 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:128:3
	#APP
	vwredsumu.vs v4, v6, v2, v0.t
	#NO_APP
.Ltmp317:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	j	.LBB4_47
.LBB4_47:
.Ltmp318:
	.loc	1 129 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -700(s0)
	lw	a0, -700(s0)
	#APP
	vse64.v v4, (a0)

	#NO_APP
	sw	a0, -700(s0)
	j	.LBB4_48
.Ltmp319:
.LBB4_48:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lui	a1, %hi(.L__const.TEST_CASE5.vact.44)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.vact.44)
	addi	a0, s0, -832
	li	a2, 128
	call	memcpy
	li	a0, 15
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 15
	call	printf_
.Ltmp320:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	sw	zero, -836(s0)
	j	.LBB4_49
.LBB4_49:                               # =>This Inner Loop Header: Depth=1
.Ltmp321:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lw	a0, -836(s0)
	li	a1, 15
.Ltmp322:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	bltu	a1, a0, .LBB4_54
	j	.LBB4_50
.LBB4_50:                               #   in Loop: Header=BB4_49 Depth=1
.Ltmp323:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lw	a1, -836(s0)
	li	a0, 15
	call	ara_compare_step
.Ltmp324:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lw	a0, -836(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -836(s0)
	slli	a2, a2, 3
	addi	a3, s0, -832
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB4_52
	j	.LBB4_51
.LBB4_51:
.Ltmp325:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lw	a1, -836(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -836(s0)
	slli	a0, a0, 3
	addi	a4, s0, -832
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB4_55
.Ltmp326:
.LBB4_52:                               #   in Loop: Header=BB4_49 Depth=1
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	j	.LBB4_53
.Ltmp327:
.LBB4_53:                               #   in Loop: Header=BB4_49 Depth=1
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lw	a0, -836(s0)
	addi	a0, a0, 1
	sw	a0, -836(s0)
	j	.LBB4_49
.Ltmp328:
.LBB4_54:
	.loc	1 129 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:129:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 15
	call	ara_assert_end
.Ltmp329:
	.loc	1 130 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:130:1
	j	.LBB4_55
.LBB4_55:
	.cfi_def_cfa sp, 848
	.loc	1 130 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:130:1
	lw	ra, 844(sp)                     # 4-byte Folded Reload
	lw	s0, 840(sp)                     # 4-byte Folded Reload
	lw	s1, 836(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 848
	.cfi_def_cfa_offset 0
	ret
.Ltmp330:
.Lfunc_end4:
	.size	TEST_CASE5, .Lfunc_end4-TEST_CASE5
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE6                      # -- Begin function TEST_CASE6
	.p2align	2
	.type	TEST_CASE6,@function
TEST_CASE6:                             # @TEST_CASE6
.Lfunc_begin5:
	.loc	1 133 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:133:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sw	ra, 44(sp)                      # 4-byte Folded Spill
	sw	s0, 40(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 48
	.cfi_def_cfa s0, 0
.Ltmp331:
	.loc	1 134 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:134:3
	j	.LBB5_1
.LBB5_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 16
.Ltmp332:
	.loc	1 134 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:134:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 134
	li	a1, 16
	call	ara_trace_vset
	j	.LBB5_2
.Ltmp333:
.LBB5_2:
	.loc	1 135 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:135:3
	j	.LBB5_3
.LBB5_3:
.Ltmp334:
	.loc	1 135 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:135:3
	lui	a0, %hi(.L__const.TEST_CASE6.Vv6)
	addi	a1, a0, %lo(.L__const.TEST_CASE6.Vv6)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -12(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -16(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a0, %lo(.L__const.TEST_CASE6.Vv6)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -24(s0)
	addi	a0, s0, -24
	#APP
	vle8.v v6, (a0)  

	#NO_APP
	j	.LBB5_4
.Ltmp335:
.LBB5_4:
	.loc	1 136 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:136:3
	j	.LBB5_5
.LBB5_5:
.Ltmp336:
	.loc	1 136 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:136:3
	lui	a0, %hi(.L__const.TEST_CASE6.Vv2)
	lh	a0, %lo(.L__const.TEST_CASE6.Vv2)(a0)
	sh	a0, -26(s0)
	addi	a0, s0, -26
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB5_6
.Ltmp337:
.LBB5_6:
	.loc	1 137 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:137:3
	#APP
	vwredsumu.vs v4, v6, v2
	#NO_APP
.Ltmp338:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	j	.LBB5_7
.LBB5_7:
.Ltmp339:
	.loc	1 138 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -32(s0)
	lw	a0, -32(s0)
	#APP
	vse16.v v4, (a0)

	#NO_APP
	sw	a0, -32(s0)
	j	.LBB5_8
.Ltmp340:
.LBB5_8:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:0:3
	li	a0, 581
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	sh	a0, -34(s0)
	li	a0, 16
	li	a1, 1
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 16
	call	printf_
.Ltmp341:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	sw	zero, -40(s0)
	j	.LBB5_9
.LBB5_9:                                # =>This Inner Loop Header: Depth=1
.Ltmp342:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lw	a0, -40(s0)
.Ltmp343:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	bnez	a0, .LBB5_14
	j	.LBB5_10
.LBB5_10:                               #   in Loop: Header=BB5_9 Depth=1
.Ltmp344:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lw	a1, -40(s0)
	li	a0, 16
	call	ara_compare_step
.Ltmp345:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lw	a0, -40(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -40(s0)
	slli	a1, a1, 1
	addi	a2, s0, -34
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB5_12
	j	.LBB5_11
.LBB5_11:
.Ltmp346:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lw	a1, -40(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -40(s0)
	slli	a0, a0, 1
	addi	a3, s0, -34
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB5_15
.Ltmp347:
.LBB5_12:                               #   in Loop: Header=BB5_9 Depth=1
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	j	.LBB5_13
.Ltmp348:
.LBB5_13:                               #   in Loop: Header=BB5_9 Depth=1
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lw	a0, -40(s0)
	addi	a0, a0, 1
	sw	a0, -40(s0)
	j	.LBB5_9
.Ltmp349:
.LBB5_14:
	.loc	1 138 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:138:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 16
	call	ara_assert_end
.Ltmp350:
	.loc	1 139 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:139:1
	j	.LBB5_15
.LBB5_15:
	.cfi_def_cfa sp, 48
	.loc	1 139 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:139:1
	lw	ra, 44(sp)                      # 4-byte Folded Reload
	lw	s0, 40(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Ltmp351:
.Lfunc_end5:
	.size	TEST_CASE6, .Lfunc_end5-TEST_CASE6
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin6:
	.loc	1 141 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:141:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp352:
	.loc	1 142 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:142:3
	lui	s2, %hi(.L_MergedGlobals)
	sw	zero, %lo(.L_MergedGlobals)(s2)
	addi	a0, s2, %lo(.L_MergedGlobals)
	sw	zero, 4(a0)
	.loc	1 145 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:145:3
	lui	s1, %hi(.L.str.45)
	addi	s1, s1, %lo(.L.str.45)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 145 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:145:33
	call	TEST_CASE1
	.loc	1 145 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:145:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 145 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:145:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 146 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:146:3
	lui	s1, %hi(.L.str.46)
	addi	s1, s1, %lo(.L.str.46)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 146 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:146:33
	call	TEST_CASE2
	.loc	1 146 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:146:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 146 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:146:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 147 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:147:3
	lui	s1, %hi(.L.str.47)
	addi	s1, s1, %lo(.L.str.47)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 147 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:147:33
	call	TEST_CASE3
	.loc	1 147 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:147:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 147 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:147:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 148 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:148:3
	lui	s1, %hi(.L.str.48)
	addi	s1, s1, %lo(.L.str.48)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 148 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:148:33
	call	TEST_CASE4
	.loc	1 148 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:148:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 148 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:148:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 149 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:149:3
	lui	s1, %hi(.L.str.49)
	addi	s1, s1, %lo(.L.str.49)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 149 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:149:33
	call	TEST_CASE5
	.loc	1 149 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:149:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 149 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:149:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 150 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:150:3
	lui	s1, %hi(.L.str.50)
	addi	s1, s1, %lo(.L.str.50)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 150 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:150:33
	call	TEST_CASE6
	.loc	1 150 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:150:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 150 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:150:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 152 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:152:3
	j	.LBB6_1
.LBB6_1:
.Ltmp353:
	.loc	1 152 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:152:3
	lui	a0, %hi(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals)(a0)
	blez	a0, .LBB6_3
	j	.LBB6_2
.LBB6_2:
.Ltmp354:
	.loc	1 152 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:152:3
	lui	s1, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(s1)
	lui	a0, %hi(.L.str.51)
	addi	a0, a0, %lo(.L.str.51)
	lui	a1, %hi(.L.str.52)
	addi	a1, a1, %lo(.L.str.52)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	sw	a0, -20(s0)
	j	.LBB6_4
.Ltmp355:
.LBB6_3:
	.loc	1 152 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:152:3
	lui	a0, %hi(.L.str.53)
	addi	a0, a0, %lo(.L.str.53)
	lui	a1, %hi(.L.str.52)
	addi	a1, a1, %lo(.L.str.52)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB6_4
.Ltmp356:
.LBB6_4:
	.loc	1 153 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:153:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	1 153 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c:153:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp357:
.Lfunc_end6:
	.size	main, .Lfunc_end6-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE1.Vv6,@object # @__const.TEST_CASE1.Vv6
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE1.Vv6:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE1.Vv6, 16

	.type	.L__const.TEST_CASE1.Vv2,@object # @__const.TEST_CASE1.Vv2
	.section	.rodata,"a",@progbits
	.p2align	1, 0x0
.L__const.TEST_CASE1.Vv2:
	.half	255                             # 0xff
	.size	.L__const.TEST_CASE1.Vv2, 2

	.type	Ru16,@object                    # @Ru16
	.local	Ru16
	.comm	Ru16,2048,128
	.type	.L__const.TEST_CASE1.vact,@object # @__const.TEST_CASE1.vact
	.p2align	1, 0x0
.L__const.TEST_CASE1.vact:
	.half	327                             # 0x147
	.size	.L__const.TEST_CASE1.vact, 2

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %x, expected %x.\n"
	.size	.L.str.1, 39

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L__const.TEST_CASE1.Vv6.3,@object # @__const.TEST_CASE1.Vv6.3
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE1.Vv6.3:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE1.Vv6.3, 32

	.type	.L__const.TEST_CASE1.Vv2.4,@object # @__const.TEST_CASE1.Vv2.4
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv2.4:
	.word	1                               # 0x1
	.size	.L__const.TEST_CASE1.Vv2.4, 4

	.type	Ru32,@object                    # @Ru32
	.local	Ru32
	.comm	Ru32,4096,128
	.type	.L__const.TEST_CASE1.vact.5,@object # @__const.TEST_CASE1.vact.5
	.p2align	2, 0x0
.L__const.TEST_CASE1.vact.5:
	.word	73                              # 0x49
	.size	.L__const.TEST_CASE1.vact.5, 4

	.type	.L__const.TEST_CASE1.Vv6.6,@object # @__const.TEST_CASE1.Vv6.6
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv6.6:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE1.Vv6.6, 64

	.type	.L__const.TEST_CASE1.Vv2.7,@object # @__const.TEST_CASE1.Vv2.7
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.L__const.TEST_CASE1.Vv2.7:
	.quad	1                               # 0x1
	.size	.L__const.TEST_CASE1.Vv2.7, 8

	.type	Ru64,@object                    # @Ru64
	.local	Ru64
	.comm	Ru64,8192,128
	.type	.L__const.TEST_CASE1.vact.8,@object # @__const.TEST_CASE1.vact.8
	.p2align	3, 0x0
.L__const.TEST_CASE1.vact.8:
	.quad	73                              # 0x49
	.size	.L__const.TEST_CASE1.vact.8, 8

	.type	.L__const.TEST_CASE2.Vv0,@object # @__const.TEST_CASE2.Vv0
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE2.Vv0:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0, 2

	.type	.L__const.TEST_CASE2.Vv6,@object # @__const.TEST_CASE2.Vv6
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE2.Vv6:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE2.Vv6, 16

	.type	.L__const.TEST_CASE2.Vv2,@object # @__const.TEST_CASE2.Vv2
	.section	.rodata,"a",@progbits
	.p2align	1, 0x0
.L__const.TEST_CASE2.Vv2:
	.half	255                             # 0xff
	.size	.L__const.TEST_CASE2.Vv2, 2

	.type	.L__const.TEST_CASE2.Vv4,@object # @__const.TEST_CASE2.Vv4
	.p2align	1, 0x0
.L__const.TEST_CASE2.Vv4:
	.half	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv4, 2

	.type	.L__const.TEST_CASE2.vact,@object # @__const.TEST_CASE2.vact
	.p2align	1, 0x0
.L__const.TEST_CASE2.vact:
	.half	291                             # 0x123
	.size	.L__const.TEST_CASE2.vact, 2

	.type	.L__const.TEST_CASE2.Vv0.9,@object # @__const.TEST_CASE2.Vv0.9
.L__const.TEST_CASE2.Vv0.9:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0.9, 2

	.type	.L__const.TEST_CASE2.Vv6.10,@object # @__const.TEST_CASE2.Vv6.10
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE2.Vv6.10:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE2.Vv6.10, 32

	.type	.L__const.TEST_CASE2.Vv2.11,@object # @__const.TEST_CASE2.Vv2.11
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv2.11:
	.word	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv2.11, 4

	.type	.L__const.TEST_CASE2.Vv4.12,@object # @__const.TEST_CASE2.Vv4.12
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv4.12:
	.word	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv4.12, 4

	.type	.L__const.TEST_CASE2.vact.13,@object # @__const.TEST_CASE2.vact.13
	.p2align	2, 0x0
.L__const.TEST_CASE2.vact.13:
	.word	37                              # 0x25
	.size	.L__const.TEST_CASE2.vact.13, 4

	.type	.L__const.TEST_CASE2.Vv0.14,@object # @__const.TEST_CASE2.Vv0.14
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE2.Vv0.14:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0.14, 2

	.type	.L__const.TEST_CASE2.Vv6.15,@object # @__const.TEST_CASE2.Vv6.15
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv6.15:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE2.Vv6.15, 64

	.type	.L__const.TEST_CASE2.Vv2.16,@object # @__const.TEST_CASE2.Vv2.16
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.L__const.TEST_CASE2.Vv2.16:
	.quad	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv2.16, 8

	.type	.L__const.TEST_CASE2.Vv4.17,@object # @__const.TEST_CASE2.Vv4.17
	.p2align	3, 0x0
.L__const.TEST_CASE2.Vv4.17:
	.quad	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv4.17, 8

	.type	.L__const.TEST_CASE2.vact.18,@object # @__const.TEST_CASE2.vact.18
	.p2align	3, 0x0
.L__const.TEST_CASE2.vact.18:
	.quad	37                              # 0x25
	.size	.L__const.TEST_CASE2.vact.18, 8

	.type	.L__const.TEST_CASE3.Vv6,@object # @__const.TEST_CASE3.Vv6
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE3.Vv6:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE3.Vv6, 16

	.type	.L__const.TEST_CASE3.Vv2,@object # @__const.TEST_CASE3.Vv2
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv2:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv2, 32

	.type	.L__const.TEST_CASE3.Vv4,@object # @__const.TEST_CASE3.Vv4
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv4:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv4, 32

	.type	.L__const.TEST_CASE3.vact,@object # @__const.TEST_CASE3.vact
	.p2align	1, 0x0
.L__const.TEST_CASE3.vact:
	.half	73                              # 0x49
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.vact, 32

	.type	.L__const.TEST_CASE3.Vv6.19,@object # @__const.TEST_CASE3.Vv6.19
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv6.19:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv6.19, 32

	.type	.L__const.TEST_CASE3.Vv2.20,@object # @__const.TEST_CASE3.Vv2.20
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE3.Vv2.20:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv2.20, 64

	.type	.L__const.TEST_CASE3.Vv4.21,@object # @__const.TEST_CASE3.Vv4.21
	.p2align	2, 0x0
.L__const.TEST_CASE3.Vv4.21:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv4.21, 64

	.type	.L__const.TEST_CASE3.vact.22,@object # @__const.TEST_CASE3.vact.22
	.p2align	2, 0x0
.L__const.TEST_CASE3.vact.22:
	.word	73                              # 0x49
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.vact.22, 64

	.type	.L__const.TEST_CASE3.Vv6.23,@object # @__const.TEST_CASE3.Vv6.23
	.p2align	2, 0x0
.L__const.TEST_CASE3.Vv6.23:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv6.23, 64

	.type	.L__const.TEST_CASE3.Vv2.24,@object # @__const.TEST_CASE3.Vv2.24
	.p2align	3, 0x0
.L__const.TEST_CASE3.Vv2.24:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv2.24, 128

	.type	.L__const.TEST_CASE3.Vv4.25,@object # @__const.TEST_CASE3.Vv4.25
	.p2align	3, 0x0
.L__const.TEST_CASE3.Vv4.25:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv4.25, 128

	.type	.L__const.TEST_CASE3.vact.26,@object # @__const.TEST_CASE3.vact.26
	.p2align	3, 0x0
.L__const.TEST_CASE3.vact.26:
	.quad	73                              # 0x49
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.vact.26, 128

	.type	.L__const.TEST_CASE4.Vv6,@object # @__const.TEST_CASE4.Vv6
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE4.Vv6:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE4.Vv6, 16

	.type	.L__const.TEST_CASE4.Vv2,@object # @__const.TEST_CASE4.Vv2
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE4.Vv2:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2, 32

	.type	.L__const.TEST_CASE4.Vv4,@object # @__const.TEST_CASE4.Vv4
	.p2align	1, 0x0
.L__const.TEST_CASE4.Vv4:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv4, 32

	.type	.L__const.TEST_CASE4.vact,@object # @__const.TEST_CASE4.vact
	.p2align	1, 0x0
.L__const.TEST_CASE4.vact:
	.half	65                              # 0x41
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact, 32

	.type	.L__const.TEST_CASE4.Vv6.27,@object # @__const.TEST_CASE4.Vv6.27
	.p2align	1, 0x0
.L__const.TEST_CASE4.Vv6.27:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv6.27, 32

	.type	.L__const.TEST_CASE4.Vv2.28,@object # @__const.TEST_CASE4.Vv2.28
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv2.28:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2.28, 64

	.type	.L__const.TEST_CASE4.Vv4.29,@object # @__const.TEST_CASE4.Vv4.29
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv4.29:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv4.29, 64

	.type	.L__const.TEST_CASE4.vact.30,@object # @__const.TEST_CASE4.vact.30
	.p2align	2, 0x0
.L__const.TEST_CASE4.vact.30:
	.word	2                               # 0x2
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact.30, 64

	.type	.L__const.TEST_CASE4.Vv6.31,@object # @__const.TEST_CASE4.Vv6.31
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv6.31:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv6.31, 64

	.type	.L__const.TEST_CASE4.Vv2.32,@object # @__const.TEST_CASE4.Vv2.32
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv2.32:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2.32, 128

	.type	.L__const.TEST_CASE4.Vv4.33,@object # @__const.TEST_CASE4.Vv4.33
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv4.33:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv4.33, 128

	.type	.L__const.TEST_CASE4.vact.34,@object # @__const.TEST_CASE4.vact.34
	.p2align	3, 0x0
.L__const.TEST_CASE4.vact.34:
	.quad	7                               # 0x7
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact.34, 128

	.type	.L__const.TEST_CASE5.Vv0,@object # @__const.TEST_CASE5.Vv0
.L__const.TEST_CASE5.Vv0:
	.ascii	"\000@"
	.size	.L__const.TEST_CASE5.Vv0, 2

	.type	.L__const.TEST_CASE5.Vv6,@object # @__const.TEST_CASE5.Vv6
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE5.Vv6:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE5.Vv6, 16

	.type	.L__const.TEST_CASE5.Vv2,@object # @__const.TEST_CASE5.Vv2
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE5.Vv2:
	.half	100                             # 0x64
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv2, 32

	.type	.L__const.TEST_CASE5.Vv4,@object # @__const.TEST_CASE5.Vv4
	.p2align	1, 0x0
.L__const.TEST_CASE5.Vv4:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv4, 32

	.type	.L__const.TEST_CASE5.vact,@object # @__const.TEST_CASE5.vact
	.p2align	1, 0x0
.L__const.TEST_CASE5.vact:
	.half	107                             # 0x6b
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.vact, 32

	.type	.L__const.TEST_CASE5.Vv0.35,@object # @__const.TEST_CASE5.Vv0.35
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE5.Vv0.35:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE5.Vv0.35, 2

	.type	.L__const.TEST_CASE5.Vv6.36,@object # @__const.TEST_CASE5.Vv6.36
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE5.Vv6.36:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv6.36, 32

	.type	.L__const.TEST_CASE5.Vv2.37,@object # @__const.TEST_CASE5.Vv2.37
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv2.37:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv2.37, 64

	.type	.L__const.TEST_CASE5.Vv4.38,@object # @__const.TEST_CASE5.Vv4.38
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv4.38:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv4.38, 64

	.type	.L__const.TEST_CASE5.vact.39,@object # @__const.TEST_CASE5.vact.39
	.p2align	2, 0x0
.L__const.TEST_CASE5.vact.39:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.vact.39, 64

	.type	.L__const.TEST_CASE5.Vv0.40,@object # @__const.TEST_CASE5.Vv0.40
.L__const.TEST_CASE5.Vv0.40:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE5.Vv0.40, 2

	.type	.L__const.TEST_CASE5.Vv6.41,@object # @__const.TEST_CASE5.Vv6.41
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv6.41:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv6.41, 64

	.type	.L__const.TEST_CASE5.Vv2.42,@object # @__const.TEST_CASE5.Vv2.42
	.p2align	3, 0x0
.L__const.TEST_CASE5.Vv2.42:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv2.42, 128

	.type	.L__const.TEST_CASE5.Vv4.43,@object # @__const.TEST_CASE5.Vv4.43
	.p2align	3, 0x0
.L__const.TEST_CASE5.Vv4.43:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv4.43, 128

	.type	.L__const.TEST_CASE5.vact.44,@object # @__const.TEST_CASE5.vact.44
	.p2align	3, 0x0
.L__const.TEST_CASE5.vact.44:
	.quad	3                               # 0x3
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE5.vact.44, 128

	.type	.L__const.TEST_CASE6.Vv6,@object # @__const.TEST_CASE6.Vv6
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE6.Vv6:
	.ascii	"\001\002\003\004\005\006\007\b\377\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE6.Vv6, 16

	.type	.L__const.TEST_CASE6.Vv2,@object # @__const.TEST_CASE6.Vv2
	.section	.rodata,"a",@progbits
	.p2align	1, 0x0
.L__const.TEST_CASE6.Vv2:
	.half	255                             # 0xff
	.size	.L__const.TEST_CASE6.Vv2, 2

	.type	.L__const.TEST_CASE6.vact,@object # @__const.TEST_CASE6.vact
	.p2align	1, 0x0
.L__const.TEST_CASE6.vact:
	.half	581                             # 0x245
	.size	.L__const.TEST_CASE6.vact, 2

	.type	.L.str.45,@object               # @.str.45
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.45:
	.asciz	"TEST_CASE1"
	.size	.L.str.45, 11

	.type	.L.str.46,@object               # @.str.46
.L.str.46:
	.asciz	"TEST_CASE2"
	.size	.L.str.46, 11

	.type	.L.str.47,@object               # @.str.47
.L.str.47:
	.asciz	"TEST_CASE3"
	.size	.L.str.47, 11

	.type	.L.str.48,@object               # @.str.48
.L.str.48:
	.asciz	"TEST_CASE4"
	.size	.L.str.48, 11

	.type	.L.str.49,@object               # @.str.49
.L.str.49:
	.asciz	"TEST_CASE5"
	.size	.L.str.49, 11

	.type	.L.str.50,@object               # @.str.50
.L.str.50:
	.asciz	"TEST_CASE6"
	.size	.L.str.50, 11

	.type	.L.str.51,@object               # @.str.51
.L.str.51:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.51, 28

	.type	.L.str.52,@object               # @.str.52
.L.str.52:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c"
	.size	.L.str.52, 146

	.type	.L.str.53,@object               # @.str.53
.L.str.53:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.53, 13

	.type	.L_MergedGlobals,@object        # @_MergedGlobals
	.local	.L_MergedGlobals
	.comm	.L_MergedGlobals,8,4
	.globl	num_failed
.set num_failed, .L_MergedGlobals
	.size	num_failed, 4
	.globl	test_case
.set test_case, .L_MergedGlobals+4
	.size	test_case, 4
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.ascii	"\210\001"                      # DW_AT_alignment
	.byte	15                              # DW_FORM_udata
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	0                               # DW_CHILDREN_no
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x9d6 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	16                              # DW_AT_low_pc
	.word	.Lfunc_end6-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x6d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	145                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x77:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x83:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	146                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	2                               # Abbrev [2] 0x8d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	147                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	2                               # Abbrev [2] 0x97:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	148                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	2                               # Abbrev [2] 0xa1:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	149                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	2                               # Abbrev [2] 0xab:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	150                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	2                               # Abbrev [2] 0xb5:0xa DW_TAG_variable
	.word	191                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	152                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	3                               # Abbrev [3] 0xbf:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xc4:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xcb:0xa DW_TAG_variable
	.word	213                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	152                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	10
	.byte	3                               # Abbrev [3] 0xd5:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xda:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	146                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xe1:0xa DW_TAG_variable
	.word	235                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	152                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	3                               # Abbrev [3] 0xeb:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xf0:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xf7:0xd DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	260                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	12
	.byte	3                               # Abbrev [3] 0x104:0xd DW_TAG_array_type
	.word	273                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x109:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x111:0x5 DW_TAG_volatile_type
	.word	278                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x116:0x8 DW_TAG_typedef
	.word	286                             # DW_AT_type
	.byte	7                               # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x11e:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x122:0xd DW_TAG_variable
	.byte	8                               # DW_AT_name
	.word	303                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	26                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	13
	.byte	3                               # Abbrev [3] 0x12f:0xd DW_TAG_array_type
	.word	316                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x134:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x13c:0x5 DW_TAG_volatile_type
	.word	321                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x141:0x8 DW_TAG_typedef
	.word	329                             # DW_AT_type
	.byte	10                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x149:0x4 DW_TAG_base_type
	.byte	9                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x14d:0xd DW_TAG_variable
	.byte	11                              # DW_AT_name
	.word	346                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	14
	.byte	3                               # Abbrev [3] 0x15a:0xd DW_TAG_array_type
	.word	359                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x15f:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x167:0x5 DW_TAG_volatile_type
	.word	364                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x16c:0x8 DW_TAG_typedef
	.word	372                             # DW_AT_type
	.byte	13                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	247                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x174:0x4 DW_TAG_base_type
	.byte	12                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	2                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0x178:0xb DW_TAG_variable
	.byte	14                              # DW_AT_name
	.word	387                             # DW_AT_type
                                        # DW_AT_external
	.byte	4                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	15
	.byte	5                               # Abbrev [5] 0x183:0x4 DW_TAG_base_type
	.byte	15                              # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0x187:0xd DW_TAG_variable
	.byte	16                              # DW_AT_name
	.word	387                             # DW_AT_type
                                        # DW_AT_external
	.byte	4                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	15
	.byte	35
	.byte	4
	.byte	12                              # Abbrev [12] 0x194:0x5 DW_TAG_pointer_type
	.word	364                             # DW_AT_type
	.byte	12                              # Abbrev [12] 0x199:0x5 DW_TAG_pointer_type
	.word	321                             # DW_AT_type
	.byte	12                              # Abbrev [12] 0x19e:0x5 DW_TAG_pointer_type
	.word	278                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x1a3:0x124 DW_TAG_subprogram
	.byte	16                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x1ae:0x12 DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1b4:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.word	2343                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1c0:0x12 DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1c6:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	98
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.word	2373                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1d2:0x36 DW_TAG_lexical_block
	.byte	19                              # DW_AT_low_pc
	.word	.Ltmp19-.Ltmp7                  # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1d8:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	90
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	2385                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x1e3:0x12 DW_TAG_lexical_block
	.byte	20                              # DW_AT_low_pc
	.word	.Ltmp9-.Ltmp8                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1e9:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	404                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1f5:0x12 DW_TAG_lexical_block
	.byte	21                              # DW_AT_low_pc
	.word	.Ltmp18-.Ltmp10                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1fb:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x208:0x13 DW_TAG_lexical_block
	.byte	22                              # DW_AT_low_pc
	.word	.Ltmp23-.Ltmp22                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x20e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	18                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x21b:0x13 DW_TAG_lexical_block
	.byte	23                              # DW_AT_low_pc
	.word	.Ltmp25-.Ltmp24                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x221:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260\177"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	19                              # DW_AT_decl_line
	.word	2409                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x22e:0x39 DW_TAG_lexical_block
	.byte	24                              # DW_AT_low_pc
	.word	.Ltmp38-.Ltmp26                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x234:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	2421                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x240:0x13 DW_TAG_lexical_block
	.byte	25                              # DW_AT_low_pc
	.word	.Ltmp28-.Ltmp27                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x246:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	409                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x253:0x13 DW_TAG_lexical_block
	.byte	26                              # DW_AT_low_pc
	.word	.Ltmp37-.Ltmp29                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x259:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x267:0x13 DW_TAG_lexical_block
	.byte	27                              # DW_AT_low_pc
	.word	.Ltmp42-.Ltmp41                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x26d:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\344~"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	24                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x27a:0x13 DW_TAG_lexical_block
	.byte	28                              # DW_AT_low_pc
	.word	.Ltmp44-.Ltmp43                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x280:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	2445                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x28d:0x39 DW_TAG_lexical_block
	.byte	29                              # DW_AT_low_pc
	.word	.Ltmp57-.Ltmp45                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x293:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	2457                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x29f:0x13 DW_TAG_lexical_block
	.byte	30                              # DW_AT_low_pc
	.word	.Ltmp47-.Ltmp46                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x2a5:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324~"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	414                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x2b2:0x13 DW_TAG_lexical_block
	.byte	31                              # DW_AT_low_pc
	.word	.Ltmp56-.Ltmp48                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x2b8:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x2c7:0x193 DW_TAG_subprogram
	.byte	32                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	31                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x2d2:0x12 DW_TAG_lexical_block
	.byte	33                              # DW_AT_low_pc
	.word	.Ltmp63-.Ltmp62                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x2d8:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	114
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	33                              # DW_AT_decl_line
	.word	2469                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x2e4:0x12 DW_TAG_lexical_block
	.byte	34                              # DW_AT_low_pc
	.word	.Ltmp65-.Ltmp64                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x2ea:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	34                              # DW_AT_decl_line
	.word	2343                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x2f6:0x12 DW_TAG_lexical_block
	.byte	35                              # DW_AT_low_pc
	.word	.Ltmp67-.Ltmp66                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x2fc:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	94
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	35                              # DW_AT_decl_line
	.word	2373                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x308:0x12 DW_TAG_lexical_block
	.byte	36                              # DW_AT_low_pc
	.word	.Ltmp69-.Ltmp68                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x30e:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.word	2373                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x31a:0x36 DW_TAG_lexical_block
	.byte	37                              # DW_AT_low_pc
	.word	.Ltmp82-.Ltmp70                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x320:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	86
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.word	2385                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x32b:0x12 DW_TAG_lexical_block
	.byte	38                              # DW_AT_low_pc
	.word	.Ltmp72-.Ltmp71                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x331:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.word	404                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x33d:0x12 DW_TAG_lexical_block
	.byte	39                              # DW_AT_low_pc
	.word	.Ltmp81-.Ltmp73                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x343:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x350:0x12 DW_TAG_lexical_block
	.byte	40                              # DW_AT_low_pc
	.word	.Ltmp86-.Ltmp85                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x356:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	78
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	41                              # DW_AT_decl_line
	.word	2469                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x362:0x13 DW_TAG_lexical_block
	.byte	41                              # DW_AT_low_pc
	.word	.Ltmp88-.Ltmp87                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x368:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	42                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x375:0x13 DW_TAG_lexical_block
	.byte	42                              # DW_AT_low_pc
	.word	.Ltmp90-.Ltmp89                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x37b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	43                              # DW_AT_decl_line
	.word	2409                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x388:0x13 DW_TAG_lexical_block
	.byte	43                              # DW_AT_low_pc
	.word	.Ltmp92-.Ltmp91                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x38e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	44                              # DW_AT_decl_line
	.word	2409                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x39b:0x39 DW_TAG_lexical_block
	.byte	44                              # DW_AT_low_pc
	.word	.Ltmp105-.Ltmp93                # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x3a1:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
	.word	2421                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x3ad:0x13 DW_TAG_lexical_block
	.byte	45                              # DW_AT_low_pc
	.word	.Ltmp95-.Ltmp94                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x3b3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240\177"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
	.word	409                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x3c0:0x13 DW_TAG_lexical_block
	.byte	46                              # DW_AT_low_pc
	.word	.Ltmp104-.Ltmp96                # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x3c6:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x3d4:0x13 DW_TAG_lexical_block
	.byte	47                              # DW_AT_low_pc
	.word	.Ltmp109-.Ltmp108               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x3da:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\226\177"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	49                              # DW_AT_decl_line
	.word	2469                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x3e7:0x13 DW_TAG_lexical_block
	.byte	48                              # DW_AT_low_pc
	.word	.Ltmp111-.Ltmp110               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x3ed:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324~"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x3fa:0x13 DW_TAG_lexical_block
	.byte	49                              # DW_AT_low_pc
	.word	.Ltmp113-.Ltmp112               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x400:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	51                              # DW_AT_decl_line
	.word	2445                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x40d:0x13 DW_TAG_lexical_block
	.byte	50                              # DW_AT_low_pc
	.word	.Ltmp115-.Ltmp114               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x413:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\300~"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	52                              # DW_AT_decl_line
	.word	2445                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x420:0x39 DW_TAG_lexical_block
	.byte	51                              # DW_AT_low_pc
	.word	.Ltmp128-.Ltmp116               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x426:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	54                              # DW_AT_decl_line
	.word	2457                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x432:0x13 DW_TAG_lexical_block
	.byte	52                              # DW_AT_low_pc
	.word	.Ltmp118-.Ltmp117               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x438:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274~"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	54                              # DW_AT_decl_line
	.word	414                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x445:0x13 DW_TAG_lexical_block
	.byte	53                              # DW_AT_low_pc
	.word	.Ltmp127-.Ltmp119               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x44b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	54                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x45a:0x160 DW_TAG_subprogram
	.byte	54                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin2       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	19                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	58                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x465:0x12 DW_TAG_lexical_block
	.byte	55                              # DW_AT_low_pc
	.word	.Ltmp134-.Ltmp133               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x46b:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	60                              # DW_AT_decl_line
	.word	2343                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x477:0x12 DW_TAG_lexical_block
	.byte	56                              # DW_AT_low_pc
	.word	.Ltmp136-.Ltmp135               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x47d:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	61                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x489:0x13 DW_TAG_lexical_block
	.byte	57                              # DW_AT_low_pc
	.word	.Ltmp138-.Ltmp137               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x48f:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	62                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x49c:0x39 DW_TAG_lexical_block
	.byte	58                              # DW_AT_low_pc
	.word	.Ltmp151-.Ltmp139               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x4a2:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\200\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	2481                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x4ae:0x13 DW_TAG_lexical_block
	.byte	59                              # DW_AT_low_pc
	.word	.Ltmp141-.Ltmp140               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x4b4:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240\177"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	404                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x4c1:0x13 DW_TAG_lexical_block
	.byte	60                              # DW_AT_low_pc
	.word	.Ltmp150-.Ltmp142               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x4c7:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\374~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x4d5:0x13 DW_TAG_lexical_block
	.byte	61                              # DW_AT_low_pc
	.word	.Ltmp155-.Ltmp154               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x4db:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\334~"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	67                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x4e8:0x13 DW_TAG_lexical_block
	.byte	62                              # DW_AT_low_pc
	.word	.Ltmp157-.Ltmp156               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x4ee:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	68                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x4fb:0x13 DW_TAG_lexical_block
	.byte	63                              # DW_AT_low_pc
	.word	.Ltmp159-.Ltmp158               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x501:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\334}"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	69                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x50e:0x39 DW_TAG_lexical_block
	.byte	64                              # DW_AT_low_pc
	.word	.Ltmp172-.Ltmp160               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x514:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230}"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	71                              # DW_AT_decl_line
	.word	2493                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x520:0x13 DW_TAG_lexical_block
	.byte	65                              # DW_AT_low_pc
	.word	.Ltmp162-.Ltmp161               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x526:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330}"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	71                              # DW_AT_decl_line
	.word	409                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x533:0x13 DW_TAG_lexical_block
	.byte	66                              # DW_AT_low_pc
	.word	.Ltmp171-.Ltmp163               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x539:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224}"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	71                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x547:0x13 DW_TAG_lexical_block
	.byte	67                              # DW_AT_low_pc
	.word	.Ltmp176-.Ltmp175               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x54d:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324|"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	74                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x55a:0x13 DW_TAG_lexical_block
	.byte	68                              # DW_AT_low_pc
	.word	.Ltmp178-.Ltmp177               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x560:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320{"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	75                              # DW_AT_decl_line
	.word	2505                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x56d:0x13 DW_TAG_lexical_block
	.byte	69                              # DW_AT_low_pc
	.word	.Ltmp180-.Ltmp179               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x573:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320z"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	76                              # DW_AT_decl_line
	.word	2505                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x580:0x39 DW_TAG_lexical_block
	.byte	70                              # DW_AT_low_pc
	.word	.Ltmp193-.Ltmp181               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x586:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310y"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.word	2517                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x592:0x13 DW_TAG_lexical_block
	.byte	71                              # DW_AT_low_pc
	.word	.Ltmp183-.Ltmp182               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x598:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\314z"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.word	414                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x5a5:0x13 DW_TAG_lexical_block
	.byte	72                              # DW_AT_low_pc
	.word	.Ltmp192-.Ltmp184               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x5ab:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304y"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x5ba:0x160 DW_TAG_subprogram
	.byte	73                              # DW_AT_low_pc
	.word	.Lfunc_end3-.Lfunc_begin3       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	20                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	82                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x5c5:0x12 DW_TAG_lexical_block
	.byte	74                              # DW_AT_low_pc
	.word	.Ltmp199-.Ltmp198               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x5cb:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	84                              # DW_AT_decl_line
	.word	2343                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x5d7:0x12 DW_TAG_lexical_block
	.byte	75                              # DW_AT_low_pc
	.word	.Ltmp201-.Ltmp200               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x5dd:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	85                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x5e9:0x13 DW_TAG_lexical_block
	.byte	76                              # DW_AT_low_pc
	.word	.Ltmp203-.Ltmp202               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x5ef:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	86                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x5fc:0x39 DW_TAG_lexical_block
	.byte	77                              # DW_AT_low_pc
	.word	.Ltmp216-.Ltmp204               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x602:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\200\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	88                              # DW_AT_decl_line
	.word	2481                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x60e:0x13 DW_TAG_lexical_block
	.byte	78                              # DW_AT_low_pc
	.word	.Ltmp206-.Ltmp205               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x614:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240\177"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	88                              # DW_AT_decl_line
	.word	404                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x621:0x13 DW_TAG_lexical_block
	.byte	79                              # DW_AT_low_pc
	.word	.Ltmp215-.Ltmp207               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x627:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\374~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	88                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x635:0x13 DW_TAG_lexical_block
	.byte	80                              # DW_AT_low_pc
	.word	.Ltmp220-.Ltmp219               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x63b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\334~"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	91                              # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x648:0x13 DW_TAG_lexical_block
	.byte	81                              # DW_AT_low_pc
	.word	.Ltmp222-.Ltmp221               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x64e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	92                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x65b:0x13 DW_TAG_lexical_block
	.byte	82                              # DW_AT_low_pc
	.word	.Ltmp224-.Ltmp223               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x661:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\334}"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	93                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x66e:0x39 DW_TAG_lexical_block
	.byte	83                              # DW_AT_low_pc
	.word	.Ltmp237-.Ltmp225               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x674:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230}"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	95                              # DW_AT_decl_line
	.word	2493                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x680:0x13 DW_TAG_lexical_block
	.byte	84                              # DW_AT_low_pc
	.word	.Ltmp227-.Ltmp226               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x686:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330}"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	95                              # DW_AT_decl_line
	.word	409                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x693:0x13 DW_TAG_lexical_block
	.byte	85                              # DW_AT_low_pc
	.word	.Ltmp236-.Ltmp228               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x699:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224}"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	95                              # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x6a7:0x13 DW_TAG_lexical_block
	.byte	86                              # DW_AT_low_pc
	.word	.Ltmp241-.Ltmp240               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x6ad:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324|"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	98                              # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x6ba:0x13 DW_TAG_lexical_block
	.byte	87                              # DW_AT_low_pc
	.word	.Ltmp243-.Ltmp242               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x6c0:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320{"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	99                              # DW_AT_decl_line
	.word	2505                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x6cd:0x13 DW_TAG_lexical_block
	.byte	88                              # DW_AT_low_pc
	.word	.Ltmp245-.Ltmp244               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x6d3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320z"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	100                             # DW_AT_decl_line
	.word	2505                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x6e0:0x39 DW_TAG_lexical_block
	.byte	89                              # DW_AT_low_pc
	.word	.Ltmp258-.Ltmp246               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x6e6:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310y"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.word	2517                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x6f2:0x13 DW_TAG_lexical_block
	.byte	90                              # DW_AT_low_pc
	.word	.Ltmp248-.Ltmp247               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x6f8:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\314z"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.word	414                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x705:0x13 DW_TAG_lexical_block
	.byte	91                              # DW_AT_low_pc
	.word	.Ltmp257-.Ltmp249               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x70b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304y"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x71a:0x198 DW_TAG_subprogram
	.byte	92                              # DW_AT_low_pc
	.word	.Lfunc_end4-.Lfunc_begin4       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	21                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	106                             # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x725:0x12 DW_TAG_lexical_block
	.byte	93                              # DW_AT_low_pc
	.word	.Ltmp264-.Ltmp263               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x72b:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	114
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	108                             # DW_AT_decl_line
	.word	2469                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x737:0x12 DW_TAG_lexical_block
	.byte	94                              # DW_AT_low_pc
	.word	.Ltmp266-.Ltmp265               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x73d:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	109                             # DW_AT_decl_line
	.word	2343                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x749:0x12 DW_TAG_lexical_block
	.byte	95                              # DW_AT_low_pc
	.word	.Ltmp268-.Ltmp267               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x74f:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	110                             # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x75b:0x13 DW_TAG_lexical_block
	.byte	96                              # DW_AT_low_pc
	.word	.Ltmp270-.Ltmp269               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x761:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240\177"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	111                             # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x76e:0x39 DW_TAG_lexical_block
	.byte	97                              # DW_AT_low_pc
	.word	.Ltmp283-.Ltmp271               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x774:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\374~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	113                             # DW_AT_decl_line
	.word	2481                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x780:0x13 DW_TAG_lexical_block
	.byte	98                              # DW_AT_low_pc
	.word	.Ltmp273-.Ltmp272               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x786:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234\177"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	113                             # DW_AT_decl_line
	.word	404                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x793:0x13 DW_TAG_lexical_block
	.byte	99                              # DW_AT_low_pc
	.word	.Ltmp282-.Ltmp274               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x799:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\370~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	113                             # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x7a7:0x13 DW_TAG_lexical_block
	.byte	100                             # DW_AT_low_pc
	.word	.Ltmp287-.Ltmp286               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x7ad:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\366~"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	116                             # DW_AT_decl_line
	.word	2469                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x7ba:0x13 DW_TAG_lexical_block
	.byte	101                             # DW_AT_low_pc
	.word	.Ltmp289-.Ltmp288               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x7c0:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324~"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	117                             # DW_AT_decl_line
	.word	2397                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x7cd:0x13 DW_TAG_lexical_block
	.byte	102                             # DW_AT_low_pc
	.word	.Ltmp291-.Ltmp290               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x7d3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	118                             # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x7e0:0x13 DW_TAG_lexical_block
	.byte	103                             # DW_AT_low_pc
	.word	.Ltmp293-.Ltmp292               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x7e6:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324}"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	119                             # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x7f3:0x39 DW_TAG_lexical_block
	.byte	104                             # DW_AT_low_pc
	.word	.Ltmp306-.Ltmp294               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x7f9:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\220}"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	2493                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x805:0x13 DW_TAG_lexical_block
	.byte	105                             # DW_AT_low_pc
	.word	.Ltmp296-.Ltmp295               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x80b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320}"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	409                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x818:0x13 DW_TAG_lexical_block
	.byte	106                             # DW_AT_low_pc
	.word	.Ltmp305-.Ltmp297               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x81e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\214}"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x82c:0x13 DW_TAG_lexical_block
	.byte	107                             # DW_AT_low_pc
	.word	.Ltmp310-.Ltmp309               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x832:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\212}"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	124                             # DW_AT_decl_line
	.word	2469                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x83f:0x13 DW_TAG_lexical_block
	.byte	108                             # DW_AT_low_pc
	.word	.Ltmp312-.Ltmp311               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x845:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310|"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	125                             # DW_AT_decl_line
	.word	2433                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x852:0x13 DW_TAG_lexical_block
	.byte	109                             # DW_AT_low_pc
	.word	.Ltmp314-.Ltmp313               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x858:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310{"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	126                             # DW_AT_decl_line
	.word	2505                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x865:0x13 DW_TAG_lexical_block
	.byte	110                             # DW_AT_low_pc
	.word	.Ltmp316-.Ltmp315               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x86b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310z"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	127                             # DW_AT_decl_line
	.word	2505                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x878:0x39 DW_TAG_lexical_block
	.byte	111                             # DW_AT_low_pc
	.word	.Ltmp329-.Ltmp317               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x87e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\300y"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	129                             # DW_AT_decl_line
	.word	2517                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x88a:0x13 DW_TAG_lexical_block
	.byte	112                             # DW_AT_low_pc
	.word	.Ltmp319-.Ltmp318               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x890:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304z"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	129                             # DW_AT_decl_line
	.word	414                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x89d:0x13 DW_TAG_lexical_block
	.byte	113                             # DW_AT_low_pc
	.word	.Ltmp328-.Ltmp320               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x8a3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274y"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	129                             # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x8b2:0x66 DW_TAG_subprogram
	.byte	114                             # DW_AT_low_pc
	.word	.Lfunc_end5-.Lfunc_begin5       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	22                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	133                             # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x8bd:0x12 DW_TAG_lexical_block
	.byte	115                             # DW_AT_low_pc
	.word	.Ltmp335-.Ltmp334               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x8c3:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	135                             # DW_AT_decl_line
	.word	2343                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x8cf:0x12 DW_TAG_lexical_block
	.byte	116                             # DW_AT_low_pc
	.word	.Ltmp337-.Ltmp336               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x8d5:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	102
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	136                             # DW_AT_decl_line
	.word	2373                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x8e1:0x36 DW_TAG_lexical_block
	.byte	117                             # DW_AT_low_pc
	.word	.Ltmp350-.Ltmp338               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x8e7:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	94
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	138                             # DW_AT_decl_line
	.word	2385                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x8f2:0x12 DW_TAG_lexical_block
	.byte	118                             # DW_AT_low_pc
	.word	.Ltmp340-.Ltmp339               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x8f8:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	138                             # DW_AT_decl_line
	.word	404                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x904:0x12 DW_TAG_lexical_block
	.byte	119                             # DW_AT_low_pc
	.word	.Ltmp349-.Ltmp341               # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x90a:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	138                             # DW_AT_decl_line
	.word	329                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x918:0xf DW_TAG_subprogram
	.byte	120                             # DW_AT_low_pc
	.word	.Lfunc_end6-.Lfunc_begin6       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	23                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	141                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	387                             # DW_AT_type
                                        # DW_AT_external
	.byte	3                               # Abbrev [3] 0x927:0xc DW_TAG_array_type
	.word	2355                            # DW_AT_type
	.byte	4                               # Abbrev [4] 0x92c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x933:0x5 DW_TAG_volatile_type
	.word	2360                            # DW_AT_type
	.byte	17                              # Abbrev [17] 0x938:0x9 DW_TAG_typedef
	.word	2369                            # DW_AT_type
	.byte	26                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	270                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x941:0x4 DW_TAG_base_type
	.byte	25                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x945:0xc DW_TAG_array_type
	.word	359                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x94a:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x951:0xc DW_TAG_array_type
	.word	364                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x956:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x95d:0xc DW_TAG_array_type
	.word	359                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x962:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x969:0xc DW_TAG_array_type
	.word	316                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x96e:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x975:0xc DW_TAG_array_type
	.word	321                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x97a:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x981:0xc DW_TAG_array_type
	.word	316                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x986:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x98d:0xc DW_TAG_array_type
	.word	273                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x992:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x999:0xc DW_TAG_array_type
	.word	278                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x99e:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x9a5:0xc DW_TAG_array_type
	.word	2355                            # DW_AT_type
	.byte	4                               # Abbrev [4] 0x9aa:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	2                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x9b1:0xc DW_TAG_array_type
	.word	364                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x9b6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x9bd:0xc DW_TAG_array_type
	.word	321                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x9c2:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x9c9:0xc DW_TAG_array_type
	.word	273                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x9ce:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x9d5:0xc DW_TAG_array_type
	.word	278                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x9da:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	144                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vwredsumu.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=232
.Linfo_string3:
	.asciz	"char"                          # string offset=284
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=289
.Linfo_string5:
	.asciz	"Ru64"                          # string offset=309
.Linfo_string6:
	.asciz	"unsigned long long"            # string offset=314
.Linfo_string7:
	.asciz	"uint64_t"                      # string offset=333
.Linfo_string8:
	.asciz	"Ru32"                          # string offset=342
.Linfo_string9:
	.asciz	"unsigned int"                  # string offset=347
.Linfo_string10:
	.asciz	"uint32_t"                      # string offset=360
.Linfo_string11:
	.asciz	"Ru16"                          # string offset=369
.Linfo_string12:
	.asciz	"unsigned short"                # string offset=374
.Linfo_string13:
	.asciz	"uint16_t"                      # string offset=389
.Linfo_string14:
	.asciz	"num_failed"                    # string offset=398
.Linfo_string15:
	.asciz	"int"                           # string offset=409
.Linfo_string16:
	.asciz	"test_case"                     # string offset=413
.Linfo_string17:
	.asciz	"TEST_CASE1"                    # string offset=423
.Linfo_string18:
	.asciz	"TEST_CASE2"                    # string offset=434
.Linfo_string19:
	.asciz	"TEST_CASE3"                    # string offset=445
.Linfo_string20:
	.asciz	"TEST_CASE4"                    # string offset=456
.Linfo_string21:
	.asciz	"TEST_CASE5"                    # string offset=467
.Linfo_string22:
	.asciz	"TEST_CASE6"                    # string offset=478
.Linfo_string23:
	.asciz	"main"                          # string offset=489
.Linfo_string24:
	.asciz	"Vv6"                           # string offset=494
.Linfo_string25:
	.asciz	"unsigned char"                 # string offset=498
.Linfo_string26:
	.asciz	"uint8_t"                       # string offset=512
.Linfo_string27:
	.asciz	"Vv2"                           # string offset=520
.Linfo_string28:
	.asciz	"Ru16_t"                        # string offset=524
.Linfo_string29:
	.asciz	"vact"                          # string offset=531
.Linfo_string30:
	.asciz	"i"                             # string offset=536
.Linfo_string31:
	.asciz	"Ru32_t"                        # string offset=538
.Linfo_string32:
	.asciz	"Ru64_t"                        # string offset=545
.Linfo_string33:
	.asciz	"Vv0"                           # string offset=552
.Linfo_string34:
	.asciz	"Vv4"                           # string offset=556
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.word	.Linfo_string25
	.word	.Linfo_string26
	.word	.Linfo_string27
	.word	.Linfo_string28
	.word	.Linfo_string29
	.word	.Linfo_string30
	.word	.Linfo_string31
	.word	.Linfo_string32
	.word	.Linfo_string33
	.word	.Linfo_string34
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.45
	.word	.L.str.46
	.word	.L.str.47
	.word	.L.str.48
	.word	.L.str.49
	.word	.L.str.50
	.word	.L.str.51
	.word	.L.str.52
	.word	.L.str.53
	.word	Ru64
	.word	Ru32
	.word	Ru16
	.word	.L_MergedGlobals
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Ltmp8
	.word	.Ltmp10
	.word	.Ltmp22
	.word	.Ltmp24
	.word	.Ltmp26
	.word	.Ltmp27
	.word	.Ltmp29
	.word	.Ltmp41
	.word	.Ltmp43
	.word	.Ltmp45
	.word	.Ltmp46
	.word	.Ltmp48
	.word	.Lfunc_begin1
	.word	.Ltmp62
	.word	.Ltmp64
	.word	.Ltmp66
	.word	.Ltmp68
	.word	.Ltmp70
	.word	.Ltmp71
	.word	.Ltmp73
	.word	.Ltmp85
	.word	.Ltmp87
	.word	.Ltmp89
	.word	.Ltmp91
	.word	.Ltmp93
	.word	.Ltmp94
	.word	.Ltmp96
	.word	.Ltmp108
	.word	.Ltmp110
	.word	.Ltmp112
	.word	.Ltmp114
	.word	.Ltmp116
	.word	.Ltmp117
	.word	.Ltmp119
	.word	.Lfunc_begin2
	.word	.Ltmp133
	.word	.Ltmp135
	.word	.Ltmp137
	.word	.Ltmp139
	.word	.Ltmp140
	.word	.Ltmp142
	.word	.Ltmp154
	.word	.Ltmp156
	.word	.Ltmp158
	.word	.Ltmp160
	.word	.Ltmp161
	.word	.Ltmp163
	.word	.Ltmp175
	.word	.Ltmp177
	.word	.Ltmp179
	.word	.Ltmp181
	.word	.Ltmp182
	.word	.Ltmp184
	.word	.Lfunc_begin3
	.word	.Ltmp198
	.word	.Ltmp200
	.word	.Ltmp202
	.word	.Ltmp204
	.word	.Ltmp205
	.word	.Ltmp207
	.word	.Ltmp219
	.word	.Ltmp221
	.word	.Ltmp223
	.word	.Ltmp225
	.word	.Ltmp226
	.word	.Ltmp228
	.word	.Ltmp240
	.word	.Ltmp242
	.word	.Ltmp244
	.word	.Ltmp246
	.word	.Ltmp247
	.word	.Ltmp249
	.word	.Lfunc_begin4
	.word	.Ltmp263
	.word	.Ltmp265
	.word	.Ltmp267
	.word	.Ltmp269
	.word	.Ltmp271
	.word	.Ltmp272
	.word	.Ltmp274
	.word	.Ltmp286
	.word	.Ltmp288
	.word	.Ltmp290
	.word	.Ltmp292
	.word	.Ltmp294
	.word	.Ltmp295
	.word	.Ltmp297
	.word	.Ltmp309
	.word	.Ltmp311
	.word	.Ltmp313
	.word	.Ltmp315
	.word	.Ltmp317
	.word	.Ltmp318
	.word	.Ltmp320
	.word	.Lfunc_begin5
	.word	.Ltmp334
	.word	.Ltmp336
	.word	.Ltmp338
	.word	.Ltmp339
	.word	.Ltmp341
	.word	.Lfunc_begin6
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
