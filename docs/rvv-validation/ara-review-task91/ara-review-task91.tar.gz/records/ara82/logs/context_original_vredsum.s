	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"context_original_vredsum.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c" md5 0x055e45e51a839450b0be373398810851
	.file	1 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c" md5 0x055e45e51a839450b0be373398810851
	.file	2 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	3 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/upstream/dataset.h" md5 0x6e87c523f491ba527fcaa8da037d753f
	.file	4 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/vector_macros.h" md5 0xf0792279c410650ddf6b368633799e9a
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE1                      # -- Begin function TEST_CASE1
	.p2align	2
	.type	TEST_CASE1,@function
TEST_CASE1:                             # @TEST_CASE1
.Lfunc_begin0:
	.loc	1 10 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:10:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -336
	.cfi_def_cfa_offset 336
	sw	ra, 332(sp)                     # 4-byte Folded Spill
	sw	s0, 328(sp)                     # 4-byte Folded Spill
	sw	s1, 324(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 336
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 11 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:11:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp1:
	.loc	1 11 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:11:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 11
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 12 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:12:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 12 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:12:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv1)
	addi	a1, a0, %lo(.L__const.TEST_CASE1.Vv1)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -16(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a0, %lo(.L__const.TEST_CASE1.Vv1)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -28(s0)
	addi	a0, s0, -28
	#APP
	vle8.v v1, (a0)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 13 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:13:3
	j	.LBB0_5
.LBB0_5:
.Ltmp5:
	.loc	1 13 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:13:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2)
	lbu	a0, %lo(.L__const.TEST_CASE1.Vv2)(a0)
	sb	a0, -29(s0)
	addi	a0, s0, -29
	#APP
	vle8.v v2, (a0)  

	#NO_APP
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 14 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:14:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp7:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	j	.LBB0_7
.LBB0_7:
.Ltmp8:
	.loc	1 15 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	addi	a0, a0, 128
	sw	a0, -36(s0)
	lw	a0, -36(s0)
	#APP
	vse8.v v3, (a0)

	#NO_APP
	sw	a0, -36(s0)
	j	.LBB0_8
.Ltmp9:
.LBB0_8:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 73
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	sb	a0, -37(s0)
	li	a0, 1
	li	a1, 1
	li	a2, 1
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 1
	call	printf_
.Ltmp10:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	sw	zero, -44(s0)
	j	.LBB0_9
.LBB0_9:                                # =>This Inner Loop Header: Depth=1
.Ltmp11:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lw	a0, -44(s0)
.Ltmp12:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	bnez	a0, .LBB0_14
	j	.LBB0_10
.LBB0_10:                               #   in Loop: Header=BB0_9 Depth=1
.Ltmp13:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lw	a1, -44(s0)
	li	a0, 1
	call	ara_compare_step
.Ltmp14:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lw	a0, -44(s0)
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	add	a0, a1, a0
	lbu	a0, 128(a0)
	lw	a1, -44(s0)
	addi	a2, s0, -37
	add	a1, a2, a1
	lbu	a1, 0(a1)
	beq	a0, a1, .LBB0_12
	j	.LBB0_11
.LBB0_11:
.Ltmp15:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lw	a1, -44(s0)
	lui	s1, %hi(.L_MergedGlobals)
	addi	a0, s1, %lo(.L_MergedGlobals)
	add	a0, a0, a1
	lbu	a2, 128(a0)
	lw	a0, -44(s0)
	addi	a3, s0, -37
	add	a0, a3, a0
	lbu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	addi	a0, a0, 1
	sw	a0, %lo(.L_MergedGlobals)(s1)
	j	.LBB0_57
.Ltmp16:
.LBB0_12:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	j	.LBB0_13
.Ltmp17:
.LBB0_13:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lw	a0, -44(s0)
	addi	a0, a0, 1
	sw	a0, -44(s0)
	j	.LBB0_9
.Ltmp18:
.LBB0_14:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:15:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 1
	call	ara_assert_end
.Ltmp19:
	.loc	1 17 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:17:3
	j	.LBB0_15
.LBB0_15:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp20:
	.loc	1 17 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:17:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 17
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_16
.Ltmp21:
.LBB0_16:
	.loc	1 18 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:18:3
	j	.LBB0_17
.LBB0_17:
.Ltmp22:
	.loc	1 18 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:18:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv1.3)
	addi	a1, a0, %lo(.L__const.TEST_CASE1.Vv1.3)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -48(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -52(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -60(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -64(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a0, %lo(.L__const.TEST_CASE1.Vv1.3)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -76(s0)
	addi	a0, s0, -76
	#APP
	vle16.v v1, (a0)  

	#NO_APP
	j	.LBB0_18
.Ltmp23:
.LBB0_18:
	.loc	1 19 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:19:3
	j	.LBB0_19
.LBB0_19:
.Ltmp24:
	.loc	1 19 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:19:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2.4)
	lh	a0, %lo(.L__const.TEST_CASE1.Vv2.4)(a0)
	sh	a0, -78(s0)
	addi	a0, s0, -78
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB0_20
.Ltmp25:
.LBB0_20:
	.loc	1 20 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:20:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp26:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	j	.LBB0_21
.LBB0_21:
.Ltmp27:
	.loc	1 21 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -84(s0)
	lw	a0, -84(s0)
	#APP
	vse16.v v3, (a0)

	#NO_APP
	sw	a0, -84(s0)
	j	.LBB0_22
.Ltmp28:
.LBB0_22:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 73
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	sh	a0, -86(s0)
	li	a0, 2
	li	a1, 1
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 2
	call	printf_
.Ltmp29:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	sw	zero, -92(s0)
	j	.LBB0_23
.LBB0_23:                               # =>This Inner Loop Header: Depth=1
.Ltmp30:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lw	a0, -92(s0)
.Ltmp31:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	bnez	a0, .LBB0_28
	j	.LBB0_24
.LBB0_24:                               #   in Loop: Header=BB0_23 Depth=1
.Ltmp32:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lw	a1, -92(s0)
	li	a0, 2
	call	ara_compare_step
.Ltmp33:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lw	a0, -92(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -92(s0)
	slli	a1, a1, 1
	addi	a2, s0, -86
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB0_26
	j	.LBB0_25
.LBB0_25:
.Ltmp34:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lw	a1, -92(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -92(s0)
	slli	a0, a0, 1
	addi	a3, s0, -86
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_57
.Ltmp35:
.LBB0_26:                               #   in Loop: Header=BB0_23 Depth=1
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	j	.LBB0_27
.Ltmp36:
.LBB0_27:                               #   in Loop: Header=BB0_23 Depth=1
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lw	a0, -92(s0)
	addi	a0, a0, 1
	sw	a0, -92(s0)
	j	.LBB0_23
.Ltmp37:
.LBB0_28:
	.loc	1 21 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:21:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 2
	call	ara_assert_end
.Ltmp38:
	.loc	1 23 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:23:3
	j	.LBB0_29
.LBB0_29:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp39:
	.loc	1 23 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:23:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 23
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_30
.Ltmp40:
.LBB0_30:
	.loc	1 24 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:24:3
	j	.LBB0_31
.LBB0_31:
.Ltmp41:
	.loc	1 24 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:24:3
	lui	a1, %hi(.L__const.TEST_CASE1.Vv1.6)
	addi	a1, a1, %lo(.L__const.TEST_CASE1.Vv1.6)
	addi	s1, s0, -156
	addi	a0, s0, -156
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v1, (s1)  

	#NO_APP
	j	.LBB0_32
.Ltmp42:
.LBB0_32:
	.loc	1 25 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:25:3
	j	.LBB0_33
.LBB0_33:
.Ltmp43:
	.loc	1 25 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:25:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2.7)
	lw	a0, %lo(.L__const.TEST_CASE1.Vv2.7)(a0)
	sw	a0, -160(s0)
	addi	a0, s0, -160
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB0_34
.Ltmp44:
.LBB0_34:
	.loc	1 26 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:26:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp45:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	j	.LBB0_35
.LBB0_35:
.Ltmp46:
	.loc	1 27 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -164(s0)
	lw	a0, -164(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -164(s0)
	j	.LBB0_36
.Ltmp47:
.LBB0_36:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 73
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	sw	a0, -168(s0)
	li	a0, 3
	li	a1, 1
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 3
	call	printf_
.Ltmp48:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	sw	zero, -172(s0)
	j	.LBB0_37
.LBB0_37:                               # =>This Inner Loop Header: Depth=1
.Ltmp49:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lw	a0, -172(s0)
.Ltmp50:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	bnez	a0, .LBB0_42
	j	.LBB0_38
.LBB0_38:                               #   in Loop: Header=BB0_37 Depth=1
.Ltmp51:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lw	a1, -172(s0)
	li	a0, 3
	call	ara_compare_step
.Ltmp52:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lw	a0, -172(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -172(s0)
	slli	a1, a1, 2
	addi	a2, s0, -168
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB0_40
	j	.LBB0_39
.LBB0_39:
.Ltmp53:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lw	a1, -172(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -172(s0)
	slli	a0, a0, 2
	addi	a3, s0, -168
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_57
.Ltmp54:
.LBB0_40:                               #   in Loop: Header=BB0_37 Depth=1
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	j	.LBB0_41
.Ltmp55:
.LBB0_41:                               #   in Loop: Header=BB0_37 Depth=1
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lw	a0, -172(s0)
	addi	a0, a0, 1
	sw	a0, -172(s0)
	j	.LBB0_37
.Ltmp56:
.LBB0_42:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:27:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 3
	call	ara_assert_end
.Ltmp57:
	.loc	1 29 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:29:3
	j	.LBB0_43
.LBB0_43:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp58:
	.loc	1 29 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:29:3
	#APP
	vsetvli t0, a0,e64,m1, ta, ma 

	#NO_APP
	li	a0, 29
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_44
.Ltmp59:
.LBB0_44:
	.loc	1 30 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:30:3
	j	.LBB0_45
.LBB0_45:
.Ltmp60:
	.loc	1 30 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:30:3
	lui	a1, %hi(.L__const.TEST_CASE1.Vv1.9)
	addi	a1, a1, %lo(.L__const.TEST_CASE1.Vv1.9)
	addi	s1, s0, -304
	addi	a0, s0, -304
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v1, (s1)  

	#NO_APP
	j	.LBB0_46
.Ltmp61:
.LBB0_46:
	.loc	1 31 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:31:3
	j	.LBB0_47
.LBB0_47:
.Ltmp62:
	.loc	1 31 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:31:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2.10)
	lw	a1, %lo(.L__const.TEST_CASE1.Vv2.10+4)(a0)
	sw	a1, -308(s0)
	lw	a0, %lo(.L__const.TEST_CASE1.Vv2.10)(a0)
	sw	a0, -312(s0)
	addi	a0, s0, -312
	#APP
	vle64.v v2, (a0)  

	#NO_APP
	j	.LBB0_48
.Ltmp63:
.LBB0_48:
	.loc	1 32 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:32:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp64:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	j	.LBB0_49
.LBB0_49:
.Ltmp65:
	.loc	1 33 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -316(s0)
	lw	a0, -316(s0)
	#APP
	vse64.v v3, (a0)

	#NO_APP
	sw	a0, -316(s0)
	j	.LBB0_50
.Ltmp66:
.LBB0_50:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	sw	zero, -324(s0)
	li	a0, 73
	sw	a0, -328(s0)
	li	a0, 4
	li	a1, 1
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 4
	call	printf_
.Ltmp67:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	sw	zero, -332(s0)
	j	.LBB0_51
.LBB0_51:                               # =>This Inner Loop Header: Depth=1
.Ltmp68:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lw	a0, -332(s0)
.Ltmp69:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	bnez	a0, .LBB0_56
	j	.LBB0_52
.LBB0_52:                               #   in Loop: Header=BB0_51 Depth=1
.Ltmp70:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lw	a1, -332(s0)
	li	a0, 4
	call	ara_compare_step
.Ltmp71:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lw	a0, -332(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -332(s0)
	slli	a2, a2, 3
	addi	a3, s0, -328
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB0_54
	j	.LBB0_53
.LBB0_53:
.Ltmp72:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lw	a1, -332(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -332(s0)
	slli	a0, a0, 3
	addi	a4, s0, -328
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_57
.Ltmp73:
.LBB0_54:                               #   in Loop: Header=BB0_51 Depth=1
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	j	.LBB0_55
.Ltmp74:
.LBB0_55:                               #   in Loop: Header=BB0_51 Depth=1
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lw	a0, -332(s0)
	addi	a0, a0, 1
	sw	a0, -332(s0)
	j	.LBB0_51
.Ltmp75:
.LBB0_56:
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:33:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 4
	call	ara_assert_end
.Ltmp76:
	.loc	1 34 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:34:1
	j	.LBB0_57
.LBB0_57:
	.cfi_def_cfa sp, 336
	.loc	1 34 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:34:1
	lw	ra, 332(sp)                     # 4-byte Folded Reload
	lw	s0, 328(sp)                     # 4-byte Folded Reload
	lw	s1, 324(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 336
	.cfi_def_cfa_offset 0
	ret
.Ltmp77:
.Lfunc_end0:
	.size	TEST_CASE1, .Lfunc_end0-TEST_CASE1
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE2                      # -- Begin function TEST_CASE2
	.p2align	2
	.type	TEST_CASE2,@function
TEST_CASE2:                             # @TEST_CASE2
.Lfunc_begin1:
	.loc	1 37 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:37:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -368
	.cfi_def_cfa_offset 368
	sw	ra, 364(sp)                     # 4-byte Folded Spill
	sw	s0, 360(sp)                     # 4-byte Folded Spill
	sw	s1, 356(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 368
	.cfi_def_cfa s0, 0
.Ltmp78:
	.loc	1 38 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:38:3
	j	.LBB1_1
.LBB1_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp79:
	.loc	1 38 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:38:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 38
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_2
.Ltmp80:
.LBB1_2:
	.loc	1 39 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:39:3
	j	.LBB1_3
.LBB1_3:
.Ltmp81:
	.loc	1 39 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:39:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -14(s0)
	addi	a0, s0, -14
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_4
.Ltmp82:
.LBB1_4:
	.loc	1 40 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:40:3
	j	.LBB1_5
.LBB1_5:
.Ltmp83:
	.loc	1 40 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:40:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv1)
	addi	a1, a0, %lo(.L__const.TEST_CASE2.Vv1)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -28(s0)
	lbu	a0, %lo(.L__const.TEST_CASE2.Vv1)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -32(s0)
	addi	a0, s0, -32
	#APP
	vle8.v v1, (a0)  

	#NO_APP
	j	.LBB1_6
.Ltmp84:
.LBB1_6:
	.loc	1 41 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:41:3
	j	.LBB1_7
.LBB1_7:
.Ltmp85:
	.loc	1 41 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:41:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2)
	lbu	a0, %lo(.L__const.TEST_CASE2.Vv2)(a0)
	sb	a0, -33(s0)
	addi	a0, s0, -33
	#APP
	vle8.v v2, (a0)  

	#NO_APP
	j	.LBB1_8
.Ltmp86:
.LBB1_8:
	.loc	1 42 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:42:3
	j	.LBB1_9
.LBB1_9:
.Ltmp87:
	.loc	1 42 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:42:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv3)
	lbu	a0, %lo(.L__const.TEST_CASE2.Vv3)(a0)
	sb	a0, -34(s0)
	addi	a0, s0, -34
	#APP
	vle8.v v3, (a0)  

	#NO_APP
	j	.LBB1_10
.Ltmp88:
.LBB1_10:
	.loc	1 43 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:43:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp89:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	j	.LBB1_11
.LBB1_11:
.Ltmp90:
	.loc	1 44 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	addi	a0, a0, 128
	sw	a0, -40(s0)
	lw	a0, -40(s0)
	#APP
	vse8.v v3, (a0)

	#NO_APP
	sw	a0, -40(s0)
	j	.LBB1_12
.Ltmp91:
.LBB1_12:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 37
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	sb	a0, -41(s0)
	li	a0, 5
	li	a1, 1
	li	a2, 1
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 5
	call	printf_
.Ltmp92:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	sw	zero, -48(s0)
	j	.LBB1_13
.LBB1_13:                               # =>This Inner Loop Header: Depth=1
.Ltmp93:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lw	a0, -48(s0)
.Ltmp94:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	bnez	a0, .LBB1_18
	j	.LBB1_14
.LBB1_14:                               #   in Loop: Header=BB1_13 Depth=1
.Ltmp95:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lw	a1, -48(s0)
	li	a0, 5
	call	ara_compare_step
.Ltmp96:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lw	a0, -48(s0)
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	add	a0, a1, a0
	lbu	a0, 128(a0)
	lw	a1, -48(s0)
	addi	a2, s0, -41
	add	a1, a2, a1
	lbu	a1, 0(a1)
	beq	a0, a1, .LBB1_16
	j	.LBB1_15
.LBB1_15:
.Ltmp97:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lw	a1, -48(s0)
	lui	s1, %hi(.L_MergedGlobals)
	addi	a0, s1, %lo(.L_MergedGlobals)
	add	a0, a0, a1
	lbu	a2, 128(a0)
	lw	a0, -48(s0)
	addi	a3, s0, -41
	add	a0, a3, a0
	lbu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	addi	a0, a0, 1
	sw	a0, %lo(.L_MergedGlobals)(s1)
	j	.LBB1_73
.Ltmp98:
.LBB1_16:                               #   in Loop: Header=BB1_13 Depth=1
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	j	.LBB1_17
.Ltmp99:
.LBB1_17:                               #   in Loop: Header=BB1_13 Depth=1
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lw	a0, -48(s0)
	addi	a0, a0, 1
	sw	a0, -48(s0)
	j	.LBB1_13
.Ltmp100:
.LBB1_18:
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:44:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 5
	call	ara_assert_end
.Ltmp101:
	.loc	1 46 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:46:3
	j	.LBB1_19
.LBB1_19:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp102:
	.loc	1 46 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:46:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 46
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_20
.Ltmp103:
.LBB1_20:
	.loc	1 47 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:47:3
	j	.LBB1_21
.LBB1_21:
.Ltmp104:
	.loc	1 47 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:47:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0.12)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0.12)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0.12)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -50(s0)
	addi	a0, s0, -50
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_22
.Ltmp105:
.LBB1_22:
	.loc	1 48 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:48:3
	j	.LBB1_23
.LBB1_23:
.Ltmp106:
	.loc	1 48 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:48:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv1.13)
	addi	a1, a0, %lo(.L__const.TEST_CASE2.Vv1.13)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -56(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -60(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -64(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -68(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -72(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -76(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -80(s0)
	lhu	a0, %lo(.L__const.TEST_CASE2.Vv1.13)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -84(s0)
	addi	a0, s0, -84
	#APP
	vle16.v v1, (a0)  

	#NO_APP
	j	.LBB1_24
.Ltmp107:
.LBB1_24:
	.loc	1 49 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:49:3
	j	.LBB1_25
.LBB1_25:
.Ltmp108:
	.loc	1 49 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:49:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2.14)
	lh	a0, %lo(.L__const.TEST_CASE2.Vv2.14)(a0)
	sh	a0, -86(s0)
	addi	a0, s0, -86
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB1_26
.Ltmp109:
.LBB1_26:
	.loc	1 50 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:50:3
	j	.LBB1_27
.LBB1_27:
.Ltmp110:
	.loc	1 50 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:50:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv3.15)
	lh	a0, %lo(.L__const.TEST_CASE2.Vv3.15)(a0)
	sh	a0, -88(s0)
	addi	a0, s0, -88
	#APP
	vle16.v v3, (a0)  

	#NO_APP
	j	.LBB1_28
.Ltmp111:
.LBB1_28:
	.loc	1 51 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:51:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp112:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	j	.LBB1_29
.LBB1_29:
.Ltmp113:
	.loc	1 52 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -92(s0)
	lw	a0, -92(s0)
	#APP
	vse16.v v3, (a0)

	#NO_APP
	sw	a0, -92(s0)
	j	.LBB1_30
.Ltmp114:
.LBB1_30:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 37
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	sh	a0, -94(s0)
	li	a0, 6
	li	a1, 1
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 6
	call	printf_
.Ltmp115:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	sw	zero, -100(s0)
	j	.LBB1_31
.LBB1_31:                               # =>This Inner Loop Header: Depth=1
.Ltmp116:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lw	a0, -100(s0)
.Ltmp117:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	bnez	a0, .LBB1_36
	j	.LBB1_32
.LBB1_32:                               #   in Loop: Header=BB1_31 Depth=1
.Ltmp118:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lw	a1, -100(s0)
	li	a0, 6
	call	ara_compare_step
.Ltmp119:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lw	a0, -100(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -100(s0)
	slli	a1, a1, 1
	addi	a2, s0, -94
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB1_34
	j	.LBB1_33
.LBB1_33:
.Ltmp120:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lw	a1, -100(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -100(s0)
	slli	a0, a0, 1
	addi	a3, s0, -94
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_73
.Ltmp121:
.LBB1_34:                               #   in Loop: Header=BB1_31 Depth=1
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	j	.LBB1_35
.Ltmp122:
.LBB1_35:                               #   in Loop: Header=BB1_31 Depth=1
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lw	a0, -100(s0)
	addi	a0, a0, 1
	sw	a0, -100(s0)
	j	.LBB1_31
.Ltmp123:
.LBB1_36:
	.loc	1 52 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:52:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 6
	call	ara_assert_end
.Ltmp124:
	.loc	1 54 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:54:3
	j	.LBB1_37
.LBB1_37:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp125:
	.loc	1 54 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:54:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 54
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_38
.Ltmp126:
.LBB1_38:
	.loc	1 55 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:55:3
	j	.LBB1_39
.LBB1_39:
.Ltmp127:
	.loc	1 55 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:55:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0.17)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0.17)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0.17)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -102(s0)
	addi	a0, s0, -102
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_40
.Ltmp128:
.LBB1_40:
	.loc	1 56 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:56:3
	j	.LBB1_41
.LBB1_41:
.Ltmp129:
	.loc	1 56 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:56:3
	lui	a1, %hi(.L__const.TEST_CASE2.Vv1.18)
	addi	a1, a1, %lo(.L__const.TEST_CASE2.Vv1.18)
	addi	s1, s0, -168
	addi	a0, s0, -168
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v1, (s1)  

	#NO_APP
	j	.LBB1_42
.Ltmp130:
.LBB1_42:
	.loc	1 57 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:57:3
	j	.LBB1_43
.LBB1_43:
.Ltmp131:
	.loc	1 57 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:57:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2.19)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv2.19)(a0)
	sw	a0, -172(s0)
	addi	a0, s0, -172
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB1_44
.Ltmp132:
.LBB1_44:
	.loc	1 58 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:58:3
	j	.LBB1_45
.LBB1_45:
.Ltmp133:
	.loc	1 58 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:58:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv3.20)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv3.20)(a0)
	sw	a0, -176(s0)
	addi	a0, s0, -176
	#APP
	vle32.v v3, (a0)  

	#NO_APP
	j	.LBB1_46
.Ltmp134:
.LBB1_46:
	.loc	1 59 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:59:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp135:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	j	.LBB1_47
.LBB1_47:
.Ltmp136:
	.loc	1 60 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -180(s0)
	lw	a0, -180(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -180(s0)
	j	.LBB1_48
.Ltmp137:
.LBB1_48:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 37
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	sw	a0, -184(s0)
	li	a0, 7
	li	a1, 1
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 7
	call	printf_
.Ltmp138:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	sw	zero, -188(s0)
	j	.LBB1_49
.LBB1_49:                               # =>This Inner Loop Header: Depth=1
.Ltmp139:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lw	a0, -188(s0)
.Ltmp140:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	bnez	a0, .LBB1_54
	j	.LBB1_50
.LBB1_50:                               #   in Loop: Header=BB1_49 Depth=1
.Ltmp141:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lw	a1, -188(s0)
	li	a0, 7
	call	ara_compare_step
.Ltmp142:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lw	a0, -188(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -188(s0)
	slli	a1, a1, 2
	addi	a2, s0, -184
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB1_52
	j	.LBB1_51
.LBB1_51:
.Ltmp143:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lw	a1, -188(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -188(s0)
	slli	a0, a0, 2
	addi	a3, s0, -184
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_73
.Ltmp144:
.LBB1_52:                               #   in Loop: Header=BB1_49 Depth=1
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	j	.LBB1_53
.Ltmp145:
.LBB1_53:                               #   in Loop: Header=BB1_49 Depth=1
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lw	a0, -188(s0)
	addi	a0, a0, 1
	sw	a0, -188(s0)
	j	.LBB1_49
.Ltmp146:
.LBB1_54:
	.loc	1 60 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:60:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 7
	call	ara_assert_end
.Ltmp147:
	.loc	1 62 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:62:3
	j	.LBB1_55
.LBB1_55:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp148:
	.loc	1 62 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:62:3
	#APP
	vsetvli t0, a0,e64,m1, ta, ma 

	#NO_APP
	li	a0, 62
	li	a1, 16
	call	ara_trace_vset
	j	.LBB1_56
.Ltmp149:
.LBB1_56:
	.loc	1 63 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:63:3
	j	.LBB1_57
.LBB1_57:
.Ltmp150:
	.loc	1 63 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:63:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0.22)
	lbu	a1, %lo(.L__const.TEST_CASE2.Vv0.22)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0.22)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -190(s0)
	addi	a0, s0, -190
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB1_58
.Ltmp151:
.LBB1_58:
	.loc	1 64 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:64:3
	j	.LBB1_59
.LBB1_59:
.Ltmp152:
	.loc	1 64 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:64:3
	lui	a1, %hi(.L__const.TEST_CASE2.Vv1.23)
	addi	a1, a1, %lo(.L__const.TEST_CASE2.Vv1.23)
	addi	s1, s0, -320
	addi	a0, s0, -320
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v1, (s1)  

	#NO_APP
	j	.LBB1_60
.Ltmp153:
.LBB1_60:
	.loc	1 65 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:65:3
	j	.LBB1_61
.LBB1_61:
.Ltmp154:
	.loc	1 65 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:65:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2.24)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv2.24+4)(a0)
	sw	a1, -324(s0)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv2.24)(a0)
	sw	a0, -328(s0)
	addi	a0, s0, -328
	#APP
	vle64.v v2, (a0)  

	#NO_APP
	j	.LBB1_62
.Ltmp155:
.LBB1_62:
	.loc	1 66 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:66:3
	j	.LBB1_63
.LBB1_63:
.Ltmp156:
	.loc	1 66 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:66:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv3.25)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv3.25+4)(a0)
	sw	a1, -332(s0)
	lw	a0, %lo(.L__const.TEST_CASE2.Vv3.25)(a0)
	sw	a0, -336(s0)
	addi	a0, s0, -336
	#APP
	vle64.v v3, (a0)  

	#NO_APP
	j	.LBB1_64
.Ltmp157:
.LBB1_64:
	.loc	1 67 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:67:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp158:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	j	.LBB1_65
.LBB1_65:
.Ltmp159:
	.loc	1 68 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -340(s0)
	lw	a0, -340(s0)
	#APP
	vse64.v v3, (a0)

	#NO_APP
	sw	a0, -340(s0)
	j	.LBB1_66
.Ltmp160:
.LBB1_66:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	sw	zero, -348(s0)
	li	a0, 37
	sw	a0, -352(s0)
	li	a0, 8
	li	a1, 1
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 8
	call	printf_
.Ltmp161:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	sw	zero, -356(s0)
	j	.LBB1_67
.LBB1_67:                               # =>This Inner Loop Header: Depth=1
.Ltmp162:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lw	a0, -356(s0)
.Ltmp163:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	bnez	a0, .LBB1_72
	j	.LBB1_68
.LBB1_68:                               #   in Loop: Header=BB1_67 Depth=1
.Ltmp164:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lw	a1, -356(s0)
	li	a0, 8
	call	ara_compare_step
.Ltmp165:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lw	a0, -356(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -356(s0)
	slli	a2, a2, 3
	addi	a3, s0, -352
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB1_70
	j	.LBB1_69
.LBB1_69:
.Ltmp166:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lw	a1, -356(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -356(s0)
	slli	a0, a0, 3
	addi	a4, s0, -352
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_73
.Ltmp167:
.LBB1_70:                               #   in Loop: Header=BB1_67 Depth=1
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	j	.LBB1_71
.Ltmp168:
.LBB1_71:                               #   in Loop: Header=BB1_67 Depth=1
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lw	a0, -356(s0)
	addi	a0, a0, 1
	sw	a0, -356(s0)
	j	.LBB1_67
.Ltmp169:
.LBB1_72:
	.loc	1 68 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:68:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 8
	call	ara_assert_end
.Ltmp170:
	.loc	1 69 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:69:1
	j	.LBB1_73
.LBB1_73:
	.cfi_def_cfa sp, 368
	.loc	1 69 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:69:1
	lw	ra, 364(sp)                     # 4-byte Folded Reload
	lw	s0, 360(sp)                     # 4-byte Folded Reload
	lw	s1, 356(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 368
	.cfi_def_cfa_offset 0
	ret
.Ltmp171:
.Lfunc_end1:
	.size	TEST_CASE2, .Lfunc_end1-TEST_CASE2
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE3                      # -- Begin function TEST_CASE3
	.p2align	2
	.type	TEST_CASE3,@function
TEST_CASE3:                             # @TEST_CASE3
.Lfunc_begin2:
	.loc	1 72 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:72:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -1024
	.cfi_def_cfa_offset 1024
	sw	ra, 1020(sp)                    # 4-byte Folded Spill
	sw	s0, 1016(sp)                    # 4-byte Folded Spill
	sw	s1, 1012(sp)                    # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 1024
	.cfi_def_cfa s0, 0
.Ltmp172:
	.loc	1 73 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:73:3
	j	.LBB2_1
.LBB2_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp173:
	.loc	1 73 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:73:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 73
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_2
.Ltmp174:
.LBB2_2:
	.loc	1 74 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:74:3
	j	.LBB2_3
.LBB2_3:
.Ltmp175:
	.loc	1 74 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:74:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv1)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv1)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -16(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a0, %lo(.L__const.TEST_CASE3.Vv1)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -28(s0)
	addi	a0, s0, -28
	#APP
	vle8.v v1, (a0)  

	#NO_APP
	j	.LBB2_4
.Ltmp176:
.LBB2_4:
	.loc	1 75 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:75:3
	j	.LBB2_5
.LBB2_5:
.Ltmp177:
	.loc	1 75 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:75:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv2)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -32(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -36(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -40(s0)
	lbu	a0, %lo(.L__const.TEST_CASE3.Vv2)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -44(s0)
	addi	a0, s0, -44
	#APP
	vle8.v v2, (a0)  

	#NO_APP
	j	.LBB2_6
.Ltmp178:
.LBB2_6:
	.loc	1 76 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:76:3
	j	.LBB2_7
.LBB2_7:
.Ltmp179:
	.loc	1 76 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:76:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv3)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv3)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -48(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -52(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -56(s0)
	lbu	a0, %lo(.L__const.TEST_CASE3.Vv3)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -60(s0)
	addi	a0, s0, -60
	#APP
	vle8.v v3, (a0)  

	#NO_APP
	j	.LBB2_8
.Ltmp180:
.LBB2_8:
	.loc	1 77 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:77:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp181:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	j	.LBB2_9
.LBB2_9:
.Ltmp182:
	.loc	1 78 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	addi	a0, a0, 128
	sw	a0, -64(s0)
	lw	a0, -64(s0)
	#APP
	vse8.v v3, (a0)

	#NO_APP
	sw	a0, -64(s0)
	j	.LBB2_10
.Ltmp183:
.LBB2_10:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	lui	a0, 32880
	addi	a0, a0, 1541
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	sw	a0, -68(s0)
	lui	a1, 16432
	addi	a2, a1, 513
	sw	a2, -72(s0)
	sw	a0, -76(s0)
	addi	a0, a1, 585
	sw	a0, -80(s0)
	li	a0, 9
	li	a1, 16
	li	a2, 1
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 9
	call	printf_
.Ltmp184:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	sw	zero, -84(s0)
	j	.LBB2_11
.LBB2_11:                               # =>This Inner Loop Header: Depth=1
.Ltmp185:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lw	a0, -84(s0)
	li	a1, 15
.Ltmp186:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	bltu	a1, a0, .LBB2_16
	j	.LBB2_12
.LBB2_12:                               #   in Loop: Header=BB2_11 Depth=1
.Ltmp187:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lw	a1, -84(s0)
	li	a0, 9
	call	ara_compare_step
.Ltmp188:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lw	a0, -84(s0)
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	add	a0, a1, a0
	lbu	a0, 128(a0)
	lw	a1, -84(s0)
	addi	a2, s0, -80
	add	a1, a2, a1
	lbu	a1, 0(a1)
	beq	a0, a1, .LBB2_14
	j	.LBB2_13
.LBB2_13:
.Ltmp189:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lw	a1, -84(s0)
	lui	s1, %hi(.L_MergedGlobals)
	addi	a0, s1, %lo(.L_MergedGlobals)
	add	a0, a0, a1
	lbu	a2, 128(a0)
	lw	a0, -84(s0)
	addi	a3, s0, -80
	add	a0, a3, a0
	lbu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	addi	a0, a0, 1
	sw	a0, %lo(.L_MergedGlobals)(s1)
	j	.LBB2_65
.Ltmp190:
.LBB2_14:                               #   in Loop: Header=BB2_11 Depth=1
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	j	.LBB2_15
.Ltmp191:
.LBB2_15:                               #   in Loop: Header=BB2_11 Depth=1
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lw	a0, -84(s0)
	addi	a0, a0, 1
	sw	a0, -84(s0)
	j	.LBB2_11
.Ltmp192:
.LBB2_16:
	.loc	1 78 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:78:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 9
	call	ara_assert_end
.Ltmp193:
	.loc	1 80 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:80:3
	j	.LBB2_17
.LBB2_17:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp194:
	.loc	1 80 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:80:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 80
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_18
.Ltmp195:
.LBB2_18:
	.loc	1 81 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:81:3
	j	.LBB2_19
.LBB2_19:
.Ltmp196:
	.loc	1 81 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:81:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv1.27)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv1.27)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -88(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -92(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -96(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -100(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -104(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -108(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -112(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv1.27)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -116(s0)
	addi	a0, s0, -116
	#APP
	vle16.v v1, (a0)  

	#NO_APP
	j	.LBB2_20
.Ltmp197:
.LBB2_20:
	.loc	1 82 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:82:3
	j	.LBB2_21
.LBB2_21:
.Ltmp198:
	.loc	1 82 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:82:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv2.28)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv2.28)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -120(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -124(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -128(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -132(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -136(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -140(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -144(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv2.28)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -148(s0)
	addi	a0, s0, -148
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB2_22
.Ltmp199:
.LBB2_22:
	.loc	1 83 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:83:3
	j	.LBB2_23
.LBB2_23:
.Ltmp200:
	.loc	1 83 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:83:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv3.29)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv3.29)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -152(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -156(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -160(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -164(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -168(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -172(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -176(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv3.29)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -180(s0)
	addi	a0, s0, -180
	#APP
	vle16.v v3, (a0)  

	#NO_APP
	j	.LBB2_24
.Ltmp201:
.LBB2_24:
	.loc	1 84 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:84:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp202:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	j	.LBB2_25
.LBB2_25:
.Ltmp203:
	.loc	1 85 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -184(s0)
	lw	a0, -184(s0)
	#APP
	vse16.v v3, (a0)

	#NO_APP
	sw	a0, -184(s0)
	j	.LBB2_26
.Ltmp204:
.LBB2_26:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	lui	a0, 128
	addi	a0, a0, 7
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	sw	a0, -188(s0)
	lui	a1, 96
	addi	a1, a1, 5
	sw	a1, -192(s0)
	lui	a2, 64
	addi	a2, a2, 3
	sw	a2, -196(s0)
	lui	a3, 32
	addi	a4, a3, 1
	sw	a4, -200(s0)
	sw	a0, -204(s0)
	sw	a1, -208(s0)
	sw	a2, -212(s0)
	addi	a0, a3, 73
	sw	a0, -216(s0)
	li	a0, 10
	li	a1, 16
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 10
	call	printf_
.Ltmp205:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	sw	zero, -220(s0)
	j	.LBB2_27
.LBB2_27:                               # =>This Inner Loop Header: Depth=1
.Ltmp206:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lw	a0, -220(s0)
	li	a1, 15
.Ltmp207:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	bltu	a1, a0, .LBB2_32
	j	.LBB2_28
.LBB2_28:                               #   in Loop: Header=BB2_27 Depth=1
.Ltmp208:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lw	a1, -220(s0)
	li	a0, 10
	call	ara_compare_step
.Ltmp209:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lw	a0, -220(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -220(s0)
	slli	a1, a1, 1
	addi	a2, s0, -216
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB2_30
	j	.LBB2_29
.LBB2_29:
.Ltmp210:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lw	a1, -220(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -220(s0)
	slli	a0, a0, 1
	addi	a3, s0, -216
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_65
.Ltmp211:
.LBB2_30:                               #   in Loop: Header=BB2_27 Depth=1
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	j	.LBB2_31
.Ltmp212:
.LBB2_31:                               #   in Loop: Header=BB2_27 Depth=1
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lw	a0, -220(s0)
	addi	a0, a0, 1
	sw	a0, -220(s0)
	j	.LBB2_27
.Ltmp213:
.LBB2_32:
	.loc	1 85 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:85:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 10
	call	ara_assert_end
.Ltmp214:
	.loc	1 87 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:87:3
	j	.LBB2_33
.LBB2_33:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp215:
	.loc	1 87 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:87:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 87
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_34
.Ltmp216:
.LBB2_34:
	.loc	1 88 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:88:3
	j	.LBB2_35
.LBB2_35:
.Ltmp217:
	.loc	1 88 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:88:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv1.31)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv1.31)
	addi	s1, s0, -284
	addi	a0, s0, -284
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v1, (s1)  

	#NO_APP
	j	.LBB2_36
.Ltmp218:
.LBB2_36:
	.loc	1 89 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:89:3
	j	.LBB2_37
.LBB2_37:
.Ltmp219:
	.loc	1 89 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:89:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv2.32)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv2.32)
	addi	s1, s0, -348
	addi	a0, s0, -348
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB2_38
.Ltmp220:
.LBB2_38:
	.loc	1 90 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:90:3
	j	.LBB2_39
.LBB2_39:
.Ltmp221:
	.loc	1 90 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:90:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv3.33)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv3.33)
	addi	s1, s0, -412
	addi	a0, s0, -412
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v3, (s1)  

	#NO_APP
	j	.LBB2_40
.Ltmp222:
.LBB2_40:
	.loc	1 91 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:91:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp223:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	j	.LBB2_41
.LBB2_41:
.Ltmp224:
	.loc	1 92 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -416(s0)
	lw	a0, -416(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -416(s0)
	j	.LBB2_42
.Ltmp225:
.LBB2_42:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lui	a1, %hi(.L__const.TEST_CASE3.vact.34)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.vact.34)
	addi	a0, s0, -480
	li	a2, 64
	call	memcpy
	li	a0, 11
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 11
	call	printf_
.Ltmp226:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	sw	zero, -484(s0)
	j	.LBB2_43
.LBB2_43:                               # =>This Inner Loop Header: Depth=1
.Ltmp227:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lw	a0, -484(s0)
	li	a1, 15
.Ltmp228:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	bltu	a1, a0, .LBB2_48
	j	.LBB2_44
.LBB2_44:                               #   in Loop: Header=BB2_43 Depth=1
.Ltmp229:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lw	a1, -484(s0)
	li	a0, 11
	call	ara_compare_step
.Ltmp230:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lw	a0, -484(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -484(s0)
	slli	a1, a1, 2
	addi	a2, s0, -480
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB2_46
	j	.LBB2_45
.LBB2_45:
.Ltmp231:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lw	a1, -484(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -484(s0)
	slli	a0, a0, 2
	addi	a3, s0, -480
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_65
.Ltmp232:
.LBB2_46:                               #   in Loop: Header=BB2_43 Depth=1
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	j	.LBB2_47
.Ltmp233:
.LBB2_47:                               #   in Loop: Header=BB2_43 Depth=1
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lw	a0, -484(s0)
	addi	a0, a0, 1
	sw	a0, -484(s0)
	j	.LBB2_43
.Ltmp234:
.LBB2_48:
	.loc	1 92 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:92:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 11
	call	ara_assert_end
.Ltmp235:
	.loc	1 94 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:94:3
	j	.LBB2_49
.LBB2_49:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 16
.Ltmp236:
	.loc	1 94 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:94:3
	#APP
	vsetvli t0, a0,e64,m1, ta, ma 

	#NO_APP
	li	a0, 94
	li	a1, 16
	call	ara_trace_vset
	j	.LBB2_50
.Ltmp237:
.LBB2_50:
	.loc	1 95 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:95:3
	j	.LBB2_51
.LBB2_51:
.Ltmp238:
	.loc	1 95 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:95:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv1.35)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv1.35)
	addi	s1, s0, -616
	addi	a0, s0, -616
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v1, (s1)  

	#NO_APP
	j	.LBB2_52
.Ltmp239:
.LBB2_52:
	.loc	1 96 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:96:3
	j	.LBB2_53
.LBB2_53:
.Ltmp240:
	.loc	1 96 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:96:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv2.36)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv2.36)
	addi	s1, s0, -744
	addi	a0, s0, -744
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB2_54
.Ltmp241:
.LBB2_54:
	.loc	1 97 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:97:3
	j	.LBB2_55
.LBB2_55:
.Ltmp242:
	.loc	1 97 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:97:3
	lui	a1, %hi(.L__const.TEST_CASE3.Vv3.37)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.Vv3.37)
	addi	s1, s0, -872
	addi	a0, s0, -872
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v3, (s1)  

	#NO_APP
	j	.LBB2_56
.Ltmp243:
.LBB2_56:
	.loc	1 98 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:98:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp244:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	j	.LBB2_57
.LBB2_57:
.Ltmp245:
	.loc	1 99 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -876(s0)
	lw	a0, -876(s0)
	#APP
	vse64.v v3, (a0)

	#NO_APP
	sw	a0, -876(s0)
	j	.LBB2_58
.Ltmp246:
.LBB2_58:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lui	a1, %hi(.L__const.TEST_CASE3.vact.38)
	addi	a1, a1, %lo(.L__const.TEST_CASE3.vact.38)
	addi	a0, s0, -1008
	li	a2, 128
	call	memcpy
	li	a0, 12
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 12
	call	printf_
.Ltmp247:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	sw	zero, -1012(s0)
	j	.LBB2_59
.LBB2_59:                               # =>This Inner Loop Header: Depth=1
.Ltmp248:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lw	a0, -1012(s0)
	li	a1, 15
.Ltmp249:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	bltu	a1, a0, .LBB2_64
	j	.LBB2_60
.LBB2_60:                               #   in Loop: Header=BB2_59 Depth=1
.Ltmp250:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lw	a1, -1012(s0)
	li	a0, 12
	call	ara_compare_step
.Ltmp251:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lw	a0, -1012(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -1012(s0)
	slli	a2, a2, 3
	addi	a3, s0, -1008
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB2_62
	j	.LBB2_61
.LBB2_61:
.Ltmp252:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lw	a1, -1012(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -1012(s0)
	slli	a0, a0, 3
	addi	a4, s0, -1008
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_65
.Ltmp253:
.LBB2_62:                               #   in Loop: Header=BB2_59 Depth=1
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	j	.LBB2_63
.Ltmp254:
.LBB2_63:                               #   in Loop: Header=BB2_59 Depth=1
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lw	a0, -1012(s0)
	addi	a0, a0, 1
	sw	a0, -1012(s0)
	j	.LBB2_59
.Ltmp255:
.LBB2_64:
	.loc	1 99 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:99:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 12
	call	ara_assert_end
.Ltmp256:
	.loc	1 100 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:100:1
	j	.LBB2_65
.LBB2_65:
	.cfi_def_cfa sp, 1024
	.loc	1 100 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:100:1
	lw	ra, 1020(sp)                    # 4-byte Folded Reload
	lw	s0, 1016(sp)                    # 4-byte Folded Reload
	lw	s1, 1012(sp)                    # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 1024
	.cfi_def_cfa_offset 0
	ret
.Ltmp257:
.Lfunc_end2:
	.size	TEST_CASE3, .Lfunc_end2-TEST_CASE3
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE4                      # -- Begin function TEST_CASE4
	.p2align	2
	.type	TEST_CASE4,@function
TEST_CASE4:                             # @TEST_CASE4
.Lfunc_begin3:
	.loc	1 103 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:103:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -1552
	.cfi_def_cfa_offset 1552
	sw	ra, 1548(sp)                    # 4-byte Folded Spill
	sw	s0, 1544(sp)                    # 4-byte Folded Spill
	sw	s1, 1540(sp)                    # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 1552
	.cfi_def_cfa s0, 0
.Ltmp258:
	.loc	1 104 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:104:3
	j	.LBB3_1
.LBB3_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 15
.Ltmp259:
	.loc	1 104 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:104:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 104
	li	a1, 15
	call	ara_trace_vset
	j	.LBB3_2
.Ltmp260:
.LBB3_2:
	.loc	1 105 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:105:3
	j	.LBB3_3
.LBB3_3:
.Ltmp261:
	.loc	1 105 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:105:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv1)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv1)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -28(s0)
	lbu	a0, %lo(.L__const.TEST_CASE4.Vv1)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -32(s0)
	addi	a0, s0, -32
	#APP
	vle8.v v1, (a0)  

	#NO_APP
	j	.LBB3_4
.Ltmp262:
.LBB3_4:
	.loc	1 106 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:106:3
	j	.LBB3_5
.LBB3_5:
.Ltmp263:
	.loc	1 106 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:106:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv2)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -36(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -40(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -44(s0)
	lbu	a0, %lo(.L__const.TEST_CASE4.Vv2)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -48(s0)
	addi	a0, s0, -48
	#APP
	vle8.v v2, (a0)  

	#NO_APP
	j	.LBB3_6
.Ltmp264:
.LBB3_6:
	.loc	1 107 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:107:3
	j	.LBB3_7
.LBB3_7:
.Ltmp265:
	.loc	1 107 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:107:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv3)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv3)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -52(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -56(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -60(s0)
	lbu	a0, %lo(.L__const.TEST_CASE4.Vv3)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -64(s0)
	addi	a0, s0, -64
	#APP
	vle8.v v3, (a0)  

	#NO_APP
	j	.LBB3_8
.Ltmp266:
.LBB3_8:
	.loc	1 108 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:108:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp267:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	j	.LBB3_9
.LBB3_9:
.Ltmp268:
	.loc	1 109 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	addi	a0, a0, 128
	sw	a0, -68(s0)
	lw	a0, -68(s0)
	#APP
	vse8.v v3, (a0)

	#NO_APP
	sw	a0, -68(s0)
	j	.LBB3_10
.Ltmp269:
.LBB3_10:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	lui	a0, 32880
	addi	a0, a0, 1541
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	sw	a0, -72(s0)
	lui	a1, 16432
	addi	a2, a1, 513
	sw	a2, -76(s0)
	sw	a0, -80(s0)
	addi	a0, a1, 577
	sw	a0, -84(s0)
	li	a0, 13
	li	a1, 16
	li	a2, 1
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 13
	call	printf_
.Ltmp270:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	sw	zero, -88(s0)
	j	.LBB3_11
.LBB3_11:                               # =>This Inner Loop Header: Depth=1
.Ltmp271:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lw	a0, -88(s0)
	li	a1, 15
.Ltmp272:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	bltu	a1, a0, .LBB3_16
	j	.LBB3_12
.LBB3_12:                               #   in Loop: Header=BB3_11 Depth=1
.Ltmp273:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lw	a1, -88(s0)
	li	a0, 13
	call	ara_compare_step
.Ltmp274:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lw	a0, -88(s0)
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	add	a0, a1, a0
	lbu	a0, 128(a0)
	lw	a1, -88(s0)
	addi	a2, s0, -84
	add	a1, a2, a1
	lbu	a1, 0(a1)
	beq	a0, a1, .LBB3_14
	j	.LBB3_13
.LBB3_13:
.Ltmp275:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lw	a1, -88(s0)
	lui	s1, %hi(.L_MergedGlobals)
	addi	a0, s1, %lo(.L_MergedGlobals)
	add	a0, a0, a1
	lbu	a2, 128(a0)
	lw	a0, -88(s0)
	addi	a3, s0, -84
	add	a0, a3, a0
	lbu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	addi	a0, a0, 1
	sw	a0, %lo(.L_MergedGlobals)(s1)
	j	.LBB3_81
.Ltmp276:
.LBB3_14:                               #   in Loop: Header=BB3_11 Depth=1
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	j	.LBB3_15
.Ltmp277:
.LBB3_15:                               #   in Loop: Header=BB3_11 Depth=1
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lw	a0, -88(s0)
	addi	a0, a0, 1
	sw	a0, -88(s0)
	j	.LBB3_11
.Ltmp278:
.LBB3_16:
	.loc	1 109 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:109:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 13
	call	ara_assert_end
.Ltmp279:
	.loc	1 111 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:111:3
	j	.LBB3_17
.LBB3_17:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 1
.Ltmp280:
	.loc	1 111 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:111:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 111
	li	a1, 1
	call	ara_trace_vset
	j	.LBB3_18
.Ltmp281:
.LBB3_18:
	.loc	1 112 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:112:3
	j	.LBB3_19
.LBB3_19:
.Ltmp282:
	.loc	1 112 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:112:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv1.39)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv1.39)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -92(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -96(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -100(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -104(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -108(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -112(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -116(s0)
	lhu	a0, %lo(.L__const.TEST_CASE4.Vv1.39)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -120(s0)
	addi	a0, s0, -120
	#APP
	vle16.v v1, (a0)  

	#NO_APP
	j	.LBB3_20
.Ltmp283:
.LBB3_20:
	.loc	1 113 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:113:3
	j	.LBB3_21
.LBB3_21:
.Ltmp284:
	.loc	1 113 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:113:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv2.40)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv2.40)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -124(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -128(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -132(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -136(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -140(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -144(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -148(s0)
	lhu	a0, %lo(.L__const.TEST_CASE4.Vv2.40)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -152(s0)
	addi	a0, s0, -152
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB3_22
.Ltmp285:
.LBB3_22:
	.loc	1 114 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:114:3
	j	.LBB3_23
.LBB3_23:
.Ltmp286:
	.loc	1 114 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:114:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv3.41)
	addi	a1, a0, %lo(.L__const.TEST_CASE4.Vv3.41)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -156(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -160(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -164(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -168(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -172(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -176(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -180(s0)
	lhu	a0, %lo(.L__const.TEST_CASE4.Vv3.41)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -184(s0)
	addi	a0, s0, -184
	#APP
	vle16.v v3, (a0)  

	#NO_APP
	j	.LBB3_24
.Ltmp287:
.LBB3_24:
	.loc	1 115 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:115:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp288:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	j	.LBB3_25
.LBB3_25:
.Ltmp289:
	.loc	1 116 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -188(s0)
	lw	a0, -188(s0)
	#APP
	vse16.v v3, (a0)

	#NO_APP
	sw	a0, -188(s0)
	j	.LBB3_26
.Ltmp290:
.LBB3_26:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	lui	a0, 128
	addi	a0, a0, 7
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	sw	a0, -192(s0)
	lui	a1, 96
	addi	a1, a1, 5
	sw	a1, -196(s0)
	lui	a2, 64
	addi	a2, a2, 3
	sw	a2, -200(s0)
	lui	a3, 32
	addi	a4, a3, 1
	sw	a4, -204(s0)
	sw	a0, -208(s0)
	sw	a1, -212(s0)
	sw	a2, -216(s0)
	addi	a3, a3, 2
	sw	a3, -220(s0)
	li	a0, 14
	li	a1, 16
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 14
	call	printf_
.Ltmp291:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	sw	zero, -224(s0)
	j	.LBB3_27
.LBB3_27:                               # =>This Inner Loop Header: Depth=1
.Ltmp292:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lw	a0, -224(s0)
	li	a1, 15
.Ltmp293:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	bltu	a1, a0, .LBB3_32
	j	.LBB3_28
.LBB3_28:                               #   in Loop: Header=BB3_27 Depth=1
.Ltmp294:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lw	a1, -224(s0)
	li	a0, 14
	call	ara_compare_step
.Ltmp295:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lw	a0, -224(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -224(s0)
	slli	a1, a1, 1
	addi	a2, s0, -220
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB3_30
	j	.LBB3_29
.LBB3_29:
.Ltmp296:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lw	a1, -224(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -224(s0)
	slli	a0, a0, 1
	addi	a3, s0, -220
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_81
.Ltmp297:
.LBB3_30:                               #   in Loop: Header=BB3_27 Depth=1
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	j	.LBB3_31
.Ltmp298:
.LBB3_31:                               #   in Loop: Header=BB3_27 Depth=1
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lw	a0, -224(s0)
	addi	a0, a0, 1
	sw	a0, -224(s0)
	j	.LBB3_27
.Ltmp299:
.LBB3_32:
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:116:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 14
	call	ara_assert_end
.Ltmp300:
	.loc	1 118 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:118:3
	j	.LBB3_33
.LBB3_33:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 3
.Ltmp301:
	.loc	1 118 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:118:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 118
	li	a1, 3
	call	ara_trace_vset
	j	.LBB3_34
.Ltmp302:
.LBB3_34:
	.loc	1 119 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:119:3
	j	.LBB3_35
.LBB3_35:
.Ltmp303:
	.loc	1 119 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:119:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv1.43)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv1.43)
	addi	s1, s0, -288
	addi	a0, s0, -288
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v1, (s1)  

	#NO_APP
	j	.LBB3_36
.Ltmp304:
.LBB3_36:
	.loc	1 120 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:120:3
	j	.LBB3_37
.LBB3_37:
.Ltmp305:
	.loc	1 120 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:120:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv2.44)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv2.44)
	addi	s1, s0, -352
	addi	a0, s0, -352
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB3_38
.Ltmp306:
.LBB3_38:
	.loc	1 121 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:121:3
	j	.LBB3_39
.LBB3_39:
.Ltmp307:
	.loc	1 121 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:121:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv3.45)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv3.45)
	addi	s1, s0, -416
	addi	a0, s0, -416
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v3, (s1)  

	#NO_APP
	j	.LBB3_40
.Ltmp308:
.LBB3_40:
	.loc	1 122 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:122:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp309:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	j	.LBB3_41
.LBB3_41:
.Ltmp310:
	.loc	1 123 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -420(s0)
	lw	a0, -420(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -420(s0)
	j	.LBB3_42
.Ltmp311:
.LBB3_42:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lui	a1, %hi(.L__const.TEST_CASE4.vact.46)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.vact.46)
	addi	a0, s0, -484
	li	a2, 64
	call	memcpy
	li	a0, 15
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 15
	call	printf_
.Ltmp312:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	sw	zero, -488(s0)
	j	.LBB3_43
.LBB3_43:                               # =>This Inner Loop Header: Depth=1
.Ltmp313:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lw	a0, -488(s0)
	li	a1, 15
.Ltmp314:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	bltu	a1, a0, .LBB3_48
	j	.LBB3_44
.LBB3_44:                               #   in Loop: Header=BB3_43 Depth=1
.Ltmp315:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lw	a1, -488(s0)
	li	a0, 15
	call	ara_compare_step
.Ltmp316:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lw	a0, -488(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -488(s0)
	slli	a1, a1, 2
	addi	a2, s0, -484
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB3_46
	j	.LBB3_45
.LBB3_45:
.Ltmp317:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lw	a1, -488(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -488(s0)
	slli	a0, a0, 2
	addi	a3, s0, -484
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_81
.Ltmp318:
.LBB3_46:                               #   in Loop: Header=BB3_43 Depth=1
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	j	.LBB3_47
.Ltmp319:
.LBB3_47:                               #   in Loop: Header=BB3_43 Depth=1
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lw	a0, -488(s0)
	addi	a0, a0, 1
	sw	a0, -488(s0)
	j	.LBB3_43
.Ltmp320:
.LBB3_48:
	.loc	1 123 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:123:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 15
	call	ara_assert_end
.Ltmp321:
	.loc	1 125 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:125:3
	j	.LBB3_49
.LBB3_49:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 7
.Ltmp322:
	.loc	1 125 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:125:3
	#APP
	vsetvli t0, a0,e64,m1, ta, ma 

	#NO_APP
	li	a0, 125
	li	a1, 7
	call	ara_trace_vset
	j	.LBB3_50
.Ltmp323:
.LBB3_50:
	.loc	1 126 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:126:3
	j	.LBB3_51
.LBB3_51:
.Ltmp324:
	.loc	1 126 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:126:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv1.47)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv1.47)
	addi	s1, s0, -616
	addi	a0, s0, -616
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v1, (s1)  

	#NO_APP
	j	.LBB3_52
.Ltmp325:
.LBB3_52:
	.loc	1 127 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:127:3
	j	.LBB3_53
.LBB3_53:
.Ltmp326:
	.loc	1 127 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:127:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv2.48)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv2.48)
	addi	s1, s0, -744
	addi	a0, s0, -744
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB3_54
.Ltmp327:
.LBB3_54:
	.loc	1 128 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:128:3
	j	.LBB3_55
.LBB3_55:
.Ltmp328:
	.loc	1 128 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:128:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv3.49)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv3.49)
	addi	s1, s0, -872
	addi	a0, s0, -872
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v3, (s1)  

	#NO_APP
	j	.LBB3_56
.Ltmp329:
.LBB3_56:
	.loc	1 129 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:129:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp330:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	j	.LBB3_57
.LBB3_57:
.Ltmp331:
	.loc	1 130 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -876(s0)
	lw	a0, -876(s0)
	#APP
	vse64.v v3, (a0)

	#NO_APP
	sw	a0, -876(s0)
	j	.LBB3_58
.Ltmp332:
.LBB3_58:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lui	a1, %hi(.L__const.TEST_CASE4.vact.50)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.vact.50)
	addi	a0, s0, -1008
	li	a2, 128
	call	memcpy
	li	a0, 16
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 16
	call	printf_
.Ltmp333:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	sw	zero, -1012(s0)
	j	.LBB3_59
.LBB3_59:                               # =>This Inner Loop Header: Depth=1
.Ltmp334:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lw	a0, -1012(s0)
	li	a1, 15
.Ltmp335:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	bltu	a1, a0, .LBB3_64
	j	.LBB3_60
.LBB3_60:                               #   in Loop: Header=BB3_59 Depth=1
.Ltmp336:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lw	a1, -1012(s0)
	li	a0, 16
	call	ara_compare_step
.Ltmp337:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lw	a0, -1012(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -1012(s0)
	slli	a2, a2, 3
	addi	a3, s0, -1008
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB3_62
	j	.LBB3_61
.LBB3_61:
.Ltmp338:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lw	a1, -1012(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -1012(s0)
	slli	a0, a0, 3
	addi	a4, s0, -1008
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_81
.Ltmp339:
.LBB3_62:                               #   in Loop: Header=BB3_59 Depth=1
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	j	.LBB3_63
.Ltmp340:
.LBB3_63:                               #   in Loop: Header=BB3_59 Depth=1
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lw	a0, -1012(s0)
	addi	a0, a0, 1
	sw	a0, -1012(s0)
	j	.LBB3_59
.Ltmp341:
.LBB3_64:
	.loc	1 130 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:130:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 16
	call	ara_assert_end
.Ltmp342:
	.loc	1 132 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:132:3
	j	.LBB3_65
.LBB3_65:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 15
.Ltmp343:
	.loc	1 132 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:132:3
	#APP
	vsetvli t0, a0,e64,m1, ta, ma 

	#NO_APP
	li	a0, 132
	li	a1, 15
	call	ara_trace_vset
	j	.LBB3_66
.Ltmp344:
.LBB3_66:
	.loc	1 133 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:133:3
	j	.LBB3_67
.LBB3_67:
.Ltmp345:
	.loc	1 133 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:133:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv1.51)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv1.51)
	addi	s1, s0, -1144
	addi	a0, s0, -1144
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v1, (s1)  

	#NO_APP
	j	.LBB3_68
.Ltmp346:
.LBB3_68:
	.loc	1 134 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:134:3
	j	.LBB3_69
.LBB3_69:
.Ltmp347:
	.loc	1 134 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:134:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv2.52)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv2.52)
	addi	s1, s0, -1272
	addi	a0, s0, -1272
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB3_70
.Ltmp348:
.LBB3_70:
	.loc	1 135 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:135:3
	j	.LBB3_71
.LBB3_71:
.Ltmp349:
	.loc	1 135 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:135:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv3.53)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv3.53)
	addi	s1, s0, -1400
	addi	a0, s0, -1400
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v3, (s1)  

	#NO_APP
	j	.LBB3_72
.Ltmp350:
.LBB3_72:
	.loc	1 136 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:136:3
	#APP
	vredsum.vs v3, v1, v2
	#NO_APP
.Ltmp351:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	j	.LBB3_73
.LBB3_73:
.Ltmp352:
	.loc	1 137 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -1404(s0)
	lw	a0, -1404(s0)
	#APP
	vse64.v v3, (a0)

	#NO_APP
	sw	a0, -1404(s0)
	j	.LBB3_74
.Ltmp353:
.LBB3_74:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lui	a1, %hi(.L__const.TEST_CASE4.vact.54)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.vact.54)
	addi	a0, s0, -1536
	li	a2, 128
	call	memcpy
	li	a0, 17
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 17
	call	printf_
.Ltmp354:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	sw	zero, -1540(s0)
	j	.LBB3_75
.LBB3_75:                               # =>This Inner Loop Header: Depth=1
.Ltmp355:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lw	a0, -1540(s0)
	li	a1, 15
.Ltmp356:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	bltu	a1, a0, .LBB3_80
	j	.LBB3_76
.LBB3_76:                               #   in Loop: Header=BB3_75 Depth=1
.Ltmp357:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lw	a1, -1540(s0)
	li	a0, 17
	call	ara_compare_step
.Ltmp358:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lw	a0, -1540(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -1540(s0)
	slli	a2, a2, 3
	addi	a3, s0, -1536
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB3_78
	j	.LBB3_77
.LBB3_77:
.Ltmp359:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lw	a1, -1540(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -1540(s0)
	slli	a0, a0, 3
	addi	a4, s0, -1536
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB3_81
.Ltmp360:
.LBB3_78:                               #   in Loop: Header=BB3_75 Depth=1
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	j	.LBB3_79
.Ltmp361:
.LBB3_79:                               #   in Loop: Header=BB3_75 Depth=1
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lw	a0, -1540(s0)
	addi	a0, a0, 1
	sw	a0, -1540(s0)
	j	.LBB3_75
.Ltmp362:
.LBB3_80:
	.loc	1 137 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:137:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 17
	call	ara_assert_end
.Ltmp363:
	.loc	1 138 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:138:1
	j	.LBB3_81
.LBB3_81:
	.cfi_def_cfa sp, 1552
	.loc	1 138 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:138:1
	lw	ra, 1548(sp)                    # 4-byte Folded Reload
	lw	s0, 1544(sp)                    # 4-byte Folded Reload
	lw	s1, 1540(sp)                    # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 1552
	.cfi_def_cfa_offset 0
	ret
.Ltmp364:
.Lfunc_end3:
	.size	TEST_CASE4, .Lfunc_end3-TEST_CASE4
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE5                      # -- Begin function TEST_CASE5
	.p2align	2
	.type	TEST_CASE5,@function
TEST_CASE5:                             # @TEST_CASE5
.Lfunc_begin4:
	.loc	1 141 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:141:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -496
	.cfi_def_cfa_offset 496
	sw	ra, 492(sp)                     # 4-byte Folded Spill
	sw	s0, 488(sp)                     # 4-byte Folded Spill
	sw	s1, 484(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 496
	.cfi_def_cfa s0, 0
.Ltmp365:
	.loc	1 142 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:142:3
	j	.LBB4_1
.LBB4_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 15
.Ltmp366:
	.loc	1 142 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:142:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 142
	li	a1, 15
	call	ara_trace_vset
	j	.LBB4_2
.Ltmp367:
.LBB4_2:
	.loc	1 143 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:143:3
	j	.LBB4_3
.LBB4_3:
.Ltmp368:
	.loc	1 143 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:143:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv0)
	lbu	a1, %lo(.L__const.TEST_CASE5.Vv0)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv0)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -14(s0)
	addi	a0, s0, -14
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB4_4
.Ltmp369:
.LBB4_4:
	.loc	1 144 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:144:3
	j	.LBB4_5
.LBB4_5:
.Ltmp370:
	.loc	1 144 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:144:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv1)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv1)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -20(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -24(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -28(s0)
	lbu	a0, %lo(.L__const.TEST_CASE5.Vv1)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -32(s0)
	addi	a0, s0, -32
	#APP
	vle8.v v1, (a0)  

	#NO_APP
	j	.LBB4_6
.Ltmp371:
.LBB4_6:
	.loc	1 145 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:145:3
	j	.LBB4_7
.LBB4_7:
.Ltmp372:
	.loc	1 145 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:145:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv2)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -36(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -40(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -44(s0)
	lbu	a0, %lo(.L__const.TEST_CASE5.Vv2)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -48(s0)
	addi	a0, s0, -48
	#APP
	vle8.v v2, (a0)  

	#NO_APP
	j	.LBB4_8
.Ltmp373:
.LBB4_8:
	.loc	1 146 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:146:3
	j	.LBB4_9
.LBB4_9:
.Ltmp374:
	.loc	1 146 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:146:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv3)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv3)
	lbu	a2, 12(a1)
	lbu	a3, 13(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 14(a1)
	slli	a3, a3, 16
	lbu	a4, 15(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -52(s0)
	lbu	a2, 8(a1)
	lbu	a3, 9(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 10(a1)
	slli	a3, a3, 16
	lbu	a4, 11(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -56(s0)
	lbu	a2, 4(a1)
	lbu	a3, 5(a1)
	slli	a3, a3, 8
	or	a2, a3, a2
	lbu	a3, 6(a1)
	slli	a3, a3, 16
	lbu	a4, 7(a1)
	slli	a4, a4, 24
	or	a3, a4, a3
	or	a2, a3, a2
	sw	a2, -60(s0)
	lbu	a0, %lo(.L__const.TEST_CASE5.Vv3)(a0)
	lbu	a2, 1(a1)
	slli	a2, a2, 8
	or	a0, a2, a0
	lbu	a2, 2(a1)
	slli	a2, a2, 16
	lbu	a1, 3(a1)
	slli	a1, a1, 24
	or	a1, a1, a2
	or	a0, a1, a0
	sw	a0, -64(s0)
	addi	a0, s0, -64
	#APP
	vle8.v v3, (a0)  

	#NO_APP
	j	.LBB4_10
.Ltmp375:
.LBB4_10:
	.loc	1 147 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:147:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp376:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	j	.LBB4_11
.LBB4_11:
.Ltmp377:
	.loc	1 148 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	addi	a0, a0, 128
	sw	a0, -68(s0)
	lw	a0, -68(s0)
	#APP
	vse8.v v3, (a0)

	#NO_APP
	sw	a0, -68(s0)
	j	.LBB4_12
.Ltmp378:
.LBB4_12:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	lui	a0, 32880
	addi	a0, a0, 1541
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	sw	a0, -72(s0)
	lui	a1, 16432
	addi	a2, a1, 513
	sw	a2, -76(s0)
	sw	a0, -80(s0)
	addi	a0, a1, 619
	sw	a0, -84(s0)
	li	a0, 18
	li	a1, 16
	li	a2, 1
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 18
	call	printf_
.Ltmp379:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	sw	zero, -88(s0)
	j	.LBB4_13
.LBB4_13:                               # =>This Inner Loop Header: Depth=1
.Ltmp380:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lw	a0, -88(s0)
	li	a1, 15
.Ltmp381:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	bltu	a1, a0, .LBB4_18
	j	.LBB4_14
.LBB4_14:                               #   in Loop: Header=BB4_13 Depth=1
.Ltmp382:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lw	a1, -88(s0)
	li	a0, 18
	call	ara_compare_step
.Ltmp383:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lw	a0, -88(s0)
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	add	a0, a1, a0
	lbu	a0, 128(a0)
	lw	a1, -88(s0)
	addi	a2, s0, -84
	add	a1, a2, a1
	lbu	a1, 0(a1)
	beq	a0, a1, .LBB4_16
	j	.LBB4_15
.LBB4_15:
.Ltmp384:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lw	a1, -88(s0)
	lui	s1, %hi(.L_MergedGlobals)
	addi	a0, s1, %lo(.L_MergedGlobals)
	add	a0, a0, a1
	lbu	a2, 128(a0)
	lw	a0, -88(s0)
	addi	a3, s0, -84
	add	a0, a3, a0
	lbu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	addi	a0, a0, 1
	sw	a0, %lo(.L_MergedGlobals)(s1)
	j	.LBB4_55
.Ltmp385:
.LBB4_16:                               #   in Loop: Header=BB4_13 Depth=1
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	j	.LBB4_17
.Ltmp386:
.LBB4_17:                               #   in Loop: Header=BB4_13 Depth=1
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lw	a0, -88(s0)
	addi	a0, a0, 1
	sw	a0, -88(s0)
	j	.LBB4_13
.Ltmp387:
.LBB4_18:
	.loc	1 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:148:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 18
	call	ara_assert_end
.Ltmp388:
	.loc	1 150 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:150:3
	j	.LBB4_19
.LBB4_19:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 1
.Ltmp389:
	.loc	1 150 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:150:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 150
	li	a1, 1
	call	ara_trace_vset
	j	.LBB4_20
.Ltmp390:
.LBB4_20:
	.loc	1 151 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:151:3
	j	.LBB4_21
.LBB4_21:
.Ltmp391:
	.loc	1 151 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:151:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv0.55)
	lbu	a1, %lo(.L__const.TEST_CASE5.Vv0.55)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv0.55)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -90(s0)
	addi	a0, s0, -90
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB4_22
.Ltmp392:
.LBB4_22:
	.loc	1 152 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:152:3
	j	.LBB4_23
.LBB4_23:
.Ltmp393:
	.loc	1 152 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:152:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv1.56)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv1.56)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -96(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -100(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -104(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -108(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -112(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -116(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -120(s0)
	lhu	a0, %lo(.L__const.TEST_CASE5.Vv1.56)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -124(s0)
	addi	a0, s0, -124
	#APP
	vle16.v v1, (a0)  

	#NO_APP
	j	.LBB4_24
.Ltmp394:
.LBB4_24:
	.loc	1 153 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:153:3
	j	.LBB4_25
.LBB4_25:
.Ltmp395:
	.loc	1 153 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:153:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv2.57)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv2.57)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -128(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -132(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -136(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -140(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -144(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -148(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -152(s0)
	lhu	a0, %lo(.L__const.TEST_CASE5.Vv2.57)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -156(s0)
	addi	a0, s0, -156
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB4_26
.Ltmp396:
.LBB4_26:
	.loc	1 154 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:154:3
	j	.LBB4_27
.LBB4_27:
.Ltmp397:
	.loc	1 154 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:154:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv3.58)
	addi	a1, a0, %lo(.L__const.TEST_CASE5.Vv3.58)
	lhu	a2, 28(a1)
	lhu	a3, 30(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -160(s0)
	lhu	a2, 24(a1)
	lhu	a3, 26(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -164(s0)
	lhu	a2, 20(a1)
	lhu	a3, 22(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -168(s0)
	lhu	a2, 16(a1)
	lhu	a3, 18(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -172(s0)
	lhu	a2, 12(a1)
	lhu	a3, 14(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -176(s0)
	lhu	a2, 8(a1)
	lhu	a3, 10(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -180(s0)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -184(s0)
	lhu	a0, %lo(.L__const.TEST_CASE5.Vv3.58)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -188(s0)
	addi	a0, s0, -188
	#APP
	vle16.v v3, (a0)  

	#NO_APP
	j	.LBB4_28
.Ltmp398:
.LBB4_28:
	.loc	1 155 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:155:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp399:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	j	.LBB4_29
.LBB4_29:
.Ltmp400:
	.loc	1 156 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lui	a0, %hi(Ru16)
	addi	a0, a0, %lo(Ru16)
	sw	a0, -192(s0)
	lw	a0, -192(s0)
	#APP
	vse16.v v3, (a0)

	#NO_APP
	sw	a0, -192(s0)
	j	.LBB4_30
.Ltmp401:
.LBB4_30:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	lui	a0, 128
	addi	a0, a0, 7
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	sw	a0, -196(s0)
	lui	a1, 96
	addi	a1, a1, 5
	sw	a1, -200(s0)
	lui	a2, 64
	addi	a2, a2, 3
	sw	a2, -204(s0)
	lui	a3, 32
	addi	a3, a3, 1
	sw	a3, -208(s0)
	sw	a0, -212(s0)
	sw	a1, -216(s0)
	sw	a2, -220(s0)
	sw	a3, -224(s0)
	li	a0, 19
	li	a1, 16
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 19
	call	printf_
.Ltmp402:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	sw	zero, -228(s0)
	j	.LBB4_31
.LBB4_31:                               # =>This Inner Loop Header: Depth=1
.Ltmp403:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lw	a0, -228(s0)
	li	a1, 15
.Ltmp404:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	bltu	a1, a0, .LBB4_36
	j	.LBB4_32
.LBB4_32:                               #   in Loop: Header=BB4_31 Depth=1
.Ltmp405:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lw	a1, -228(s0)
	li	a0, 19
	call	ara_compare_step
.Ltmp406:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lw	a0, -228(s0)
	slli	a0, a0, 1
	lui	a1, %hi(Ru16)
	addi	a1, a1, %lo(Ru16)
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -228(s0)
	slli	a1, a1, 1
	addi	a2, s0, -224
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB4_34
	j	.LBB4_33
.LBB4_33:
.Ltmp407:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lw	a1, -228(s0)
	slli	a0, a1, 1
	lui	a2, %hi(Ru16)
	addi	a2, a2, %lo(Ru16)
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -228(s0)
	slli	a0, a0, 1
	addi	a3, s0, -224
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB4_55
.Ltmp408:
.LBB4_34:                               #   in Loop: Header=BB4_31 Depth=1
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	j	.LBB4_35
.Ltmp409:
.LBB4_35:                               #   in Loop: Header=BB4_31 Depth=1
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lw	a0, -228(s0)
	addi	a0, a0, 1
	sw	a0, -228(s0)
	j	.LBB4_31
.Ltmp410:
.LBB4_36:
	.loc	1 156 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:156:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 19
	call	ara_assert_end
.Ltmp411:
	.loc	1 158 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:158:3
	j	.LBB4_37
.LBB4_37:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:0:3
	li	a0, 3
.Ltmp412:
	.loc	1 158 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:158:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 158
	li	a1, 3
	call	ara_trace_vset
	j	.LBB4_38
.Ltmp413:
.LBB4_38:
	.loc	1 159 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:159:3
	j	.LBB4_39
.LBB4_39:
.Ltmp414:
	.loc	1 159 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:159:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv0.60)
	lbu	a1, %lo(.L__const.TEST_CASE5.Vv0.60)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv0.60)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -230(s0)
	addi	a0, s0, -230
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB4_40
.Ltmp415:
.LBB4_40:
	.loc	1 160 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:160:3
	j	.LBB4_41
.LBB4_41:
.Ltmp416:
	.loc	1 160 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:160:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv1.61)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv1.61)
	addi	s1, s0, -296
	addi	a0, s0, -296
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v1, (s1)  

	#NO_APP
	j	.LBB4_42
.Ltmp417:
.LBB4_42:
	.loc	1 161 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:161:3
	j	.LBB4_43
.LBB4_43:
.Ltmp418:
	.loc	1 161 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:161:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv2.62)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv2.62)
	addi	s1, s0, -360
	addi	a0, s0, -360
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB4_44
.Ltmp419:
.LBB4_44:
	.loc	1 162 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:162:3
	j	.LBB4_45
.LBB4_45:
.Ltmp420:
	.loc	1 162 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:162:3
	lui	a1, %hi(.L__const.TEST_CASE5.Vv3.63)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.Vv3.63)
	addi	s1, s0, -424
	addi	a0, s0, -424
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v3, (s1)  

	#NO_APP
	j	.LBB4_46
.Ltmp421:
.LBB4_46:
	.loc	1 163 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:163:3
	#APP
	vredsum.vs v3, v1, v2, v0.t
	#NO_APP
.Ltmp422:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	j	.LBB4_47
.LBB4_47:
.Ltmp423:
	.loc	1 164 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -428(s0)
	lw	a0, -428(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -428(s0)
	j	.LBB4_48
.Ltmp424:
.LBB4_48:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lui	a1, %hi(.L__const.TEST_CASE5.vact.64)
	addi	a1, a1, %lo(.L__const.TEST_CASE5.vact.64)
	addi	a0, s0, -492
	li	a2, 64
	call	memcpy
	li	a0, 20
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 20
	call	printf_
.Ltmp425:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	sw	zero, -496(s0)
	j	.LBB4_49
.LBB4_49:                               # =>This Inner Loop Header: Depth=1
.Ltmp426:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lw	a0, -496(s0)
	li	a1, 15
.Ltmp427:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	bltu	a1, a0, .LBB4_54
	j	.LBB4_50
.LBB4_50:                               #   in Loop: Header=BB4_49 Depth=1
.Ltmp428:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lw	a1, -496(s0)
	li	a0, 20
	call	ara_compare_step
.Ltmp429:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lw	a0, -496(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -496(s0)
	slli	a1, a1, 2
	addi	a2, s0, -492
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB4_52
	j	.LBB4_51
.LBB4_51:
.Ltmp430:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lw	a1, -496(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -496(s0)
	slli	a0, a0, 2
	addi	a3, s0, -492
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB4_55
.Ltmp431:
.LBB4_52:                               #   in Loop: Header=BB4_49 Depth=1
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	j	.LBB4_53
.Ltmp432:
.LBB4_53:                               #   in Loop: Header=BB4_49 Depth=1
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lw	a0, -496(s0)
	addi	a0, a0, 1
	sw	a0, -496(s0)
	j	.LBB4_49
.Ltmp433:
.LBB4_54:
	.loc	1 164 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:164:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 20
	call	ara_assert_end
.Ltmp434:
	.loc	1 165 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:165:1
	j	.LBB4_55
.LBB4_55:
	.cfi_def_cfa sp, 496
	.loc	1 165 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:165:1
	lw	ra, 492(sp)                     # 4-byte Folded Reload
	lw	s0, 488(sp)                     # 4-byte Folded Reload
	lw	s1, 484(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 496
	.cfi_def_cfa_offset 0
	ret
.Ltmp435:
.Lfunc_end4:
	.size	TEST_CASE5, .Lfunc_end4-TEST_CASE5
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin5:
	.loc	1 167 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:167:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp436:
	.loc	1 168 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:168:3
	lui	s2, %hi(.L_MergedGlobals)
	sw	zero, %lo(.L_MergedGlobals)(s2)
	sw	zero, %lo(.L_MergedGlobals+4)(s2)
	.loc	1 171 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:171:3
	lui	s1, %hi(.L.str.65)
	addi	s1, s1, %lo(.L.str.65)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 171 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:171:33
	call	TEST_CASE1
	.loc	1 171 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:171:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 171 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:171:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 172 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:172:3
	lui	s1, %hi(.L.str.66)
	addi	s1, s1, %lo(.L.str.66)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 172 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:172:33
	call	TEST_CASE2
	.loc	1 172 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:172:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 172 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:172:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 173 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:173:3
	lui	s1, %hi(.L.str.67)
	addi	s1, s1, %lo(.L.str.67)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 173 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:173:33
	call	TEST_CASE3
	.loc	1 173 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:173:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 173 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:173:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 174 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:174:3
	lui	s1, %hi(.L.str.68)
	addi	s1, s1, %lo(.L.str.68)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 174 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:174:33
	call	TEST_CASE4
	.loc	1 174 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:174:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 174 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:174:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 175 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:175:3
	lui	s1, %hi(.L.str.69)
	addi	s1, s1, %lo(.L.str.69)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 175 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:175:33
	call	TEST_CASE5
	.loc	1 175 73                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:175:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 175 47                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:175:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 177 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:177:3
	j	.LBB5_1
.LBB5_1:
.Ltmp437:
	.loc	1 177 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:177:3
	lui	a0, %hi(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals)(a0)
	blez	a0, .LBB5_3
	j	.LBB5_2
.LBB5_2:
.Ltmp438:
	.loc	1 177 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:177:3
	lui	s1, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(s1)
	lui	a0, %hi(.L.str.70)
	addi	a0, a0, %lo(.L.str.70)
	lui	a1, %hi(.L.str.71)
	addi	a1, a1, %lo(.L.str.71)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	sw	a0, -20(s0)
	j	.LBB5_4
.Ltmp439:
.LBB5_3:
	.loc	1 177 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:177:3
	lui	a0, %hi(.L.str.72)
	addi	a0, a0, %lo(.L.str.72)
	lui	a1, %hi(.L.str.71)
	addi	a1, a1, %lo(.L.str.71)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB5_4
.Ltmp440:
.LBB5_4:
	.loc	1 178 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:178:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	1 178 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c:178:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp441:
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE1.Vv1,@object # @__const.TEST_CASE1.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE1.Vv1:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE1.Vv1, 16

	.type	.L__const.TEST_CASE1.Vv2,@object # @__const.TEST_CASE1.Vv2
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE1.Vv2:
	.byte	1
	.size	.L__const.TEST_CASE1.Vv2, 1

	.type	.L__const.TEST_CASE1.vact,@object # @__const.TEST_CASE1.vact
.L__const.TEST_CASE1.vact:
	.byte	73
	.size	.L__const.TEST_CASE1.vact, 1

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %x, expected %x.\n"
	.size	.L.str.1, 39

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L__const.TEST_CASE1.Vv1.3,@object # @__const.TEST_CASE1.Vv1.3
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE1.Vv1.3:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE1.Vv1.3, 32

	.type	.L__const.TEST_CASE1.Vv2.4,@object # @__const.TEST_CASE1.Vv2.4
	.section	.rodata,"a",@progbits
	.p2align	1, 0x0
.L__const.TEST_CASE1.Vv2.4:
	.half	1                               # 0x1
	.size	.L__const.TEST_CASE1.Vv2.4, 2

	.type	Ru16,@object                    # @Ru16
	.local	Ru16
	.comm	Ru16,2048,128
	.type	.L__const.TEST_CASE1.vact.5,@object # @__const.TEST_CASE1.vact.5
	.p2align	1, 0x0
.L__const.TEST_CASE1.vact.5:
	.half	73                              # 0x49
	.size	.L__const.TEST_CASE1.vact.5, 2

	.type	.L__const.TEST_CASE1.Vv1.6,@object # @__const.TEST_CASE1.Vv1.6
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv1.6:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE1.Vv1.6, 64

	.type	.L__const.TEST_CASE1.Vv2.7,@object # @__const.TEST_CASE1.Vv2.7
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv2.7:
	.word	1                               # 0x1
	.size	.L__const.TEST_CASE1.Vv2.7, 4

	.type	Ru32,@object                    # @Ru32
	.local	Ru32
	.comm	Ru32,4096,128
	.type	.L__const.TEST_CASE1.vact.8,@object # @__const.TEST_CASE1.vact.8
	.p2align	2, 0x0
.L__const.TEST_CASE1.vact.8:
	.word	73                              # 0x49
	.size	.L__const.TEST_CASE1.vact.8, 4

	.type	.L__const.TEST_CASE1.Vv1.9,@object # @__const.TEST_CASE1.Vv1.9
	.section	.rodata,"a",@progbits
	.p2align	3, 0x0
.L__const.TEST_CASE1.Vv1.9:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE1.Vv1.9, 128

	.type	.L__const.TEST_CASE1.Vv2.10,@object # @__const.TEST_CASE1.Vv2.10
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.L__const.TEST_CASE1.Vv2.10:
	.quad	1                               # 0x1
	.size	.L__const.TEST_CASE1.Vv2.10, 8

	.type	Ru64,@object                    # @Ru64
	.local	Ru64
	.comm	Ru64,8192,128
	.type	.L__const.TEST_CASE1.vact.11,@object # @__const.TEST_CASE1.vact.11
	.p2align	3, 0x0
.L__const.TEST_CASE1.vact.11:
	.quad	73                              # 0x49
	.size	.L__const.TEST_CASE1.vact.11, 8

	.type	.L__const.TEST_CASE2.Vv0,@object # @__const.TEST_CASE2.Vv0
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE2.Vv0:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0, 2

	.type	.L__const.TEST_CASE2.Vv1,@object # @__const.TEST_CASE2.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE2.Vv1:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE2.Vv1, 16

	.type	.L__const.TEST_CASE2.Vv2,@object # @__const.TEST_CASE2.Vv2
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE2.Vv2:
	.byte	1
	.size	.L__const.TEST_CASE2.Vv2, 1

	.type	.L__const.TEST_CASE2.Vv3,@object # @__const.TEST_CASE2.Vv3
.L__const.TEST_CASE2.Vv3:
	.byte	1
	.size	.L__const.TEST_CASE2.Vv3, 1

	.type	.L__const.TEST_CASE2.vact,@object # @__const.TEST_CASE2.vact
.L__const.TEST_CASE2.vact:
	.byte	37
	.size	.L__const.TEST_CASE2.vact, 1

	.type	.L__const.TEST_CASE2.Vv0.12,@object # @__const.TEST_CASE2.Vv0.12
.L__const.TEST_CASE2.Vv0.12:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0.12, 2

	.type	.L__const.TEST_CASE2.Vv1.13,@object # @__const.TEST_CASE2.Vv1.13
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE2.Vv1.13:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE2.Vv1.13, 32

	.type	.L__const.TEST_CASE2.Vv2.14,@object # @__const.TEST_CASE2.Vv2.14
	.section	.rodata,"a",@progbits
	.p2align	1, 0x0
.L__const.TEST_CASE2.Vv2.14:
	.half	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv2.14, 2

	.type	.L__const.TEST_CASE2.Vv3.15,@object # @__const.TEST_CASE2.Vv3.15
	.p2align	1, 0x0
.L__const.TEST_CASE2.Vv3.15:
	.half	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv3.15, 2

	.type	.L__const.TEST_CASE2.vact.16,@object # @__const.TEST_CASE2.vact.16
	.p2align	1, 0x0
.L__const.TEST_CASE2.vact.16:
	.half	37                              # 0x25
	.size	.L__const.TEST_CASE2.vact.16, 2

	.type	.L__const.TEST_CASE2.Vv0.17,@object # @__const.TEST_CASE2.Vv0.17
.L__const.TEST_CASE2.Vv0.17:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0.17, 2

	.type	.L__const.TEST_CASE2.Vv1.18,@object # @__const.TEST_CASE2.Vv1.18
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv1.18:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE2.Vv1.18, 64

	.type	.L__const.TEST_CASE2.Vv2.19,@object # @__const.TEST_CASE2.Vv2.19
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv2.19:
	.word	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv2.19, 4

	.type	.L__const.TEST_CASE2.Vv3.20,@object # @__const.TEST_CASE2.Vv3.20
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv3.20:
	.word	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv3.20, 4

	.type	.L__const.TEST_CASE2.vact.21,@object # @__const.TEST_CASE2.vact.21
	.p2align	2, 0x0
.L__const.TEST_CASE2.vact.21:
	.word	37                              # 0x25
	.size	.L__const.TEST_CASE2.vact.21, 4

	.type	.L__const.TEST_CASE2.Vv0.22,@object # @__const.TEST_CASE2.Vv0.22
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE2.Vv0.22:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE2.Vv0.22, 2

	.type	.L__const.TEST_CASE2.Vv1.23,@object # @__const.TEST_CASE2.Vv1.23
	.p2align	3, 0x0
.L__const.TEST_CASE2.Vv1.23:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE2.Vv1.23, 128

	.type	.L__const.TEST_CASE2.Vv2.24,@object # @__const.TEST_CASE2.Vv2.24
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.L__const.TEST_CASE2.Vv2.24:
	.quad	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv2.24, 8

	.type	.L__const.TEST_CASE2.Vv3.25,@object # @__const.TEST_CASE2.Vv3.25
	.p2align	3, 0x0
.L__const.TEST_CASE2.Vv3.25:
	.quad	1                               # 0x1
	.size	.L__const.TEST_CASE2.Vv3.25, 8

	.type	.L__const.TEST_CASE2.vact.26,@object # @__const.TEST_CASE2.vact.26
	.p2align	3, 0x0
.L__const.TEST_CASE2.vact.26:
	.quad	37                              # 0x25
	.size	.L__const.TEST_CASE2.vact.26, 8

	.type	.L__const.TEST_CASE3.Vv1,@object # @__const.TEST_CASE3.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE3.Vv1:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE3.Vv1, 16

	.type	.L__const.TEST_CASE3.Vv2,@object # @__const.TEST_CASE3.Vv2
.L__const.TEST_CASE3.Vv2:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE3.Vv2, 16

	.type	.L__const.TEST_CASE3.Vv3,@object # @__const.TEST_CASE3.Vv3
.L__const.TEST_CASE3.Vv3:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE3.Vv3, 16

	.type	.L__const.TEST_CASE3.vact,@object # @__const.TEST_CASE3.vact
.L__const.TEST_CASE3.vact:
	.ascii	"I\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE3.vact, 16

	.type	.L__const.TEST_CASE3.Vv1.27,@object # @__const.TEST_CASE3.Vv1.27
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv1.27:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv1.27, 32

	.type	.L__const.TEST_CASE3.Vv2.28,@object # @__const.TEST_CASE3.Vv2.28
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv2.28:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv2.28, 32

	.type	.L__const.TEST_CASE3.Vv3.29,@object # @__const.TEST_CASE3.Vv3.29
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv3.29:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv3.29, 32

	.type	.L__const.TEST_CASE3.vact.30,@object # @__const.TEST_CASE3.vact.30
	.p2align	1, 0x0
.L__const.TEST_CASE3.vact.30:
	.half	73                              # 0x49
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE3.vact.30, 32

	.type	.L__const.TEST_CASE3.Vv1.31,@object # @__const.TEST_CASE3.Vv1.31
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE3.Vv1.31:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv1.31, 64

	.type	.L__const.TEST_CASE3.Vv2.32,@object # @__const.TEST_CASE3.Vv2.32
	.p2align	2, 0x0
.L__const.TEST_CASE3.Vv2.32:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv2.32, 64

	.type	.L__const.TEST_CASE3.Vv3.33,@object # @__const.TEST_CASE3.Vv3.33
	.p2align	2, 0x0
.L__const.TEST_CASE3.Vv3.33:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv3.33, 64

	.type	.L__const.TEST_CASE3.vact.34,@object # @__const.TEST_CASE3.vact.34
	.p2align	2, 0x0
.L__const.TEST_CASE3.vact.34:
	.word	73                              # 0x49
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE3.vact.34, 64

	.type	.L__const.TEST_CASE3.Vv1.35,@object # @__const.TEST_CASE3.Vv1.35
	.p2align	3, 0x0
.L__const.TEST_CASE3.Vv1.35:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv1.35, 128

	.type	.L__const.TEST_CASE3.Vv2.36,@object # @__const.TEST_CASE3.Vv2.36
	.p2align	3, 0x0
.L__const.TEST_CASE3.Vv2.36:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv2.36, 128

	.type	.L__const.TEST_CASE3.Vv3.37,@object # @__const.TEST_CASE3.Vv3.37
	.p2align	3, 0x0
.L__const.TEST_CASE3.Vv3.37:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.Vv3.37, 128

	.type	.L__const.TEST_CASE3.vact.38,@object # @__const.TEST_CASE3.vact.38
	.p2align	3, 0x0
.L__const.TEST_CASE3.vact.38:
	.quad	73                              # 0x49
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE3.vact.38, 128

	.type	.L__const.TEST_CASE4.Vv1,@object # @__const.TEST_CASE4.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE4.Vv1:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE4.Vv1, 16

	.type	.L__const.TEST_CASE4.Vv2,@object # @__const.TEST_CASE4.Vv2
.L__const.TEST_CASE4.Vv2:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE4.Vv2, 16

	.type	.L__const.TEST_CASE4.Vv3,@object # @__const.TEST_CASE4.Vv3
.L__const.TEST_CASE4.Vv3:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE4.Vv3, 16

	.type	.L__const.TEST_CASE4.vact,@object # @__const.TEST_CASE4.vact
.L__const.TEST_CASE4.vact:
	.ascii	"A\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE4.vact, 16

	.type	.L__const.TEST_CASE4.Vv1.39,@object # @__const.TEST_CASE4.Vv1.39
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE4.Vv1.39:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv1.39, 32

	.type	.L__const.TEST_CASE4.Vv2.40,@object # @__const.TEST_CASE4.Vv2.40
	.p2align	1, 0x0
.L__const.TEST_CASE4.Vv2.40:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2.40, 32

	.type	.L__const.TEST_CASE4.Vv3.41,@object # @__const.TEST_CASE4.Vv3.41
	.p2align	1, 0x0
.L__const.TEST_CASE4.Vv3.41:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv3.41, 32

	.type	.L__const.TEST_CASE4.vact.42,@object # @__const.TEST_CASE4.vact.42
	.p2align	1, 0x0
.L__const.TEST_CASE4.vact.42:
	.half	2                               # 0x2
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact.42, 32

	.type	.L__const.TEST_CASE4.Vv1.43,@object # @__const.TEST_CASE4.Vv1.43
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv1.43:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv1.43, 64

	.type	.L__const.TEST_CASE4.Vv2.44,@object # @__const.TEST_CASE4.Vv2.44
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv2.44:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2.44, 64

	.type	.L__const.TEST_CASE4.Vv3.45,@object # @__const.TEST_CASE4.Vv3.45
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv3.45:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv3.45, 64

	.type	.L__const.TEST_CASE4.vact.46,@object # @__const.TEST_CASE4.vact.46
	.p2align	2, 0x0
.L__const.TEST_CASE4.vact.46:
	.word	7                               # 0x7
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact.46, 64

	.type	.L__const.TEST_CASE4.Vv1.47,@object # @__const.TEST_CASE4.Vv1.47
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv1.47:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv1.47, 128

	.type	.L__const.TEST_CASE4.Vv2.48,@object # @__const.TEST_CASE4.Vv2.48
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv2.48:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2.48, 128

	.type	.L__const.TEST_CASE4.Vv3.49,@object # @__const.TEST_CASE4.Vv3.49
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv3.49:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv3.49, 128

	.type	.L__const.TEST_CASE4.vact.50,@object # @__const.TEST_CASE4.vact.50
	.p2align	3, 0x0
.L__const.TEST_CASE4.vact.50:
	.quad	29                              # 0x1d
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact.50, 128

	.type	.L__const.TEST_CASE4.Vv1.51,@object # @__const.TEST_CASE4.Vv1.51
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv1.51:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv1.51, 128

	.type	.L__const.TEST_CASE4.Vv2.52,@object # @__const.TEST_CASE4.Vv2.52
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv2.52:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv2.52, 128

	.type	.L__const.TEST_CASE4.Vv3.53,@object # @__const.TEST_CASE4.Vv3.53
	.p2align	3, 0x0
.L__const.TEST_CASE4.Vv3.53:
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.Vv3.53, 128

	.type	.L__const.TEST_CASE4.vact.54,@object # @__const.TEST_CASE4.vact.54
	.p2align	3, 0x0
.L__const.TEST_CASE4.vact.54:
	.quad	65                              # 0x41
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.quad	1                               # 0x1
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.quad	8                               # 0x8
	.size	.L__const.TEST_CASE4.vact.54, 128

	.type	.L__const.TEST_CASE5.Vv0,@object # @__const.TEST_CASE5.Vv0
.L__const.TEST_CASE5.Vv0:
	.ascii	"\000@"
	.size	.L__const.TEST_CASE5.Vv0, 2

	.type	.L__const.TEST_CASE5.Vv1,@object # @__const.TEST_CASE5.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
.L__const.TEST_CASE5.Vv1:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE5.Vv1, 16

	.type	.L__const.TEST_CASE5.Vv2,@object # @__const.TEST_CASE5.Vv2
.L__const.TEST_CASE5.Vv2:
	.ascii	"d\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE5.Vv2, 16

	.type	.L__const.TEST_CASE5.Vv3,@object # @__const.TEST_CASE5.Vv3
.L__const.TEST_CASE5.Vv3:
	.ascii	"\001\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE5.Vv3, 16

	.type	.L__const.TEST_CASE5.vact,@object # @__const.TEST_CASE5.vact
.L__const.TEST_CASE5.vact:
	.ascii	"k\002\003\004\005\006\007\b\001\002\003\004\005\006\007\b"
	.size	.L__const.TEST_CASE5.vact, 16

	.type	.L__const.TEST_CASE5.Vv0.55,@object # @__const.TEST_CASE5.Vv0.55
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE5.Vv0.55:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE5.Vv0.55, 2

	.type	.L__const.TEST_CASE5.Vv1.56,@object # @__const.TEST_CASE5.Vv1.56
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	1, 0x0
.L__const.TEST_CASE5.Vv1.56:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv1.56, 32

	.type	.L__const.TEST_CASE5.Vv2.57,@object # @__const.TEST_CASE5.Vv2.57
	.p2align	1, 0x0
.L__const.TEST_CASE5.Vv2.57:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv2.57, 32

	.type	.L__const.TEST_CASE5.Vv3.58,@object # @__const.TEST_CASE5.Vv3.58
	.p2align	1, 0x0
.L__const.TEST_CASE5.Vv3.58:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv3.58, 32

	.type	.L__const.TEST_CASE5.vact.59,@object # @__const.TEST_CASE5.vact.59
	.p2align	1, 0x0
.L__const.TEST_CASE5.vact.59:
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.half	1                               # 0x1
	.half	2                               # 0x2
	.half	3                               # 0x3
	.half	4                               # 0x4
	.half	5                               # 0x5
	.half	6                               # 0x6
	.half	7                               # 0x7
	.half	8                               # 0x8
	.size	.L__const.TEST_CASE5.vact.59, 32

	.type	.L__const.TEST_CASE5.Vv0.60,@object # @__const.TEST_CASE5.Vv0.60
	.section	.rodata,"a",@progbits
.L__const.TEST_CASE5.Vv0.60:
	.ascii	"\252U"
	.size	.L__const.TEST_CASE5.Vv0.60, 2

	.type	.L__const.TEST_CASE5.Vv1.61,@object # @__const.TEST_CASE5.Vv1.61
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv1.61:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv1.61, 64

	.type	.L__const.TEST_CASE5.Vv2.62,@object # @__const.TEST_CASE5.Vv2.62
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv2.62:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv2.62, 64

	.type	.L__const.TEST_CASE5.Vv3.63,@object # @__const.TEST_CASE5.Vv3.63
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv3.63:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.Vv3.63, 64

	.type	.L__const.TEST_CASE5.vact.64,@object # @__const.TEST_CASE5.vact.64
	.p2align	2, 0x0
.L__const.TEST_CASE5.vact.64:
	.word	3                               # 0x3
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	5                               # 0x5
	.word	6                               # 0x6
	.word	7                               # 0x7
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE5.vact.64, 64

	.type	.L.str.65,@object               # @.str.65
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.65:
	.asciz	"TEST_CASE1"
	.size	.L.str.65, 11

	.type	.L.str.66,@object               # @.str.66
.L.str.66:
	.asciz	"TEST_CASE2"
	.size	.L.str.66, 11

	.type	.L.str.67,@object               # @.str.67
.L.str.67:
	.asciz	"TEST_CASE3"
	.size	.L.str.67, 11

	.type	.L.str.68,@object               # @.str.68
.L.str.68:
	.asciz	"TEST_CASE4"
	.size	.L.str.68, 11

	.type	.L.str.69,@object               # @.str.69
.L.str.69:
	.asciz	"TEST_CASE5"
	.size	.L.str.69, 11

	.type	.L.str.70,@object               # @.str.70
.L.str.70:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.70, 28

	.type	.L.str.71,@object               # @.str.71
.L.str.71:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c"
	.size	.L.str.71, 144

	.type	.L.str.72,@object               # @.str.72
.L.str.72:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.72, 13

	.type	.L_MergedGlobals,@object        # @_MergedGlobals
	.local	.L_MergedGlobals
	.comm	.L_MergedGlobals,1152,128
	.globl	num_failed
.set num_failed, .L_MergedGlobals
	.size	num_failed, 4
	.globl	test_case
.set test_case, .L_MergedGlobals+4
	.size	test_case, 4
.set Ru8, .L_MergedGlobals+128
	.size	Ru8, 1024
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.ascii	"\210\001"                      # DW_AT_alignment
	.byte	15                              # DW_FORM_udata
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	0                               # DW_CHILDREN_no
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0xbf2 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	15                              # DW_AT_low_pc
	.word	.Lfunc_end5-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x6d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	171                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x77:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x83:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	172                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	2                               # Abbrev [2] 0x8d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	173                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	2                               # Abbrev [2] 0x97:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	174                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	2                               # Abbrev [2] 0xa1:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	175                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	2                               # Abbrev [2] 0xab:0xa DW_TAG_variable
	.word	181                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	177                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xb5:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xba:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xc1:0xa DW_TAG_variable
	.word	203                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	177                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	3                               # Abbrev [3] 0xcb:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xd0:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	144                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xd7:0xa DW_TAG_variable
	.word	225                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	177                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	10
	.byte	3                               # Abbrev [3] 0xe1:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xe6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xed:0xd DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	250                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	3                               # Abbrev [3] 0xfa:0xd DW_TAG_array_type
	.word	263                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0xff:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x107:0x5 DW_TAG_volatile_type
	.word	268                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x10c:0x8 DW_TAG_typedef
	.word	276                             # DW_AT_type
	.byte	7                               # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x114:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x118:0xd DW_TAG_variable
	.byte	8                               # DW_AT_name
	.word	293                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	26                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	12
	.byte	3                               # Abbrev [3] 0x125:0xd DW_TAG_array_type
	.word	306                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x12a:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x132:0x5 DW_TAG_volatile_type
	.word	311                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x137:0x8 DW_TAG_typedef
	.word	319                             # DW_AT_type
	.byte	10                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x13f:0x4 DW_TAG_base_type
	.byte	9                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x143:0xd DW_TAG_variable
	.byte	11                              # DW_AT_name
	.word	336                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	13
	.byte	3                               # Abbrev [3] 0x150:0xd DW_TAG_array_type
	.word	349                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x155:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x15d:0x5 DW_TAG_volatile_type
	.word	354                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x162:0x8 DW_TAG_typedef
	.word	362                             # DW_AT_type
	.byte	13                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	247                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x16a:0x4 DW_TAG_base_type
	.byte	12                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	2                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x16e:0x10 DW_TAG_variable
	.byte	14                              # DW_AT_name
	.word	382                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	28                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	5                               # DW_AT_location
	.byte	161
	.byte	14
	.byte	35
	.ascii	"\200\001"
	.byte	3                               # Abbrev [3] 0x17e:0xd DW_TAG_array_type
	.word	395                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x183:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x18b:0x5 DW_TAG_volatile_type
	.word	400                             # DW_AT_type
	.byte	11                              # Abbrev [11] 0x190:0x9 DW_TAG_typedef
	.word	409                             # DW_AT_type
	.byte	16                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	270                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x199:0x4 DW_TAG_base_type
	.byte	15                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	12                              # Abbrev [12] 0x19d:0xb DW_TAG_variable
	.byte	17                              # DW_AT_name
	.word	424                             # DW_AT_type
                                        # DW_AT_external
	.byte	4                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	14
	.byte	5                               # Abbrev [5] 0x1a8:0x4 DW_TAG_base_type
	.byte	18                              # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	12                              # Abbrev [12] 0x1ac:0xd DW_TAG_variable
	.byte	19                              # DW_AT_name
	.word	424                             # DW_AT_type
                                        # DW_AT_external
	.byte	4                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	14
	.byte	35
	.byte	4
	.byte	13                              # Abbrev [13] 0x1b9:0x5 DW_TAG_pointer_type
	.word	400                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x1be:0x5 DW_TAG_pointer_type
	.word	354                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x1c3:0x5 DW_TAG_pointer_type
	.word	311                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x1c8:0x5 DW_TAG_pointer_type
	.word	268                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x1cd:0x183 DW_TAG_subprogram
	.byte	15                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	20                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x1d8:0x12 DW_TAG_lexical_block
	.byte	16                              # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x1de:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x1ea:0x12 DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x1f0:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	99
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.word	2877                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x1fc:0x36 DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp19-.Ltmp7                  # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x202:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	91
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	2889                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x20d:0x12 DW_TAG_lexical_block
	.byte	19                              # DW_AT_low_pc
	.word	.Ltmp9-.Ltmp8                   # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x213:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	441                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x21f:0x12 DW_TAG_lexical_block
	.byte	20                              # DW_AT_low_pc
	.word	.Ltmp18-.Ltmp10                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x225:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x232:0x13 DW_TAG_lexical_block
	.byte	21                              # DW_AT_low_pc
	.word	.Ltmp23-.Ltmp22                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x238:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	18                              # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x245:0x13 DW_TAG_lexical_block
	.byte	22                              # DW_AT_low_pc
	.word	.Ltmp25-.Ltmp24                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x24b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\262\177"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	19                              # DW_AT_decl_line
	.word	2913                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x258:0x39 DW_TAG_lexical_block
	.byte	23                              # DW_AT_low_pc
	.word	.Ltmp38-.Ltmp26                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x25e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\252\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	2925                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x26a:0x13 DW_TAG_lexical_block
	.byte	24                              # DW_AT_low_pc
	.word	.Ltmp28-.Ltmp27                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x270:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	446                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x27d:0x13 DW_TAG_lexical_block
	.byte	25                              # DW_AT_low_pc
	.word	.Ltmp37-.Ltmp29                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x283:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x291:0x13 DW_TAG_lexical_block
	.byte	26                              # DW_AT_low_pc
	.word	.Ltmp42-.Ltmp41                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x297:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\344~"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	24                              # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x2a4:0x13 DW_TAG_lexical_block
	.byte	27                              # DW_AT_low_pc
	.word	.Ltmp44-.Ltmp43                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x2aa:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\340~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	2949                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x2b7:0x39 DW_TAG_lexical_block
	.byte	28                              # DW_AT_low_pc
	.word	.Ltmp57-.Ltmp45                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x2bd:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	2961                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x2c9:0x13 DW_TAG_lexical_block
	.byte	29                              # DW_AT_low_pc
	.word	.Ltmp47-.Ltmp46                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x2cf:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\334~"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	451                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x2dc:0x13 DW_TAG_lexical_block
	.byte	30                              # DW_AT_low_pc
	.word	.Ltmp56-.Ltmp48                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x2e2:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x2f0:0x13 DW_TAG_lexical_block
	.byte	31                              # DW_AT_low_pc
	.word	.Ltmp61-.Ltmp60                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x2f6:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320}"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	30                              # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x303:0x13 DW_TAG_lexical_block
	.byte	32                              # DW_AT_low_pc
	.word	.Ltmp63-.Ltmp62                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x309:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310}"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	31                              # DW_AT_decl_line
	.word	2985                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x316:0x39 DW_TAG_lexical_block
	.byte	33                              # DW_AT_low_pc
	.word	.Ltmp76-.Ltmp64                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x31c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\270}"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	33                              # DW_AT_decl_line
	.word	2997                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x328:0x13 DW_TAG_lexical_block
	.byte	34                              # DW_AT_low_pc
	.word	.Ltmp66-.Ltmp65                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x32e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304}"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	33                              # DW_AT_decl_line
	.word	456                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x33b:0x13 DW_TAG_lexical_block
	.byte	35                              # DW_AT_low_pc
	.word	.Ltmp75-.Ltmp67                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x341:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264}"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	33                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x350:0x218 DW_TAG_subprogram
	.byte	36                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	21                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	37                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x35b:0x12 DW_TAG_lexical_block
	.byte	37                              # DW_AT_low_pc
	.word	.Ltmp82-.Ltmp81                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x361:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	114
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	39                              # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x36d:0x12 DW_TAG_lexical_block
	.byte	38                              # DW_AT_low_pc
	.word	.Ltmp84-.Ltmp83                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x373:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	40                              # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x37f:0x12 DW_TAG_lexical_block
	.byte	39                              # DW_AT_low_pc
	.word	.Ltmp86-.Ltmp85                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x385:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	95
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	41                              # DW_AT_decl_line
	.word	2877                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x391:0x12 DW_TAG_lexical_block
	.byte	40                              # DW_AT_low_pc
	.word	.Ltmp88-.Ltmp87                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x397:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	94
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	42                              # DW_AT_decl_line
	.word	2877                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x3a3:0x36 DW_TAG_lexical_block
	.byte	41                              # DW_AT_low_pc
	.word	.Ltmp101-.Ltmp89                # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x3a9:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	87
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	44                              # DW_AT_decl_line
	.word	2889                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x3b4:0x12 DW_TAG_lexical_block
	.byte	42                              # DW_AT_low_pc
	.word	.Ltmp91-.Ltmp90                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x3ba:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	44                              # DW_AT_decl_line
	.word	441                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x3c6:0x12 DW_TAG_lexical_block
	.byte	43                              # DW_AT_low_pc
	.word	.Ltmp100-.Ltmp92                # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x3cc:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	44                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x3d9:0x12 DW_TAG_lexical_block
	.byte	44                              # DW_AT_low_pc
	.word	.Ltmp105-.Ltmp104               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x3df:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	78
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	47                              # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x3eb:0x13 DW_TAG_lexical_block
	.byte	45                              # DW_AT_low_pc
	.word	.Ltmp107-.Ltmp106               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x3f1:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	48                              # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x3fe:0x13 DW_TAG_lexical_block
	.byte	46                              # DW_AT_low_pc
	.word	.Ltmp109-.Ltmp108               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x404:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\252\177"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	49                              # DW_AT_decl_line
	.word	2913                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x411:0x13 DW_TAG_lexical_block
	.byte	47                              # DW_AT_low_pc
	.word	.Ltmp111-.Ltmp110               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x417:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
	.word	2913                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x424:0x39 DW_TAG_lexical_block
	.byte	48                              # DW_AT_low_pc
	.word	.Ltmp124-.Ltmp112               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x42a:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\242\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	52                              # DW_AT_decl_line
	.word	2925                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x436:0x13 DW_TAG_lexical_block
	.byte	49                              # DW_AT_low_pc
	.word	.Ltmp114-.Ltmp113               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x43c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	52                              # DW_AT_decl_line
	.word	446                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x449:0x13 DW_TAG_lexical_block
	.byte	50                              # DW_AT_low_pc
	.word	.Ltmp123-.Ltmp115               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x44f:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	52                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x45d:0x13 DW_TAG_lexical_block
	.byte	51                              # DW_AT_low_pc
	.word	.Ltmp128-.Ltmp127               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x463:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\232\177"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x470:0x13 DW_TAG_lexical_block
	.byte	52                              # DW_AT_low_pc
	.word	.Ltmp130-.Ltmp129               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x476:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330~"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	56                              # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x483:0x13 DW_TAG_lexical_block
	.byte	53                              # DW_AT_low_pc
	.word	.Ltmp132-.Ltmp131               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x489:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	57                              # DW_AT_decl_line
	.word	2949                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x496:0x13 DW_TAG_lexical_block
	.byte	54                              # DW_AT_low_pc
	.word	.Ltmp134-.Ltmp133               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x49c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320~"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	58                              # DW_AT_decl_line
	.word	2949                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x4a9:0x39 DW_TAG_lexical_block
	.byte	55                              # DW_AT_low_pc
	.word	.Ltmp147-.Ltmp135               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x4af:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	60                              # DW_AT_decl_line
	.word	2961                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x4bb:0x13 DW_TAG_lexical_block
	.byte	56                              # DW_AT_low_pc
	.word	.Ltmp137-.Ltmp136               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x4c1:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\314~"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	60                              # DW_AT_decl_line
	.word	451                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x4ce:0x13 DW_TAG_lexical_block
	.byte	57                              # DW_AT_low_pc
	.word	.Ltmp146-.Ltmp138               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x4d4:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	60                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x4e2:0x13 DW_TAG_lexical_block
	.byte	58                              # DW_AT_low_pc
	.word	.Ltmp151-.Ltmp150               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x4e8:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\302~"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	63                              # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x4f5:0x13 DW_TAG_lexical_block
	.byte	59                              # DW_AT_low_pc
	.word	.Ltmp153-.Ltmp152               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x4fb:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\300}"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x508:0x13 DW_TAG_lexical_block
	.byte	60                              # DW_AT_low_pc
	.word	.Ltmp155-.Ltmp154               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x50e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\270}"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	65                              # DW_AT_decl_line
	.word	2985                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x51b:0x13 DW_TAG_lexical_block
	.byte	61                              # DW_AT_low_pc
	.word	.Ltmp157-.Ltmp156               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x521:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260}"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	66                              # DW_AT_decl_line
	.word	2985                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x52e:0x39 DW_TAG_lexical_block
	.byte	62                              # DW_AT_low_pc
	.word	.Ltmp170-.Ltmp158               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x534:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240}"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	68                              # DW_AT_decl_line
	.word	2997                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x540:0x13 DW_TAG_lexical_block
	.byte	63                              # DW_AT_low_pc
	.word	.Ltmp160-.Ltmp159               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x546:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254}"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	68                              # DW_AT_decl_line
	.word	456                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x553:0x13 DW_TAG_lexical_block
	.byte	64                              # DW_AT_low_pc
	.word	.Ltmp169-.Ltmp161               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x559:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234}"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	68                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x568:0x1d0 DW_TAG_subprogram
	.byte	65                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin2       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	22                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x573:0x12 DW_TAG_lexical_block
	.byte	66                              # DW_AT_low_pc
	.word	.Ltmp176-.Ltmp175               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x579:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	74                              # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x585:0x12 DW_TAG_lexical_block
	.byte	67                              # DW_AT_low_pc
	.word	.Ltmp178-.Ltmp177               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x58b:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	75                              # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x597:0x12 DW_TAG_lexical_block
	.byte	68                              # DW_AT_low_pc
	.word	.Ltmp180-.Ltmp179               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x59d:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	76                              # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x5a9:0x38 DW_TAG_lexical_block
	.byte	69                              # DW_AT_low_pc
	.word	.Ltmp193-.Ltmp181               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x5af:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.word	3021                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x5bb:0x12 DW_TAG_lexical_block
	.byte	70                              # DW_AT_low_pc
	.word	.Ltmp183-.Ltmp182               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x5c1:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.word	441                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x5cd:0x13 DW_TAG_lexical_block
	.byte	71                              # DW_AT_low_pc
	.word	.Ltmp192-.Ltmp184               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x5d3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x5e1:0x13 DW_TAG_lexical_block
	.byte	72                              # DW_AT_low_pc
	.word	.Ltmp197-.Ltmp196               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x5e7:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\214\177"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	81                              # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x5f4:0x13 DW_TAG_lexical_block
	.byte	73                              # DW_AT_low_pc
	.word	.Ltmp199-.Ltmp198               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x5fa:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\354~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	82                              # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x607:0x13 DW_TAG_lexical_block
	.byte	74                              # DW_AT_low_pc
	.word	.Ltmp201-.Ltmp200               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x60d:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\314~"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	83                              # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x61a:0x39 DW_TAG_lexical_block
	.byte	75                              # DW_AT_low_pc
	.word	.Ltmp214-.Ltmp202               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x620:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	85                              # DW_AT_decl_line
	.word	3033                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x62c:0x13 DW_TAG_lexical_block
	.byte	76                              # DW_AT_low_pc
	.word	.Ltmp204-.Ltmp203               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x632:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310~"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	85                              # DW_AT_decl_line
	.word	446                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x63f:0x13 DW_TAG_lexical_block
	.byte	77                              # DW_AT_low_pc
	.word	.Ltmp213-.Ltmp205               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x645:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	85                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x653:0x13 DW_TAG_lexical_block
	.byte	78                              # DW_AT_low_pc
	.word	.Ltmp218-.Ltmp217               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x659:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\344}"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	88                              # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x666:0x13 DW_TAG_lexical_block
	.byte	79                              # DW_AT_low_pc
	.word	.Ltmp220-.Ltmp219               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x66c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244}"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	89                              # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x679:0x13 DW_TAG_lexical_block
	.byte	80                              # DW_AT_low_pc
	.word	.Ltmp222-.Ltmp221               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x67f:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\344|"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	90                              # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x68c:0x39 DW_TAG_lexical_block
	.byte	81                              # DW_AT_low_pc
	.word	.Ltmp235-.Ltmp223               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x692:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240|"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	92                              # DW_AT_decl_line
	.word	3045                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x69e:0x13 DW_TAG_lexical_block
	.byte	82                              # DW_AT_low_pc
	.word	.Ltmp225-.Ltmp224               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x6a4:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\340|"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	92                              # DW_AT_decl_line
	.word	451                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x6b1:0x13 DW_TAG_lexical_block
	.byte	83                              # DW_AT_low_pc
	.word	.Ltmp234-.Ltmp226               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x6b7:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234|"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	92                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x6c5:0x13 DW_TAG_lexical_block
	.byte	84                              # DW_AT_low_pc
	.word	.Ltmp239-.Ltmp238               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x6cb:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230{"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	95                              # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x6d8:0x13 DW_TAG_lexical_block
	.byte	85                              # DW_AT_low_pc
	.word	.Ltmp241-.Ltmp240               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x6de:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230z"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	96                              # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x6eb:0x13 DW_TAG_lexical_block
	.byte	86                              # DW_AT_low_pc
	.word	.Ltmp243-.Ltmp242               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x6f1:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230y"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	97                              # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x6fe:0x39 DW_TAG_lexical_block
	.byte	87                              # DW_AT_low_pc
	.word	.Ltmp256-.Ltmp244               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x704:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\220x"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	99                              # DW_AT_decl_line
	.word	3057                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x710:0x13 DW_TAG_lexical_block
	.byte	88                              # DW_AT_low_pc
	.word	.Ltmp246-.Ltmp245               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x716:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224y"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	99                              # DW_AT_decl_line
	.word	456                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x723:0x13 DW_TAG_lexical_block
	.byte	89                              # DW_AT_low_pc
	.word	.Ltmp255-.Ltmp247               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x729:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\214x"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	99                              # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x738:0x243 DW_TAG_subprogram
	.byte	90                              # DW_AT_low_pc
	.word	.Lfunc_end3-.Lfunc_begin3       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	23                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	103                             # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x743:0x12 DW_TAG_lexical_block
	.byte	91                              # DW_AT_low_pc
	.word	.Ltmp262-.Ltmp261               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x749:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	105                             # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x755:0x12 DW_TAG_lexical_block
	.byte	92                              # DW_AT_low_pc
	.word	.Ltmp264-.Ltmp263               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x75b:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	106                             # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x767:0x12 DW_TAG_lexical_block
	.byte	93                              # DW_AT_low_pc
	.word	.Ltmp266-.Ltmp265               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x76d:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	107                             # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x779:0x39 DW_TAG_lexical_block
	.byte	94                              # DW_AT_low_pc
	.word	.Ltmp279-.Ltmp267               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x77f:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	109                             # DW_AT_decl_line
	.word	3021                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x78b:0x13 DW_TAG_lexical_block
	.byte	95                              # DW_AT_low_pc
	.word	.Ltmp269-.Ltmp268               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x791:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274\177"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	109                             # DW_AT_decl_line
	.word	441                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x79e:0x13 DW_TAG_lexical_block
	.byte	96                              # DW_AT_low_pc
	.word	.Ltmp278-.Ltmp270               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x7a4:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	109                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x7b2:0x13 DW_TAG_lexical_block
	.byte	97                              # DW_AT_low_pc
	.word	.Ltmp283-.Ltmp282               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x7b8:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\210\177"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	112                             # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x7c5:0x13 DW_TAG_lexical_block
	.byte	98                              # DW_AT_low_pc
	.word	.Ltmp285-.Ltmp284               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x7cb:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\350~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	113                             # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x7d8:0x13 DW_TAG_lexical_block
	.byte	99                              # DW_AT_low_pc
	.word	.Ltmp287-.Ltmp286               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x7de:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310~"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	114                             # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x7eb:0x39 DW_TAG_lexical_block
	.byte	100                             # DW_AT_low_pc
	.word	.Ltmp300-.Ltmp288               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x7f1:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	116                             # DW_AT_decl_line
	.word	3033                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x7fd:0x13 DW_TAG_lexical_block
	.byte	101                             # DW_AT_low_pc
	.word	.Ltmp290-.Ltmp289               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x803:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304~"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	116                             # DW_AT_decl_line
	.word	446                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x810:0x13 DW_TAG_lexical_block
	.byte	102                             # DW_AT_low_pc
	.word	.Ltmp299-.Ltmp291               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x816:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	116                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x824:0x13 DW_TAG_lexical_block
	.byte	103                             # DW_AT_low_pc
	.word	.Ltmp304-.Ltmp303               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x82a:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\340}"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	119                             # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x837:0x13 DW_TAG_lexical_block
	.byte	104                             # DW_AT_low_pc
	.word	.Ltmp306-.Ltmp305               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x83d:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240}"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	120                             # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x84a:0x13 DW_TAG_lexical_block
	.byte	105                             # DW_AT_low_pc
	.word	.Ltmp308-.Ltmp307               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x850:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\340|"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x85d:0x39 DW_TAG_lexical_block
	.byte	106                             # DW_AT_low_pc
	.word	.Ltmp321-.Ltmp309               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x863:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234|"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	123                             # DW_AT_decl_line
	.word	3045                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x86f:0x13 DW_TAG_lexical_block
	.byte	107                             # DW_AT_low_pc
	.word	.Ltmp311-.Ltmp310               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x875:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\334|"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	123                             # DW_AT_decl_line
	.word	451                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x882:0x13 DW_TAG_lexical_block
	.byte	108                             # DW_AT_low_pc
	.word	.Ltmp320-.Ltmp312               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x888:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230|"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	123                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x896:0x13 DW_TAG_lexical_block
	.byte	109                             # DW_AT_low_pc
	.word	.Ltmp325-.Ltmp324               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x89c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230{"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	126                             # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x8a9:0x13 DW_TAG_lexical_block
	.byte	110                             # DW_AT_low_pc
	.word	.Ltmp327-.Ltmp326               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x8af:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230z"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	127                             # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x8bc:0x13 DW_TAG_lexical_block
	.byte	111                             # DW_AT_low_pc
	.word	.Ltmp329-.Ltmp328               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x8c2:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230y"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	128                             # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x8cf:0x39 DW_TAG_lexical_block
	.byte	112                             # DW_AT_low_pc
	.word	.Ltmp342-.Ltmp330               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x8d5:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\220x"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	130                             # DW_AT_decl_line
	.word	3057                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x8e1:0x13 DW_TAG_lexical_block
	.byte	113                             # DW_AT_low_pc
	.word	.Ltmp332-.Ltmp331               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x8e7:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224y"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	130                             # DW_AT_decl_line
	.word	456                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x8f4:0x13 DW_TAG_lexical_block
	.byte	114                             # DW_AT_low_pc
	.word	.Ltmp341-.Ltmp333               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x8fa:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\214x"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	130                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x908:0x13 DW_TAG_lexical_block
	.byte	115                             # DW_AT_low_pc
	.word	.Ltmp346-.Ltmp345               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x90e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\210w"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	133                             # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x91b:0x13 DW_TAG_lexical_block
	.byte	116                             # DW_AT_low_pc
	.word	.Ltmp348-.Ltmp347               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x921:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\210v"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	134                             # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x92e:0x13 DW_TAG_lexical_block
	.byte	117                             # DW_AT_low_pc
	.word	.Ltmp350-.Ltmp349               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x934:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\210u"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	135                             # DW_AT_decl_line
	.word	2973                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x941:0x39 DW_TAG_lexical_block
	.byte	118                             # DW_AT_low_pc
	.word	.Ltmp363-.Ltmp351               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x947:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\200t"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	137                             # DW_AT_decl_line
	.word	3057                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x953:0x13 DW_TAG_lexical_block
	.byte	119                             # DW_AT_low_pc
	.word	.Ltmp353-.Ltmp352               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x959:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\204u"
	.byte	33                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	137                             # DW_AT_decl_line
	.word	456                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x966:0x13 DW_TAG_lexical_block
	.byte	120                             # DW_AT_low_pc
	.word	.Ltmp362-.Ltmp354               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x96c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\374s"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	137                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x97b:0x1a6 DW_TAG_subprogram
	.byte	121                             # DW_AT_low_pc
	.word	.Lfunc_end4-.Lfunc_begin4       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	141                             # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x986:0x12 DW_TAG_lexical_block
	.byte	122                             # DW_AT_low_pc
	.word	.Ltmp369-.Ltmp368               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x98c:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	114
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	143                             # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x998:0x12 DW_TAG_lexical_block
	.byte	123                             # DW_AT_low_pc
	.word	.Ltmp371-.Ltmp370               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x99e:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	144                             # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x9aa:0x12 DW_TAG_lexical_block
	.byte	124                             # DW_AT_low_pc
	.word	.Ltmp373-.Ltmp372               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x9b0:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	145                             # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x9bc:0x12 DW_TAG_lexical_block
	.byte	125                             # DW_AT_low_pc
	.word	.Ltmp375-.Ltmp374               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x9c2:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	146                             # DW_AT_decl_line
	.word	2865                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x9ce:0x3a DW_TAG_lexical_block
	.byte	126                             # DW_AT_low_pc
	.word	.Ltmp388-.Ltmp376               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x9d4:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	148                             # DW_AT_decl_line
	.word	3021                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x9e0:0x13 DW_TAG_lexical_block
	.byte	127                             # DW_AT_low_pc
	.word	.Ltmp378-.Ltmp377               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x9e6:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274\177"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	148                             # DW_AT_decl_line
	.word	441                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x9f3:0x14 DW_TAG_lexical_block
	.ascii	"\200\001"                      # DW_AT_low_pc
	.word	.Ltmp387-.Ltmp379               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x9fa:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	148                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa08:0x14 DW_TAG_lexical_block
	.ascii	"\201\001"                      # DW_AT_low_pc
	.word	.Ltmp392-.Ltmp391               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa0f:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\246\177"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	151                             # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa1c:0x14 DW_TAG_lexical_block
	.ascii	"\202\001"                      # DW_AT_low_pc
	.word	.Ltmp394-.Ltmp393               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa23:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\204\177"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	152                             # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa30:0x14 DW_TAG_lexical_block
	.ascii	"\203\001"                      # DW_AT_low_pc
	.word	.Ltmp396-.Ltmp395               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa37:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\344~"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	153                             # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa44:0x14 DW_TAG_lexical_block
	.ascii	"\204\001"                      # DW_AT_low_pc
	.word	.Ltmp398-.Ltmp397               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa4b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304~"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	154                             # DW_AT_decl_line
	.word	2901                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa58:0x3c DW_TAG_lexical_block
	.ascii	"\205\001"                      # DW_AT_low_pc
	.word	.Ltmp411-.Ltmp399               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa5f:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240~"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	156                             # DW_AT_decl_line
	.word	3033                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0xa6b:0x14 DW_TAG_lexical_block
	.ascii	"\206\001"                      # DW_AT_low_pc
	.word	.Ltmp401-.Ltmp400               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa72:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\300~"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	156                             # DW_AT_decl_line
	.word	446                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa7f:0x14 DW_TAG_lexical_block
	.ascii	"\207\001"                      # DW_AT_low_pc
	.word	.Ltmp410-.Ltmp402               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa86:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\234~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	156                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xa94:0x14 DW_TAG_lexical_block
	.ascii	"\210\001"                      # DW_AT_low_pc
	.word	.Ltmp415-.Ltmp414               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xa9b:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\232~"
	.byte	34                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	159                             # DW_AT_decl_line
	.word	3009                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xaa8:0x14 DW_TAG_lexical_block
	.ascii	"\211\001"                      # DW_AT_low_pc
	.word	.Ltmp417-.Ltmp416               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xaaf:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330}"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	160                             # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xabc:0x14 DW_TAG_lexical_block
	.ascii	"\212\001"                      # DW_AT_low_pc
	.word	.Ltmp419-.Ltmp418               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xac3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230}"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	161                             # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xad0:0x14 DW_TAG_lexical_block
	.ascii	"\213\001"                      # DW_AT_low_pc
	.word	.Ltmp421-.Ltmp420               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xad7:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330|"
	.byte	35                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	162                             # DW_AT_decl_line
	.word	2937                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xae4:0x3c DW_TAG_lexical_block
	.ascii	"\214\001"                      # DW_AT_low_pc
	.word	.Ltmp434-.Ltmp422               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xaeb:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224|"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	164                             # DW_AT_decl_line
	.word	3045                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0xaf7:0x14 DW_TAG_lexical_block
	.ascii	"\215\001"                      # DW_AT_low_pc
	.word	.Ltmp424-.Ltmp423               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xafe:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\324|"
	.byte	32                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	164                             # DW_AT_decl_line
	.word	451                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xb0b:0x14 DW_TAG_lexical_block
	.ascii	"\216\001"                      # DW_AT_low_pc
	.word	.Ltmp433-.Ltmp425               # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0xb12:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\220|"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	164                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0xb21:0x10 DW_TAG_subprogram
	.ascii	"\217\001"                      # DW_AT_low_pc
	.word	.Lfunc_end5-.Lfunc_begin5       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	25                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	167                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	424                             # DW_AT_type
                                        # DW_AT_external
	.byte	3                               # Abbrev [3] 0xb31:0xc DW_TAG_array_type
	.word	395                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb36:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb3d:0xc DW_TAG_array_type
	.word	395                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb42:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb49:0xc DW_TAG_array_type
	.word	400                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb4e:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb55:0xc DW_TAG_array_type
	.word	349                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb5a:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb61:0xc DW_TAG_array_type
	.word	349                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb6d:0xc DW_TAG_array_type
	.word	354                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb72:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb79:0xc DW_TAG_array_type
	.word	306                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb7e:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb85:0xc DW_TAG_array_type
	.word	306                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb8a:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb91:0xc DW_TAG_array_type
	.word	311                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb96:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xb9d:0xc DW_TAG_array_type
	.word	263                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xba2:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xba9:0xc DW_TAG_array_type
	.word	263                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbae:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xbb5:0xc DW_TAG_array_type
	.word	268                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbba:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xbc1:0xc DW_TAG_array_type
	.word	395                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbc6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	2                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xbcd:0xc DW_TAG_array_type
	.word	400                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbd2:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xbd9:0xc DW_TAG_array_type
	.word	354                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbde:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xbe5:0xc DW_TAG_array_type
	.word	311                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbea:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0xbf1:0xc DW_TAG_array_type
	.word	268                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbf6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	148                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara-remainder52/adapter/context_original_vredsum.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=230
.Linfo_string3:
	.asciz	"char"                          # string offset=282
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=287
.Linfo_string5:
	.asciz	"Ru64"                          # string offset=307
.Linfo_string6:
	.asciz	"unsigned long long"            # string offset=312
.Linfo_string7:
	.asciz	"uint64_t"                      # string offset=331
.Linfo_string8:
	.asciz	"Ru32"                          # string offset=340
.Linfo_string9:
	.asciz	"unsigned int"                  # string offset=345
.Linfo_string10:
	.asciz	"uint32_t"                      # string offset=358
.Linfo_string11:
	.asciz	"Ru16"                          # string offset=367
.Linfo_string12:
	.asciz	"unsigned short"                # string offset=372
.Linfo_string13:
	.asciz	"uint16_t"                      # string offset=387
.Linfo_string14:
	.asciz	"Ru8"                           # string offset=396
.Linfo_string15:
	.asciz	"unsigned char"                 # string offset=400
.Linfo_string16:
	.asciz	"uint8_t"                       # string offset=414
.Linfo_string17:
	.asciz	"num_failed"                    # string offset=422
.Linfo_string18:
	.asciz	"int"                           # string offset=433
.Linfo_string19:
	.asciz	"test_case"                     # string offset=437
.Linfo_string20:
	.asciz	"TEST_CASE1"                    # string offset=447
.Linfo_string21:
	.asciz	"TEST_CASE2"                    # string offset=458
.Linfo_string22:
	.asciz	"TEST_CASE3"                    # string offset=469
.Linfo_string23:
	.asciz	"TEST_CASE4"                    # string offset=480
.Linfo_string24:
	.asciz	"TEST_CASE5"                    # string offset=491
.Linfo_string25:
	.asciz	"main"                          # string offset=502
.Linfo_string26:
	.asciz	"Vv1"                           # string offset=507
.Linfo_string27:
	.asciz	"Vv2"                           # string offset=511
.Linfo_string28:
	.asciz	"Ru8_t"                         # string offset=515
.Linfo_string29:
	.asciz	"vact"                          # string offset=521
.Linfo_string30:
	.asciz	"i"                             # string offset=526
.Linfo_string31:
	.asciz	"Ru16_t"                        # string offset=528
.Linfo_string32:
	.asciz	"Ru32_t"                        # string offset=535
.Linfo_string33:
	.asciz	"Ru64_t"                        # string offset=542
.Linfo_string34:
	.asciz	"Vv0"                           # string offset=549
.Linfo_string35:
	.asciz	"Vv3"                           # string offset=553
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.word	.Linfo_string25
	.word	.Linfo_string26
	.word	.Linfo_string27
	.word	.Linfo_string28
	.word	.Linfo_string29
	.word	.Linfo_string30
	.word	.Linfo_string31
	.word	.Linfo_string32
	.word	.Linfo_string33
	.word	.Linfo_string34
	.word	.Linfo_string35
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.65
	.word	.L.str.66
	.word	.L.str.67
	.word	.L.str.68
	.word	.L.str.69
	.word	.L.str.70
	.word	.L.str.71
	.word	.L.str.72
	.word	Ru64
	.word	Ru32
	.word	Ru16
	.word	.L_MergedGlobals
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Ltmp8
	.word	.Ltmp10
	.word	.Ltmp22
	.word	.Ltmp24
	.word	.Ltmp26
	.word	.Ltmp27
	.word	.Ltmp29
	.word	.Ltmp41
	.word	.Ltmp43
	.word	.Ltmp45
	.word	.Ltmp46
	.word	.Ltmp48
	.word	.Ltmp60
	.word	.Ltmp62
	.word	.Ltmp64
	.word	.Ltmp65
	.word	.Ltmp67
	.word	.Lfunc_begin1
	.word	.Ltmp81
	.word	.Ltmp83
	.word	.Ltmp85
	.word	.Ltmp87
	.word	.Ltmp89
	.word	.Ltmp90
	.word	.Ltmp92
	.word	.Ltmp104
	.word	.Ltmp106
	.word	.Ltmp108
	.word	.Ltmp110
	.word	.Ltmp112
	.word	.Ltmp113
	.word	.Ltmp115
	.word	.Ltmp127
	.word	.Ltmp129
	.word	.Ltmp131
	.word	.Ltmp133
	.word	.Ltmp135
	.word	.Ltmp136
	.word	.Ltmp138
	.word	.Ltmp150
	.word	.Ltmp152
	.word	.Ltmp154
	.word	.Ltmp156
	.word	.Ltmp158
	.word	.Ltmp159
	.word	.Ltmp161
	.word	.Lfunc_begin2
	.word	.Ltmp175
	.word	.Ltmp177
	.word	.Ltmp179
	.word	.Ltmp181
	.word	.Ltmp182
	.word	.Ltmp184
	.word	.Ltmp196
	.word	.Ltmp198
	.word	.Ltmp200
	.word	.Ltmp202
	.word	.Ltmp203
	.word	.Ltmp205
	.word	.Ltmp217
	.word	.Ltmp219
	.word	.Ltmp221
	.word	.Ltmp223
	.word	.Ltmp224
	.word	.Ltmp226
	.word	.Ltmp238
	.word	.Ltmp240
	.word	.Ltmp242
	.word	.Ltmp244
	.word	.Ltmp245
	.word	.Ltmp247
	.word	.Lfunc_begin3
	.word	.Ltmp261
	.word	.Ltmp263
	.word	.Ltmp265
	.word	.Ltmp267
	.word	.Ltmp268
	.word	.Ltmp270
	.word	.Ltmp282
	.word	.Ltmp284
	.word	.Ltmp286
	.word	.Ltmp288
	.word	.Ltmp289
	.word	.Ltmp291
	.word	.Ltmp303
	.word	.Ltmp305
	.word	.Ltmp307
	.word	.Ltmp309
	.word	.Ltmp310
	.word	.Ltmp312
	.word	.Ltmp324
	.word	.Ltmp326
	.word	.Ltmp328
	.word	.Ltmp330
	.word	.Ltmp331
	.word	.Ltmp333
	.word	.Ltmp345
	.word	.Ltmp347
	.word	.Ltmp349
	.word	.Ltmp351
	.word	.Ltmp352
	.word	.Ltmp354
	.word	.Lfunc_begin4
	.word	.Ltmp368
	.word	.Ltmp370
	.word	.Ltmp372
	.word	.Ltmp374
	.word	.Ltmp376
	.word	.Ltmp377
	.word	.Ltmp379
	.word	.Ltmp391
	.word	.Ltmp393
	.word	.Ltmp395
	.word	.Ltmp397
	.word	.Ltmp399
	.word	.Ltmp400
	.word	.Ltmp402
	.word	.Ltmp414
	.word	.Ltmp416
	.word	.Ltmp418
	.word	.Ltmp420
	.word	.Ltmp422
	.word	.Ltmp423
	.word	.Ltmp425
	.word	.Lfunc_begin5
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
