import subprocess,json
from pathlib import Path
R=Path(__file__).resolve().parent
records=[]
for name in ['context_original_vredsum','context_original_vwredsum','context_original_vwredsumu']:
 for arm in ['M1','M2','BOTH']:
  if name=='context_original_vredsum'and arm=='M1':continue
  cmd=['ssh','xbd','python3 /home/vick/ara82/runner.py '+name+' '+arm]
  p=subprocess.run(cmd,capture_output=True);(R/'logs'/(name+'-'+arm+'.launch.stdout')).write_bytes(p.stdout);(R/'logs'/(name+'-'+arm+'.launch.stderr')).write_bytes(p.stderr);records.append(dict(command=cmd,returncode=p.returncode));(R/'LAUNCH_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n');print(name,arm,p.returncode,p.stdout.decode(),flush=True)
