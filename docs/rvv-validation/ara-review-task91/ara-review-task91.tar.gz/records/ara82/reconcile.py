import csv,json,collections,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;W=R.parents[2];A=W/'artifacts/external_suite_coverage_20261007'
read=lambda p:list(csv.DictReader(p.open()));j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
def csvout(n,rows):
 with (R/n).open('w')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
fc=[r for r in read(A/'ara/FORM_COVERAGE.csv')if r['rv32_denominator']=='REQUIRED'and r['native_assertion_covered']=='True'];ts=read(A/'ara/ASSERTION_TARGETS.csv');ledger=[r for r in read(A/'SUITE_RUN_MANIFEST.csv')if r['suite']=='Ara'];sources={(Path(r['source_file']).name,r['source_case']):r for r in ledger if r['row_kind']=='SOURCE_CASE'};bindings=[r for r in read(A/'ACTUAL_FORM_VALIDATION_BINDINGS.csv')if r['suite']=='Ara'];checked=set();emitted=set()
for r in bindings:
 emitted.update(filter(None,r['emitted_forms'].split(';')))
 if r['acceptance']=='ACCEPTED_SCOPED':checked.update(filter(None,r['result_checked_forms'].split(';')))
forms=[];assertions=[];details={};counts=collections.Counter()
for f in fc:
 form=f['form'];targets=[t for t in ts if t['form']==form];bbs=[b for b in bindings if form in b['target_forms'].split(';')];srcs=[sources[(Path(t['path']).name,t['function'])]for t in targets];statuses=collections.Counter(s['dut_status']for s in srcs)
 if form in checked:category='CANONICAL_ACCEPTED'
 elif statuses.get('PASS'):category='REUSED_PER_FUNCTION_PASS_JOIN_OMISSION'
 elif set(statuses)=={'N/A'}:category='ORIGINAL_FUNCTION_PROFILE_BLOCKED'
 else:category='ORIGINAL_CHECKER_OR_INPUT_BLOCKED'
 counts[category]+=1
 entries=[]
 for t,s in zip(targets,srcs):
  raw=A/'ara/raw/source'/t['path'];lines=raw.read_text().splitlines();entry=dict(t,source_absolute=str(raw),source_sha256=sha(raw),instruction_text=lines[int(t['line'])-1],checker_text=lines[int(t['checker_line'])-1]if t['checker_line'].isdigit()else t['checker_proof'],ledger_row_id=s['row_id'],source_disposition=s['dut_status'],blocker=s['blocker'],source_result=s['result_evidence'],execution_joins=s['aliases_json'])
  entries.append(entry);assertions.append(dict(form=form,source=str(raw),function=t['function'],instruction_line=t['line'],checker_line=t['checker_line'],instruction=entry['instruction_text'],checker=entry['checker_text'],required_extension=t['required_extension'],required_xlen=t['required_xlen'],source_row_id=s['row_id'],source_disposition=s['dut_status'],blocker=s['blocker'],result_evidence=s['result_evidence'],execution_joins=s['aliases_json']))
 perfunction=[]
 if category=='REUSED_PER_FUNCTION_PASS_JOIN_OMISSION':
  stem=Path(targets[0]['path']).stem
  for arm in ['B','M1','M2','BOTH']:
   p=R.parent/'ara-remainder52/remote-raw'/('batch_'+stem)/arm;cr=j(p/'case-results.json');accepted=[x for x in cr if x['function']in {t['function']for t in targets}and x['status']=='PASS'];assert accepted
   perfunction.append(dict(arm=arm,passing_functions=[x['function']for x in accepted],raw=str(p/'stdout'),case_results=str(p/'case-results.json'),group_result=str(p/'result.json'),group_status=j(p/'result.json')['status']))
 details[form]=dict(category=category,emitted_in_existing_binding=form in emitted,assertions=entries,bindings=bbs,per_function_evidence=perfunction,next_action='Main review per-function binding repair; reuse existing results, no rerun'if perfunction else 'Reuse accepted evidence'if form in checked else 'Resolve exact original profile/checker/input blocker; no valid unexecuted source body identified')
 forms.append(dict(form=form,category=category,canonical_checked=form in checked,emission_recorded=form in emitted,source_assertions=len(targets),source_statuses=json.dumps(statuses,sort_keys=True),source_assertion_details='FORM_DETAILS.json#'+form,source_lines=f['source_lines'],result_links=json.dumps([dict(row_id=b['ledger_row_id'],result=b['result'],acceptance=b['acceptance'],raw=b['raw_stdout'],result_evidence=b['result_evidence'])for b in bbs]),next_action=details[form]['next_action']))
save('FORM_DETAILS.json',details);csvout('FORM_RECONCILIATION.csv',forms);csvout('ASSERTION_CASES.csv',assertions)
source_set={f['form']for f in fc}
outside=[b for b in bindings if set(b['result_checked_forms'].split(';')) & (checked-source_set)]
save('ACCEPTED_OUTSIDE_SOURCE_SET.json',dict(forms=sorted(checked-source_set),bindings=outside,inventory_record=[x for x in read(A/'ara/FORM_COVERAGE.csv')if x['form']in checked-source_set],opcode_records=[x for x in read(A/'ara/OPCODE_OCCURRENCES.csv')if x['form']in checked-source_set],reason='vrgatherei16.vv is present at pinned vrgather.c:113 and immediately checked by VCMP_U32 at114, but original inventory labels it setup_explicit. Main must review that classification; do not silently change the frozen424 set.'))
summary=dict(pinned_revision=j(A/'ara/SUMMARY.json')['revision'],source_forms=len(fc),canonical_checked=len(checked),intersection=len(source_set & checked),checked_outside_source=sorted(checked-source_set),source_minus_checked=len(source_set-checked),arithmetic_difference=len(fc)-len(checked),categories=dict(counts),gap_emission_absent=sum(not f['emission_recorded'] for f in forms if not f['canonical_checked']),gap_emission_present=sum(f['emission_recorded'] for f in forms if not f['canonical_checked']),emission_absent_scope='No emitted target in existing canonical binding; not proof no source ELF ever contained opcode. Profile/input dispositions explain launch eligibility separately.',genuinely_unexecuted_original_source_bodies=0,unfinished_configuration_files=['vredsum','vwredsum','vwredsumu'],input_sha256={str(p):sha(p)for p in [A/'ara/FORM_COVERAGE.csv',A/'ara/ASSERTION_TARGETS.csv',A/'SUITE_RUN_MANIFEST.csv',A/'ACTUAL_FORM_VALIDATION_BINDINGS.csv']},canonical_modified=False)
save('RECONCILIATION_SUMMARY.json',summary);print(summary['categories']);print('gap emission absent/present',summary['gap_emission_absent'],summary['gap_emission_present'])
