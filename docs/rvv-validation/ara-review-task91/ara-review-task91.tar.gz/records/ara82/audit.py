import sys,json,re,hashlib,collections,csv
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';W=R.parents[2];A=W/'artifacts/external_suite_coverage_20261007';sys.path.insert(0,str(P));from common import funcs,body
j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
ts=list(csv.DictReader((A/'ara/ASSERTION_TARGETS.csv').open()));cases=[];runs=[];pres=[]
for g in j(R/'GROUPS.json'):
 src=A/'ara/raw/source/apps/riscv-tests/isa/rv64uv'/(g['file']+'.c');original=src.read_text();adapt=R/'adapter'/(g['name']+'.c');adapted=adapt.read_text();fo=funcs(original);fa=funcs(adapted)
 assert sha(src)==sha(R/'upstream'/(g['file']+'.c'))
 for fn in g['functions']:assert body(original,fo[fn])==body(adapted,fa[fn])
 pres.append(dict(case=g['name'],source=str(src),source_sha256=sha(src),adapter_sha256=sha(adapt),all_function_bodies_byte_identical=True,main_diff=str(R/'provenance'/(g['name']+'.diff')),original_elf_sha256=g['elf_sha256'],rebuilt_elf_sha256=sha(R/'bin'/(g['name']+'.elf')),checker_sha256=sha(R/'checker.py'),checker_unchanged=sha(R/'checker.py')==sha(P/'checker.py'),previous_memory_preflight=g['memory_preflight']))
 for arm in ['M1','M2','BOTH']:
  p=R/'raw'/g['name']/arm;result=j(p/'result.json');assert result['status']=='PASS'and result['returncode']==0;assert j(p/'IDENTITY.json')==j(p/'IDENTITY_AFTER.json');assert result['elf_sha256']==g['elf_sha256'];cr=j(p/'case-results.json');assert len(cr)==len(g['functions'])and all(c['status']=='PASS'for c in cr)
  err=(p/'stderr').read_text();direct=re.search(r'RVV_DIRECT (.*)',err).group(1);run=re.search(r'RVV_RUN (.*)',err)
  runs.append(dict(case=g['name'],arm=arm,result=result,raw_stdout=str(p/'stdout'),raw_stderr=str(p/'stderr'),command=j(p/'command.json'),identity=j(p/'IDENTITY.json'),functions=len(cr),original_checker_calls=sum(c['original_success_lines']for c in cr),element_comparisons=sum(c['comparisons']for c in cr),direct_census=direct,run_census=run.group(1)if run else 'disabled',target_specific_optimized_admission='UNOBSERVED; aggregate direct hits include setup/checker code, no reduction PC proof',M1_actual_admission='zero formed/admitted runs'if run else 'not configured'))
 for fn in g['functions']:
  t=[x for x in ts if Path(x['path']).stem==g['file']and x['function']==fn];result_links={arm:str(R/'raw'/g['name']/arm/'case-results.json')for arm in ['M1','M2','BOTH']};result_links.update(B=str(P/'remote-raw'/g['name']/'B/case-results.json'),reference=str(P/'raw'/g['name']/'reference/case-results.json'))
  failures=[str(p)for p in (R.parent/'ara-source51').glob('**/'+g['file']+'__'+fn+'/*/result.json')if j(p).get('status')not in ['PASS']]
  cases.append(dict(file=g['file'],function=fn,source=str(src),source_start_line=original[:fo[fn]['start']].count('\n')+1,what_checked='Original typed VCMP literal equality; reduction seed/result, masking, varying VL and original retained destination/checker entries. No extra tail/full-state guarantee.',assertions=t,initialization='Entire original main call order and globals retained, including predecessors and stale checker buffers; no preload/golden changes',VLEN=g['vlen'],arm_results=result_links,B_reference='REUSED Task52 exact same ELF',new_arms=['M1','M2','BOTH'],original_failure_links=failures))
save('CASE_MANIFEST.json',cases);save('EXECUTION_RESULTS.json',runs);save('PRESERVATION.json',pres)
save('AUDIT.json',dict(new_calls=len(runs),new_function_invocations=sum(r['functions']for r in runs),new_original_checker_calls=sum(r['original_checker_calls']for r in runs),new_element_comparisons=sum(r['element_comparisons']for r in runs),new_PASS=len(runs),new_FAIL=0,new_timeout=0,reused_calls=6,canonical_inputs_unchanged=all(sha(Path(p))==v for p,v in j(R/'RECONCILIATION_SUMMARY.json')['input_sha256'].items()),no_DUT_generated_golden=True,production_edits=0,assertions_weakened=0))
print(j(R/'AUDIT.json'))
