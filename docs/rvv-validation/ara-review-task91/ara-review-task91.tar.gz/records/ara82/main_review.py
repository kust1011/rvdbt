"""Recheck stored external outputs; this does not execute new ISA tests."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from checker import check_cases

groups = {g['name']: g for g in json.loads((ROOT / 'GROUPS.json').read_text())}
rows = []
for path in sorted((ROOT / 'raw').glob('*/*/result.json')):
    result = json.loads(path.read_text())
    raw = path.with_name('stdout').read_bytes()
    group = groups[result['case']]
    accepted, _, cases = check_cases(group, result['returncode'], raw)
    assert result['returncode'] == 0 and accepted
    assert b'FAILED' not in raw and b'ERROR' not in raw
    assert len(cases) == len(group['functions'])
    # Verify that the result parser cannot turn a failed original assertion into PASS.
    altered = raw.replace(b'PASSED.', b'FAILED.', 1)
    assert altered != raw and not check_cases(group, 0, altered)[0]
    assert not check_cases(group, 1, raw)[0]
    assert not check_cases(group, 0, raw.replace(b'ARA_SUMMARY', b'NO_SUMMARY'))[0]
    summary = re.findall(rb'ARA_SUMMARY status=(\d+) vsets=(\d+) assertions=(\d+) comparisons=(\d+)', raw)
    assert len(summary) == 1 and int(summary[0][0]) == 0
    assert int(summary[0][2]) == sum(c['original_success_lines'] for c in cases)
    rows.append({'case': result['case'], 'arm': result['arm'],
                 'assertions': int(summary[0][2]), 'comparisons': int(summary[0][3]),
                 'raw_rechecked': True, 'parser_negative_controls': 3})
assert len(rows) == 9
report = {'scope': 'Stored raw replay and parser checks, not new DUT execution',
          'rows': rows, 'assertions': sum(r['assertions'] for r in rows),
          'comparisons': sum(r['comparisons'] for r in rows)}
prior = ROOT.parent / 'ara-remainder52'
prior_groups = {g['name']: g for g in json.loads((prior / 'GROUPS.json').read_text())}
mac_rows = []
for name in ['batch_vmacc', 'batch_vmadd', 'batch_vnmsac', 'batch_vnmsub']:
    for arm in ['B', 'M1', 'M2', 'BOTH']:
        directory = prior / 'remote-raw' / name / arm
        result = json.loads((directory / 'result.json').read_text())
        accepted, _, cases = check_cases(prior_groups[name], result['returncode'],
                                        (directory / 'stdout').read_bytes())
        assert not accepted and result['status'] == 'RESULT_MISMATCH'
        assert [c['function'] for c in cases[:2]] == ['TEST_CASE1', 'TEST_CASE2']
        assert all(c['status'] == 'PASS' and c['original_success_lines'] == 4 for c in cases[:2])
        assert all(c['status'] == 'RESULT_MISMATCH' for c in cases[2:])
        mac_rows.append({'case': name, 'arm': arm, 'accepted_functions': ['TEST_CASE1', 'TEST_CASE2'],
                         'whole_file': 'RESULT_MISMATCH'})
report['scoped_mac_recheck'] = mac_rows
(ROOT / 'MAIN_REVIEW.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'rows'}))
