import ast,json,hashlib,os,re,subprocess,tempfile,shutil,sys,resource,textwrap
from pathlib import Path
R=Path(__file__).resolve().parent;j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
original=(R/'run.original.py.txt').read_text();tree=ast.parse(original)
for node in tree.body:
 if isinstance(node,ast.FunctionDef):exec(ast.get_source_segment(original,node))
start=original.index(' raw=(dest/');end=original.index(' row=dict',start);predicate=textwrap.dedent(original[original.rfind('\n',0,start)+1:end])
def check(c,rc,raw):
 expected=[[m['id'],m['elements'],m['width']//8,m['avl'],m['vtype'],m['elements'],1]for m in c['assertions']]
 expected_obs=dict(vsets=[[v['line'],v['avl'],v['actual_vl'],v['vtype']]for v in c['vsets']],assertions=expected,summary=[0,len(c['vsets']),c['vector_assertions'],c['comparisons']],flags=[],flag_summary=[0,0,0,0],scalars=[],scalar_summary=[0,0,0])
 # Exact original acceptance expression, supplying only immutable case metadata.
 text=raw.decode(errors='replace');obs=observations(raw);sequences=[int(x)for x in re.findall(r'ARA_ASSERT[^\n]+ sequence=(\d+)',text)];n=c['vector_assertions']
 expr=next(ast.get_source_segment(original,node.value)for node in ast.walk(tree)if isinstance(node,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='ok'for x in node.targets))
 ok=eval(expr);return ok,obs
if __name__=='__main__':
 name,arm=sys.argv[1:];c=next(x for x in j(R/'GROUPS.json')if x['name']==name);conf=next(x for x in j(R/'CONFIGS.json')if x['case']==name and x['arm']==arm);out=R/'raw'/name/arm;out.mkdir(parents=True,exist_ok=False)
 elf=R/'bin'/(name+'.elf');assert sha(elf)==conf['elf_sha256'];resource.setrlimit(resource.RLIMIT_CORE,(0,0));env=dict(os.environ)
 if arm=='reference':
  spike=Path('/home/user/research/third_party/chips-spike-20261007-install/bin/spike');pk=Path('/home/user/research/third_party/riscv-pk-audit-20261006-build/pk');lib=spike.parent.parent/'lib/libriscv.so';pins={str(p):sha(p)for p in [spike,pk,lib]};assert pins==j(R/'REFERENCE_IDENTITY.json');env['LD_LIBRARY_PATH']=str(lib.parent)
 else:
  stage=Path('/home/vick/ara-clean961-stage');pins={str(stage/f):sha(stage/f)for f in ['elfrun','libdbtjitshared.so','FLAGS.A.txt','FLAGS.S0.txt']};assert pins[str(stage/'elfrun')]==conf['executable_sha256']and pins[str(stage/'libdbtjitshared.so')]==conf['library_sha256'];env['LD_LIBRARY_PATH']=str(stage)+':/lib/x86_64-linux-gnu'
 save(out/'IDENTITY.json',pins)
 with tempfile.TemporaryDirectory(prefix='ara_remainder52_')as tmp:
  work=Path(tmp);(work/'fs').mkdir();(work/'cache').mkdir()
  if arm=='reference':cmd=[str(spike),f'--isa=rv32gcv'+('_zfh_zvfh'if c.get('reference_optional_fp16')else'')+f'_zvl{c["vlen"]}b',str(pk),str(elf)]
  else:
   shutil.copy2(elf,work/'fs/t.elf');flags=[f.replace('{WORK}',str(work))for f in conf['flags']];cmd=[str(stage/'elfrun'),*flags]
  save(out/'command.json',cmd);save(out/'ENVIRONMENT.json',{'LD_LIBRARY_PATH':env['LD_LIBRARY_PATH']})
  with(out/'stdout').open('wb')as o,(out/'stderr').open('wb')as e:
   try:rc=subprocess.run(cmd,stdout=o,stderr=e,env=env,timeout=120).returncode
   except subprocess.TimeoutExpired:rc=None
 if c.get('observer')=='case-spans-v2':
  from checker import check_cases
  ok,obs,case_results=check_cases(c,rc,(out/'stdout').read_bytes());save(out/'case-results.json',case_results)
 else:ok,obs=check(c,rc,(out/'stdout').read_bytes())
 save(out/'observations.json',obs);status='TIMEOUT'if rc is None else'CRASH'if rc<0 else'PASS'if ok else'RESULT_MISMATCH'
 save(out/'result.json',dict(case=name,arm=arm,status=status,returncode=rc,original_checker_accepted=ok,elf_sha256=sha(elf),diagnostic_only=bool(c['reasons']),source_disposition='BLOCKED_UNDEFINED_INPUT'if c['reasons']else status))
 assert pins=={p:sha(Path(p))for p in pins};save(out/'IDENTITY_AFTER.json',pins);print(name,arm,status,flush=True)
