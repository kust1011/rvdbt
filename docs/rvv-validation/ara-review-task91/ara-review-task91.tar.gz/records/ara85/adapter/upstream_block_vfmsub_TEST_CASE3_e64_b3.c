// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 297 "vfmsub.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                               -0.6953502965951812
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfe6404f43e47c8c);
  //               -0.8873182146436771,  0.3913246153259273, 0.8941416868753180,
  //               0.2630283463166789, -0.8096670634564123,  0.6449486037845993,
  //               0.8384405697279889, -0.9956067461953679, -0.8936777193492917,
  //               -0.4464070291333477,  0.5599998966835931,
  //               -0.3406088963725078,  0.4908382567748615,
  //               -0.5194254665571632,  0.0909287222245825,  0.5893410930389467
  VLOAD_64(v2, 0xbfec64e92b21453c, 0x3fd90b76663c74f4, 0x3fec9ccf06e3d51a,
           0x3fd0d574d8567864, 0xbfe9e8cae6c6325c, 0x3fe4a36b411b6206,
           0x3fead4815153e1da, 0xbfefdc02add2c126, 0xbfec990204389c42,
           0xbfdc91eec9b5438c, 0x3fe1eb84e7409f04, 0xbfd5cc8941a96178,
           0x3fdf69e4dd1e50c8, 0xbfe09f2227f25264, 0x3fb7471ad038be10,
           0x3fe2dbe1da195142);
  //               -0.4387964890891065, -0.2425720412460179,
  //               -0.8909058709916624, -0.7961584351708695, 0.0353694444236163,
  //               0.2992862865812480, -0.4186756300648600, -0.5421957392048740,
  //               0.3780444269462682, -0.6731508364205383,  0.1263808806166760,
  //               0.8571806635726140,  0.5149747658358419,  0.3530123248386567,
  //               -0.3756405874818076, -0.4529815298587780
  VLOAD_64(v1, 0xbfdc153dde8f3078, 0xbfcf0c99c409ad98, 0xbfec824d0777279c,
           0xbfe97a21412fca1a, 0x3fa21bf19e277c80, 0x3fd32781ab407ee0,
           0xbfdacb94deb0b06c, 0xbfe159aae0fd4b9a, 0x3fd831e1408ad588,
           0xbfe58a739f7670b4, 0x3fc02d3faa8b4d88, 0x3feb6e062499dac6,
           0x3fe07aac5c30f764, 0x3fd697c1019115dc, 0xbfd80a7ed19236bc,
           0xbfdcfda63e1bdf38);
  asm volatile("vfmsub.vf v1, %[A], v2" ::[A] "f"(dscalar_64));
  //               1.1924354834767115, -0.2226520744998102, -0.2746500252428773,
  //               0.2905806577161405,  0.7850729097860438, -0.8530574119257405,
  //               -0.5473143461852141,  1.3726227142641205, 0.6308044149460488,
  //               0.9144826628916634, -0.6478788795043589, -0.2554319322783636,
  //               -0.8489261129378481,  0.2739582417788488, 0.1702730716940806,
  //               -0.2743602518995064
  VCMP_U64(9, v1, 0x3ff314373ac1f573, 0xbfcc7fdcf92e7eaa, 0xbfd193ddb310e0ff,
           0x3fd298df9d6f6c70, 0x3fe91f5139103634, 0xbfeb4c3f0eba9b49,
           0xbfe18399602fe862, 0x3ff5f6433c382dac, 0x3fe42f8cbd8bb3c3,
           0x3fed4371253c1e34, 0xbfe4bb6c7ce7b0ea, 0xbfd058ff2cdf5691,
           0xbfeb2a6718793b11, 0x3fd18888263a3a6e, 0x3fc5cb820d286398,
           0xbfd18f1e4d4ec3d2);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
