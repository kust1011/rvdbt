// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 37 "vfmacc.c"
  VSET(16, e32, m1);
  //               0.72754014,  0.34003398,  0.70107144, -0.41727209,
  //               -0.52331781, -0.11821542, -0.16069038,  0.30835113,
  //               -0.59407759, -0.53240144, -0.92390168,  0.33251825,
  //               -0.45979658,  0.32465541, -0.99342769, -0.16221718
  VLOAD_32(v2, 0x3f3a4012, 0x3eae18ef, 0x3f33796b, 0xbed5a4b0, 0xbf05f828,
           0xbdf21aed, 0xbe248c05, 0x3e9de033, 0xbf181578, 0xbf084b76,
           0xbf6c84d2, 0x3eaa3fd5, 0xbeeb6a75, 0x3ea6393c, 0xbf7e5147,
           0xbe261c43);
  //               0.95104939, -0.11575679,  0.13276713,  0.22784369,
  //               0.93318671, -0.32301557,  0.41414812,  0.81797487,
  //               -0.21847244, -0.00211347, -0.72070456, -0.58624452,
  //               0.07381243, -0.16745377,  0.55389816, -0.23427610
  VLOAD_32(v3, 0x3f7377f9, 0xbded11e6, 0x3e07f41b, 0x3e694fdb, 0x3f6ee553,
           0xbea5624c, 0x3ed40b39, 0x3f5166cd, 0xbe5fb73d, 0xbb0a8224,
           0xbf388018, 0xbf16141f, 0x3d972af9, 0xbe2b7900, 0x3f0dcc45,
           0xbe6fe613);
  //              -0.07459558, -0.00461283, -0.97654468,  0.94394064,
  //              0.24971253,  0.97819000,  0.55116856, -0.97427863, 0.61764765,
  //              0.86367106,  0.48787504, -0.26353455, -0.22228357, 0.40454853,
  //              0.64000225, -0.51787829
  VLOAD_32(v1, 0xbd98c591, 0xbb97273a, 0xbf79fed5, 0x3f71a618, 0x3e7fb4a4,
           0x3f7a6aa9, 0x3f0d1962, 0xbf796a53, 0x3f1e1e28, 0x3f5d198c,
           0x3ef9cac2, 0xbe86ee00, 0xbe639e4e, 0x3ecf20fc, 0x3f23d730,
           0xbf0493ac);
  asm volatile("vfmacc.vv v1, v2, v3");
  //               0.61733103, -0.04397407, -0.88346541,  0.84886783,
  //               -0.23864070,  1.01637542,  0.48461893, -0.72205520,
  //               0.74743724,  0.86479628,  1.15373516, -0.45847154,
  //               -0.25622228,  0.35018376,  0.08974451, -0.47987467
  VCMP_U32(2, v1, 0x3f1e0968, 0xbd341e29, 0xbf622aca, 0x3f594f67, 0xbe745e3a,
           0x3f821897, 0x3ef81ff9, 0xbf38d89b, 0x3f3f580c, 0x3f5d634a,
           0x3f93ad98, 0xbeeabcc8, 0xbe832f91, 0x3eb34b49, 0x3db7cbf5,
           0xbef5b222);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
