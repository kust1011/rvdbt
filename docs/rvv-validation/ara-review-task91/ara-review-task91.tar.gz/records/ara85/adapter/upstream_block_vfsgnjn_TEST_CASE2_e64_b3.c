// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 150 "vfsgnjn.c"
  VSET(16, e64, m1);
  //               0.3054868811191440, -0.2848737407493320,  0.8796894022735833,
  //               -0.2053728688878902, -0.3336030943630310, 0.2807217618714037,
  //               0.4723331455917303, -0.8582398814993568,  0.8015611350975347,
  //               0.0545934239457773,  0.8461592442963186,  0.5731810427237676,
  //               0.9004228762726765, -0.5815114412549589, -0.4481603571708770,
  //               -0.3109452697316515
  VLOAD_64(v2, 0x3fd38d18d8f0e180, 0xbfd23b5f12007bec, 0x3fec266a63ace3f8,
           0xbfca49a87dadf9c0, 0xbfd559c0cb088d3c, 0x3fd1f75868a0d7ec,
           0x3fde3ab4cd4887cc, 0xbfeb76b37be53474, 0x3fe9a663899fa232,
           0x3fabf3ab54d8f940, 0x3feb13bc8d2ebe92, 0x3fe2577fc525f1c0,
           0x3fecd043a2c52a30, 0xbfe29bbde1ce1372, 0xbfdcaea8c75a67f8,
           0xbfd3e686fd15f950);
  //              -0.8601583185162320, -0.2023208019417544,  0.7046992650654684,
  //              0.0669209072111863, -0.9495814052980500,  0.4501419112888980,
  //              0.1528430256162707, -0.2750771515266404, -0.5539880061109905,
  //              -0.7302340801247744,  0.1579280396497211, -0.6128023516491234,
  //              0.2706272563647967, -0.7982929669593624, -0.2521632643799878,
  //              0.9025785865542095
  VLOAD_64(v3, 0xbfeb866abced1b2e, 0xbfc9e5a5e5d1f648, 0x3fe68ce5791f15e4,
           0x3fb121ba83e404a0, 0xbfee62f88b14a294, 0x3fdccf2004e2dd30,
           0x3fc3905c3a38c700, 0xbfd19add326bc2ac, 0xbfe1ba450e13ef3a,
           0xbfe75e13dc91f006, 0x3fc436fc6ab55e68, 0xbfe39c13ad67d608,
           0x3fd151f4fbdf8d78, 0xbfe98b9db136f3e0, 0xbfd023716370f004,
           0x3fece1ec7cea3f5e);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfsgnjn.vv v1, v2, v3, v0.t");
  //               0.0000000000000000,  0.2848737407493320,  0.0000000000000000,
  //               -0.2053728688878902,  0.0000000000000000,
  //               -0.2807217618714037,  0.0000000000000000, 0.8582398814993568,
  //               0.0000000000000000,  0.0545934239457773,  0.0000000000000000,
  //               0.5731810427237676,  0.0000000000000000,  0.5815114412549589,
  //               0.0000000000000000, -0.3109452697316515
  VCMP_U64(6, v1, 0x0, 0x3fd23b5f12007bec, 0x0, 0xbfca49a87dadf9c0, 0x0,
           0xbfd1f75868a0d7ec, 0x0, 0x3feb76b37be53474, 0x0, 0x3fabf3ab54d8f940,
           0x0, 0x3fe2577fc525f1c0, 0x0, 0x3fe29bbde1ce1372, 0x0,
           0xbfd3e686fd15f950);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
