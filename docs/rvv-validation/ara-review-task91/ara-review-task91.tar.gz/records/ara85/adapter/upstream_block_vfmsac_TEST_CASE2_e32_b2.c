// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 153 "vfmsac.c"
  VSET(16, e32, m1);
  //              -0.90310860,  0.30282700,  0.54854167, -0.38732994,
  //              0.92121714,  0.99595129, -0.10263380,  0.83759040,
  //              -0.23468767,  0.03914077, -0.46234205,  0.38326120,
  //              0.36417511, -0.50103557,  0.36991179,  0.44718841
  VLOAD_32(v2, 0xbf673220, 0x3e9b0c24, 0x3f0c6d3a, 0xbec6501c, 0x3f6bd4e3,
           0x3f7ef6aa, 0xbdd231ab, 0x3f566c53, 0xbe7051f7, 0x3d205212,
           0xbeecb819, 0x3ec43ad0, 0x3eba7529, 0xbf0043de, 0x3ebd6514,
           0x3ee4f5e1);
  //               0.84989786, -0.04543342, -0.74596256, -0.30687407,
  //               -0.30795863,  0.57084304,  0.51653886, -0.97366458,
  //               0.49300706,  0.62932760,  0.45846274, -0.73850167,
  //               -0.42686453, -0.31419462, -0.47245970, -0.87721694
  VLOAD_32(v3, 0x3f5992e8, 0xbd3a1866, 0xbf3ef767, 0xbe9d1e99, 0xbe9dacc1,
           0x3f1222c5, 0x3f043be4, 0xbf794215, 0x3efc6b6c, 0x3f211b9d,
           0x3eeabba1, 0xbf3d0e72, 0xbeda8dfd, 0xbea0de1e, 0xbef1e63d,
           0xbf60914a);
  VLOAD_8(v0, 0xAA, 0xAA);
  //              -0.76813585,  0.87161541, -0.67958647, -0.98584491,
  //              0.12284227, -0.04006640, -0.93113720, -0.93526161,
  //              -0.27461481,  0.64110506,  0.61687475, -0.43741968,
  //              0.70502371,  0.37014356, -0.98105848,  0.77993429
  VLOAD_32(v1, 0xbf44a48d, 0x3f5f2230, 0xbf2df961, 0xbf7c6055, 0x3dfb94bb,
           0xbd241caa, 0xbf6e5f02, 0xbf6f6d4e, 0xbe8c9a50, 0x3f241f76,
           0x3f1deb81, 0xbedff579, 0x3f347c6f, 0x3ebd8375, 0xbf7b26a6,
           0x3f47a9c6);
  asm volatile("vfmsac.vv v1, v2, v3, v0.t");
  //              -0.76813585, -0.88537389, -0.67958647,  1.10470641,
  //              0.12284227,  0.60859829, -0.93113720,  0.11972952,
  //              -0.27461481, -0.61647266,  0.61687475,  0.15438065,
  //              0.70502371, -0.21272089, -0.98105848, -1.17221546
  VCMP_U32(5, v1, 0xbf44a48d, 0xbf62a7dd, 0xbf2df961, 0x3f8d6705, 0x3dfb94bb,
           0x3f1bcd19, 0xbf6e5f02, 0x3df534be, 0xbe8c9a50, 0xbf1dd127,
           0x3f1deb81, 0x3e1e15f6, 0x3f347c6f, 0xbe59d381, 0xbf7b26a6,
           0xbf960b29);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
