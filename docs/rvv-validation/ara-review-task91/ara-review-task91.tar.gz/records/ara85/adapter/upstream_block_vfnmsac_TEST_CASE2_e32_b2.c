// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 152 "vfnmsac.c"
  VSET(16, e32, m1);
  //               0.11577118, -0.10074481,  0.13861528,  0.44782066,
  //               0.42196107, -0.67597556,  0.34948668, -0.87903690,
  //               -0.34136006, -0.19722189,  0.76997000, -0.68663412,
  //               0.45603558,  0.60629857, -0.86984915, -0.08019307
  VLOAD_32(v2, 0x3ded1971, 0xbdce534c, 0x3e0df12a, 0x3ee548c0, 0x3ed80b48,
           0xbf2d0cbc, 0x3eb2efeb, 0xbf610890, 0xbeaec6bf, 0xbe49f489,
           0x3f451cc1, 0xbf2fc741, 0x3ee97d7f, 0x3f1b3662, 0xbf5eae6f,
           0xbda43c43);
  //              -0.38970658,  0.40460527,  0.69067985, -0.98108912,
  //              0.47494572, -0.34277225, -0.54462087, -0.90492284, 0.60100728,
  //              -0.02819708, -0.46859986,  0.87238866,  0.46812481,
  //              0.49922746,  0.97036403,  0.04279163
  VLOAD_32(v3, 0xbec7879f, 0x3ecf286c, 0x3f30d065, 0xbf7b28a8, 0x3ef32c16,
           0xbeaf7fd8, 0xbf0b6c46, 0xbf67a906, 0x3f19db9d, 0xbce6fd92,
           0xbeefec52, 0x3f5f54dd, 0x3eefae0e, 0x3eff9abe, 0x3f7869c7,
           0x3d2f4647);
  VLOAD_8(v0, 0xAA, 0xAA);
  //               0.79804420, -0.70010293, -0.51047552,  0.38566175,
  //               0.15318950,  0.15531392, -0.20705318, -0.82493448,
  //               0.12047531,  0.57526720,  0.23939800, -0.19725421,
  //               0.15403098,  0.03931713, -0.45930895, -0.15395784
  VLOAD_32(v1, 0x3f4c4ca0, 0xbf3339f2, 0xbf02ae86, 0x3ec57575, 0x3e1cddb5,
           0x3e1f0a9d, 0xbe5405c0, 0xbf532ee8, 0x3df6bbc3, 0x3f1344b6,
           0x3e7524c0, 0xbe49fd02, 0x3e1dba4c, 0x3d210b00, 0xbeeb2a8b,
           0xbe1da720);
  asm volatile("vfnmsac.vv v1, v2, v3, v0.t");
  //               0.79804420, -0.65934104, -0.51047552,  0.82501376,
  //               0.15318950, -0.07639174, -0.20705318, -1.62039506,
  //               0.12047531,  0.56970614,  0.23939800,  0.40175763,
  //               0.15403098, -0.26336378, -0.45930895, -0.15052626
  VCMP_U32(5, v1, 0x3f4c4ca0, 0xbf28ca93, 0xbf02ae86, 0x3f53341a, 0x3e1cddb5,
           0xbd9c7345, 0xbe5405c0, 0xbfcf691b, 0x3df6bbc3, 0x3f11d843,
           0x3e7524c0, 0x3ecdb32c, 0x3e1dba4c, 0xbe86d79e, 0xbeeb2a8b,
           0xbe1a238e);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
