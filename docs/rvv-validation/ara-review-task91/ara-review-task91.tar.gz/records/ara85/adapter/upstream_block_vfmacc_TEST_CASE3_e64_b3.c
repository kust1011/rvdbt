// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 243 "vfmacc.c"
  VSET(16, e64, m1);
  //              -0.1981785436218435,  0.2324321764718080,  0.3529425082887112,
  //              -0.4889737836823891,  0.1335009259637479, -0.7964186221277452,
  //              -0.2707335519445100,  0.8070543770008602, -0.1237072120160827,
  //              -0.2357903062216291, -0.0812498320849093,  0.8656662449573254,
  //              0.7178262144151533, -0.3106178959409680, -0.1410836751949509,
  //              0.6904294937898030
  VLOAD_64(v3, 0xbfc95dea1dcff710, 0x3fcdc0566a3e04a0, 0x3fd6969c2c9df760,
           0xbfdf4b58b2611a74, 0x3fc1168eef800078, 0xbfe97c42e7fed97a,
           0xbfd153b2d1e20588, 0x3fe9d363b369fec4, 0xbfbfab469de36f10,
           0xbfce2e6072f7c5c0, 0xbfb4ccc9fb9c3490, 0x3febb389b26af886,
           0x3fe6f86eae63fc74, 0xbfd3e129e2279a3c, 0xbfc20f07a57b1c48,
           0x3fe617ff9800ac5a);
  double dscalar_64;
  //                               0.8738839355493300
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3febf6db7175e482);
  //              -0.9433584234417285, -0.0696473591160720, -0.8171557896146857,
  //              -0.9495656113293445, -0.6353537919969880,  0.8159507202507001,
  //              0.0288919190409849, -0.6024741558584952, -0.9583084411212592,
  //              0.7665070398551490, -0.7817863527411446, -0.2155326059803253,
  //              -0.7807395886866346,  0.2528540140694266, -0.1740695080779533,
  //              0.7247829241803623
  VLOAD_64(v1, 0xbfee2ffe0122d3b6, 0xbfb1d468c9a80310, 0xbfea2623e6043a6c,
           0xbfee62d76bc21ae2, 0xbfe454d179c08866, 0x3fea1c44af53fb1a,
           0x3f9d95d7dd994d80, 0xbfe34777e1831e42, 0xbfeeaa7676c316f0,
           0x3fe88739c58a9cbe, 0xbfe90464d02f6f4c, 0xbfcb96928af41d88,
           0xbfe8fbd197034034, 0x3fd02ec29a45caf0, 0xbfc647e8de367aa0,
           0x3fe7316bf581b994);
  asm volatile("vfmacc.vf v1, %[A], v3" ::[A] "f"(dscalar_64));
  //              -1.1165434690834197,  0.1334713860074080, -0.5087250014486948,
  //              -1.3768719457941574, -0.5186894774163083,  0.1199732804009315,
  //              -0.2076977828175325,  0.1027976993173292, -1.0664141864137089,
  //              0.5604536790898100, -0.8527892757662274,  0.5409592190351925,
  //              -0.1534427913930433, -0.0185899752875187, -0.2973602653990804,
  //              1.3281381674327271
  VCMP_U64(9, v1, 0xbff1dd5caf44692a, 0x3fc1159722ed4311, 0xbfe04779a77c2679,
           0xbff607aae09f73e1, 0xbfe0991aacc90937, 0x3fbeb691a3b74133,
           0xbfca95d7485395ec, 0x3fba50f334ac0644, 0xbff11008526a327e,
           0x3fe1ef3c8dd3a2b9, 0xbfeb4a0cbc397482, 0x3fe14f89b5473a2f,
           0xbfc3a4036d6b8775, 0xbf9309401f92c802, 0xbfd307f359c13629,
           0x3ff5400dce9b1643);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
