// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfsgnj.c"
  VSET(16, e32, m1);
  //               0.30226409,  0.06318295, -0.82590002, -0.17829193,
  //               0.45379546,  0.85831785, -0.43186289, -0.32250872,
  //               0.35404092, -0.55081791,  0.09124859, -0.13254598,
  //               0.95786512,  0.95395225,  0.19890578,  0.76956910
  VLOAD_32(v2, 0x3e9ac25c, 0x3d816610, 0xbf536e2f, 0xbe369229, 0x3ee857e1,
           0x3f5bbab8, 0xbedd1d22, 0xbea51fdd, 0x3eb544da, 0xbf0d0267,
           0x3dbae08b, 0xbe07ba22, 0x3f7536a6, 0x3f743637, 0x3e4badf5,
           0x3f45027b);
  //               0.06560040,  0.31805936,  0.14663234, -0.85004497,
  //               -0.49171701,  0.32139263, -0.09995110, -0.34368968,
  //               0.33917251,  0.07372360,  0.70147520,  0.82915747,
  //               -0.14581841, -0.19974701, -0.58837658,  0.95794803
  VLOAD_32(v3, 0x3d865981, 0x3ea2d8ad, 0x3e1626ca, 0xbf599c8c, 0xbefbc255,
           0x3ea48d93, 0xbdccb329, 0xbeaff818, 0x3eada805, 0x3d96fc66,
           0x3f3393e1, 0x3f5443aa, 0xbe15516c, 0xbe4c8a7b, 0xbf169fd9,
           0x3f753c15);
  asm volatile("vfsgnj.vv v1, v2, v3");
  //               0.30226409,  0.06318295,  0.82590002, -0.17829193,
  //               -0.45379546,  0.85831785, -0.43186289, -0.32250872,
  //               0.35404092,  0.55081791,  0.09124859,  0.13254598,
  //               -0.95786512, -0.95395225, -0.19890578,  0.76956910
  VCMP_U32(2, v1, 0x3e9ac25c, 0x3d816610, 0x3f536e2f, 0xbe369229, 0xbee857e1,
           0x3f5bbab8, 0xbedd1d22, 0xbea51fdd, 0x3eb544da, 0x3f0d0267,
           0x3dbae08b, 0x3e07ba22, 0xbf7536a6, 0xbf743637, 0xbe4badf5,
           0x3f45027b);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
