// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 302 "vfmacc.c"
  VSET(16, e32, m1);
  VLOAD_32(v3, 0xbf4aa962, 0xbe07c535, 0xbf71e6ee, 0xbf6ff24b, 0x3f4dae80,
           0x3f4620d0, 0x3ea00507, 0xbed9cd2f, 0xbe4dad5d, 0xbf23b3b5,
           0x3e7ebb6b, 0xbee9ace6, 0x3f6dad4f, 0x3ec8479c, 0xbf34a4ae,
           0x3e0ecf23);
  double dscalar_32;
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f79eed6);
  VLOAD_32(v1, 0xbee017a1, 0xbf3e0603, 0x3f1a339a, 0x3edf5b43, 0x3eb1f879,
           0x3f277380, 0x3f7e333e, 0xbea17473, 0xbf657f2b, 0x3ef3d4f5,
           0xbf2e8e35, 0x3f454e51, 0x3e4b0786, 0xbe267148, 0x3f50f5e9,
           0xbe798a90);
  VLOAD_8(v0, 0xAA, 0xAA);
  asm volatile("vfmacc.vf v1, %[A], v3, v0.t" ::[A] "f"(dscalar_32));
  VCMP_U32(11, v1, 0xbee017a1, 0xbf5f2962, 0x3f1a339a, 0xbef529cb, 0x3eb1f879,
           0x3fb47121, 0x3f7e333e, 0xbf3b0c1c, 0xbf657f2b, 0xbe17a02a,
           0xbf2e8e35, 0x3ea67974, 0x3e4b0786, 0x3e609fb9, 0x3f50f5e9,
           0xbddc3bb6);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
