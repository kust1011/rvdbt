// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE12(void) {
#line 766 "vfcvt.c"
  VSET(16, e32, m1);
  //                      -39422,          54262,          12833, -40266,
  //                      -64918,          28317,          89178, 54320, -99922,
  //                      -73005,          95070,         -24716, 60663, 59516,
  //                      14865,          26328
  VLOAD_32(v2, 0xffff6602, 0x0000d3f6, 0x00003221, 0xffff62b6, 0xffff026a,
           0x00006e9d, 0x00015c5a, 0x0000d430, 0xfffe79ae, 0xfffee2d3,
           0x0001735e, 0xffff9f74, 0x0000ecf7, 0x0000e87c, 0x00003a11,
           0x000066d8);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.f.x.v v3, v2, v0.t");
  //                0.000,   54262.000,   0.000, -40266.000,   0.000, 28317.000,
  //                0.000,   54320.000,   0.000, -73005.000,   0.000,
  //                -24716.000,   0.000,   59516.000,   0.000,   26328.000
  VCMP_U32(35, v3, 0x0, 0x4753f600, 0x0, 0xc71d4a00, 0x0, 0x46dd3a00, 0x0,
           0x47543000, 0x0, 0xc78e9680, 0x0, 0xc6c11800, 0x0, 0x47687c00, 0x0,
           0x46cdb000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE12"); TEST_CASE12(); ara_case_end("TEST_CASE12",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
