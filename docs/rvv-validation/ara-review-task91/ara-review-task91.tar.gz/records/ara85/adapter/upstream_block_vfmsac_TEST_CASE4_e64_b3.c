// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 396 "vfmsac.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                                0.0070730785066928
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3f7cf8a90de48000);
  //                -0.3542445595658672,  0.5861662785402695,
  //                0.5713440701195280,  0.2841717566030781, 0.4022451154567073,
  //                -0.9804628417449213, -0.9703836833708208,
  //                0.2288593539727362,  0.1806576644288407, 0.4892172254017777,
  //                0.9508074316559227, -0.9022151172016701,
  //                -0.7929839752648156,  0.5513143449560454,
  //                0.4823446191982377, -0.7486658065787619
  VLOAD_64(v2, 0xbfd6abf15f87c3c4, 0x3fe2c1dfc88b26c8, 0x3fe248735bfda932,
           0x3fd22fdebc43a768, 0x3fd9be624bf72ff4, 0xbfef5ff39c079aea,
           0xbfef0d621514ca4c, 0x3fcd4b43685929d8, 0x3fc71fca543f2eb8,
           0x3fdf4f55c3ef6448, 0x3fee6d03b4f830b0, 0xbfecdef23ccad0bc,
           0xbfe9601fee00766c, 0x3fe1a45dfb2cdc2e, 0x3fdedebbf736e98c,
           0xbfe7f511fe5c74b0);
  VLOAD_8(v0, 0xAA, 0xAA);
  //                -0.7603855538897846, -0.0491604902215765,
  //                -0.3714656077097227, -0.6096204185796581,
  //                -0.2818689596683441,  0.3527700521309320,
  //                0.1176602936422064, -0.2049443830034134,
  //                -0.6926950556538125,  0.7269529331298494,
  //                -0.2107692441818434,  0.1746722346734710,
  //                -0.5298547863982788,  0.2397543330794352,
  //                -0.8347981409736787, -0.6198539479673024
  VLOAD_64(v1, 0xbfe8551415c9d6cc, 0xbfa92b9053839560, 0xbfd7c617af2cedf8,
           0xbfe38202ae18c034, 0xbfd20a241ae21e00, 0x3fd693c8d73a46c0,
           0x3fbe1efc293b2500, 0xbfca3b9e173fd0c8, 0xbfe62a8ed24449ee,
           0x3fe74332cc30c46e, 0xbfcafa7c9161bf78, 0x3fc65ba8e7b88cc0,
           0xbfe0f4920666b5a4, 0x3fceb0451dd34270, 0xbfeab6aa9747cb24,
           0xbfe3d5d7f25a1d14);
  asm volatile("vfmsac.vf v1, %[A], v2, v0.t" ::[A] "f"(dscalar_64));
  //               -0.7603855538897846,  0.0533064903276678,
  //               -0.3714656077097227,  0.6116303877234964,
  //               -0.2818689596683441, -0.3597049427834890, 0.1176602936422064,
  //               0.2065631231810536, -0.6926950556538125, -0.7234926612877562,
  //               -0.2107692441818434, -0.1810536730273635,
  //               -0.5298547863982788, -0.2358548434356951,
  //               -0.8347981409736787,  0.6145585759420944
  VCMP_U64(12, v1, 0xbfe8551415c9d6cc, 0x3fab4afd013e6639, 0xbfd7c617af2cedf8,
           0x3fe39279e4106415, 0xbfd20a241ae21e00, 0xbfd70567e15dbc9b,
           0x3fbe1efc293b2500, 0x3fca70a9114fa5b7, 0xbfe62a8ed24449ee,
           0xbfe726da14e40fb7, 0xbfcafa7c9161bf78, 0xbfc72cc44a3c91ef,
           0xbfe0f4920666b5a4, 0xbfce307dd3946ada, 0xbfeab6aa9747cb24,
           0x3fe3aa76bf24b95e);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
