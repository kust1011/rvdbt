// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 54 "vfmerge.c"
  VSET(16, e64, m1);
  //               -0.3488917150781869, -0.4501495513738740, 0.8731197104152684,
  //               0.3256432550932964,  0.6502591178769535, -0.3169358689246526,
  //               -0.5396694979141685, -0.5417807430937591,
  //               -0.7971574213160249, -0.1764794100111047, 0.3564275916066595,
  //               -0.3754449946313438,  0.6580947137446858,
  //               -0.3328857144699515,  0.1761214464164236,  0.1429774118511240
  VLOAD_64(v2, 0xbfd6543dea86cb60, 0xbfdccf40105d6e5c, 0x3febf098bf37400c,
           0x3fd4d756ceb279f4, 0x3fe4ceec35a6a266, 0xbfd448ad61fd7c88,
           0xbfe144f8f7861540, 0xbfe1564491a616b8, 0xbfe9825047ca1cd6,
           0xbfc696e097352100, 0x3fd6cfb5ac55edec, 0xbfd8074a7158dd78,
           0x3fe50f1ca5268668, 0xbfd54dffe23d0eec, 0x3fc68b25c63dcaf0,
           0x3fc24d1575fbd080);
  double dscalar_64;
  //                               0.9108707261227378
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3fed25da5d7296fe);
  VLOAD_8(v0, 0x0F, 0xAA);
  asm volatile("vfmerge.vfm v1, v2, %[A], v0" ::[A] "f"(dscalar_64));
  //                0.9108707261227378,  0.9108707261227378, 0.9108707261227378,
  //                0.9108707261227378,  0.6502591178769535,
  //                -0.3169358689246526, -0.5396694979141685,
  //                -0.5417807430937591  -0.7971574213160249,
  //                0.9108707261227378,  0.3564275916066595, 0.9108707261227378,
  //                0.6580947137446858,  0.9108707261227378, 0.1761214464164236,
  //                0.9108707261227378
  VCMP_U64(3, v1, 0x3fed25da5d7296fe, 0x3fed25da5d7296fe, 0x3fed25da5d7296fe,
           0x3fed25da5d7296fe, 0x3fe4ceec35a6a266, 0xbfd448ad61fd7c88,
           0xbfe144f8f7861540, 0xbfe1564491a616b8, 0xbfe9825047ca1cd6,
           0x3fed25da5d7296fe, 0x3fd6cfb5ac55edec, 0x3fed25da5d7296fe,
           0x3fe50f1ca5268668, 0x3fed25da5d7296fe, 0x3fc68b25c63dcaf0,
           0x3fed25da5d7296fe);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
