// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 109 "vfrdiv.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                981163.06250000, -831670.37500000, -85439.06250000,
  //                64225.75781250, -215361.43750000, -292944.75000000,
  //                396490.21875000,  954345.93750000,  241910.40625000,
  //                -62372.83593750,  391838.50000000,  263890.03125000,
  //                755217.06250000, -6653.31689453,  526939.25000000,
  //                -759232.75000000
  VLOAD_32(v2, 0x496f8ab1, 0xc94b0b66, 0xc7a6df88, 0x477ae1c2, 0xc852505c,
           0xc88f0a18, 0x48c19947, 0x4968fe9f, 0x486c3d9a, 0xc773a4d6,
           0x48bf53d0, 0x4880da41, 0x49386111, 0xc5cfea89, 0x4900a5b4,
           0xc9395c0c);
  //                              -816463.43750000
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xc94754f7);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfrdiv.vf v4, v2, %[A], v0.t" ::[A] "f"(dscalar_32));
  //                0.00000000,  0.98171520,  0.00000000, -12.71239853,
  //                0.00000000,  2.78709030,  0.00000000, -0.85552144,
  //                0.00000000,  13.09004879,  0.00000000, -3.09395337,
  //                0.00000000,  122.71524811,  0.00000000,  1.07537961
  VCMP_U32(5, v4, 0x0, 0x3f7b51af, 0x0, 0xc14b65fc, 0x0, 0x40325faf, 0x0,
           0xbf5b0374, 0x0, 0x415170d6, 0x0, 0xc0460354, 0x0, 0x42f56e35, 0x0,
           0x3f89a60a);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
