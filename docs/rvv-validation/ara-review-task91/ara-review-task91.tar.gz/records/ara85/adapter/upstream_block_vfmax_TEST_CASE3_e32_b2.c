// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 209 "vfmax.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.94383347
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbf719f12);
  //               0.51733643,  0.31252080,  0.47358772,  0.13738893,
  //               0.11194360, -0.33637357,  0.83680850,  0.95792335,
  //               0.41251704,  0.27496886, -0.06774041, -0.19357064,
  //               -0.48802575, -0.53921199,  0.32722279,  0.28428423
  VLOAD_32(v2, 0x3f047029, 0x3ea002ba, 0x3ef27a17, 0x3e0cafaf, 0x3de542b0,
           0xbeac3928, 0x3f563915, 0x3f753a77, 0x3ed3356f, 0x3e8cc8b8,
           0xbd8abb7c, 0xbe463762, 0xbef9de83, 0xbf0a09cc, 0x3ea789bf,
           0x3e918db4);
  asm volatile("vfmax.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //               0.51733643,  0.31252080,  0.47358772,  0.13738893,
  //               0.11194360, -0.33637357,  0.83680850,  0.95792335,
  //               0.41251704,  0.27496886, -0.06774041, -0.19357064,
  //               -0.48802575, -0.53921199,  0.32722279,  0.28428423
  VCMP_U32(8, v1, 0x3f047029, 0x3ea002ba, 0x3ef27a17, 0x3e0cafaf, 0x3de542b0,
           0xbeac3928, 0x3f563915, 0x3f753a77, 0x3ed3356f, 0x3e8cc8b8,
           0xbd8abb7c, 0xbe463762, 0xbef9de83, 0xbf0a09cc, 0x3ea789bf,
           0x3e918db4);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
