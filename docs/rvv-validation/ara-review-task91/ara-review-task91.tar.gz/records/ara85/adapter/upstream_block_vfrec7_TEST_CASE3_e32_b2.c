// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Shafiullah Khan <shafi.ullah@10xengineers.ai>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 84 "vfrec7.c"
  CLEAR_FFLAGS;
  VSET(16, e32, m1);
  CHECK_FFLAGS(0);
  CHANGE_RM(RM_RDN);
  VLOAD_32(v2, 0x800dd27e, 0x8005d27e, 0x8005d27c, 0x8001d27c, 0x8000d27c,
           0x8000527c, 0x8000127c, 0x8000107c, 0x000dd27e, 0x0005d27e,
           0x0005d27c, 0x0001d27c, 0x0000d27c, 0x0000527c, 0x0000127c,
           0x0000107c);
  asm volatile("vfrec7.v v1, v2");
  VCMP_U32(8, v1, mInff, mInff, mInff, mInff, mInff, mInff, mInff, mInff, pMaxf,
           pMaxf, pMaxf, pMaxf, pMaxf, pMaxf, pMaxf, pMaxf);
  CHECK_FFLAGS(NX | OF);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
