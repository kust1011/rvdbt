// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Shafiullah Khan <shafi.ullah@10xengineers.ai>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 61 "vfrec7.c"
  CLEAR_FFLAGS;
  VSET(16, e64, m1);
  CHECK_FFLAGS(0);
  VLOAD_64(v2, pZero, mZerod, pZero, mZerod, pZero, mZerod, pZero, mZerod,
           pZero, mZerod, pZero, mZerod, pZero, mZerod, pZero, mZerod);
  asm volatile("vfrec7.v v1, v2");
  VCMP_U64(6, v1, pInfd, mInfd, pInfd, mInfd, pInfd, mInfd, pInfd, mInfd, pInfd,
           mInfd, pInfd, mInfd, pInfd, mInfd, pInfd, mInfd);
  CHECK_FFLAGS(DZ);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
