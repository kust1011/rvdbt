// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 367 "vfnmadd.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.13809182
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbe0d67f1);
  //               -0.16977388, -0.30800357, -0.37010264, -0.92290556,
  //               0.55768263,  0.47349435,  0.77556002,  0.16363664,
  //               0.80314618, -0.48171839, -0.60694915,  0.16937894,
  //               0.86316317,  0.00897404, -0.96310323, -0.27890080
  VLOAD_32(v2, 0xbe2dd934, 0xbe9db2a5, 0xbebd7e18, 0xbf6c438a, 0x3f0ec44a,
           0x3ef26dda, 0x3f468b1a, 0x3e27905d, 0x3f4d9afd, 0xbef6a3cb,
           0xbf1b6105, 0x3e2d71ac, 0x3f5cf843, 0x3c1307df, 0xbf768def,
           0xbe8ecc16);
  VLOAD_8(v0, 0xAA, 0xAA);
  //               -0.33133313, -0.48972869,  0.95656961, -0.89211702,
  //               0.72045243, -0.36672497,  0.69402671,  0.44954479,
  //               -0.77024877, -0.83221292,  0.37576449, -0.77536738,
  //               -0.55040795, -0.71568310, -0.75874990,  0.91956782
  VLOAD_32(v1, 0xbea9a47f, 0xbefabdb8, 0x3f74e1bf, 0xbf6461c8, 0x3f386f92,
           0xbebbc360, 0x3f31abbc, 0x3ee62abc, 0xbf452f06, 0xbf550be8,
           0x3ec06434, 0xbf467e7a, 0xbf0ce789, 0xbf373702, 0xbf423d6f,
           0x3f6b68cc);
  asm volatile("vfnmadd.vf v1, %[A], v2, v0.t" ::[A] "f"(dscalar_32));
  //               -0.33133313,  0.24037606,  0.95656961,  0.79971153,
  //               0.72045243, -0.52413607,  0.69402671, -0.10155818,
  //               -0.77024877,  0.36679661,  0.37576449, -0.27645081,
  //               -0.55040795, -0.10780402, -0.75874990,  0.40588558
  VCMP_U32(11, v1, 0xbea9a47f, 0x3e762524, 0x3f74e1bf, 0x3f4cb9e5, 0x3f386f92,
           0xbf062dc8, 0x3f31abbc, 0xbdcffdbd, 0xbf452f06, 0x3ebbccc3,
           0x3ec06434, 0xbe8d8af6, 0xbf0ce789, 0xbddcc85b, 0xbf423d6f,
           0x3ecfd03d);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
