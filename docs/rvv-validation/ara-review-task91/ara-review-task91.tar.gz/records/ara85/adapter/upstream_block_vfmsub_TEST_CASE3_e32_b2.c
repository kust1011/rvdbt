// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 267 "vfmsub.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.12857932
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbe03aa4c);
  //               0.31050768, -0.13843875,  0.23405042, -0.30545133,
  //               -0.28880060,  0.46233574, -0.51105869, -0.11776974,
  //               -0.39969075,  0.51141965,  0.88750082, -0.22310242,
  //               0.60111052,  0.58466393, -0.14306845, -0.01826003
  VLOAD_32(v2, 0x3e9efadd, 0xbe0dc2e3, 0x3e6faaea, 0xbe9c641e, 0xbe93ddac,
           0x3eecb745, 0xbf02d4be, 0xbdf13143, 0xbecca444, 0x3f02ec66,
           0x3f633341, 0xbe6474f6, 0x3f19e261, 0x3f15ac89, 0xbe128089,
           0xbc95960e);
  //              -0.51789892,  0.77328473, -0.88433731,  0.40865302,
  //              -0.50454420,  0.30827177, -0.25503114,  0.07736996,
  //              0.20596179, -0.42633566,  0.89622146,  0.03779412, 0.50878429,
  //              0.67896879, -0.17667305,  0.06984760
  VLOAD_32(v1, 0xbf049506, 0x3f45f5fd, 0xbf6263ee, 0x3ed13af8, 0xbf0129cf,
           0x3e9dd5cc, 0xbe829371, 0x3d9e7424, 0x3e52e7a6, 0xbeda48ab,
           0x3f656ec5, 0x3d1ace01, 0x3f023fb0, 0x3f2dd0e6, 0xbe34e9c8,
           0x3d8f0c42);
  asm volatile("vfmsub.vf v1, %[A], v2" ::[A] "f"(dscalar_32));
  //              -0.24391660,  0.03901032, -0.12034293,  0.25290701,
  //              0.35367453, -0.50197309,  0.54385042,  0.10782156, 0.37320831,
  //              -0.45660171, -1.00273633,  0.21824288, -0.66652966,
  //              -0.67196524,  0.16578496,  0.00927907
  VCMP_U32(8, v1, 0xbe79c546, 0x3d1fc94a, 0xbdf6765b, 0x3e817d07, 0x3eb514d5,
           0xbf00814f, 0x3f0b39c8, 0x3ddcd18d, 0x3ebf1529, 0xbee9c7b3,
           0xbf8059aa, 0x3e5f7b10, 0xbf2aa1b0, 0xbf2c05eb, 0x3e29c388,
           0x3c18073f);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
