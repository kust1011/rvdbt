// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 163 "vfwcvt.c"
  VSET(16, e32, m1);
  //                  -22345.104,     -55208.160,   60155.754, -4924.268,
  //                  -42337.285, -60609.004,   51795.328,   33876.547,
  //                  -99812.922,   59419.867, -78706.844,   72266.555,
  //                  -70664.008, -83501.727, -15981.749, -2004.535
  VLOAD_32(v2, 0xc6ae9235, 0xc757a829, 0x476afbc1, 0xc599e225, 0xc7256149,
           0xc76cc101, 0x474a5354, 0x4704548c, 0xc7c2f276, 0x47681bde,
           0xc799b96c, 0x478d2547, 0xc78a0401, 0xc7a316dd, 0xc679b6ff,
           0xc4fa9120);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfwcvt.x.f.v v4, v2, v0.t");
  //                                   0,                 -55208, 0, -4924, 0,
  //                                   -60609,                      0, 33877, 0,
  //                                   59420,                      0, 72267, 0,
  //                                   -83502,                      0, -2005
  VCMP_U64(8, v4, 0x0000000000000000, 0xffffffffffff2858, 0x0000000000000000,
           0xffffffffffffecc4, 0x0000000000000000, 0xffffffffffff133f,
           0x0000000000000000, 0x0000000000008455, 0x0000000000000000,
           0x000000000000e81c, 0x0000000000000000, 0x0000000000011a4b,
           0x0000000000000000, 0xfffffffffffeb9d2, 0x0000000000000000,
           0xfffffffffffff82b);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
