// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 231 "vfsgnjn.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                                0.1909501680714165
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3fc8710e1b8426e8);
  //               -0.2692390874696449, -0.3268380231167121, 0.8386824891028197,
  //               -0.5650452268361481, -0.6389787807266418, 0.5318945600667211,
  //               -0.7817543128402196, -0.5679136293897145,
  //               -0.0001555883762874,  0.5283267089670276, 0.5439688283816015,
  //               -0.2866314604291811, -0.0576946087921848, 0.7960283598249005,
  //               -0.8999056473475127,  0.2142070697411482
  VLOAD_64(v2, 0xbfd13b3694df2b24, 0xbfd4eaea07180958, 0x3fead67ca8cd9566,
           0xbfe214d9ba40b584, 0xbfe47283a0c1e25c, 0x3fe10547bd8d051e,
           0xbfe904219ee4fb76, 0xbfe22c593425cec0, 0xbf2464adf9bfe000,
           0x3fe0e80d6a13bbf4, 0x3fe1683150fe2844, 0xbfd2582b7b231344,
           0xbfad8a25d3d5fd40, 0x3fe9791077845df2, 0xbfeccc06ed9afc1e,
           0x3fcb6b23238e1bc8);
  asm volatile("vfsgnjn.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //              -0.2692390874696449, -0.3268380231167121, -0.8386824891028197,
  //              -0.5650452268361481, -0.6389787807266418, -0.5318945600667211,
  //              -0.7817543128402196, -0.5679136293897145, -0.0001555883762874,
  //              -0.5283267089670276, -0.5439688283816015, -0.2866314604291811,
  //              -0.0576946087921848, -0.7960283598249005, -0.8999056473475127,
  //              -0.2142070697411482
  VCMP_U64(9, v1, 0xbfd13b3694df2b24, 0xbfd4eaea07180958, 0xbfead67ca8cd9566,
           0xbfe214d9ba40b584, 0xbfe47283a0c1e25c, 0xbfe10547bd8d051e,
           0xbfe904219ee4fb76, 0xbfe22c593425cec0, 0xbf2464adf9bfe000,
           0xbfe0e80d6a13bbf4, 0xbfe1683150fe2844, 0xbfd2582b7b231344,
           0xbfad8a25d3d5fd40, 0xbfe9791077845df2, 0xbfeccc06ed9afc1e,
           0xbfcb6b23238e1bc8);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
