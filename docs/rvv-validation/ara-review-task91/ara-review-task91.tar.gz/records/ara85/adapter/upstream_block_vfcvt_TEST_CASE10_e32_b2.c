// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE10(void) {
#line 634 "vfcvt.c"
  VSET(16, e32, m1);
  //                       72473,     4294949057,          50975, 4294915723,
  //                       4294876584,     4294895088,          24967, 34761,
  //                       83805,          68361,          49397, 51562, 24877,
  //                       4294942241,     4294909502,          42562
  VLOAD_32(v2, 0x00011b19, 0xffffb8c1, 0x0000c71f, 0xffff368b, 0xfffe9da8,
           0xfffee5f0, 0x00006187, 0x000087c9, 0x0001475d, 0x00010b09,
           0x0000c0f5, 0x0000c96a, 0x0000612d, 0xffff9e21, 0xffff1e3e,
           0x0000a642);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.f.xu.v v3, v2, v0.t");
  //                0.000,   4294949120.000,   0.000,   4294915840.000,   0.000,
  //                4294895104.000,   0.000,   34761.000,   0.000,   68361.000,
  //                0.000,   51562.000,   0.000,   4294942208.000,   0.000,
  //                42562.000
  VCMP_U32(29, v3, 0x0, 0x4f7fffb9, 0x0, 0x4f7fff37, 0x0, 0x4f7ffee6, 0x0,
           0x4707c900, 0x0, 0x47858480, 0x0, 0x47496a00, 0x0, 0x4f7fff9e, 0x0,
           0x47264200);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE10"); TEST_CASE10(); ara_case_end("TEST_CASE10",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
