// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 59 "vfmin.c"
  VSET(16, e64, m1);
  //               0.9387726994461698,  0.8517969615002949, -0.8864275043807637,
  //               0.3621349692771021,  0.5392486258321831, -0.1288714247798126,
  //               -0.9149173505741688, -0.9378576380992047,
  //               -0.2263428385339852,  0.1016628884386184, 0.4783549203499486,
  //               0.5394596797016060,  0.7861587828590215,  0.0194772848204161,
  //               -0.9126826319328591,  0.3997583898469530
  VLOAD_64(v2, 0x3fee0a6d0b4ff74a, 0x3feb41ebb38f3ae2, 0xbfec5d9d36b2e38c,
           0x3fd72d3826721e9c, 0x3fe14186558b96e0, 0xbfc07edbdd68bb68,
           0xbfed4700c06849e8, 0xbfee02ee057e1390, 0xbfccf8cd5897f8a0,
           0x3fba06943d0f8e20, 0x3fde9d5df4b22860, 0x3fe14340f23a8770,
           0x3fe9283676baf718, 0x3f93f1da754635c0, 0xbfed34b234f8ec38,
           0x3fd995a436ac6f1c);
  //               0.4808082103120717,  0.7218925128932789, -0.9454618185734458,
  //               0.7335258472548418,  0.9800819535502201, -0.6873536121819364,
  //               -0.7090903925273744,  0.7813319828098306, 0.6810234154055235,
  //               0.1176441554686278,  0.4929731878752270,  0.0942028280153233,
  //               0.9496420237972776, -0.4549651855719854, -0.9663401540020158,
  //               0.4114236885680320
  VLOAD_64(v3, 0x3fdec58fccbc12a4, 0x3fe719be53c35314, 0xbfee413924cc77e4,
           0x3fe7790b32975e1a, 0x3fef5cd4d43cbc4e, 0xbfe5fecd00a37bfa,
           0xbfe6b0de55ba0314, 0x3fe900abee2f95f8, 0x3fe5caf19e1f4324,
           0x3fbe1ded684da4d0, 0x3fdf8cdf69eea758, 0x3fb81dad31843b10,
           0x3fee6377ab63bade, 0xbfdd1e264c366a78, 0xbfeeec422fc80224,
           0x3fda54c405ccc2c0);
  asm volatile("vfmin.vv v1, v2, v3");
  //               0.4808082103120717,  0.7218925128932789, -0.9454618185734458,
  //               0.3621349692771021,  0.5392486258321831, -0.6873536121819364,
  //               -0.9149173505741688, -0.9378576380992047,
  //               -0.2263428385339852,  0.1016628884386184, 0.4783549203499486,
  //               0.0942028280153233,  0.7861587828590215, -0.4549651855719854,
  //               -0.9663401540020158,  0.3997583898469530
  VCMP_U64(3, v1, 0x3fdec58fccbc12a4, 0x3fe719be53c35314, 0xbfee413924cc77e4,
           0x3fd72d3826721e9c, 0x3fe14186558b96e0, 0xbfe5fecd00a37bfa,
           0xbfed4700c06849e8, 0xbfee02ee057e1390, 0xbfccf8cd5897f8a0,
           0x3fba06943d0f8e20, 0x3fde9d5df4b22860, 0x3fb81dad31843b10,
           0x3fe9283676baf718, 0xbfdd1e264c366a78, 0xbfeeec422fc80224,
           0x3fd995a436ac6f1c);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
