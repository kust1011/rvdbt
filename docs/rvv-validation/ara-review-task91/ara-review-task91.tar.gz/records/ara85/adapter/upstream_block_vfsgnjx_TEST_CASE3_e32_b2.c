// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 210 "vfsgnjx.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.71056527
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbf35e79b);
  //              -0.13350210, -0.18642496,  0.30152589, -0.62076813,
  //              0.00040700, -0.59566921, -0.88075870,  0.08096603, 0.94059193,
  //              -0.29601631, -0.54263371, -0.86016685, -0.57158113,
  //              0.85538357, -0.76839548,  0.28374606
  VLOAD_32(v2, 0xbe08b4c6, 0xbe3ee62f, 0x3e9a619a, 0xbf1eeaa9, 0x39d561f4,
           0xbf187dc7, 0xbf617967, 0x3da5d185, 0x3f70caa2, 0xbe978f73,
           0xbf0aea0b, 0xbf5c33e5, 0xbf125324, 0x3f5afa6b, 0xbf44b591,
           0x3e91472a);
  asm volatile("vfsgnjx.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //               0.13350210,  0.18642496, -0.30152589,  0.62076813,
  //               -0.00040700,  0.59566921,  0.88075870, -0.08096603,
  //               -0.94059193,  0.29601631,  0.54263371,  0.86016685,
  //               0.57158113, -0.85538357,  0.76839548, -0.28374606
  VCMP_U32(8, v1, 0x3e08b4c6, 0x3e3ee62f, 0xbe9a619a, 0x3f1eeaa9, 0xb9d561f4,
           0x3f187dc7, 0x3f617967, 0xbda5d185, 0xbf70caa2, 0x3e978f73,
           0x3f0aea0b, 0x3f5c33e5, 0x3f125324, 0xbf5afa6b, 0x3f44b591,
           0xbe91472a);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
