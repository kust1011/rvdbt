// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 213 "vfmacc.c"
  VSET(16, e32, m1);
  //              -0.79164708, -0.13258822, -0.94492996, -0.93729085,
  //              0.80344391,  0.77393818,  0.31253836, -0.42539355,
  //              -0.20085664, -0.63946086,  0.24876182, -0.45639724,
  //              0.92842573,  0.39117134, -0.70563781,  0.13946204
  VLOAD_32(v3, 0xbf4aa962, 0xbe07c535, 0xbf71e6ee, 0xbf6ff24b, 0x3f4dae80,
           0x3f4620d0, 0x3ea00507, 0xbed9cd2f, 0xbe4dad5d, 0xbf23b3b5,
           0x3e7ebb6b, 0xbee9ace6, 0x3f6dad4f, 0x3ec8479c, 0xbf34a4ae,
           0x3e0ecf23);
  double dscalar_32;
  //                              0.97630060
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f79eed6);
  //              -0.43768027, -0.74227923,  0.60234988,  0.43624315,
  //              0.34759882,  0.65410614,  0.99296939, -0.31534156,
  //              -0.89647168,  0.47623411, -0.68185741,  0.77072626,
  //              0.19827089, -0.16254151,  0.81625229, -0.24369264
  VLOAD_32(v1, 0xbee017a1, 0xbf3e0603, 0x3f1a339a, 0x3edf5b43, 0x3eb1f879,
           0x3f277380, 0x3f7e333e, 0xbea17473, 0xbf657f2b, 0x3ef3d4f5,
           0xbf2e8e35, 0x3f454e51, 0x3e4b0786, 0xbe267148, 0x3f50f5e9,
           0xbe798a90);
  asm volatile("vfmacc.vf v1, %[A], v3" ::[A] "f"(dscalar_32));
  //              -1.21056581, -0.87172520, -0.32018578,
  //              -0.47883448,  1.13200164,  1.40970242,  1.29810071,
  //              -0.73065352, -1.09256816, -0.14807191, -0.43899110,
  //              0.32514536,  1.10469353,  0.21935931,  0.12733769, -0.10753576
  VCMP_U32(8, v1, 0xbf9af3d2, 0xbf5f2962, 0xbea3ef65, 0xbef529cb, 0x3f90e56e,
           0x3fb47121, 0x3fa6282b, 0xbf3b0c1c, 0xbf8bd946, 0xbe17a02a,
           0xbee0c371, 0x3ea67974, 0x3f8d6699, 0x3e609fb9, 0x3e0264cf,
           0xbddc3bb6);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
