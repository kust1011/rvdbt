// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 37 "vfnmadd.c"
  VSET(16, e32, m1);
  //              -0.36820358,  0.10496315, -0.32905263, -0.92334682,
  //              0.43153936,  0.92736709, -0.59600371,  0.75117606, 0.84123290,
  //              0.33028743, -0.43412161,  0.95273590,  0.06816643,
  //              -0.88978988,  0.18573478,  0.61926919
  VLOAD_32(v2, 0xbebc852e, 0x3dd6f6ec, 0xbea87996, 0xbf6c6075, 0x3edcf2ba,
           0x3f6d67ee, 0xbf1893b3, 0x3f404d13, 0x3f575b0a, 0x3ea91b6f,
           0xbede4530, 0x3f73e680, 0x3d8b9ad8, 0xbf63c945, 0x3e3e3142,
           0x3f1e886d);
  //               0.69083834, -0.31329882, -0.54809541,  0.25019145,
  //               -0.67489260,  0.23259214, -0.14038530,  0.09741956,
  //               -0.23567833,  0.75417399, -0.90357685, -0.87489468,
  //               0.54726779, -0.06705534, -0.15476358, -0.96940458
  VLOAD_32(v3, 0x3f30dac8, 0xbea068b4, 0xbf0c4ffb, 0x3e801918, 0xbf2cc5c3,
           0x3e6e2ca2, 0xbe0fc12a, 0x3dc783e8, 0xbe7155a9, 0x3f41118c,
           0xbf6750d0, 0xbf5ff919, 0x3f0c19be, 0xbd895450, 0xbe1e7a58,
           0xbf782ae6);
  //               0.03722767,  0.80796093,  0.53925264, -0.50804031,
  //               0.63562357, -0.45508829, -0.22051410,  0.42499006,
  //               -0.59229839, -0.50074077, -0.80474108, -0.20762257,
  //               0.15367362,  0.98349953, -0.15871963, -0.07445616
  VLOAD_32(v1, 0x3d187c0a, 0x3f4ed687, 0x3f0a0c76, 0xbf020eee, 0x3f22b83a,
           0xbee90155, 0xbe61ce73, 0x3ed9984c, 0xbf17a0de, 0xbf00308c,
           0xbf4e0383, 0xbe549b03, 0x3e1d5c9e, 0x3f7bc6a0, 0xbe228766,
           0xbd987c79);
  asm volatile("vfnmadd.vv v1, v2, v3");
  //              -0.67713100,  0.22849269,  0.72553790, -0.71928883,
  //              0.40059602,  0.18944177,  0.00895807, -0.41666192, 0.73393923,
  //              -0.58878565,  0.55422139,  1.07270420, -0.55774319,
  //              0.94216329,  0.18424334,  1.01551294
  VCMP_U32(2, v1, 0xbf2d5875, 0x3e69f9fd, 0x3f39bcda, 0xbf382350, 0x3ecd1aec,
           0x3e41fd06, 0x3c12c4e5, 0xbed554b6, 0x3f3be371, 0xbf16baa7,
           0x3f0de173, 0x3f894e5f, 0xbf0ec842, 0x3f71319d, 0x3e3caa49,
           0x3f81fc54);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
