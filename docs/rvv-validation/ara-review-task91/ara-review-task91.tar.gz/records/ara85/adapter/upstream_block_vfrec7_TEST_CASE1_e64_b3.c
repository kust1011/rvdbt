// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Shafiullah Khan <shafi.ullah@10xengineers.ai>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 28 "vfrec7.c"
  VSET(16, e64, m1);
  VLOAD_64(v2, mInfd, pInfd, qNaNd, sNaNd, pZero, mZerod, 0xffee384e0c3fbf7c,
           0xffdfa4dc68d2ae1a, 0xffcf49b8d1aa1fda, 0x800f47ea9ea8e436,
           0x800747ea961ff344, 0x00060000005e7fcf, 0x000bffffd07b5869,
           0x7fbfffff9bfec946, 0x7fdc709c2bde6967, 0x000347ea91db7acb);
  asm volatile("vfrec7.v v1, v2");
  VCMP_U64(3, v1, mZerod, pZero, qNaNd, qNaNd, pInfd, mInfd, 0x8004400000000000,
           0x8008100000000000, 0x8010600000000000, 0xffd0c00000000000,
           0xffe1a00000000000, 0x7fe5400000000000, 0x7fd5600000000000,
           0x0020000000000000, 0x0009000000000000, pInfd);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
