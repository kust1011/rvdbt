// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 209 "vfdiv.c"
  VSET(16, e32, m1);
  //               0.74354362,  0.49774653,  0.25714639,  0.51635689,
  //               0.74569613,  0.41876560,  0.21346331,  0.08743033,
  //               -0.15111920, -0.93289024,  0.08753468, -0.33427054,
  //               0.06167563, -0.54564798,  0.78990245, -0.77273035
  VLOAD_32(v2, 0x3f3e58e0, 0x3efed8a2, 0x3e83a8b1, 0x3f042ff7, 0x3f3ee5f1,
           0x3ed66872, 0x3e5a9620, 0x3db30eac, 0xbe1abefe, 0xbf6ed1e5,
           0x3db34562, 0xbeab2582, 0x3d7c9f95, 0xbf0baf96, 0x3f4a370c,
           0xbf45d1a8);
  double dscalar_32;
  //                              -0.45971388
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbeeb5f9e);
  asm volatile("vfdiv.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //              -1.61740518, -1.08273113, -0.55936182, -1.12321365,
  //              -1.62208748, -0.91092664, -0.46433949, -0.19018422,
  //              0.32872447,  2.02928448, -0.19041122,  0.72712737,
  //              -0.13416091,  1.18692958, -1.71824801,  1.68089414
  VCMP_U32(8, v1, 0xbfcf0722, 0xbf8a96ef, 0xbf0f3255, 0xbf8fc576, 0xbfcfa090,
           0xbf69327c, 0xbeedbde7, 0xbe42bfa7, 0x3ea84e93, 0x4001dfcc,
           0xbe42fb28, 0x3f3a2504, 0xbe096179, 0x3f97ed4e, 0xbfdbef8c,
           0x3fd72789);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
