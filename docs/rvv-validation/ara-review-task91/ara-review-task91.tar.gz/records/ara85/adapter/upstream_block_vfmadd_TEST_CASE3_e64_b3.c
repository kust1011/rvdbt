// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 288 "vfmadd.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                                0.5717861827636179
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3fe24c128968c808);
  //               -0.0978999279373105, -0.8066508697961206, 0.1001298330116740,
  //               0.6183499729699258, -0.7091158569428311,  0.4713309006442494,
  //               -0.9363173157138223,  0.6720957973877764,
  //               -0.1684678230133414, -0.0206783343753454,
  //               -0.6941474840922310,  0.4809970389518419,
  //               -0.4671263490725479,  0.5176516826232249,
  //               -0.9714116214357187,  0.0212574845134876
  VLOAD_64(v2, 0xbfb90ff83cc58160, 0xbfe9d0157c220eae, 0x3fb9a21bd6239ad0,
           0x3fe3c985e1ec6d14, 0xbfe6b113bcd49f88, 0x3fde2a4914f71f28,
           0xbfedf64fbb356b82, 0x3fe581cf0bb1e7c4, 0xbfc5905a8722a398,
           0xbf952cb38782ee00, 0xbfe63674c8d8dba6, 0x3fdec8a7cdf1580c,
           0xbfdde565ea17744c, 0x3fe0909a42f2c184, 0xbfef15cdd320a9f0,
           0x3f95c485a31f6440);
  //               -0.8599787754583945, -0.8609648323347547,
  //               -0.5642848553711928,  0.8958493001041692, 0.3661374487395561,
  //               0.1017901385891375,  0.2298954297904690, -0.4970717320718749,
  //               -0.5860844501192310, -0.6581386742527398,
  //               -0.8379133193505066, -0.6497652150347000,
  //               -0.4444119628309799, -0.8810041425660891, 0.4421772814931029,
  //               0.0606105644967410
  VLOAD_64(v1, 0xbfeb84f2357b2242, 0xbfeb8d061ebc48de, 0xbfe20e9f1cee50cc,
           0x3fecaacc26c2f0d0, 0x3fd76ecbc40b5864, 0x3fba0eeb244baff0,
           0x3fcd6d36a4399740, 0xbfdfd005f440f21c, 0xbfe2c1342d3e9986,
           0xbfe50f78d644befe, 0xbfead02f97efc88a, 0xbfe4cae06b94e0d2,
           0xbfdc713edf93dac0, 0xbfec312f997ec7ac, 0x3fdc4ca1f0c30314,
           0x3faf0859109c77c0);
  asm volatile("vfmadd.vf v1, %[A], v2" ::[A] "f"(dscalar_64));
  //              -0.5896239092143964, -1.2989386647705283, -0.2225204504323405,
  //              1.1305842246079476, -0.4997635227612305,  0.5295330954311120,
  //              -0.8048662854791286,  0.3878770491466992, -0.5035828135241305,
  //              -0.3969929346554276, -1.1732547424504496,  0.1094702669545694,
  //              -0.7212349688741608,  0.0139056869464266, -0.7185807615459836,
  //              0.0559137678222272
  VCMP_U64(9, v1, 0xbfe2de32f5e07f06, 0xbff4c873e8cb3071, 0xbfcc7b8cd4a627de,
           0x3ff216df7be108d1, 0xbfdffc20247f9130, 0x3fe0f1ef63e0d73b,
           0xbfe9c176f0b925be, 0x3fd8d2fa423d0f48, 0xbfe01d59b45d3de9,
           0xbfd968550dc5a3de, 0xbff2c5a6c3cb39b0, 0x3fbc063e50744ab8,
           0xbfe7145b5b8179a4, 0x3f8c7a95b54e78da, 0xbfe6fe9d14cbfe26,
           0x3faca0bab8629cdd);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
