// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 320 "vfmacc.c"
  VSET(16, e64, m1);
  VLOAD_64(v3, 0xbfc95dea1dcff710, 0x3fcdc0566a3e04a0, 0x3fd6969c2c9df760,
           0xbfdf4b58b2611a74, 0x3fc1168eef800078, 0xbfe97c42e7fed97a,
           0xbfd153b2d1e20588, 0x3fe9d363b369fec4, 0xbfbfab469de36f10,
           0xbfce2e6072f7c5c0, 0xbfb4ccc9fb9c3490, 0x3febb389b26af886,
           0x3fe6f86eae63fc74, 0xbfd3e129e2279a3c, 0xbfc20f07a57b1c48,
           0x3fe617ff9800ac5a);
  double dscalar_64;
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3febf6db7175e482);
  VLOAD_64(v1, 0xbfee2ffe0122d3b6, 0xbfb1d468c9a80310, 0xbfea2623e6043a6c,
           0xbfee62d76bc21ae2, 0xbfe454d179c08866, 0x3fea1c44af53fb1a,
           0x3f9d95d7dd994d80, 0xbfe34777e1831e42, 0xbfeeaa7676c316f0,
           0x3fe88739c58a9cbe, 0xbfe90464d02f6f4c, 0xbfcb96928af41d88,
           0xbfe8fbd197034034, 0x3fd02ec29a45caf0, 0xbfc647e8de367aa0,
           0x3fe7316bf581b994);
  VLOAD_8(v0, 0xAA, 0xAA);
  asm volatile("vfmacc.vf v1, %[A], v3, v0.t" ::[A] "f"(dscalar_64));
  VCMP_U64(12, v1, 0xbfee2ffe0122d3b6, 0x3fc1159722ed4311, 0xbfea2623e6043a6c,
           0xbff607aae09f73e1, 0xbfe454d179c08866, 0x3fbeb691a3b74133,
           0x3f9d95d7dd994d80, 0x3fba50f334ac0644, 0xbfeeaa7676c316f0,
           0x3fe1ef3c8dd3a2b9, 0xbfe90464d02f6f4c, 0x3fe14f89b5473a2f,
           0xbfe8fbd197034034, 0xbf9309401f92c802, 0xbfc647e8de367aa0,
           0x3ff5400dce9b1643);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
