// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 308 "vfdiv.c"
  VSET(16, e64, m1);
  //                -0.8580137874650531, -0.4775160339931992,
  //                0.3831482495481682, -0.3582952848420831, 0.0009796501269754,
  //                0.5485795361059773, -0.8055070333165963,
  //                -0.2632019868496005, -0.0782680309690278,
  //                -0.7119901734202212, -0.5084969452651125,
  //                -0.7586325258910223,  0.6253847342253853,
  //                0.5751160060426936,  0.0609762717873976, -0.7366654110036495
  VLOAD_64(v2, 0xbfeb74d95495be72, 0xbfde8f9f69544024, 0x3fd885803c550ed0,
           0xbfd6ee4f58ad4bcc, 0x3f500cf35070c000, 0x3fe18df6abda8f8e,
           0xbfe9c6b6af995e52, 0xbfd0d84d2570b86c, 0xbfb4095fa9559400,
           0xbfe6c89f9dbd3916, 0xbfe0459b62c0f228, 0xbfe846b7b80c4834,
           0x3fe40326d89d4d44, 0x3fe26759aeab8116, 0x3faf38482a5158c0,
           0xbfe792c3570b5cc2);
  double dscalar_64;
  //                                0.0072652319849018
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3f7dc225dc5e3c00);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfdiv.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_64));
  //                0.0000000000000000, -65.7261922242188206,
  //                0.0000000000000000, -49.3164272781202087,
  //                0.0000000000000000,  75.5075044053657223,
  //                0.0000000000000000, -36.2276094413188474,
  //                0.0000000000000000, -97.9996474854262800,
  //                0.0000000000000000, -104.4195873535172723,
  //                0.0000000000000000,  79.1600333255520070,
  //                0.0000000000000000, -101.3959929338175954
  VCMP_U64(12, v1, 0x0, 0xc0506e79eef36846, 0x0, 0xc048a880b0658b57, 0x0,
           0x4052e07af3c1e7c9, 0x0, 0xc0421d224e615cd6, 0x0, 0xc0587ffa39725bce,
           0x0, 0xc05a1ada84ea4b00, 0x0, 0x4053ca3dfc6ae106, 0x0,
           0xc0595957f2bf0c64);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
