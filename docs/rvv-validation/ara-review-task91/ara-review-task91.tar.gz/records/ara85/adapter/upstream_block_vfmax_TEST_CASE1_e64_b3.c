// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 59 "vfmax.c"
  VSET(16, e64, m1);
  //              -0.4061329687298849, -0.2985478109200665,  0.0070087316277823,
  //              -0.2169778494878496, -0.8530745559533048, -0.1247477743553222,
  //              0.5680045000966327,  0.9515829310663801, -0.9797693611753244,
  //              0.0055288881366042,  0.3717566019240965,  0.0982171502328268,
  //              -0.1563664923399100,  0.9555697921812856,  0.4810293698835877,
  //              -0.1835757691555060
  VLOAD_64(v2, 0xbfd9fe1522a16c7c, 0xbfd31b68470c6bc4, 0x3f7cb530120b5400,
           0xbfcbc5ee1fc0dc58, 0xbfeb4c6302dbd036, 0xbfbfef785b1ada80,
           0x3fe22d17c5fcaaf0, 0x3fee735e0c0b94e4, 0xbfef5a45467bddd8,
           0x3f76a5759bade800, 0x3fd7cadc33d5826c, 0x3fb924c2582803f0,
           0xbfc403d135652390, 0x3fee940719ceda38, 0x3fdec92f69043118,
           0xbfc77f692a6e3368);
  //              -0.5461826062085420, -0.4431702866722571, -0.7458438472286320,
  //              -0.8611805160192025,  0.5288841839862100,  0.4836992661145783,
  //              -0.5942889927274901,  0.5287333894552471,  0.3093279352228719,
  //              -0.5415645292681506,  0.0094485111801912, -0.2151605186231076,
  //              -0.0785069829906857,  0.6345480854408712,  0.4658290296396683,
  //              -0.5143497066150833
  VLOAD_64(v3, 0xbfe17a53f1e9e958, 0xbfdc5ce6e7f43e14, 0xbfe7ddf3ea78a228,
           0xbfeb8eca710827f8, 0x3fe0ec9e8632f518, 0x3fdef4edc443ec94,
           0xbfe3046a59846530, 0x3fe0eb6249006ebc, 0x3fd3cc0765615f4c,
           0xbfe1547f22bc2bc2, 0x3f8359bdb41e5580, 0xbfcb8a613f7035f0,
           0xbfb419089c73df20, 0x3fe44e37c956a792, 0x3fddd0248ff51b48,
           0xbfe0758d8413ceaa);
  asm volatile("vfmax.vv v1, v2, v3");
  //              -0.4061329687298849, -0.2985478109200665,  0.0070087316277823,
  //              -0.2169778494878496,  0.5288841839862100,  0.4836992661145783,
  //              0.5680045000966327,  0.9515829310663801,  0.3093279352228719,
  //              0.0055288881366042,  0.3717566019240965,  0.0982171502328268,
  //              -0.0785069829906857,  0.9555697921812856,  0.4810293698835877,
  //              -0.1835757691555060
  VCMP_U64(3, v1, 0xbfd9fe1522a16c7c, 0xbfd31b68470c6bc4, 0x3f7cb530120b5400,
           0xbfcbc5ee1fc0dc58, 0x3fe0ec9e8632f518, 0x3fdef4edc443ec94,
           0x3fe22d17c5fcaaf0, 0x3fee735e0c0b94e4, 0x3fd3cc0765615f4c,
           0x3f76a5759bade800, 0x3fd7cadc33d5826c, 0x3fb924c2582803f0,
           0xbfb419089c73df20, 0x3fee940719ceda38, 0x3fdec92f69043118,
           0xbfc77f692a6e3368);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
