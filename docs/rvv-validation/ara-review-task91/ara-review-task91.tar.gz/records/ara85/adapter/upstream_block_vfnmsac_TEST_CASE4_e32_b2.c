// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 365 "vfnmsac.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.73549986
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbf3c49b8);
  //                0.74252719,  0.73023552,  0.75118375,  0.04020444,
  //                -0.77184784, -0.41120139, -0.57577437, -0.15976480,
  //                -0.05041125,  0.42673740,  0.88473374, -0.49891368,
  //                -0.84324479, -0.26009968, -0.01877740, -0.13754985
  VLOAD_32(v2, 0x3f3e1643, 0x3f3af0b7, 0x3f404d94, 0x3d24ad6a, 0xbf4597d2,
           0xbed288fd, 0xbf1365f3, 0xbe239962, 0xbd4e7c07, 0x3eda7d53,
           0x3f627de9, 0xbeff719d, 0xbf57dee4, 0xbe852bc9, 0xbc99d30f,
           0xbe0cd9de);
  VLOAD_8(v0, 0xAA, 0xAA);
  //                0.89538908,  0.68592542,  0.67501348,  0.08327232,
  //                0.28473541, -0.93230879, -0.77235961, -0.92498165,
  //                -0.55227244,  0.97729182,  0.28253901,  0.45306230,
  //                -0.50359881,  0.40307203, -0.65891176, -0.59297264
  VLOAD_32(v1, 0x3f653838, 0x3f2f98cf, 0x3f2ccdaf, 0x3daa8aad, 0x3e91c8d7,
           0xbf6eabca, 0xbf45b95c, 0xbf6ccb99, 0xbf0d61ba, 0x3f7a2fcc,
           0x3e90a8f4, 0x3ee7f7c8, 0xbf00ebda, 0x3ece5f75, 0xbf28ae71,
           0xbf17cd0e);
  asm volatile("vfnmsac.vf v1, %[A], v2, v0.t" ::[A] "f"(dscalar_32));
  //                0.89538908,  1.22301352,  0.67501348,  0.11284268,
  //                0.28473541, -1.23474741, -0.77235961, -1.04248869,
  //                -0.55227244,  1.29115713,  0.28253901,  0.08611137,
  //                -0.50359881,  0.21176875, -0.65891176, -0.69414055
  VCMP_U32(11, v1, 0x3f653838, 0x3f9c8bb5, 0x3f2ccdaf, 0x3de71a10, 0x3e91c8d7,
           0xbf9e0c34, 0xbf45b95c, 0xbf857045, 0xbf0d61ba, 0x3fa544a3,
           0x3e90a8f4, 0x3db05b27, 0xbf00ebda, 0x3e58d9e8, 0xbf28ae71,
           0xbf31b332);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
