// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 52 "vfrsub.c"
  VSET(16, e64, m1);
  //               -0.0920900511004143,  0.2386858516984947, 0.7068975504949517,
  //               0.5997172971219242,  0.7714780386644180, -0.1053493184316212,
  //               0.8711121216121871, -0.7388672665065719,  0.0889924652556937,
  //               0.3266446452514173, -0.5909707717470494, -0.2733520923877579,
  //               0.2365505631181986,  0.9616545156279142, -0.9315790291358075,
  //               -0.8056559777055108
  VLOAD_64(v2, 0xbfb79336adc36440, 0x3fce8d420b880e70, 0x3fe69ee79c9ff24a,
           0x3fe330e2543f7e66, 0x3fe8aff2b634ab34, 0xbfbaf82c4551d810,
           0x3febe026872f2710, 0xbfe7a4ccf737616c, 0x3fb6c835cfdd1640,
           0x3fd4e7bef1312ccc, 0xbfe2e93b89317464, 0xbfd17e99c6464f50,
           0x3fce4749f238b5c0, 0x3feec5dfb0d5860a, 0xbfedcf7ed2f8e31e,
           0xbfe9c7ef0b824e6e);
  double dscalar_64;
  //                               -0.4500891854782252
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfdcce42defa6264);
  asm volatile("vfrsub.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //              -0.3579991343778108, -0.6887750371767198, -1.1569867359731769,
  //              -1.0498064826001494, -1.2215672241426432, -0.3447398670466040,
  //              -1.3212013070904123,  0.2887780810283467, -0.5390816507339189,
  //              -0.7767338307296425,  0.1408815862688242, -0.1767370930904673,
  //              -0.6866397485964237, -1.4117437011061393,  0.4814898436575823,
  //              0.3555667922272856
  VCMP_U64(3, v1, 0xbfd6e97533898954, 0xbfe60a71f25f34ce, 0xbff28304860e91be,
           0xbff0cc01e1de57cc, 0xbff38b8a12d8ee33, 0xbfd61037cda5ec60,
           0xbff523a3fb562c21, 0x3fd27b570f746074, 0xbfe140282978d3fa,
           0xbfe8db00e815c798, 0x3fc2086866d10cc8, 0xbfc69f5231682628,
           0xbfe5f8f3ec0b5ea2, 0xbff6968090295b9e, 0x3fded0bac6f763d8,
           0x3fd6c19b380a3a78);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
