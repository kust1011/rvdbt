// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 108 "vfsqrt.c"
  VSET(16, e64, m1);
  //              -2532126.867, -601715.939, -7176821.248,   9617114.284,
  //              -4651296.040, -9962642.835,   4027953.647,   7849763.850,
  //              -9544132.585, -8682313.823,   7018932.012,   639358.130,
  //              -7598169.215, -9585529.793, -4604984.668,   314584.590
  VLOAD_64(v2, 0xc143518f6efce4ae, 0xc1225ce7e096cbf0, 0xc15b609d4fd8b968,
           0x416257db4912ef24, 0xc151be4802974a67, 0xc16300925abc1630,
           0x414ebb18d2c34030, 0x415df1c8f662a87c, 0xc162343892b8d28c,
           0xc1608f693a52837e, 0x415ac66d00c810d8, 0x412382fc427c96a0,
           0xc15cfc164dc9e320, 0xc162486f39607ee9, 0xc151910e2ac0e818,
           0x411333625c861bc0);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfsqrt.v v3, v2, v0.t");
  //                0.000,   nan,   0.000,   3101.147,   0.000,   nan,   0.000,
  //                2801.743,   0.000,   nan,   0.000,   799.599,   0.000, nan,
  //                0.000,   560.878
  VCMP_U64(6, v3, 0x0, 0x7ff8000000000000, 0x0, 0x40a83a4b64b82189, 0x0,
           0x7ff8000000000000, 0x0, 0x40a5e37c6ac52c2f, 0x0, 0x7ff8000000000000,
           0x0, 0x4088fcca333ab72d, 0x0, 0x7ff8000000000000, 0x0,
           0x40818706fb9cc11b);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
