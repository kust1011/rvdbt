// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 364 "vfnmsub.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.16110219
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbe24f7f9);
  //               -0.31537205, -0.17563045, -0.79069936,  0.22939304,
  //               -0.89379781,  0.26157290,  0.56702632, -0.11594663,
  //               0.09605245,  0.45930776, -0.76518077, -0.26341528,
  //               0.74385208,  0.89362013, -0.21185355,  0.23924881
  VLOAD_32(v2, 0xbea17872, 0xbe33d878, 0xbf4a6b46, 0x3e6ae602, 0xbf64cfef,
           0x3e85ece2, 0x3f1128a3, 0xbded756d, 0x3dc4b726, 0x3eeb2a63,
           0xbf43e2e3, 0xbe86de5e, 0x3f3e6d17, 0x3f64c44a, 0xbe58f023,
           0x3e74fda4);
  VLOAD_8(v0, 0xAA, 0xAA);
  //                0.31856158,  0.48641542,  0.57264513,  0.30210373,
  //                -0.19719712,  0.85649359,  0.36901370, -0.78377151,
  //                0.22567192, -0.75179213, -0.65690833,  0.11298654,
  //                -0.64884853, -0.48376039, -0.11539485, -0.42667609
  VLOAD_32(v1, 0x3ea31a81, 0x3ef90b71, 0x3f1298df, 0x3e9aad57, 0xbe49ee0b,
           0x3f5b432a, 0x3ebcef5d, 0xbf48a540, 0x3e67168a, 0xbf407573,
           0xbf282b25, 0x3de7657d, 0xbf261af0, 0xbef7af71, 0xbdec5422,
           0xbeda754a);
  asm volatile("vfnmsub.vf v1, %[A], v2, v0.t" ::[A] "f"(dscalar_32));
  //                0.31856158, -0.09726786,  0.57264513,  0.27806261,
  //                -0.19719712,  0.39955589,  0.36901370, -0.24221393,
  //                0.22567192,  0.33819240, -0.65690833, -0.24521290,
  //                -0.64884853,  0.81568527, -0.11539485,  0.17051035
  VCMP_U32(11, v1, 0x3ea31a81, 0xbdc7345f, 0x3f1298df, 0x3e8e5e39, 0xbe49ee0b,
           0x3ecc9297, 0x3ebcef5d, 0xbe7806ee, 0x3e67168a, 0x3ead278e,
           0xbf282b25, 0xbe7b1917, 0xbf261af0, 0x3f50d0c0, 0xbdec5422,
           0x3e2e9a44);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
