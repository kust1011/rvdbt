// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 306 "vfsgnjx.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                               -0.1599292306617626
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfc4788f9faef060);
  //                -0.3770377828689853,  0.5963307040587882,
  //                -0.4228346580189990, -0.8395360297727528,
  //                0.2884308755790033, -0.9332093226534830,
  //                -0.3077793113682024, -0.3241690978469995,
  //                0.9848431705043186,  0.5835571766262024, 0.6934128987139432,
  //                -0.8499240402166686,  0.9392758702585176,
  //                0.8754505566292561, -0.4187493105472220, -0.7967172481248119
  VLOAD_64(v2, 0xbfd8216314b1d540, 0x3fe3152420f10f90, 0xbfdb0fb918f3a4fc,
           0xbfeadd7aa9f60146, 0x3fd275a6c6712e84, 0xbfeddcd9cc23cf06,
           0xbfd3b2a7ff2d8ea0, 0xbfd4bf2fbe681ba4, 0x3fef83d5d32028f6,
           0x3fe2ac80199e9490, 0x3fe630703f533af4, 0xbfeb3293e69a12ae,
           0x3fee0e8c4515d52c, 0x3fec03b0e2bf9ad6, 0xbfdaccc9e88176a4,
           0xbfe97eb52b9b5dac);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfsgnjx.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_64));
  //                0.0000000000000000, -0.5963307040587882, 0.0000000000000000,
  //                0.8395360297727528,  0.0000000000000000, 0.9332093226534830,
  //                0.0000000000000000,  0.3241690978469995, 0.0000000000000000,
  //                -0.5835571766262024,  0.0000000000000000,
  //                0.8499240402166686,  0.0000000000000000,
  //                -0.8754505566292561,  0.0000000000000000, 0.7967172481248119
  VCMP_U64(12, v1, 0x0, 0xbfe3152420f10f90, 0x0, 0x3feadd7aa9f60146, 0x0,
           0x3feddcd9cc23cf06, 0x0, 0x3fd4bf2fbe681ba4, 0x0, 0xbfe2ac80199e9490,
           0x0, 0x3feb3293e69a12ae, 0x0, 0xbfec03b0e2bf9ad6, 0x0,
           0x3fe97eb52b9b5dac);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
