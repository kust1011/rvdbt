// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 117 "vfcvt.c"
  VSET(16, e64, m1);
  //                3554390.405,   3670449.443,   3880983.535,   3452087.537,
  //                -5447847.496,   498812.179,   9535291.051,   113884.868,
  //                2124622.198, -2164534.614,   1377445.305, -2114478.485,
  //                -4704971.356, -7866057.432,   7002504.380, -2981734.692
  VLOAD_64(v2, 0x414b1e2b33d13be4, 0x414c00d8b8b34d48, 0x414d9c0bc4751d78,
           0x414a565bc4adf2d0, 0xc154c829dfc2d9f6, 0x411e71f0b7161c00,
           0x41622fe7619e55e2, 0x40fbcdcde34f1a00, 0x414035a7194d9794,
           0xc140839b4e886550, 0x413504a54df56888, 0xc14021d73e1606dc,
           0xc151f2b2d6cc57c8, 0xc15e01b25baceaba, 0x415ab6621850fa94,
           0xc146bfb358869da2);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.xu.f.v v3, v2, v0.t");
  //                                   0,                3670449, 0, 3452088, 0,
  //                                   498812,                      0, 113885,
  //                                   0,                      0, 0, 0, 0, 0, 0,
  //                                   0
  VCMP_U64(6, v3, 0x0000000000000000, 0x00000000003801b1, 0x0000000000000000,
           0x000000000034acb8, 0x0000000000000000, 0x0000000000079c7c,
           0x0000000000000000, 0x000000000001bcdd, 0x0000000000000000,
           0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
           0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
           0x0000000000000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
