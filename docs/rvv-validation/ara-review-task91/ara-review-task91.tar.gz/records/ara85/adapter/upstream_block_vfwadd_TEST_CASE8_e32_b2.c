// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE8(void) {
#line 473 "vfwadd.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                366783.2934919928666204, -648147.5638866436202079,
  //                24949.3815817765425891, -211759.8585660880198702,
  //                337740.3714956413023174, -528559.3617047512670979,
  //                -863948.2704646114725620, -463848.5980863422155380,
  //                958859.3069495267700404, -853775.5625991101842374,
  //                -7020.6864214694360271,  839278.6509590207133442,
  //                -443325.1460256360005587,  97289.3425237806513906,
  //                220009.0786798361223191,  491284.4355713783297688
  VLOAD_64(v2, 0x411662fd2c892a3c, 0xc123c7a720b5c00a, 0x40d85d586bd5f8c0,
           0xc109d97ede57e5ac, 0x41149d317c695a78, 0xc120215eb9315d7b,
           0xc12a5d988a7a566a, 0xc11c4fa26470bf00, 0x412d43169d287d06,
           0xc12a0e1f200cfd96, 0xc0bb6cafb9514280, 0x41299cdd4d4a8032,
           0xc11b0ef49587be8c, 0x40f7c0957afa3740, 0x410adb48a122e4d8,
           0x411dfc51be066c64);
  //                               572932.37500000
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x490be046);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfwadd.wf v4, v2, %[A], v0.t" ::[A] "f"(dscalar_32));
  //                0.0000000000000000, -75215.1888866436202079,
  //                0.0000000000000000,  361172.5164339119801298,
  //                0.0000000000000000,  44373.0132952487329021,
  //                0.0000000000000000,  109083.7769136577844620,
  //                0.0000000000000000, -280843.1875991101842374,
  //                0.0000000000000000,  1412211.0259590207133442,
  //                0.0000000000000000,  670221.7175237806513906,
  //                0.0000000000000000,  1064216.8105713783297688
  VCMP_U64(16, v4, 0x0, 0xc0f25cf305ae0050, 0x0, 0x41160b5210d40d2a, 0x0,
           0x40e5aaa06cea2850, 0x0, 0x40faa1bc6e3d0400, 0x0, 0xc111242cc019fb2c,
           0x0, 0x41358c7306a54019, 0x0, 0x4124741b6f5f46e8, 0x0,
           0x41303d18cf819b19);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE8"); TEST_CASE8(); ara_case_end("TEST_CASE8",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
