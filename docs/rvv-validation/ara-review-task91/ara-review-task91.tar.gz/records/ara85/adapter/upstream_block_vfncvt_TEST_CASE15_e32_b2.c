// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE15(void) {
#line 677 "vfncvt.c"
  VSET(16, e32, m1);
  //                       153431.9687, 153431.984375, -6652812.196,
  //                       1049714.758, 7538298.328, -8731739.480, 537176.622,
  //                       -3884944.157, 7612336.042, -2270131.404,
  //                       -4976406.726, -5260237.163, -4947737.810,
  //                       3583352.355, 7648790.331, -9360989.228
  VLOAD_64(v2, 0x4102babfc0000000, 0x4102babfe0000000, 0xc15960e30c871450,
           0x41300472c1efbd9f, 0x415cc19e94ffb79b, 0xc160a78b6f5bcd25,
           0x412064b13e931aa9, 0xc14da3c81425b914, 0x415d09ec02a8cc93,
           0xc14151d9b3c1ecaf, 0xc152fbc5ae718384, 0xc15410f34a6ddb48,
           0xc152dfc673d9ba53, 0x414b56bc2d765fad, 0x415d2d85952e8398,
           0xc161dacba74d791e);
  asm volatile("vfncvt.rod.f.f.w v4, v2");
  //                       153431.9687, 153431.984375,    -6652812.500,
  //                       1049714.875,    7538298.500,   -8731739.000,
  //                       537176.5625,   -3884944.250,    7612336.500,
  //                       -2270131.250, -4976406.500,     -5260237.500,
  //                       -4947737.500,    3583352.250,    7648790.500,
  //                       -9360989.000
  VCMP_U32(30, v4, 0x4815d5fe, 0x4815d5ff, 0xcacb0719, 0x49802397, 0x4ae60cf5,
           0xcb053c5b, 0x49032589, 0xca6d1e41, 0x4ae84f61, 0xca0a8ecd,
           0xca97de2d, 0xcaa0879b, 0xca96fe33, 0x4a5ab5e1, 0x4ae96c2d,
           0xcb0ed65d);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE15"); TEST_CASE15(); ara_case_end("TEST_CASE15",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
