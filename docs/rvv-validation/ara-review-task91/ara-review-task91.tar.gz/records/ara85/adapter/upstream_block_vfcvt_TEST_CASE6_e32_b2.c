// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE6(void) {
#line 364 "vfcvt.c"
  VSET(16, e32, m1);
  //                85074.883, -2035.769,   67397.633, -57745.480,   82113.172,
  //                18415.770,   57859.465,   83291.773, -83693.375, 43321.199,
  //                94626.156, -53520.090,   9604.658, -5764.834,   94299.633,
  //                57572.980
  VLOAD_32(v2, 0x47a62971, 0xc4fe789f, 0x4783a2d1, 0xc761917b, 0x47a06096,
           0x468fdf8a, 0x47620377, 0x47a2ade3, 0xc7a376b0, 0x47293933,
           0x47b8d114, 0xc7511017, 0x461612a2, 0xc5b426ac, 0x47b82dd1,
           0x4760e4fb);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.rtz.xu.f.v v3, v2, v0.t");
  //                           0,              0,              0, 0, 0, 18415,
  //                           0,          83291,              0, 43321, 0, 0,
  //                           0,              0,              0,          57572
  VCMP_U32(17, v3, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
           0x000047ef, 0x00000000, 0x0001455b, 0x00000000, 0x0000a939,
           0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
           0x0000e0e4);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE6"); TEST_CASE6(); ara_case_end("TEST_CASE6",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
