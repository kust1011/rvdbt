// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 59 "vfsgnj.c"
  VSET(16, e64, m1);
  //              -0.1900636538602862, -0.9484843154859770,  0.5869658512198073,
  //              0.4707187701595239,  0.1954104859873083,  0.0486819373954939,
  //              -0.1899986048192088, -0.1837438621239862,  0.2694105234528963,
  //              -0.7960262036276018,  0.6381040017115214,  0.2199215324293253,
  //              0.4219965521278597, -0.6541697303087526,  0.7254411745966671,
  //              0.2439726910863504
  VLOAD_64(v2, 0xbfc854017cbe7d20, 0xbfee59fbc778ffbc, 0x3fe2c86c9bdb73b4,
           0x3fde20419edcb428, 0x3fc90335f74e33c8, 0x3fa8ecd6c20a0480,
           0xbfc851dfd0fdf7f8, 0xbfc784eb3b54e580, 0x3fd13e05a2db6b68,
           0xbfe9790bf1eadde4, 0x3fe46b59155986dc, 0x3fcc266386bc2e10,
           0x3fdb01fdd39a7d9c, 0xbfe4eef55bb6b208, 0x3fe736d06902107a,
           0x3fcf3a7f44aa9f48);
  //               0.0713540199640168,  0.3499800646587572, -0.5478360240866667,
  //               -0.7324007835973676,  0.5646664961108800,
  //               -0.7430380608733607, -0.5676032662558192,
  //               -0.7382565525776155, -0.7933198466305424,
  //               -0.0650991402083496, -0.1766522935757786,
  //               -0.4663829943595241, -0.1565231028144627,
  //               -0.0629224333525875, -0.9086692399439535, -0.1206057821437510
  VLOAD_64(v3, 0x3fb24441ce2eff50, 0x3fd66612c8fd8664, 0xbfe187df69e0bb9c,
           0xbfe76fd3c4a3b1e8, 0x3fe211bf78be2e36, 0xbfe7c6f7c1644c86,
           0xbfe229ce53357d20, 0xbfe79fcc34ac1d30, 0xbfe962e04d917824,
           0xbfb0aa5656314cf0, 0xbfc69c8ad7d5ef20, 0xbfddd9380f0bd244,
           0xbfc408f2f3d40a40, 0xbfb01baf416f2160, 0xbfed13d1838e183a,
           0xbfbee005420412c0);
  asm volatile("vfsgnj.vv v1, v2, v3");
  //               0.1900636538602862,  0.9484843154859770, -0.5869658512198073,
  //               -0.4707187701595239,  0.1954104859873083,
  //               -0.0486819373954939, -0.1899986048192088,
  //               -0.1837438621239862, -0.2694105234528963,
  //               -0.7960262036276018, -0.6381040017115214,
  //               -0.2199215324293253, -0.4219965521278597,
  //               -0.6541697303087526, -0.7254411745966671, -0.2439726910863504
  VCMP_U64(3, v1, 0x3fc854017cbe7d20, 0x3fee59fbc778ffbc, 0xbfe2c86c9bdb73b4,
           0xbfde20419edcb428, 0x3fc90335f74e33c8, 0xbfa8ecd6c20a0480,
           0xbfc851dfd0fdf7f8, 0xbfc784eb3b54e580, 0xbfd13e05a2db6b68,
           0xbfe9790bf1eadde4, 0xbfe46b59155986dc, 0xbfcc266386bc2e10,
           0xbfdb01fdd39a7d9c, 0xbfe4eef55bb6b208, 0xbfe736d06902107a,
           0xbfcf3a7f44aa9f48);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
