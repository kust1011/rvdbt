// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 152 "vfnmsub.c"
  VSET(16, e32, m1);
  //               0.76259303, -0.43966120, -0.19390504, -0.57240725,
  //               -0.57148474, -0.93710214,  0.24273214,  0.44242114,
  //               -0.93160200, -0.56412256, -0.75430351, -0.02741535,
  //               -0.60542876, -0.93627954,  0.02798123,  0.23119579
  VLOAD_32(v2, 0x3f43394c, 0xbee11b46, 0xbe468f0b, 0xbf128948, 0xbf124cd3,
           0xbf6fe5ed, 0x3e788ec6, 0x3ee28506, 0xbf6e7d78, 0xbf106a56,
           0xbf411a09, 0xbce09629, 0xbf1afd61, 0xbf6fb004, 0x3ce538e6,
           0x3e6cbe97);
  //               0.48736989,  0.19715627, -0.47227743,  0.13752034,
  //               -0.16710435,  0.84761631,  0.37147006,  0.25389814,
  //               -0.44707820,  0.38169226, -0.82191414, -0.81056035,
  //               0.29047397, -0.46743703, -0.91869444, -0.08079135
  VLOAD_32(v3, 0x3ef9888c, 0x3e49e355, 0xbef1ce59, 0x3e0cd222, 0xbe2b1d67,
           0x3f58fd62, 0x3ebe3153, 0x3e81fef0, 0xbee4e76f, 0x3ec36d2b,
           0xbf5268f7, 0xbf4f80e2, 0x3e94b901, 0xbeef53e8, 0xbf6b2f8f,
           0xbda575f0);
  VLOAD_8(v0, 0xAA, 0xAA);
  //              -0.48655373, -0.87417608,  0.17854533,  0.67417324,
  //              0.46947387,  0.29113689, -0.11920074,  0.63394654,
  //              -0.82611400, -0.84088647, -0.13328743,  0.29885510,
  //              0.91797447, -0.15480036,  0.76857966,  0.16230854
  VLOAD_32(v1, 0xbef91d92, 0xbf5fca01, 0x3e36d496, 0x3f2c969e, 0x3ef05ee1,
           0x3e950fe5, 0xbdf41f84, 0x3f224a52, 0xbf537c35, 0xbf574456,
           0xbe087c80, 0x3e990389, 0x3f6b0060, 0xbe1e83fc, 0x3f44c1a3,
           0x3e263436);
  asm volatile("vfnmsub.vv v1, v2, v3, v0.t");
  //              -0.48655373, -0.18718503,  0.17854533,  0.52342200,
  //              0.46947387,  1.12044132, -0.11920074, -0.02657321,
  //              -0.82611400, -0.09267077, -0.13328743, -0.80236715,
  //              0.91797447, -0.61237341,  0.76857966, -0.11831641
  VCMP_U32(5, v1, 0xbef91d92, 0xbe3fad70, 0x3e36d496, 0x3f05fefc, 0x3ef05ee1,
           0x3f8f6a9f, 0xbdf41f84, 0xbcd9b00d, 0xbf537c35, 0xbdbdca2c,
           0xbe087c80, 0xbf4d67ef, 0x3f6b0060, 0xbf1cc481, 0x3f44c1a3,
           0xbdf24fdf);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
