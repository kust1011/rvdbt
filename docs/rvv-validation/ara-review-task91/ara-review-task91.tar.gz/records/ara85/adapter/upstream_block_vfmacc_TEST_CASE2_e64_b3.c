// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 160 "vfmacc.c"
  VSET(16, e64, m1);
  VLOAD_64(v2, 0xbfecc6a774980626, 0x3fe28c1090d967fc, 0xbfee2661acda592c,
           0x3fd5ce1d611f1590, 0xbfbd1c5eae4ec060, 0x3fd5059e742594fc,
           0x3fef4d4c223c8f84, 0x3fe34ebdaa37ac76, 0xbfc07b7b047228c0,
           0x3fe4fa2ab8176850, 0x3fe5b6a7d0ad9fa2, 0x3fe6278a8249a986,
           0x3fcbfad5c52fcfd8, 0xbfc0c664520a9f78, 0xbfe84f6c7558d3f0,
           0xbfd9ac00a3c919a8);
  VLOAD_64(v3, 0x3fd36160c2769da4, 0x3fe00d350479c3ea, 0x3fc852de63fd6e08,
           0x3fd51548a8a19488, 0x3fe306781d37ea9a, 0xbfec06bc7e604fb8,
           0x3fd7ce88a1b60584, 0x3fed4f57e864d750, 0x3fb4a00b38c069f0,
           0x3fc6b96b2d465dc0, 0xbfe6785f9bcfaa42, 0x3fedb1a26b57c7d6,
           0xbfe78bfa6823d662, 0x3fd030a94086f244, 0xbfeaab0418e7f974,
           0xbfd9b4b308e446c8);
  VLOAD_64(v1, 0xbfb0ffef54d0f220, 0xbfe5937e2c0e5202, 0x3fdba8604ddf0d80,
           0xbfc4d508600804d8, 0x3f93c690cdf47e40, 0xbfd6835fd0838044,
           0xbfdef17840e363cc, 0x3feaa6ceed574e1a, 0x3f9b1871c270c340,
           0x3fa0870f4852d0c0, 0xbfeab4640fc8d962, 0x3fe6f5f737b7bbe2,
           0xbfe7bda7d6ff9552, 0xbfd30ea762d6f1ec, 0x3fdd296165522d4c,
           0xbfe910568693fcea);
  VLOAD_8(v0, 0xAA, 0xAA);
  asm volatile("vfmacc.vv v1, v2, v3, v0.t");
  VCMP_U64(6, v1, 0xbfb0ffef54d0f220, 0xbfd88b9c84a68118, 0x3fdba8604ddf0d80,
           0xbfa9dd1149664d37, 0x3f93c690cdf47e40, 0xbfe4765babf13c96,
           0xbfdef17840e363cc, 0x3ff62b051f10acd5, 0x3f9b1871c270c340,
           0x3fc3074db9c9d78e, 0xbfeab4640fc8d962, 0x3ff5c263f334aac4,
           0xbfe7bda7d6ff9552, 0xbfd52dd4811c5fc3, 0x3fdd296165522d4c,
           0xbfe3e8809d5ef572);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
