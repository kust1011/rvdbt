// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 72 "vfmacc.c"
  VSET(16, e64, m1);
  //              -0.8992497708533775,  0.5795977429472710, -0.9421852470430045,
  //              0.3407052467776674, -0.1137141395145149,  0.3284679540868891,
  //              0.9781857174570949,  0.6033619236526551, -0.1287683269222892,
  //              0.6555379481826638,  0.6785468173738887,  0.6923267883951645,
  //              0.2185923779321672, -0.1310544396012536, -0.7596952716763763,
  //              -0.4011231994121780,
  VLOAD_64(v2, 0xbfecc6a774980626, 0x3fe28c1090d967fc, 0xbfee2661acda592c,
           0x3fd5ce1d611f1590, 0xbfbd1c5eae4ec060, 0x3fd5059e742594fc,
           0x3fef4d4c223c8f84, 0x3fe34ebdaa37ac76, 0xbfc07b7b047228c0,
           0x3fe4fa2ab8176850, 0x3fe5b6a7d0ad9fa2, 0x3fe6278a8249a986,
           0x3fcbfad5c52fcfd8, 0xbfc0c664520a9f78, 0xbfe84f6c7558d3f0,
           0xbfd9ac00a3c919a8);
  //               0.3028184794479449,  0.5016121947684244,  0.1900289524299839,
  //               0.3294240614689632,  0.5945396967575391, -0.8758223026547887,
  //               0.3719808177193829,  0.9159354723876536,  0.0805670751146079,
  //               0.1775335284298603, -0.7021940272509897,  0.9279338928738479,
  //               -0.7358371767028979,  0.2529700403354449,
  //               -0.8333759771774525, -0.4016540133317048,
  VLOAD_64(v3, 0x3fd36160c2769da4, 0x3fe00d350479c3ea, 0x3fc852de63fd6e08,
           0x3fd51548a8a19488, 0x3fe306781d37ea9a, 0xbfec06bc7e604fb8,
           0x3fd7ce88a1b60584, 0x3fed4f57e864d750, 0x3fb4a00b38c069f0,
           0x3fc6b96b2d465dc0, 0xbfe6785f9bcfaa42, 0x3fedb1a26b57c7d6,
           0xbfe78bfa6823d662, 0x3fd030a94086f244, 0xbfeaab0418e7f974,
           0xbfd9b4b308e446c8);
  //              -0.0664052564688480, -0.6742544994800144,  0.4321518669568931,
  //              -0.1627512425330113,  0.0193121553139675, -0.3517684494272582,
  //              -0.4834881433176264,  0.8328623424117183,  0.0264604353835154,
  //              0.0322804237161178, -0.8345203693668675,  0.7175251091228996,
  //              -0.7419013213335950, -0.2977694001417877,  0.4556506623709609,
  //              -0.7832443836668095,
  VLOAD_64(v1, 0xbfb0ffef54d0f220, 0xbfe5937e2c0e5202, 0x3fdba8604ddf0d80,
           0xbfc4d508600804d8, 0x3f93c690cdf47e40, 0xbfd6835fd0838044,
           0xbfdef17840e363cc, 0x3feaa6ceed574e1a, 0x3f9b1871c270c340,
           0x3fa0870f4852d0c0, 0xbfeab4640fc8d962, 0x3fe6f5f737b7bbe2,
           0xbfe7bda7d6ff9552, 0xbfd30ea762d6f1ec, 0x3fdd296165522d4c,
           0xbfe910568693fcea);
  asm volatile("vfmacc.vv v1, v2, v3");
  //              -0.3387147047225807, -0.3835212035574087,  0.2531093914663254,
  //              -0.0505147363757267, -0.0482954147100367, -0.6394480093239447,
  //              -0.1196218202565150,  1.3855029309732363,  0.0160859479159849,
  //              0.1486603886766570, -1.3109918917369803,  1.3599586010192732,
  //              -0.9027497195599737, -0.3309222470138559,  1.0887624517613512,
  //              -0.6221316407824544,
  VCMP_U64(3, v1, 0xbfd5ad8070dd4c48, 0xbfd88b9c84a68118, 0x3fd032f1bbaa2211,
           0xbfa9dd1149664d37, 0xbfa8ba2d3573e621, 0xbfe4765babf13c96,
           0xbfbe9f891de3c4d6, 0x3ff62b051f10acd5, 0x3f9078d5b0e5b2ba,
           0x3fc3074db9c9d78e, 0xbff4f9d2a2454dd5, 0x3ff5c263f334aac4,
           0xbfece353613f76db, 0xbfd52dd4811c5fc3, 0x3ff16b922d36d831,
           0xbfe3e8809d5ef572);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
