// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 189 "vfmsac.c"
  VSET(16, e64, m1);
  //               0.0971325394189311,  0.6403859199401045,  0.3478142243141771,
  //               -0.4702414117546168,  0.8862438155310881, 0.6157878617136987,
  //               -0.9954501284062294, -0.2761157935600853,
  //               -0.7189549700888722, -0.2302799669824283, 0.0093666993515229,
  //               0.9188774299961215, -0.4297410504980956,  0.2729294776457381,
  //               -0.1419575372981836, -0.8472908703054822
  VLOAD_64(v2, 0x3fb8ddad982e8680, 0x3fe47e0a9cdec59e, 0x3fd6429697a0d4f8,
           0xbfde186f6f2d8030, 0x3fec5c1bfd7f9ffe, 0x3fe3b488beeab100,
           0xbfefdaba3a49b85e, 0xbfd1abe193cffa54, 0xbfe701adda7a81f6,
           0xbfcd79d05f8e86d0, 0x3f832ed91b170d00, 0x3fed6771a3dbb538,
           0xbfdb80e09b68d514, 0x3fd177ad33269468, 0xbfc22baa220ee628,
           0xbfeb1d01be452a62);
  //              -0.2416734667201210, -0.2737616510555549,  0.6084509432766920,
  //              -0.4000545529138850,  0.5985258122916897, -0.9559409603601607,
  //              0.5010970610326939,  0.5772808284477746, -0.4551243154247406,
  //              0.6584804564152213,  0.6542532086910551, -0.2215058802905889,
  //              0.3203723346938081,  0.0696368102348055,  0.8882580549203218,
  //              0.7725843936650791
  VLOAD_64(v3, 0xbfceef27f9efdac8, 0xbfd1854f968baf44, 0x3fe3786e1cd2fff2,
           0xbfd99a7e695862ec, 0x3fe3271f9ab3593a, 0xbfee97117f34eb4c,
           0x3fe008fcb4283a76, 0x3fe27915a4d94fb2, 0xbfdd20c1bc974608,
           0x3fe512459b2b7912, 0x3fe4efa46cd43256, 0xbfcc5a4dffdc2170,
           0x3fd480faf7036588, 0x3fb1d3b7ce8e6640, 0x3fec6c9c280952c6,
           0x3fe8b902e80620ce);
  VLOAD_8(v0, 0xAA, 0xAA);
  //              -0.8982912058335177,  0.5582779858188844, -0.3988318240568800,
  //              0.0267896464795028,  0.8241806039831361,  0.2839220639224551,
  //              -0.4781090814672235, -0.1240154287362147,  0.4586341020154134,
  //              -0.6132901056934972,  0.1207753636997857,  0.4420874266235846,
  //              0.8256868703569773,  0.0642541522901756, -0.3012484644971416,
  //              0.7323810741358745
  VLOAD_64(v1, 0xbfecbecd32eadc10, 0x3fe1dd69cb65674e, 0xbfd98675ea3b69b0,
           0x3f9b6ebebe00e300, 0x3fea5fb000835cf4, 0x3fd22bc772ca399c,
           0xbfde9956d534a0f8, 0xbfbfbf79a29f1810, 0x3fdd5a42d93f2348,
           0xbfe3a012925d3f1c, 0x3fbeeb225d40ca30, 0x3fdc4b290fd48cd4,
           0x3fea6c06df1d6f14, 0x3fb072f5cab7f020, 0xbfd347a7a3bf1174,
           0x3fe76faa6f33ef10);
  asm volatile("vfmsac.vv v1, v2, v3, v0.t");
  //              -0.8982912058335177, -0.7335910925744179, -0.3988318240568800,
  //              0.1613325712615846,  0.8241806039831361, -0.8725789038271781,
  //              -0.4781090814672235, -0.0353809253176660,  0.4586341020154134,
  //              0.4616552479316257,  0.1207753636997857, -0.6456241806340295,
  //              0.8256868703569773, -0.0452482140478748, -0.3012484644971416,
  //              -1.3869847774287927
  VCMP_U64(6, v1, 0xbfecbecd32eadc10, 0xbfe7799406e7cf1f, 0xbfd98675ea3b69b0,
           0x3fc4a68bb2ac8e62, 0x3fea5fb000835cf4, 0xbfebec2a97e3c096,
           0xbfde9956d534a0f8, 0xbfa21d72da487f01, 0x3fdd5a42d93f2348,
           0x3fdd8bc273f9289e, 0x3fbeeb225d40ca30, 0xbfe4a8f40aaa8efa,
           0x3fea6c06df1d6f14, 0xbfa72ac61f1378a7, 0xbfd347a7a3bf1174,
           0xbff63116f331b43d);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
