// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE5(void) {
#line 318 "vfcvt.c"
  VSET(16, e64, m1);
  //              -5386285.220, -9081004.335, -9603879.062, -4621060.923,
  //              2017661.058,   1106405.978, -2095853.299,   1911589.313,
  //              4833261.528,   1291127.404, -9941577.120,   9259799.184,
  //              -8569693.727,   4926687.920, -7537625.130, -6328586.289
  VLOAD_64(v2, 0xc1548c0b4e12be63, 0xc16152158ab92a41, 0xc1625164e1fd6af4,
           0xc151a0c13b0c041c, 0x413ec97d0edd7a68, 0x4130e1e5fa5c8120,
           0xc13ffaed4c78fc7c, 0x413d2b2550357b50, 0x41526ffb61d23f42,
           0x4133b377675b6328, 0xc162f64923d5cce3, 0x4161a962e5e3a1e8,
           0xc160586bb74734b0, 0x4152cb37fae70f80, 0xc15cc0f6484f174c,
           0xc1582442928257b8);
  asm volatile("vfcvt.rtz.xu.f.v v3, v2");
  //                                   0,                      0, 0, 0, 2017661,
  //                                   1106405,                      0, 1911589,
  //                                   4833261,                1291127, 0,
  //                                   9259799,                      0, 4926687,
  //                                   0,                      0
  VCMP_U64(15, v3, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
           0x0000000000000000, 0x00000000001ec97d, 0x000000000010e1e5,
           0x0000000000000000, 0x00000000001d2b25, 0x000000000049bfed,
           0x000000000013b377, 0x0000000000000000, 0x00000000008d4b17,
           0x0000000000000000, 0x00000000004b2cdf, 0x0000000000000000,
           0x0000000000000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE5"); TEST_CASE5(); ara_case_end("TEST_CASE5",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
