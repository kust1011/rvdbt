// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 252 "vfcvt.c"
  VSET(16, e64, m1);
  //                3087905.033, -2534011.630,   7824302.813, -9294206.521,
  //                6436555.847,   6645117.193,   1358075.867,   5694551.012,
  //                -9840938.636,   4621816.383,   2584370.751,   5569558.860,
  //                495487.041,   4759865.418, -6831172.669,   8371055.296
  VLOAD_64(v2, 0x41478f10842c8b9c, 0xc143553dd0971c82, 0x415dd8ebb40e1fe0,
           0xc161ba2fd0a8a593, 0x41588db2f632700c, 0x4159595f4c588b60,
           0x4134b8fbde131210, 0x4155b915c0cb4294, 0xc162c52554566300,
           0x4151a17e187d1aa8, 0x4143b7996029dc68, 0x41553f05b70b6824,
           0x411e3dfc2a598ba0, 0x4152284e5ac4da5a, 0xc15a0f112acbf258,
           0x415feedbd2ed6038);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.x.f.v v3, v2, v0.t");
  //                                   0,               -2534012, 0, -9294207,
  //                                   0,                6645117, 0, 5694551, 0,
  //                                   4621816,                      0, 5569559,
  //                                   0,                4759865, 0, 8371055
  VCMP_U64(12, v3, 0x0000000000000000, 0xffffffffffd95584, 0x0000000000000000,
           0xffffffffff722e81, 0x0000000000000000, 0x000000000065657d,
           0x0000000000000000, 0x000000000056e457, 0x0000000000000000,
           0x00000000004685f8, 0x0000000000000000, 0x000000000054fc17,
           0x0000000000000000, 0x000000000048a139, 0x0000000000000000,
           0x00000000007fbb6f);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
