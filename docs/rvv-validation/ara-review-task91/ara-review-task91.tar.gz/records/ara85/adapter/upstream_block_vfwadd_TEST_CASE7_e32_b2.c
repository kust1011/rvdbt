// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE7(void) {
#line 412 "vfwadd.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //               366783.2934919928666204, -648147.5638866436202079,
  //               24949.3815817765425891, -211759.8585660880198702,
  //               337740.3714956413023174, -528559.3617047512670979,
  //               -863948.2704646114725620, -463848.5980863422155380,
  //               958859.3069495267700404, -853775.5625991101842374,
  //               -7020.6864214694360271,  839278.6509590207133442,
  //               -443325.1460256360005587,  97289.3425237806513906,
  //               220009.0786798361223191,  491284.4355713783297688
  VLOAD_64(v2, 0x411662fd2c892a3c, 0xc123c7a720b5c00a, 0x40d85d586bd5f8c0,
           0xc109d97ede57e5ac, 0x41149d317c695a78, 0xc120215eb9315d7b,
           0xc12a5d988a7a566a, 0xc11c4fa26470bf00, 0x412d43169d287d06,
           0xc12a0e1f200cfd96, 0xc0bb6cafb9514280, 0x41299cdd4d4a8032,
           0xc11b0ef49587be8c, 0x40f7c0957afa3740, 0x410adb48a122e4d8,
           0x411dfc51be066c64);
  //                               572932.37500000
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x490be046);
  asm volatile("vfwadd.wf v4, v2, %[A]" ::[A] "f"(dscalar_32));
  //               939715.6684919928666204, -75215.1888866436202079,
  //               597881.7565817765425891,  361172.5164339119801298,
  //               910672.7464956413023174,  44373.0132952487329021,
  //               -291015.8954646114725620,  109083.7769136577844620,
  //               1531791.6819495267700404, -280843.1875991101842374,
  //               565911.6885785305639729,  1412211.0259590207133442,
  //               129607.2289743639994413,  670221.7175237806513906,
  //               792941.4536798361223191,  1064216.8105713783297688
  VCMP_U64(14, v4, 0x412cad875644951e, 0xc0f25cf305ae0050, 0x41223ef3835eafc6,
           0x41160b5210d40d2a, 0x412bcaa17e34ad3c, 0x40e5aaa06cea2850,
           0xc111c31f94f4acd4, 0x40faa1bc6e3d0400, 0x41375f8fae943e83,
           0xc111242cc019fb2c, 0x4121452f608d5d7b, 0x41358c7306a54019,
           0x40ffa473a9e105d0, 0x4124741b6f5f46e8, 0x412832dae848b936,
           0x41303d18cf819b19);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE7"); TEST_CASE7(); ara_case_end("TEST_CASE7",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
