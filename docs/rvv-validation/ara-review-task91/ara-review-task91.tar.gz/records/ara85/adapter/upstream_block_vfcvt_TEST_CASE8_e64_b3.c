// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE8(void) {
#line 519 "vfcvt.c"
  VSET(16, e64, m1);
  //                1347922.217,   7326256.926,   2532328.150, -4365139.352,
  //                -3892733.643, -3401324.772, -2109243.969,   61221.157,
  //                -307581.498, -6001564.901, -1299579.664, -2048360.900,
  //                3486773.936, -5491246.977, -2222467.648,   1432204.815
  VLOAD_64(v2, 0x413491523797bd28, 0x415bf28c3b410560, 0x414351f41339c8f8,
           0xc150a6d4d6864763, 0xc14db2fed245a01c, 0xc149f33662d1f60e,
           0xc140179dfc15a4ac, 0x40ede4a503831a00, 0xc112c5f5fdac3c80,
           0xc156e4e739a40168, 0xc133d47ba9e7da00, 0xc13f4168e650cc0c,
           0x414a9a1af7c5dda0, 0xc154f28bbe844db6, 0xc140f4c1d2e7a21a,
           0x4135da8cd09570f8);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.rtz.x.f.v v3, v2, v0.t");
  //                                   0,                7326256, 0, -4365139,
  //                                   0,               -3401324, 0, 61221, 0,
  //                                   -6001564,                      0,
  //                                   -2048360,                      0,
  //                                   -5491246,                      0, 1432204
  VCMP_U64(24, v3, 0x0000000000000000, 0x00000000006fca30, 0x0000000000000000,
           0xffffffffffbd64ad, 0x0000000000000000, 0xffffffffffcc1994,
           0x0000000000000000, 0x000000000000ef25, 0x0000000000000000,
           0xffffffffffa46c64, 0x0000000000000000, 0xffffffffffe0be98,
           0x0000000000000000, 0xffffffffffac35d2, 0x0000000000000000,
           0x000000000015da8c);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE8"); TEST_CASE8(); ara_case_end("TEST_CASE8",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
