// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE8(void) {
#line 498 "vfcvt.c"
  VSET(16, e32, m1);
  //              -31395.312,   38407.539,   39625.664, -19419.770, -77414.898,
  //              -96104.727, -8227.330, -45789.250, -74805.781,   78266.945,
  //              1635.832, -33150.762,   17428.920, -93694.898,   93592.562,
  //              -83328.680
  VLOAD_32(v2, 0xc6f546a0, 0x4716078a, 0x471ac9aa, 0xc697b78a, 0xc7973373,
           0xc7bbb45d, 0xc6008d52, 0xc732dd40, 0xc7921ae4, 0x4798dd79,
           0x44cc7aa0, 0xc7017ec3, 0x468829d7, 0xc7b6ff73, 0x47b6cc48,
           0xc7a2c057);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfcvt.rtz.x.f.v v3, v2, v0.t");
  //                           0,          38407,              0, -19419, 0,
  //                           -96104,              0,         -45789, 0, 78266,
  //                           0,         -33150,              0, -93694, 0,
  //                           -83328
  VCMP_U32(23, v3, 0x00000000, 0x00009607, 0x00000000, 0xffffb425, 0x00000000,
           0xfffe8898, 0x00000000, 0xffff4d23, 0x00000000, 0x000131ba,
           0x00000000, 0xffff7e82, 0x00000000, 0xfffe9202, 0x00000000,
           0xfffeba80);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE8"); TEST_CASE8(); ara_case_end("TEST_CASE8",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
