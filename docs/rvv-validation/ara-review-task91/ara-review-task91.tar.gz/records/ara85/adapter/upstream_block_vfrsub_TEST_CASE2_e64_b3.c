// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 126 "vfrsub.c"
  VSET(16, e64, m1);
  //                -0.0920900511004143,  0.2386858516984947,
  //                0.7068975504949517,  0.5997172971219242, 0.7714780386644180,
  //                -0.1053493184316212,  0.8711121216121871,
  //                -0.7388672665065719,  0.0889924652556937,
  //                0.3266446452514173, -0.5909707717470494,
  //                -0.2733520923877579,  0.2365505631181986,
  //                0.9616545156279142, -0.9315790291358075, -0.8056559777055108
  VLOAD_64(v2, 0xbfb79336adc36440, 0x3fce8d420b880e70, 0x3fe69ee79c9ff24a,
           0x3fe330e2543f7e66, 0x3fe8aff2b634ab34, 0xbfbaf82c4551d810,
           0x3febe026872f2710, 0xbfe7a4ccf737616c, 0x3fb6c835cfdd1640,
           0x3fd4e7bef1312ccc, 0xbfe2e93b89317464, 0xbfd17e99c6464f50,
           0x3fce4749f238b5c0, 0x3feec5dfb0d5860a, 0xbfedcf7ed2f8e31e,
           0xbfe9c7ef0b824e6e);
  double dscalar_64;
  //                               -0.4500891854782252
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfdcce42defa6264);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfrsub.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_64));
  //                0.0000000000000000, -0.6887750371767198, 0.0000000000000000,
  //                -1.0498064826001494,  0.0000000000000000,
  //                -0.3447398670466040,  0.0000000000000000,
  //                0.2887780810283467,  0.0000000000000000,
  //                -0.7767338307296425,  0.0000000000000000,
  //                -0.1767370930904673,  0.0000000000000000,
  //                -1.4117437011061393,  0.0000000000000000, 0.3555667922272856
  VCMP_U64(6, v1, 0x0, 0xbfe60a71f25f34ce, 0x0, 0xbff0cc01e1de57cc, 0x0,
           0xbfd61037cda5ec60, 0x0, 0x3fd27b570f746074, 0x0, 0xbfe8db00e815c798,
           0x0, 0xbfc69f5231682628, 0x0, 0xbff6968090295b9e, 0x0,
           0x3fd6c19b380a3a78);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
