// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE9(void) {
#line 586 "vfcvt.c"
  VSET(16, e64, m1);
  //                 18446744073707704187,    18446744073702261660, 4325496,
  //                 3834488,    18446744073707063867,    18446744073706356425,
  //                 5215660,    18446744073707545423,                  69532,
  //                 18446744073707444829,                4236283, 3402850,
  //                 18446744073708706866,                 275183, 4230347,
  //                 18446744073704794800
  VLOAD_64(v2, 0xffffffffffe3cf7b, 0xffffffffff90c39c, 0x0000000000420078,
           0x00000000003a8278, 0xffffffffffda0a3b, 0xffffffffffcf3ec9,
           0x00000000004f95ac, 0xffffffffffe1634f, 0x0000000000010f9c,
           0xffffffffffdfda5d, 0x000000000040a3fb, 0x000000000033ec62,
           0xfffffffffff31c32, 0x00000000000432ef, 0x0000000000408ccb,
           0xffffffffffb76ab0);
  asm volatile("vfcvt.f.xu.v v3, v2");
  //                18446744073707704320.000,   18446744073702260736.000,
  //                4325496.000,   3834488.000,   18446744073707063296.000,
  //                18446744073706356736.000,   5215660.000,
  //                18446744073707544576.000,   69532.000,
  //                18446744073707444224.000,   4236283.000,   3402850.000,
  //                18446744073708707840.000,   275183.000,   4230347.000,
  //                18446744073704794112.000
  VCMP_U64(27, v3, 0x43effffffffffc7a, 0x43effffffffff218, 0x4150801e00000000,
           0x414d413c00000000, 0x43effffffffffb41, 0x43effffffffff9e8,
           0x4153e56b00000000, 0x43effffffffffc2c, 0x40f0f9c000000000,
           0x43effffffffffbfb, 0x415028fec0000000, 0x4149f63100000000,
           0x43effffffffffe64, 0x4110cbbc00000000, 0x41502332c0000000,
           0x43effffffffff6ed);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE9"); TEST_CASE9(); ara_case_end("TEST_CASE9",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
