// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE5(void) {
#line 209 "vfwcvt.c"
  VSET(16, e32, m1);
  //           -139027333120.000,   783549530112.000,   166903955456.000,
  //           -848099999744.000, -671032279040.000, -402660294656.000,
  //           -259808854016.000,   248555126784.000,   712853684224.000,
  //           -492155797504.000, -448682098688.000, -916605566976.000,
  //           67602378752.000,   519669350400.000,   569111478272.000,
  //           -920229773312.000
  VLOAD_32(v2, 0xd2017ab3, 0x53366f31, 0x521b7101, 0xd34576b3, 0xd31c3ca4,
           0xd2bb80d9, 0xd271f742, 0x52677c29, 0x5325f964, 0xd2e52d8b,
           0xd2d0ef13, 0xd35569f3, 0x517bd6a7, 0x52f1fd6a, 0x530481b0,
           0xd35641f8);
  asm volatile("vfwcvt.rtz.xu.f.v v4, v2");
  //                                   0,           783549530112, 166903955456,
  //                                   0,                      0, 0, 0,
  //                                   248555126784,           712853684224, 0,
  //                                   0,                      0, 67602378752,
  //                                   519669350400,           569111478272, 0
  VCMP_U64(10, v4, 0x0000000000000000, 0x000000b66f310000, 0x00000026dc404000,
           0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
           0x0000000000000000, 0x00000039df0a4000, 0x000000a5f9640000,
           0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
           0x0000000fbd6a7000, 0x00000078feb50000, 0x0000008481b00000,
           0x0000000000000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE5"); TEST_CASE5(); ara_case_end("TEST_CASE5",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
