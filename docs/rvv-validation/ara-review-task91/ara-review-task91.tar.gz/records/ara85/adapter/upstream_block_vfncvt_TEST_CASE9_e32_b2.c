// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE9(void) {
#line 402 "vfncvt.c"
  VSET(16, e32, m1);
  //                 18446744073704835106,    18446744073709117625,
  //                 18446744073705901616,        2086515, 18446744073699655996,
  //                 932771,         255753,        3148047,
  //                 18446744073705977615,    18446744073704792883,
  //                 18446744073704699584,        8685460, 18446744073709143843,
  //                 18446744073703142874,        3905530, 18446744073704152149
  VLOAD_64(v2, 0xffffffffffb80822, 0xfffffffffff960b9, 0xffffffffffc84e30,
           0x00000000001fd673, 0xffffffffff69013c, 0x00000000000e3ba3,
           0x000000000003e709, 0x000000000030090f, 0xffffffffffc9770f,
           0xffffffffffb76333, 0xffffffffffb5f6c0, 0x0000000000848794,
           0xfffffffffff9c723, 0xffffffffff9e35da, 0x00000000003b97fa,
           0xffffffffffad9c55);
  asm volatile("vfncvt.f.xu.w v4, v2");
  //                18446744073709551616.000,   18446744073709551616.000,
  //                18446744073709551616.000,   2086515.000,
  //                18446744073709551616.000,   932771.000,   255753.000,
  //                3148047.000,   18446744073709551616.000,
  //                18446744073709551616.000,   18446744073709551616.000,
  //                8685460.000,   18446744073709551616.000,
  //                18446744073709551616.000,   3905530.000,
  //                18446744073709551616.000
  VCMP_U32(18, v4, 0x5f800000, 0x5f800000, 0x5f800000, 0x49feb398, 0x5f800000,
           0x4963ba30, 0x4879c240, 0x4a40243c, 0x5f800000, 0x5f800000,
           0x5f800000, 0x4b048794, 0x5f800000, 0x5f800000, 0x4a6e5fe8,
           0x5f800000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE9"); TEST_CASE9(); ara_case_end("TEST_CASE9",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
