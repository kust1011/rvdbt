// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 33 "vfwcvt.c"
  VSET(16, e32, m1);
  //                  -54444.973,      43481.863,   88447.461,   32690.551,
  //                  -37979.809,   68218.094, -43036.512, -38011.395,
  //                  -36599.363,   48418.234,   81414.820,   16330.853,
  //                  75606.320, -85030.219,   13033.059,   7375.421
  VLOAD_32(v2, 0xc754acf9, 0x4729d9dd, 0x47acbfbb, 0x46ff651a, 0xc7145bcf,
           0x47853d0c, 0xc7281c83, 0xc7147b65, 0xc70ef75d, 0x473d223c,
           0x479f0369, 0x467f2b69, 0x4793ab29, 0xc7a6131c, 0x464ba43c,
           0x45e67b5f);
  asm volatile("vfwcvt.xu.f.v v4, v2");
  //                                   0,                  43482, 88447, 32691,
  //                                   0,                  68218, 0, 0, 0,
  //                                   48418,                  81415, 16331,
  //                                   75606,                      0, 13033,
  //                                   7375
  VCMP_U64(2, v4, 0x0000000000000000, 0x000000000000a9da, 0x000000000001597f,
           0x0000000000007fb3, 0x0000000000000000, 0x0000000000010a7a,
           0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
           0x000000000000bd22, 0x0000000000013e07, 0x0000000000003fcb,
           0x0000000000012756, 0x0000000000000000, 0x00000000000032e9,
           0x0000000000001ccf);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
