// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 282 "vfmin.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                               0.59499639
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f1851af);
  //               -0.94244474, -0.52559608, -0.72424960, -0.67824948,
  //               0.22003150, -0.67564118, -0.90376341,  0.16465612,
  //               -0.15494362, -0.01763406,  0.97777683, -0.91671157,
  //               0.81712914, -0.10151604,  0.03442690, -0.14597759
  VLOAD_32(v2, 0xbf71440f, 0xbf068d77, 0xbf39686c, 0xbf2da1c2, 0x3e614ff0,
           0xbf2cf6d2, 0xbf675d0a, 0x3e289b9d, 0xbe1ea98a, 0xbc90754e,
           0x3f7a4f95, 0xbf6aad9c, 0x3f512f60, 0xbdcfe7a4, 0x3d0d0338,
           0xbe157b26);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfmin.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_32));
  //                0.00000000, -0.52559608,  0.00000000, -0.67824948,
  //                0.00000000, -0.67564118,  0.00000000,  0.16465612,
  //                0.00000000, -0.01763406,  0.00000000, -0.91671157,
  //                0.00000000, -0.10151604,  0.00000000, -0.14597759
  VCMP_U32(11, v1, 0x0, 0xbf068d77, 0x0, 0xbf2da1c2, 0x0, 0xbf2cf6d2, 0x0,
           0x3e289b9d, 0x0, 0xbc90754e, 0x0, 0xbf6aad9c, 0x0, 0xbdcfe7a4, 0x0,
           0xbe157b26);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
