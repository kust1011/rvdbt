// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 365 "vfmsac.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.39704049
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbecb48e4);
  //                0.43844241,  0.13734208,  0.15601240,  0.48965997,
  //                -0.41457745, -0.69918746,  0.38535324,  0.83301985,
  //                0.79336989, -0.03326649, -0.85931808,  0.92554229,
  //                -0.77742523,  0.47821125, -0.53653014, -0.32442030
  VLOAD_32(v2, 0x3ee07b86, 0x3e0ca367, 0x3e1fc1b7, 0x3efab4b6, 0xbed4437f,
           0xbf32fdf3, 0x3ec54d05, 0x3f5540ca, 0x3f4b1a4a, 0xbd084272,
           0xbf5bfc45, 0x3f6cf057, 0xbf470557, 0x3ef4d81b, 0xbf095a0a,
           0xbea61a6b);
  VLOAD_8(v0, 0xAA, 0xAA);
  //               -0.73119336,  0.87333083, -0.16325396, -0.30275631,
  //               0.34779423,  0.22721651,  0.47497734, -0.58483958,
  //               -0.24916913,  0.13750601, -0.99799657,  0.66137350,
  //               0.58565408,  0.68887448, -0.74538875,  0.99311894
  VLOAD_32(v1, 0xbf3b2f7d, 0x3f5f929c, 0xbe272c0c, 0xbe9b02e0, 0x3eb21216,
           0x3e68ab72, 0x3ef3303b, 0xbf15b80c, 0xbe7f2631, 0x3e0cce60,
           0xbf7f7cb4, 0x3f294fc6, 0x3f15ed6d, 0x3f305a14, 0xbf3ed1cc,
           0x3f7e3d0b);
  asm volatile("vfmsac.vf v1, %[A], v2, v0.t" ::[A] "f"(dscalar_32));
  //               -0.73119336, -0.92786121, -0.16325396,  0.10834149,
  //               0.34779423,  0.05038923,  0.47497734,  0.25409698,
  //               -0.24916913, -0.12429786, -0.99799657, -1.02885127,
  //               0.58565408, -0.87874371, -0.74538875, -0.86431098
  VCMP_U32(11, v1, 0xbf3b2f7d, 0xbf6d8850, 0xbe272c0c, 0x3ddde223, 0x3eb21216,
           0x3d4e64ec, 0x3ef3303b, 0x3e821900, 0xbe7f2631, 0xbdfe8fe1,
           0xbf7f7cb4, 0xbf83b166, 0x3f15ed6d, 0xbf60f559, 0xbf3ed1cc,
           0xbf5d437b);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
