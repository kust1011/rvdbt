// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 231 "vfmin.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                                0.8631130564395617
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3feb9e9f45c51298);
  //               -0.0203711476424431,  0.4824066080711997, 0.5516514149436702,
  //               -0.0992829085793798,  0.7425996730256406, 0.3080149644930992,
  //               -0.6753031265127754, -0.3309631180416657,
  //               -0.7695072044924456, -0.6726760621514143,
  //               -0.9995830020822822,  0.2485224245452053, 0.7025040357726613,
  //               -0.6452676560401207,  0.5090044889036880,  0.0801949752856408
  VLOAD_64(v2, 0xbf94dc2c93a00800, 0x3fdedfbff74290e0, 0x3fe1a720de3f34c0,
           0xbfb96a9acd667320, 0x3fe7c36063b54b1e, 0x3fd3b68465cb4b28,
           0xbfe59c154d684914, 0xbfd52e7fee0af3fc, 0xbfe89fcd92aa9b24,
           0xbfe5868ff2f7c1a4, 0xbfeffc957df296c0, 0x3fcfcf9532df44b8,
           0x3fe67ae9be5e7376, 0xbfe4a6085afb7c12, 0x3fe049c3c82b791e,
           0x3fb487a86c27c560);
  asm volatile("vfmin.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //              -0.0203711476424431,  0.4824066080711997,  0.5516514149436702,
  //              -0.0992829085793798,  0.7425996730256406,  0.3080149644930992,
  //              -0.6753031265127754, -0.3309631180416657, -0.7695072044924456,
  //              -0.6726760621514143, -0.9995830020822822,  0.2485224245452053,
  //              0.7025040357726613, -0.6452676560401207,  0.5090044889036880,
  //              0.0801949752856408
  VCMP_U64(9, v1, 0xbf94dc2c93a00800, 0x3fdedfbff74290e0, 0x3fe1a720de3f34c0,
           0xbfb96a9acd667320, 0x3fe7c36063b54b1e, 0x3fd3b68465cb4b28,
           0xbfe59c154d684914, 0xbfd52e7fee0af3fc, 0xbfe89fcd92aa9b24,
           0xbfe5868ff2f7c1a4, 0xbfeffc957df296c0, 0x3fcfcf9532df44b8,
           0x3fe67ae9be5e7376, 0xbfe4a6085afb7c12, 0x3fe049c3c82b791e,
           0x3fb487a86c27c560);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
