// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 184 "vfcvt.c"
  VSET(16, e64, m1);
  //                         3087905.033,           -2534011.630, 7824302.813,
  //                         -9294206.521,   6436555.847,   6645117.193,
  //                         1358075.867,   5694551.012, -9840938.636,
  //                         4621816.383,   2584370.751,   5569558.860,
  //                         495487.041,   4759865.418, -6831172.669,
  //                         8371055.296
  VLOAD_64(v2, 0x41478f10842c8b9c, 0xc143553dd0971c82, 0x415dd8ebb40e1fe0,
           0xc161ba2fd0a8a593, 0x41588db2f632700c, 0x4159595f4c588b60,
           0x4134b8fbde131210, 0x4155b915c0cb4294, 0xc162c52554566300,
           0x4151a17e187d1aa8, 0x4143b7996029dc68, 0x41553f05b70b6824,
           0x411e3dfc2a598ba0, 0x4152284e5ac4da5a, 0xc15a0f112acbf258,
           0x415feedbd2ed6038);
  asm volatile("vfcvt.x.f.v v3, v2");
  //                             3087905,               -2534012, 7824303,
  //                             -9294207,                6436556, 6645117,
  //                             1358076,                5694551, -9840939,
  //                             4621816,                2584371, 5569559,
  //                             495487,                4759865, -6831173,
  //                             8371055
  VCMP_U64(9, v3, 0x00000000002f1e21, 0xffffffffffd95584, 0x00000000007763af,
           0xffffffffff722e81, 0x00000000006236cc, 0x000000000065657d,
           0x000000000014b8fc, 0x000000000056e457, 0xffffffffff69d6d5,
           0x00000000004685f8, 0x0000000000276f33, 0x000000000054fc17,
           0x0000000000078f7f, 0x000000000048a139, 0xffffffffff97c3bb,
           0x00000000007fbb6f);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
