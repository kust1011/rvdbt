// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE5(void) {
#line 346 "vfsgnj.c"
  CLEAR_FFLAGS;
#line 348 "vfsgnj.c"
  CHECK_FFLAGS(0);
#line 373 "vfsgnj.c"
  VSET(16, e64, m1);
  VLOAD_64(v2, 0x0000000000000000, 0xbfee59fbc778ffbc, 0x7fffffffffffffff,
           0x3fde20419edcb428, 0x8000000000000000, 0x3fa8ecd6c20a0480,
           0xbfc851dfd0fdf7f8, 0xbfc784eb3b54e580, 0x3fd13e05a2db6b68,
           0xbfe9790bf1eadde4, 0x3fe46b59155986dc, 0x3fcc266386bc2e10,
           0x3fdb01fdd39a7d9c, 0xbfe4eef55bb6b208, 0x3fe736d06902107a,
           0x3fcf3a7f44aa9f48);
  VLOAD_64(v3, 0x8000000000000000, 0x7fffffffffffffff, 0xbfe187df69e0bb9c,
           0xbfe76fd3c4a3b1e8, 0x0000000000000001, 0xbfe7c6f7c1644c86,
           0xbfe229ce53357d20, 0xbfe79fcc34ac1d30, 0xbfe962e04d917824,
           0xbfb0aa5656314cf0, 0xbfc69c8ad7d5ef20, 0xbfddd9380f0bd244,
           0xbfc408f2f3d40a40, 0xbfb01baf416f2160, 0xbfed13d1838e183a,
           0xbfbee005420412c0);
  asm volatile("vfsgnj.vv v1, v2, v3");
  VCMP_U64(15, v1, 0x8000000000000000, 0x3fee59fbc778ffbc, 0xffffffffffffffff,
           0xbfde20419edcb428, 0x0000000000000000, 0xbfa8ecd6c20a0480,
           0xbfc851dfd0fdf7f8, 0xbfc784eb3b54e580, 0xbfd13e05a2db6b68,
           0xbfe9790bf1eadde4, 0xbfe46b59155986dc, 0xbfcc266386bc2e10,
           0xbfdb01fdd39a7d9c, 0xbfe4eef55bb6b208, 0xbfe736d06902107a,
           0xbfcf3a7f44aa9f48);
  CHECK_FFLAGS(0);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE5"); TEST_CASE5(); ara_case_end("TEST_CASE5",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
