// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Shafiullah Khan <shafi.ullah@10xengineers.ai>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 19 "vfrsqrt7.c"
  VSET(16, e32, m1);
  VLOAD_32(v2, mInff, pInff, qNaNf, 0xfe7fca13, 0x00800000, 0x00200000,
           0x003f3cde, 0x00400000, 0x7f787a12, 0x7f000005, 0x7ef0f42d,
           0x7f765432, 0x00718abc, 0x00e50000, 0x001ee941, 0x00000001);
  asm volatile("vfrsqrt7.v v1, v2");
  VCMP_U32(2, v1, qNaNf, pZero, qNaNf, qNaNf, 0x5eff0000, 0x5f7f0000,
           0x5f360000, 0x5f340000, 0x1f820000, 0x1fb40000, 0x1fbb0000,
           0x1f820000, 0x5f080000, 0x5ebf0000, 0x5f820000, 0x64b40000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
