// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 122 "vfdiv.c"
  VSET(16, e32, m1);
  //               0.64838839,  0.00666664, -0.13619921,  0.21094505,
  //               -0.51040554, -0.77216595,  0.42111391,  0.82974166,
  //               -0.31227046,  0.68854737, -0.72970057,  0.10843290,
  //               -0.38442346,  0.18102080,  0.57249051,  0.76465768
  VLOAD_32(v2, 0x3f25fcc8, 0x3bda73da, 0xbe0b77ce, 0x3e5801fb, 0xbf02a9f0,
           0xbf45acab, 0x3ed79c3e, 0x3f5469f3, 0xbe9fe1ea, 0x3f3044a4,
           0xbf3acda8, 0x3dde1212, 0xbec4d327, 0x3e395d84, 0x3f128ebd,
           0x3f43c09b);
  //              -0.59629226, -0.46890569,  0.99662799, -0.49397555,
  //              0.80701596,  0.55786854, -0.26524273, -0.04642257,
  //              -0.67671824,  0.64403933,  0.06642481,  0.26544699,
  //              -0.00225505,  0.27478188,  0.76509053,  0.36194146
  VLOAD_32(v3, 0xbf18a69c, 0xbef01468, 0x3f7f2303, 0xbefcea5d, 0x3f4e9899,
           0x3f0ed079, 0xbe87cde5, 0xbd3e2597, 0xbf2d3d68, 0x3f24dfc3,
           0x3d8809bb, 0x3e87e8ab, 0xbb13c97d, 0x3e8cb036, 0x3f43dcf9,
           0x3eb95064);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfdiv.vv v1, v2, v3, v0.t");
  //               0.00000000, -0.01421745,  0.00000000, -0.42703542,
  //               0.00000000, -1.38413608,  0.00000000, -17.87367058,
  //               0.00000000,  1.06910765,  0.00000000,  0.40849173,
  //               0.00000000,  0.65877998,  0.00000000,  2.11265564
  VCMP_U32(5, v1, 0x0, 0xbc68f04d, 0x0, 0xbedaa462, 0x0, 0xbfb12b5e, 0x0,
           0xc18efd46, 0x0, 0x3f88d884, 0x0, 0x3ed125d4, 0x0, 0x3f28a5cd, 0x0,
           0x400735c0);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
