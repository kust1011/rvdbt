// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 215 "vfwadd.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -497871.25000000
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xc8f319e8);
  //               -568507.00000000,  457995.96875000,  409553.18750000,
  //               -797866.87500000,  263520.50000000,  290072.90625000,
  //               530785.75000000,  226941.43750000,  285558.65625000,
  //               -987117.31250000, -423428.21875000, -140664.31250000,
  //               -844580.25000000,  549948.50000000,  304879.87500000,
  //               -655518.43750000
  VLOAD_32(v2, 0xc90acbb0, 0x48dfa17f, 0x48c7fa26, 0xc942caae, 0x4880ac10,
           0x488da31d, 0x4901961c, 0x485d9f5c, 0x488b6ed5, 0xc970fed5,
           0xc8cec087, 0xc8095e14, 0xc94e3244, 0x490643c8, 0x4894ddfc,
           0xc92009e7);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfwadd.vf v4, v2, %[A], v0.t" ::[A] "f"(dscalar_32));
  //                0.0000000000000000, -39875.2812500000000000,
  //                0.0000000000000000, -1295738.1250000000000000,
  //                0.0000000000000000, -207798.3437500000000000,
  //                0.0000000000000000, -270929.8125000000000000,
  //                0.0000000000000000, -1484988.5625000000000000,
  //                0.0000000000000000, -638535.5625000000000000,
  //                0.0000000000000000,  52077.2500000000000000,
  //                0.0000000000000000, -1153389.6875000000000000
  VCMP_U64(8, v4, 0x0, 0xc0e3786900000000, 0x0, 0xc133c57a20000000, 0x0,
           0xc1095db2c0000000, 0x0, 0xc110894740000000, 0x0, 0xc136a8bc90000000,
           0x0, 0xc1237c8f20000000, 0x0, 0x40e96da800000000, 0x0,
           0xc131996db0000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
