// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 181 "vfmadd.c"
  VSET(16, e64, m1);
  //               0.0308264568094008,  0.5865382185158325,  0.4543411851187289,
  //               0.0036656924511687, -0.3103508259554966,  0.9658177901158624,
  //               -0.3381631341283657, -0.2003719333831677, 0.8989532087589025,
  //               -0.8054516243685412,  0.8701363884969631,
  //               -0.3585976675814562,  0.4150155349314333,
  //               -0.6908185611649824,  0.8412555125501906, -0.3357469205066645
  VLOAD_64(v2, 0x3f9f90f87f644880, 0x3fe2c4ebcc4c25b4, 0x3fdd13ed0cd3e484,
           0x3f6e0783a63d2400, 0xbfd3dcc9b5f0fd10, 0x3feee7fab5ce29f4,
           0xbfd5a476fc72d40c, 0xbfc9a5c99a756020, 0x3fecc43985081eb2,
           0xbfe9c6427c2588e6, 0x3febd8284474eda0, 0xbfd6f343a1abca7c,
           0x3fda8f9d51773268, 0xbfe61b2f86f58c4a, 0x3feaeb90ae3f72fc,
           0xbfd57ce0a6d3c3f8);
  //               0.5881481456806663, -0.9882550591195853, -0.8483939717953815,
  //               -0.9684864200393222, -0.6743741213041285, 0.4372709704288931,
  //               -0.8339944484196176, -0.1519222509233684,
  //               -0.2540075520951832,  0.6661048539265222, 0.3013290199421905,
  //               -0.0367795249610035, -0.7178804756969177, 0.1577316726139908,
  //               -0.1242681642824526, -0.9006297759672148
  VLOAD_64(v3, 0x3fe2d21c0f5cd922, 0xbfef9fc912e0ce28, 0xbfeb260b1d5f82be,
           0xbfeefdd73b960c5a, 0xbfe594790988a396, 0x3fdbfc3f615edda8,
           0xbfeab01520204008, 0xbfc3723035a012c8, 0xbfd041a8e44be49c,
           0x3fe550bb206a47d8, 0x3fd348f9837f3238, 0xbfa2d4c411bd66e0,
           0xbfe6f8e079b1c412, 0x3fc4308d2bb5d1f0, 0xbfbfd009d586ef50,
           0xbfecd1f58932a7e4);
  VLOAD_8(v0, 0xAA, 0xAA);
  //              -0.8344616273245185,  0.7077884806720691, -0.1882041492960900,
  //              -0.2751607560371576,  0.2338395078923734, -0.9938305657796487,
  //              -0.5345602642671559,  0.0887204597208056,  0.3045224871958914,
  //              -0.3946645040604191,  0.6818539464440989,  0.9719861381061521,
  //              -0.8471643748461517,  0.8077493118513845,  0.2789872574353331,
  //              0.7073875082318823
  VLOAD_64(v1, 0xbfeab3e8dee4061e, 0x3fe6a634071f1b28, 0xbfc81712d5195ee0,
           0xbfd19c3bdc149f5c, 0x3fcdee73f7748a88, 0xbfefcd75c2393d96,
           0xbfe11b1e209897fa, 0x3fb6b66250fca870, 0x3fd37d4be2d9c9a4,
           0xbfd9422ee8753844, 0x3fe5d1bf5e1407b4, 0x3fef1a82ac6a99b4,
           0xbfeb1bf876899dc0, 0x3fe9d91515b8951c, 0x3fd1daed5eabdf0c,
           0x3fe6a2eb20ae8e42);
  asm volatile("vfmadd.vv v1, v2, v3, v0.t");
  //               0.0000000000000000, -0.5731100645801621,  0.0000000000000000,
  //               -0.9694950747455855,  0.0000000000000000,
  //               -0.5225882703620045,  0.0000000000000000,
  //               -0.1696993409682697,  0.0000000000000000, 0.9839880198025914,
  //               0.0000000000000000, -0.3853314870073767,  0.0000000000000000,
  //               -0.4002765447811873,  0.0000000000000000, -1.1381329534609521
  VCMP_U64(6, v1, 0xbfeab3e8dee4061e, 0xbfe256eaeb0c2af6, 0xbfc81712d5195ee0,
           0xbfef061a88f54aac, 0x3fcdee73f7748a88, 0xbfe0b90b094f4be7,
           0xbfe11b1e209897fa, 0xbfc5b8b53fce44b1, 0x3fd37d4be2d9c9a4,
           0x3fef7cd47196a75e, 0x3fe5d1bf5e1407b4, 0xbfd8a94565b434f4,
           0xbfeb1bf876899dc0, 0xbfd99e21834c3aa4, 0x3fd1daed5eabdf0c,
           0xbff235cae659d5ba);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
