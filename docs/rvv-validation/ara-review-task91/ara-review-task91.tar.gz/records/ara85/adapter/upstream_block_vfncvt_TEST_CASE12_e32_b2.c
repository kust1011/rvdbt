// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE12(void) {
#line 545 "vfncvt.c"
  VSET(16, e32, m1);
  //                      757099,       -9365555,        3016973, -9277105,
  //                      -8350486,        -650348,       -1775160, 4659116,
  //                      148573,        4475248,       -2937762, 3310433,
  //                      9151745,       -2201488,       -1506850, 1593161
  VLOAD_64(v2, 0x00000000000b8d6b, 0xffffffffff7117cd, 0x00000000002e090d,
           0xffffffffff72714f, 0xffffffffff8094ea, 0xfffffffffff61394,
           0xffffffffffe4e9c8, 0x00000000004717ac, 0x000000000002445d,
           0x0000000000444970, 0xffffffffffd32c5e, 0x0000000000328361,
           0x00000000008ba501, 0xffffffffffde6870, 0xffffffffffe901de,
           0x0000000000184f49);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfncvt.f.x.w v4, v2, v0.t");
  //                0.000, -9365555.000,   0.000, -9277105.000,   0.000,
  //                -650348.000,   0.000,   4659116.000,   0.000,   4475248.000,
  //                0.000,   3310433.000,   0.000, -2201488.000,   0.000,
  //                1593161.000
  VCMP_U32(24, v4, 0x0, 0xcb0ee833, 0x0, 0xcb0d8eb1, 0x0, 0xc91ec6c0, 0x0,
           0x4a8e2f58, 0x0, 0x4a8892e0, 0x0, 0x4a4a0d84, 0x0, 0xca065e40, 0x0,
           0x49c27a48);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE12"); TEST_CASE12(); ara_case_end("TEST_CASE12",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
