// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 209 "vfsgnjn.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                               0.56259364
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f100623);
  //              -0.00813205, -0.38676089,  0.94379848,  0.39548567,
  //              0.90217608,  0.57424510,  0.05995686, -0.00974263,
  //              -0.45620662, -0.36967716, -0.56535333, -0.93745488,
  //              -0.55570704,  0.04399948, -0.57520008, -0.05702910
  VLOAD_32(v2, 0xbc053c4a, 0xbec60586, 0x3f719cc7, 0x3eca7d19, 0x3f66f503,
           0x3f1301ba, 0x3d759554, 0xbc1f9f8d, 0xbee993ea, 0xbebd4653,
           0xbf10baff, 0xbf6ffd0b, 0xbf0e42d1, 0x3d3438cd, 0xbf134050,
           0xbd699758);
  asm volatile("vfsgnjn.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //              -0.00813205, -0.38676089, -0.94379848, -0.39548567,
  //              -0.90217608, -0.57424510, -0.05995686, -0.00974263,
  //              -0.45620662, -0.36967716, -0.56535333, -0.93745488,
  //              -0.55570704, -0.04399948, -0.57520008, -0.05702910
  VCMP_U32(8, v1, 0xbc053c4a, 0xbec60586, 0xbf719cc7, 0xbeca7d19, 0xbf66f503,
           0xbf1301ba, 0xbd759554, 0xbc1f9f8d, 0xbee993ea, 0xbebd4653,
           0xbf10baff, 0xbf6ffd0b, 0xbf0e42d1, 0xbd3438cd, 0xbf134050,
           0xbd699758);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
