// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 89 "vfsqrt.c"
  VSET(16, e32, m1);
  //                53688.590, -5719.180, -59560.355, -34640.023, -22323.398,
  //                -52381.586,   19136.160,   13055.238, -68576.781,
  //                -35066.488,   62475.219, -25604.578,   54705.039,
  //                -19827.459,   17792.961, -28415.572
  VLOAD_32(v2, 0x4751b897, 0xc5b2b971, 0xc768a85b, 0xc7075006, 0xc6ae66cc,
           0xc74c9d96, 0x46958052, 0x464bfcf4, 0xc785f064, 0xc708fa7d,
           0x47740b38, 0xc6c80928, 0x4755b10a, 0xc69ae6eb, 0x468b01ec,
           0xc6ddff25);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v3);
  asm volatile("vfsqrt.v v3, v2, v0.t");
  //                0.000,   nan,   0.000,   nan,   0.000,   nan,   0.000,
  //                114.260,   0.000,   nan,   0.000,   nan,   0.000,   nan,
  //                0.000,   nan
  VCMP_U32(5, v3, 0x0, 0x7fc00000, 0x0, 0x7fc00000, 0x0, 0x7fc00000, 0x0,
           0x42e484e0, 0x0, 0x7fc00000, 0x0, 0x7fc00000, 0x0, 0x7fc00000, 0x0,
           0x7fc00000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
