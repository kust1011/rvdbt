// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 213 "vfsgnj.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                               0.64529878
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f25324d);
  //               0.27794743,  0.64720273,  0.88201439, -0.27750894,
  //               -0.02381280, -0.27677080, -0.58998328,  0.15329099,
  //               0.52908343, -0.63265759,  0.48432603,  0.70191479,
  //               -0.55785930,  0.34719029, -0.06872076, -0.69960916
  VLOAD_32(v2, 0x3e8e4f20, 0x3f25af14, 0x3f61cbb2, 0xbe8e15a7, 0xbcc31310,
           0xbe8db4e7, 0xbf170925, 0x3e1cf850, 0x3f077203, 0xbf21f5d9,
           0x3ef7f995, 0x3f33b0b0, 0xbf0ecfde, 0x3eb1c2ed, 0xbd8cbd78,
           0xbf331996);
  asm volatile("vfsgnj.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //               0.27794743,  0.64720273,  0.88201439,  0.27750894,
  //               0.02381280,  0.27677080,  0.58998328,  0.15329099,
  //               0.52908343,  0.63265759,  0.48432603,  0.70191479,
  //               0.55785930,  0.34719029,  0.06872076,  0.69960916
  VCMP_U32(8, v1, 0x3e8e4f20, 0x3f25af14, 0x3f61cbb2, 0x3e8e15a7, 0x3cc31310,
           0x3e8db4e7, 0x3f170925, 0x3e1cf850, 0x3f077203, 0x3f21f5d9,
           0x3ef7f995, 0x3f33b0b0, 0x3f0ecfde, 0x3eb1c2ed, 0x3d8cbd78,
           0x3f331996);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
