// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE11(void) {
#line 721 "vfcvt.c"
  VSET(16, e64, m1);
  //                            -8860682,                8064547, -5636078,
  //                            -3712253,                8492493, 9839246,
  //                            -8271278,               -6234598, -4538479,
  //                            8807688,                5640899, 3839761,
  //                            -1394518,               -6118355, 1783927,
  //                            5819812
  VLOAD_64(v2, 0xffffffffff78cbf6, 0x00000000007b0e23, 0xffffffffffaa0012,
           0xffffffffffc75b03, 0x00000000008195cd, 0x000000000096228e,
           0xffffffffff81ca52, 0xffffffffffa0de1a, 0xffffffffffbabf91,
           0x0000000000866508, 0x00000000005612c3, 0x00000000003a9711,
           0xffffffffffeab8aa, 0xffffffffffa2a42d, 0x00000000001b3877,
           0x000000000058cda4);
  asm volatile("vfcvt.f.x.v v3, v2");
  //              -8860682.000,   8064547.000, -5636078.000, -3712253.000,
  //              8492493.000,   9839246.000, -8271278.000, -6234598.000,
  //              -4538479.000,   8807688.000,   5640899.000,   3839761.000,
  //              -1394518.000, -6118355.000,   1783927.000,   5819812.000
  VCMP_U64(33, v3, 0xc160e68140000000, 0x415ec388c0000000, 0xc1557ffb80000000,
           0xc14c527e80000000, 0x416032b9a0000000, 0x4162c451c0000000,
           0xc15f8d6b80000000, 0xc157c87980000000, 0xc151501bc0000000,
           0x4160cca100000000, 0x415584b0c0000000, 0x414d4b8880000000,
           0xc135475600000000, 0xc15756f4c0000000, 0x413b387700000000,
           0x4156336900000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE11"); TEST_CASE11(); ara_case_end("TEST_CASE11",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
