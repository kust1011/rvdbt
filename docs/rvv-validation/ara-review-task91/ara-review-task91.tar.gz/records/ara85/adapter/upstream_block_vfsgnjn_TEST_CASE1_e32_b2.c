// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfsgnjn.c"
  VSET(16, e32, m1);
  //              -0.64186704,  0.87601262, -0.93132722,  0.53574133,
  //              0.17954259, -0.80486834, -0.95272040, -0.45182621, 0.20335940,
  //              0.96179944,  0.80393785,  0.06180594,  0.86447370,
  //              -0.24008171, -0.42264909, -0.01868468
  VLOAD_32(v2, 0xbf245166, 0x3f60425d, 0xbf6e6b76, 0x3f092658, 0x3e37da03,
           0xbf4e0bda, 0xbf73e57c, 0xbee755c4, 0x3e503d72, 0x3f76387d,
           0x3f4dcedf, 0x3d7d283b, 0x3f5d4e26, 0xbe75d7fb, 0xbed86576,
           0xbc99109c);
  //               0.32984266, -0.78281105,  0.73037797,  0.99060333,
  //               0.44768164,  0.66998041,  0.39474848, -0.39895460,
  //               -0.06065369,  0.53388232, -0.60164928, -0.09839682,
  //               -0.38704434,  0.47123700,  0.40912241, -0.54495376
  VLOAD_32(v3, 0x3ea8e123, 0xbf48664e, 0x3f3afa0d, 0x3f7d982e, 0x3ee53687,
           0x3f2b83d6, 0x3eca1c79, 0xbecc43c7, 0xbd787002, 0x3f08ac83,
           0xbf1a05b0, 0xbdc98446, 0xbec62aad, 0x3ef145fa, 0x3ed1787e,
           0xbf0b8217);
  asm volatile("vfsgnjn.vv v1, v2, v3");
  //              -0.64186704,  0.87601262, -0.93132722, -0.53574133,
  //              -0.17954259, -0.80486834, -0.95272040,  0.45182621,
  //              0.20335940, -0.96179944,  0.80393785,  0.06180594, 0.86447370,
  //              -0.24008171, -0.42264909,  0.01868468
  VCMP_U32(2, v1, 0xbf245166, 0x3f60425d, 0xbf6e6b76, 0xbf092658, 0xbe37da03,
           0xbf4e0bda, 0xbf73e57c, 0x3ee755c4, 0x3e503d72, 0xbf76387d,
           0x3f4dcedf, 0x3d7d283b, 0x3f5d4e26, 0xbe75d7fb, 0xbed86576,
           0x3c99109c);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
