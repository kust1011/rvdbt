// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 134 "vfrdiv.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                -1436518.0384849868714809,  7616315.8933699131011963,
  //                -3920170.8619796745479107, -8788296.3276759665459394,
  //                -4048340.2138868225738406,  7863298.6869412772357464,
  //                6686376.3073008488863707,  7004262.4451152756810188,
  //                5533006.3396991230547428,  2002846.6050684414803982,
  //                -1239975.7277694121003151,  4133787.1656649876385927,
  //                2465999.3703419454395771, -4337686.8389181373640895,
  //                -5741249.6292232554405928,  1762825.0474482532590628
  VLOAD_64(v2, 0xc135eb6609da26f0, 0x415d0dcef92cf900, 0xc14de8956e555998,
           0xc160c3290a7c524f, 0xc14ee2ea1b60a4b6, 0x415dff00abf6d88c,
           0x415981aa13aad12e, 0x415ab8199c7cc4c8, 0x41551b5395bda164,
           0x413e8f9e9ae5c3f0, 0xc132eba7ba4f18a0, 0x414f89cd953482a4,
           0x4142d067af675d68, 0xc1508c05b5b0d5b3, 0xc155e6b06845319e,
           0x413ae6090c259198);
  //                               -181636.6228598635643721
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xc1062c24fb9df3c0);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfrdiv.vf v4, v2, %[A], v0.t" ::[A] "f"(dscalar_64));
  //                0.0000000000000000, -0.0238483573164265, 0.0000000000000000,
  //                0.0206680130126992,  0.0000000000000000,
  //                -0.0230992907800273,  0.0000000000000000,
  //                -0.0259322982659703,  0.0000000000000000,
  //                -0.0906892332144711,  0.0000000000000000,
  //                -0.0439395197625382,  0.0000000000000000,
  //                0.0418740747326899,  0.0000000000000000, -0.1030372373723578
  VCMP_U64(6, v4, 0x0, 0xbf986bb42af3122b, 0x0, 0x3f9529fedfd9f42e, 0x0,
           0xbf97a75729d81370, 0x0, 0xbf9a8dff13d98f11, 0x0, 0xbfb73768dac16680,
           0x0, 0xbfa67f3da0c39bb5, 0x0, 0x3fa57084cb0de853, 0x0,
           0xbfba60a5fcc8d2be);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
