// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE6(void) {
#line 344 "vfwadd.c"
  VSET(16, e32, m1);
  //              -55997.9824854041071376,  64501.1750668793683872,
  //              -29542.1742966430028901, -97235.1376669598394074,
  //              -76290.1568635256844573, -53719.7602741207738291,
  //              -71738.9507989753619768,  76087.4621994893532246,
  //              88201.1680542646208778, -10676.6526112916035345,
  //              -87188.1793410585087258,  19855.3190320774738211,
  //              17509.5892884960630909,  30185.4023848686192650,
  //              54203.3669640090665780, -57884.3948619379953016
  VLOAD_64(v2, 0xc0eb57bf70853aee, 0x40ef7ea59a25db30, 0xc0dcd98b27ad1b60,
           0xc0f7bd3233e24524, 0xc0f2a0228283540c, 0xc0ea3af8542a6497,
           0xc0f183af3678fc84, 0x40f29377652b4ab0, 0x40f58892b059ab28,
           0xc0c4da5388c44d38, 0xc0f54942de94bad2, 0x40d363d46b0584c8,
           0x40d11965b6e718a0, 0x40dd7a59c0ac76c8, 0x40ea776bbe2b4e38,
           0xc0ec438ca2b580c4);
  //              -73536.78125000,  57454.64062500, -32693.95507812,
  //              -56205.09375000,  12513.70898438,  20858.82226562,
  //              12284.94335938,  61625.35156250, -11893.36132812,
  //              -46430.30078125,  30247.85937500, -94111.64843750,
  //              89016.30468750, -52090.74609375,  72764.65625000,
  //              -47109.86328125
  VLOAD_32(v3, 0xc78fa064, 0x47606ea4, 0xc6ff6be9, 0xc75b8d18, 0x464386d6,
           0x46a2f5a5, 0x463ff3c6, 0x4770b95a, 0xc639d572, 0xc7355e4d,
           0x46ec4fb8, 0xc7b7cfd3, 0x47addc27, 0xc74b7abf, 0x478e1e54,
           0xc73805dd);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfwadd.wv v4, v2, v3, v0.t");
  //               0.0000000000000000,  121955.8156918793683872,
  //               0.0000000000000000, -153440.2314169598394074,
  //               0.0000000000000000, -32860.9380084957738291,
  //               0.0000000000000000,  137712.8137619893532246,
  //               0.0000000000000000, -57106.9533925416035345,
  //               0.0000000000000000, -74256.3294054225261789,
  //               0.0000000000000000, -21905.3437088813807350,
  //               0.0000000000000000, -104994.2581431879953016
  VCMP_U64(12, v4, 0x0, 0x40fdc63d0d12ed98, 0x0, 0xc102bb01d9f12292, 0x0,
           0xc0e00b9e042a6497, 0x0, 0x4100cf868295a558, 0x0, 0xc0ebe25e8231134e,
           0x0, 0xc0f22105453e9ece, 0x0, 0xc0d56455ff538938, 0x0,
           0xc0f9a224215ac062);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE6"); TEST_CASE6(); ara_case_end("TEST_CASE6",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
