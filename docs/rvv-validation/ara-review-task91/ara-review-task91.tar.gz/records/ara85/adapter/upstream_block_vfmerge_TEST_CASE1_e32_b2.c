// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 31 "vfmerge.c"
  VSET(16, e32, m1);
  //               0.86539453, -0.53925377, -0.47128764,  0.99265540,
  //               0.32128176, -0.47335613, -0.30028856,  0.44394016,
  //               -0.72540921, -0.26464799,  0.77351445, -0.21725702,
  //               -0.25191557, -0.53123665,  0.80404943,  0.81841671
  VLOAD_32(v2, 0x3f5d8a7f, 0xbf0a0c89, 0xbef14c9d, 0x3f7e1eaa, 0x3ea47f0b,
           0xbef25bbc, 0xbe99bf6c, 0x3ee34c20, 0xbf39b46b, 0xbe877ff1,
           0x3f46050b, 0xbe5e78a0, 0xbe80fb14, 0xbf07ff20, 0x3f4dd62f,
           0x3f5183c2);
  double dscalar_32;
  //                             -0.96056187
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbf75e762);
  VLOAD_8(v0, 0x0F, 0xAA);
  asm volatile("vfmerge.vfm v1, v2, %[A], v0" ::[A] "f"(dscalar_32));
  //               -0.96056187, -0.96056187, -0.96056187, -0.96056187,
  //               0.32128176, -0.47335613, -0.30028856,  0.44394016,
  //               -0.72540921, -0.96056187,  0.77351445, -0.96056187,
  //               -0.25191557, -0.96056187,  0.80404943, -0.96056187
  VCMP_U32(2, v1, 0xbf75e762, 0xbf75e762, 0xbf75e762, 0xbf75e762, 0x3ea47f0b,
           0xbef25bbc, 0xbe99bf6c, 0x3ee34c20, 0xbf39b46b, 0xbf75e762,
           0x3f46050b, 0xbf75e762, 0xbe80fb14, 0xbf75e762, 0x3f4dd62f,
           0xbf75e762);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
