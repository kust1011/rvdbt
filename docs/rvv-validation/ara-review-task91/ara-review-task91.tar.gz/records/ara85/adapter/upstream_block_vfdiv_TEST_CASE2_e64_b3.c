// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 150 "vfdiv.c"
  VSET(16, e64, m1);
  //              -0.6201645522687720,  0.7701971477336478,  0.3292637140913006,
  //              -0.8434179184761514, -0.7347451981263740,  0.6543864439701519,
  //              0.1228421097534835, -0.5052233099528094, -0.5128552707464591,
  //              0.9434287237802566, -0.5723896115412233, -0.5719579148082712,
  //              -0.6537028651114556,  0.1091378410914579, -0.7602559429758879,
  //              0.2908894437497427
  VLOAD_64(v2, 0xbfe3d86354c44060, 0x3fe8a5747d1fa1c6, 0x3fd512a81cf2063c,
           0xbfeafd479316e516, 0xbfe783085c9b10ee, 0x3fe4f0bbd6f98570,
           0x3fbf72949bf67da0, 0xbfe02aca132d92f2, 0xbfe0694f74edfe18,
           0x3fee30916f57c874, 0xbfe2510404c47868, 0xbfe24d7aaf5946b0,
           0xbfe4eb22455e9102, 0x3fbbf075223e6d60, 0xbfe854044575797c,
           0x3fd29deec1ea08a0);
  //               0.6660375425590812, -0.9603615652916235, -0.1168804546788573,
  //               -0.3258082002843947,  0.0488865860405421,
  //               -0.1515621417461690, -0.1189568642850463,
  //               -0.1213016259965920, -0.1369814061459547, 0.5914369694708146,
  //               0.7538814889966272,  0.2346701936201294,  0.9227364529293489,
  //               0.9447507336323382, -0.4250995717346850, -0.0882167932097473
  VLOAD_64(v3, 0x3fe5502df6e661fe, 0xbfeebb482d68699c, 0xbfbdebe0a2632640,
           0xbfd4da0aa33f5db0, 0x3fa907a9a083b220, 0xbfc36663650e4608,
           0xbfbe73f501bd2e10, 0xbfbf0d9f949b6370, 0xbfc1889b51c74ac0,
           0x3fe2ed0d3930b850, 0x3fe81fcc12899c0a, 0x3fce09ac4378e388,
           0x3fed870e9905133a, 0x3fee3b65e3fa5532, 0xbfdb34d4d5893894,
           0xbfb6956031cb3a60);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfdiv.vv v1, v2, v3, v0.t");
  //               0.0000000000000000, -0.8019866429158581,
  //               0.0000000000000000,  2.5886945685834193,  0.0000000000000000,
  //               -4.3176114854994303, 0.0000000000000000,  4.1650167984310764,
  //               0.0000000000000000,  1.5951466892987514,  0.0000000000000000,
  //               -2.4372840282141826,  0.0000000000000000, 0.1155202501636058,
  //               0.0000000000000000, -3.2974384260161655
  VCMP_U64(6, v1, 0x0, 0xbfe9a9dfe464e0ca, 0x0, 0x4004b5a57f7b305c, 0x0,
           0xc011453bf1fc3753, 0x0, 0x4010a8fa29e23558, 0x0, 0x3ff985b888edc5e0,
           0x0, 0xc0037f8ec4c1f1c6, 0x0, 0x3fbd92bc307a7a1b, 0x0,
           0xc00a612765c28153);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
