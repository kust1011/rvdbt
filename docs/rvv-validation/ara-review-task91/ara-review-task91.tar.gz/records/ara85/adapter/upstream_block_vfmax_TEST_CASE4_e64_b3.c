// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 307 "vfmax.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                               -0.8274885128397702
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfea7ac9308eccb6);
  //                 0.9632225672084347,  0.4671677538923853,
  //                 -0.1749283847947720, -0.0938698612480795,
  //                 0.3438198935172891,  0.2938331380713377,
  //                 -0.3607699326176230,  0.6841623039857032,
  //                 -0.6959644979744999,  0.4712155929452235,
  //                 0.1886883982201846,  0.9268486384654282,
  //                 -0.9639662652720637, -0.2101071651393955,
  //                 0.0859470276611187, -0.7001184217853196
  VLOAD_64(v2, 0x3feed2b8221dbd8e, 0x3fdde613942dab28, 0xbfc6640da5eaf690,
           0xbfb807daf023fbb0, 0x3fd601252797bdcc, 0x3fd2ce29819fd630,
           0xbfd716dac57e4298, 0x3fe5e4a85818c992, 0xbfe6455756bf47f8,
           0x3fde2865724428b0, 0x3fc826f101bec2b8, 0x3feda8be79d1a2f4,
           0xbfeed8cfc7f94e06, 0xbfcae4caa576e8a8, 0x3fb6009fd8fe2f80,
           0xbfe6675ebf9ca482);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfmax.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_64));
  //                0.0000000000000000,  0.4671677538923853, 0.0000000000000000,
  //                -0.0938698612480795,  0.0000000000000000,
  //                0.2938331380713377,  0.0000000000000000, 0.6841623039857032,
  //                0.0000000000000000,  0.4712155929452235, 0.0000000000000000,
  //                0.9268486384654282,  0.0000000000000000,
  //                -0.2101071651393955,  0.0000000000000000,
  //                -0.7001184217853196
  VCMP_U64(12, v1, 0x0, 0x3fdde613942dab28, 0x0, 0xbfb807daf023fbb0, 0x0,
           0x3fd2ce29819fd630, 0x0, 0x3fe5e4a85818c992, 0x0, 0x3fde2865724428b0,
           0x0, 0x3feda8be79d1a2f4, 0x0, 0xbfcae4caa576e8a8, 0x0,
           0xbfe6675ebf9ca482);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
