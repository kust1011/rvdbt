// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 33 "vfcvt.c"
  VSET(16, e32, m1);
  //              -82436.352, -5427.481, -30119.082,   53784.066,   76500.719,
  //              65152.020, -94151.375,   71894.320, -20547.545,   95485.906,
  //              92834.711, -28081.711, -9716.506,   62508.508,   90410.883,
  //              42708.285
  VLOAD_32(v2, 0xc7a1022d, 0xc5a99bd9, 0xc6eb4e2a, 0x47521811, 0x47956a5c,
           0x477e8005, 0xc7b7e3b0, 0x478c6b29, 0xc6a08717, 0x47ba7ef4,
           0x47b5515b, 0xc6db636c, 0xc617d206, 0x47742c82, 0x47b09571,
           0x4726d449);
  asm volatile("vfcvt.xu.f.v v3, v2");
  //                           0,              0,              0, 53784, 76501,
  //                           65152,              0,          71894, 0, 95486,
  //                           92835,              0,              0, 62509,
  //                           90411,          42708
  VCMP_U32(2, v3, 0x00000000, 0x00000000, 0x00000000, 0x0000d218, 0x00012ad5,
           0x0000fe80, 0x00000000, 0x000118d6, 0x00000000, 0x000174fe,
           0x00016aa3, 0x00000000, 0x00000000, 0x0000f42d, 0x0001612b,
           0x0000a6d4);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
