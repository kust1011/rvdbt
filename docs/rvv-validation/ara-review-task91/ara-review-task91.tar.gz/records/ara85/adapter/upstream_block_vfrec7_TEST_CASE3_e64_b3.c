// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Shafiullah Khan <shafi.ullah@10xengineers.ai>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 97 "vfrec7.c"
  CLEAR_FFLAGS;
  VSET(16, e64, m1);
  CHECK_FFLAGS(0);
  CHANGE_RM(RM_RTZ);
  VLOAD_64(v2, 0x000147ea91db7acb, 0x000347ea91db7acb, 0x000047ea91db7acb,
           0x000347ea91db70cb, 0x000347ea91db7a0b, 0x000347ea91db7ac0,
           0x000347ea91db0acb, 0x000348e91db7acb, 0x800147ea91db7acb,
           0x800347ea91db7acb, 0x800047ea91db7acb, 0x800347ea91db70cb,
           0x800347ea91db7a0b, 0x800347ea91db7ac0, 0x800347ea91db0acb,
           0x800147ea91db7a0b);
  asm volatile("vfrec7.v v1, v2");
  VCMP_U64(9, v1, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, mMaxd,
           mMaxd, mMaxd, mMaxd, mMaxd, mMaxd, mMaxd, mMaxd);
  CHECK_FFLAGS(NX | OF);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
