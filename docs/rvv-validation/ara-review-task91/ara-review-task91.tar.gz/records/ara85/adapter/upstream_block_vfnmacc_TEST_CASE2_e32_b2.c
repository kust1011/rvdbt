// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 153 "vfnmacc.c"
  VSET(16, e32, m1);
  //              -0.17374928, -0.36242354, -0.18093164,  0.94970566,
  //              -0.45790458, -0.17780401, -0.51985794, -0.04832974,
  //              0.13252106,  0.77533042,  0.42536697, -0.72199643,
  //              -0.25088808,  0.28798762,  0.66300607, -0.63549894
  VLOAD_32(v2, 0xbe31eb55, 0xbeb98f94, 0xbe394625, 0x3f731fe9, 0xbeea7278,
           0xbe361241, 0xbf051569, 0xbd45f569, 0x3e07b39a, 0x3f467c0e,
           0x3ed9c9b3, 0xbf38d4c2, 0xbe807467, 0x3e93731d, 0x3f29bac4,
           0xbf22b00f);
  //              -0.61242568,  0.71439523, -0.15632962,  0.10917858,
  //              0.19637996, -0.88467985,  0.73412597, -0.98048240, 0.25438991,
  //              -0.02058743, -0.00876777,  0.21936898, -0.71130067,
  //              -0.29675287, -0.96093589,  0.24695934
  VLOAD_32(v3, 0xbf1cc7ee, 0x3f36e29b, 0xbe2014df, 0x3ddf9905, 0x3e4917d4,
           0xbf627a61, 0x3f3befae, 0xbf7b00e5, 0x3e823f65, 0xbca8a6f9,
           0xbc0fa6af, 0x3e60a243, 0xbf3617cd, 0xbe97effe, 0xbf75ffe5,
           0x3e7ce2e9);
  VLOAD_8(v0, 0xAA, 0xAA);
  //               0.77600455,  0.02542816, -0.63618338,  0.11704731,
  //               0.45613721, -0.90825689,  0.21235447,  0.35766414,
  //               0.08650716, -0.98431164,  0.21029140, -0.92919809,
  //               0.46440944,  0.70648551, -0.80876821, -0.19595607
  VLOAD_32(v1, 0x3f46a83c, 0x3cd04eb8, 0xbf22dcea, 0x3defb680, 0x3ee98ad1,
           0xbf688386, 0x3e597373, 0x3eb71fc1, 0x3db12aaa, 0xbf7bfbd9,
           0x3e5756a1, 0xbf6ddfed, 0x3eedc713, 0x3f34dc3c, 0xbf4f0b6f,
           0xbe48a8b5);
  asm volatile("vfnmacc.vv v1, v2, v3, v0.t");
  //               0.00000000,  0.23348548,  0.00000000, -0.22073483,
  //               0.00000000,  0.75095725,  0.00000000, -0.40505061,
  //               0.00000000,  1.00027370,  0.00000000,  1.08758175,
  //               0.00000000, -0.62102437,  0.00000000,  0.35289848
  VCMP_U32(5, v1, 0x3f46a83c, 0x3e6f16d2, 0xbf22dcea, 0xbe62084f, 0x3ee98ad1,
           0x3f403ebc, 0x3e597373, 0xbecf62cb, 0x3db12aaa, 0x3f8008f8,
           0x3e5756a1, 0x3f8b35e1, 0x3eedc713, 0xbf1efb74, 0xbf4f0b6f,
           0x3eb4af1c);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
