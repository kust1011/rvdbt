// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 149 "vfmadd.c"
  VSET(16, e32, m1);
  //              -0.20637949, -0.63321692,  0.40850523,  0.58702314,
  //              -0.25534528, -0.22053087,  0.96057665,  0.85530519,
  //              0.74252450, -0.87175107, -0.00987994, -0.52556008, 0.26113954,
  //              -0.71307814,  0.78942811,  0.48685852
  VLOAD_32(v2, 0xbe535525, 0xbf221a81, 0x3ed12799, 0x3f164726, 0xbe82bc9e,
           0xbe61d2d8, 0x3f75e85a, 0x3f5af548, 0x3f3e1616, 0xbf5f2b14,
           0xbc21df78, 0xbf068b1b, 0x3e85b415, 0xbf368c4a, 0x3f4a17f6,
           0x3ef94585);
  //              -0.15712014,  0.83088422,  0.57509524,  0.85365236,
  //              -0.96695948,  0.71368766,  0.23281342, -0.67807233,
  //              0.79363507,  0.62817359,  0.37205252,  0.27726358,
  //              -0.85021532, -0.16634122, -0.58148408,  0.06963744
  VLOAD_32(v3, 0xbe20e41a, 0x3f54b4d4, 0x3f133971, 0x3f5a88f6, 0xbf778aa8,
           0x3f36b43c, 0x3e6e66a4, 0xbf2d9626, 0x3f4b2bab, 0x3f20cffc,
           0x3ebe7dab, 0x3e8df57e, 0xbf59a7b6, 0xbe2a555a, 0xbf14dc24,
           0x3d8e9e13);
  VLOAD_8(v0, 0xAA, 0xAA);
  //              -0.63061494,  0.57643133,  0.08198822, -0.06029604,
  //              -0.84276563,  0.00681775,  0.30881208,  0.27571887,
  //              0.12349209,  0.29805747, -0.55497122, -0.52685922, 0.82809180,
  //              -0.83231467,  0.20959182,  0.15603130
  VLOAD_32(v1, 0xbf216ffb, 0x3f139101, 0x3da7e970, 0xbd76f8fa, 0xbf57bf7d,
           0x3bdf676d, 0x3e9e1c9e, 0x3e8d2b06, 0x3dfce96c, 0x3e989afd,
           0xbf0e1298, 0xbf06e03f, 0x3f53fdd3, 0xbf551293, 0x3e569f3d,
           0x3e1fc6ab);
  asm volatile("vfmadd.vv v1, v2, v3, v0.t");
  VCMP_U32(5, v1, 0xbf216ffb, 0x3eee8795, 0x3da7e970, 0x3f51794e, 0xbf57bf7d,
           0x3f3651b3, 0x3e9e1c9e, 0xbee26e67, 0x3dfce96c, 0x3ebc9748,
           0xbf0e1298, 0x3f0ddd6a, 0x3f53fdd3, 0x3edab544, 0x3e569f3d,
           0x3e1518d9);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
