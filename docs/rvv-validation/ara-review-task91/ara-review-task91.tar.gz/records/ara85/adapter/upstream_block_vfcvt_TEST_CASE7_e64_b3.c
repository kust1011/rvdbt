// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE7(void) {
#line 451 "vfcvt.c"
  VSET(16, e64, m1);
  //                1347922.217,   7326256.926,   2532328.150, -4365139.352,
  //                -3892733.643, -3401324.772, -2109243.969,   61221.157,
  //                -307581.498, -6001564.901, -1299579.664, -2048360.900,
  //                3486773.936, -5491246.977, -2222467.648,   1432204.815
  VLOAD_64(v2, 0x413491523797bd28, 0x415bf28c3b410560, 0x414351f41339c8f8,
           0xc150a6d4d6864763, 0xc14db2fed245a01c, 0xc149f33662d1f60e,
           0xc140179dfc15a4ac, 0x40ede4a503831a00, 0xc112c5f5fdac3c80,
           0xc156e4e739a40168, 0xc133d47ba9e7da00, 0xc13f4168e650cc0c,
           0x414a9a1af7c5dda0, 0xc154f28bbe844db6, 0xc140f4c1d2e7a21a,
           0x4135da8cd09570f8);
  asm volatile("vfcvt.rtz.x.f.v v3, v2");
  //                             1347922,                7326256, 2532328,
  //                             -4365139,               -3892733, -3401324,
  //                             -2109243,                  61221, -307581,
  //                             -6001564,               -1299579, -2048360,
  //                             3486773,               -5491246, -2222467,
  //                             1432204
  VCMP_U64(21, v3, 0x0000000000149152, 0x00000000006fca30, 0x000000000026a3e8,
           0xffffffffffbd64ad, 0xffffffffffc49a03, 0xffffffffffcc1994,
           0xffffffffffdfd0c5, 0x000000000000ef25, 0xfffffffffffb4e83,
           0xffffffffffa46c64, 0xffffffffffec2b85, 0xffffffffffe0be98,
           0x0000000000353435, 0xffffffffffac35d2, 0xffffffffffde167d,
           0x000000000015da8c);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE7"); TEST_CASE7(); ara_case_end("TEST_CASE7",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
