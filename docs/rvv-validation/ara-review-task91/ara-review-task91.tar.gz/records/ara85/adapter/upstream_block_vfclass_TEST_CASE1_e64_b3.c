// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 13 "vfclass.c"
  CLEAR_FFLAGS;
#line 14 "vfclass.c"
  CHECK_FFLAGS(0);
#line 35 "vfclass.c"
  VSET(16, e64, m1);
  VLOAD_64(v2, mInfd, pInfd, qNaNd, sNaNd, 0x3def3136584672de,
           0xbdef3136584672de, pZero, mZerod, 0x8000000000000075,
           0x0000000000000c5, mInfd, pInfd, qNaNd, sNaNd, 0x3def313584672de4,
           0xbdef313654672de4);
  asm volatile("vfclass.v v1, v2");
  VCMP_U64(3, v1, CLASS_mInf, CLASS_pInf, CLASS_qNAN, CLASS_sNAN, CLASS_pNorm,
           CLASS_mNorm, CLASS_pZero, CLASS_mZero, CLASS_mSub, CLASS_pSub,
           CLASS_mInf, CLASS_pInf, CLASS_qNAN, CLASS_sNAN, CLASS_pNorm,
           CLASS_mNorm);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
