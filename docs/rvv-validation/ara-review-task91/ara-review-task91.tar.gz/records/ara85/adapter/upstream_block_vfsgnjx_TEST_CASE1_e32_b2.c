// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfsgnjx.c"
  VSET(16, e32, m1);
  //              -0.00918692, -0.23372029,  0.42919466,  0.95128548,
  //              0.05014091,  0.08194520,  0.65458435,  0.38167605,
  //              -0.52784044,  0.46330592,  0.66792834,  0.94584799,
  //              -0.11679628,  0.12139154,  0.61421394, -0.71422517
  VLOAD_32(v2, 0xbc1684ba, 0xbe6f545f, 0x3edbbf67, 0x3f738772, 0x3d4d608d,
           0x3da7d2e2, 0x3f2792d7, 0x3ec36b0b, 0xbf07208d, 0x3eed366f,
           0x3f2afd5a, 0x3f722318, 0xbdef32e4, 0x3df89c21, 0x3f1d3d20,
           0xbf36d776);
  //              -0.96525091, -0.82903022, -0.98528612,  0.36915505,
  //              0.23285799,  0.19133335,  0.78484982, -0.40654737,
  //              -0.40144378, -0.94419461,  0.60990387, -0.37662670,
  //              0.75369638, -0.82297397,  0.24545205, -0.75572032
  VLOAD_32(v3, 0xbf771aaf, 0xbf543b53, 0xbf7c3bb6, 0x3ebd01e4, 0x3e6e7253,
           0x3e43ece4, 0x3f48ebeb, 0xbed026fa, 0xbecd8a0a, 0xbf71b6bd,
           0x3f1c22a9, 0xbec0d537, 0x3f40f23f, 0xbf52ae6c, 0x3e7b57c8,
           0xbf4176e3);
  asm volatile("vfsgnjx.vv v1, v2, v3");
  //               0.00918692,  0.23372029, -0.42919466,  0.95128548,
  //               0.05014091,  0.08194520,  0.65458435, -0.38167605,
  //               0.52784044, -0.46330592,  0.66792834, -0.94584799,
  //               -0.11679628, -0.12139154,  0.61421394,  0.71422517
  VCMP_U32(2, v1, 0x3c1684ba, 0x3e6f545f, 0xbedbbf67, 0x3f738772, 0x3d4d608d,
           0x3da7d2e2, 0x3f2792d7, 0xbec36b0b, 0x3f07208d, 0xbeed366f,
           0x3f2afd5a, 0xbf722318, 0xbdef32e4, 0xbdf89c21, 0x3f1d3d20,
           0x3f36d776);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
