// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 355 "vfmadd.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                               0.80368215
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f4dbe1d);
  //                0.13072050, -0.19741143,  0.09370349,  0.41049519,
  //                -0.69910282, -0.90573430,  0.86481184,  0.33341369,
  //                0.30657578, -0.90526944, -0.97891974, -0.50830764,
  //                0.79750061,  0.96885878,  0.48752418,  0.64305341
  VLOAD_32(v2, 0x3e05db98, 0xbe4a2639, 0x3dbfe79e, 0x3ed22c6d, 0xbf32f867,
           0xbf67de34, 0x3f5d644f, 0x3eaab533, 0x3e9cf780, 0xbf67bfbd,
           0xbf7a9a7c, 0xbf022073, 0x3f4c2900, 0x3f780721, 0x3ef99cc5,
           0x3f249f26);
  VLOAD_8(v0, 0xAA, 0xAA);
  //               -0.61117887,  0.81778014, -0.46267223, -0.30897874,
  //               -0.84296966,  0.50125730,  0.96147668,  0.65802389,
  //               0.19629262, -0.73197508, -0.06948850, -0.60436314,
  //               -0.80817568,  0.72047287, -0.78180677, -0.40237895
  VLOAD_32(v1, 0xbf1c7638, 0x3f515a0a, 0xbeece360, 0xbe9e3276, 0xbf57ccdc,
           0x3f005266, 0x3f762356, 0x3f287441, 0x3e4900ef, 0xbf3b62b8,
           0xbd8e4ffc, 0xbf1ab78b, 0xbf4ee49a, 0x3f3870e9, 0xbf48247d,
           0xbece049d);
  asm volatile("vfmadd.vf v1, %[A], v2, v0.t" ::[A] "f"(dscalar_32));
  VCMP_U32(11, v1, 0xbf1c7638, 0x3eeb6e09, 0xbeece360, 0x3e261112, 0xbf57ccdc,
           0xbf00bced, 0x3f762356, 0x3f5cbccb, 0x3e4900ef, 0xbfbf2c79,
           0xbd8e4ffc, 0xbf7e7853, 0xbf4ee49a, 0x3fc62142, 0xbf48247d,
           0x3ea3ab9c);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE4"); TEST_CASE4(); ara_case_end("TEST_CASE4",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
