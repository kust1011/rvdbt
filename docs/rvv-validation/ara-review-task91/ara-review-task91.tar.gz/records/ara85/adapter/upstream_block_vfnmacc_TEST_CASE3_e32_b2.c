// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 267 "vfnmacc.c"
  VSET(16, e32, m1);
  double dscalar_32;
  //                              -0.26917368
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbe89d122);
  //              -0.27745819, -0.86308837, -0.16746511, -0.68674469,
  //              -0.49064314, -0.74352056, -0.17169137,  0.26071417,
  //              0.71857828,  0.07920383, -0.43244356, -0.58339220, 0.80679923,
  //              0.23900302,  0.73513943, -0.80685192
  VLOAD_32(v2, 0xbe8e0f00, 0xbf5cf35c, 0xbe2b7bf9, 0xbf2fce80, 0xbefb3594,
           0xbf3e575d, 0xbe2fcfdd, 0x3e857c54, 0x3f37f4bf, 0x3da2359e,
           0xbedd693e, 0xbf155931, 0x3f4e8a65, 0x3e74bd35, 0x3f3c3219,
           0xbf4e8dd9);
  //               0.13509545, -0.29169917,  0.80494332, -0.63637137,
  //               0.63772237, -0.87242430, -0.44194883, -0.41286576,
  //               -0.57735479,  0.61664599,  0.94073379, -0.89744234,
  //               -0.70681161,  0.23247144,  0.06774496, -0.38581881
  VLOAD_32(v1, 0x3e0a5676, 0xbe955998, 0x3f4e10c4, 0xbf22e93c, 0x3f2341c6,
           0xbf5f5733, 0xbee2471e, 0xbed36324, 0xbf13cd86, 0x3f1ddc83,
           0x3f70d3ee, 0xbf65bec8, 0xbf34f19b, 0x3e6e0cfe, 0x3d8abdde,
           0xbec58a0b);
  asm volatile("vfnmacc.vf v1, %[A], v2" ::[A] "f"(dscalar_32));
  //              -0.20977989,  0.05937849, -0.85002053,  0.45151776,
  //              -0.76979059,  0.67228812,  0.39573404,  0.48304313,
  //              0.77077717, -0.59532642, -1.05713618,  0.74040854, 0.92398071,
  //              -0.16813812,  0.13013524,  0.16863550
  VCMP_U32(8, v1, 0xbe56d08a, 0x3d7336de, 0xbf599af2, 0x3ee72d57, 0xbf4510ff,
           0x3f2c1b13, 0x3eca9da7, 0x3ef7516f, 0x3f4551a7, 0xbf186750,
           0xbf87503d, 0x3f3d8b6a, 0x3f6c8a00, 0xbe2c2c66, 0x3e05422c,
           0x3e2caec9);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
