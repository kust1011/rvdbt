// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>
//         Matteo Perotti <mperotti@iis.ee.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 36 "vfwadd.c"
  VSET(16, e32, m1);
  //              -35386.17187500, -52670.69531250,  69391.31250000,
  //              3219.84130859,  74596.35156250, -45488.69921875,
  //              6598.72949219,  20221.24609375,  75105.62500000,
  //              67354.82031250,  32844.19140625, -73470.18750000,
  //              -28377.67382812,  61998.10937500,  24691.54296875,
  //              -29873.45507812
  VLOAD_32(v2, 0xc70a3a2c, 0xc74dbeb2, 0x478787a8, 0x45493d76, 0x4791b22d,
           0xc731b0b3, 0x45ce35d6, 0x469dfa7e, 0x4792b0d0, 0x47838d69,
           0x47004c31, 0xc78f7f18, 0xc6ddb359, 0x47722e1c, 0x46c0e716,
           0xc6e962e9);
  //              -90937.21875000, -72297.07031250,  18867.19531250,
  //              -516.01525879, -13301.11425781,  85173.41406250,
  //              -32079.35546875, -23770.60937500,  39295.43359375,
  //              38042.19140625, -61343.24218750,  76844.01562500,
  //              26642.50390625,  91893.05468750,  88349.72656250,
  //              29134.96093750
  VLOAD_32(v3, 0xc7b19c9c, 0xc78d3489, 0x46936664, 0xc40100fa, 0xc64fd475,
           0x47a65ab5, 0xc6fa9eb6, 0xc6b9b538, 0x47197f6f, 0x47149a31,
           0xc76f9f3e, 0x47961602, 0x46d02502, 0x47b37a87, 0x47ac8edd,
           0x46e39dec);
  asm volatile("vfwadd.vv v4, v2, v3");
  //              -126323.3906250000000000, -124967.7656250000000000,
  //              88258.5078125000000000,  2703.8260498046875000,
  //              61295.2373046875000000,  39684.7148437500000000,
  //              -25480.6259765625000000, -3549.3632812500000000,
  //              114401.0585937500000000,  105397.0117187500000000,
  //              -28499.0507812500000000,  3373.8281250000000000,
  //              -1735.1699218750000000,  153891.1640625000000000,
  //              113041.2695312500000000, -738.4941406250000000
  VCMP_U64(2, v4, 0xc0fed73640000000, 0xc0fe827c40000000, 0x40f58c2820000000,
           0x40a51fa6f0000000, 0x40edede798000000, 0x40e36096e0000000,
           0xc0d8e22810000000, 0xc0abbaba00000000, 0x40fbee10f0000000,
           0x40f9bb5030000000, 0xc0dbd4c340000000, 0x40aa5ba800000000,
           0xc09b1cae00000000, 0x4102c91950000000, 0x40fb991450000000,
           0xc08713f400000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
