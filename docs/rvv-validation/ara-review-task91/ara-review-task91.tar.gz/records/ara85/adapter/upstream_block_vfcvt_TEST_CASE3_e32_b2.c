// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 165 "vfcvt.c"
  VSET(16, e32, m1);
  //              -28075.818, -5455.616,   6106.086, -11952.592, -50887.914,
  //              -23028.832, -9221.246, -71657.047, -6655.005, -21208.561,
  //              -30018.096, -19766.838,   48541.953, -62313.625,   13515.192,
  //              -83224.820
  VLOAD_32(v2, 0xc6db57a3, 0xc5aa7ced, 0x45bed0b1, 0xc63ac25e, 0xc746c7ea,
           0xc6b3e9aa, 0xc61014fc, 0xc78bf486, 0xc5cff80a, 0xc6a5b11f,
           0xc6ea8431, 0xc69a6dad, 0x473d9df4, 0xc77369a0, 0x46532cc5,
           0xc7a28c69);
  asm volatile("vfcvt.x.f.v v3, v2");
  //                      -28076,          -5456,           6106, -11953,
  //                      -50888,         -23029,          -9221, -71657, -6655,
  //                      -21209,         -30018,         -19767, 48542, -62314,
  //                      13515,         -83225
  VCMP_U32(8, v3, 0xffff9254, 0xffffeab0, 0x000017da, 0xffffd14f, 0xffff3938,
           0xffffa60b, 0xffffdbfb, 0xfffee817, 0xffffe601, 0xffffad27,
           0xffff8abe, 0xffffb2c9, 0x0000bd9e, 0xffff0c96, 0x000034cb,
           0xfffebae7);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
