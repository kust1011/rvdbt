// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 72 "vfmsub.c"
  VSET(16, e64, m1);
  //               0.3304351537536074, -0.7528197595818080, -0.7530937950641439,
  //               -0.7994160811423281,  0.0797802827518117,
  //               -0.6361377214985149,  0.1748070414096887, 0.8251843575618585,
  //               0.0699629848559165, -0.8195631240215655, -0.4843919596862658,
  //               -0.9206444585342115,  0.9791118581337512, 0.5143481050333210,
  //               0.5856279779979670, -0.5536419150604011
  VLOAD_64(v2, 0x3fd525d97cb482ac, 0xbfe8171976e5f762, 0xbfe819582893df6e,
           0xbfe994d1088ce396, 0x3fb46c7b0948dfc0, 0xbfe45b3d7eb2d188,
           0x3fc66013befb8968, 0x3fea67e9069cc438, 0x3fb1e9181be2ff10,
           0xbfea39dc71d5c454, 0xbfdf00472253102c, 0xbfed75eb5e14bcf6,
           0x3fef54e26439ed98, 0x3fe0758a283c1602, 0x3fe2bd76e2a3f6ca,
           0xbfe1b76f3fdc22ac);
  //               0.4156163852505284, -0.7806302214299039, -0.8826873649954201,
  //               0.4810449553239884,  0.9337837820126544, -0.5377837408558668,
  //               -0.1434453653318362,  0.1199087999382409,
  //               -0.2601268153647489, -0.1813009025048657,
  //               -0.2492371358416354,  0.4131695659117063,
  //               -0.9085600854772706, -0.3952216110937696, 0.0817663443229741,
  //               0.1439804529607418
  VLOAD_64(v3, 0x3fda997577954be0, 0xbfe8faec3ae9f10e, 0xbfec3ef992a7ed86,
           0x3fdec970c7c16d8c, 0x3fede18e86a8f206, 0xbfe135863f697cd2,
           0xbfc25c6af06e7710, 0x3fbeb257d63cc310, 0xbfd0a5eaf1337874,
           0xbfc734de337f3100, 0xbfcfe700a1b1bb78, 0x3fda715ec352c558,
           0xbfed12ec99b26d4c, 0xbfd94b4f95947db0, 0x3fb4eea39ec7d8a0,
           0x3fc26df3945d6540);
  //              -0.2185765241217579, -0.9587275435281344,  0.1216903502931035,
  //              0.7653655177934149, -0.5928258331230032,  0.9123074434439491,
  //              0.1569052366565831,  0.2566745252901157, -0.9113595614847214,
  //              0.1628442001087833,  0.2337303194688813,  0.1926350000139823,
  //              -0.6653994610877216, -0.6745212179353777,  0.8748797125997727,
  //              -0.7324641634418565
  VLOAD_64(v1, 0xbfcbfa50c7635df8, 0xbfeeade562a749c2, 0x3fbf27194abf66e0,
           0x3fe87ddfd38d1514, 0xbfe2f86de1af9792, 0x3fed319f612fa6f6,
           0x3fc4157886016dd8, 0x3fd06d5afcf59780, 0xbfed29db86ef2934,
           0x3fc4d81428e7be98, 0x3fcdeae00719eac8, 0x3fc8a84380900070,
           0xbfe54af3cf84bab0, 0xbfe595ad856fb278, 0x3febff03bd3198ce,
           0xbfe77058af6f3156);
  asm volatile("vfmsub.vv v1, v2, v3");
  //              -0.4878417526056305,  1.5023792602532113,  0.7910431172705017,
  //              -1.0928904581998689, -0.9810795946017860, -0.0425694375227023,
  //              0.1708735055334605,  0.0918950033157782,  0.1963653801662987,
  //              0.0478398011349183,  0.1360200483560070, -0.5905179111943168,
  //              0.2570595827304748,  0.0482829008439404,  0.4305876927582732,
  //              0.2615424092003222
  VCMP_U64(3, v1, 0xbfdf38cc9d4420dd, 0x3ff809bed5cf9e94, 0x3fe95039a7cce2e7,
           0xbff17c7ab4814324, 0xbfef650108b2cdb1, 0xbfa5cba94bf030ac,
           0x3fc5df2edb027178, 0x3fb7866e51e83656, 0x3fc9228032f0c004,
           0x3fa87e755aa4ab1c, 0x3fc1691adda50ab1, 0xbfe2e585d18904b2,
           0x3fd073aa093cd9d6, 0x3fa8b88950295616, 0x3fdb8ebfae9d3d83,
           0x3fd0bd1c5f821364);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
