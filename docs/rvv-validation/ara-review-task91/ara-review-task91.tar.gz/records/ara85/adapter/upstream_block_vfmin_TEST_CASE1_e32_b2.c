// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfmin.c"
  VSET(16, e32, m1);
  //               0.33477312, -0.14129849, -0.94871885,  0.83600986,
  //               -0.28163233, -0.47814348,  0.77408481, -0.54823470,
  //               -0.72419900,  0.27495387, -0.76835793,  0.71516198,
  //               0.32305571, -0.76598656, -0.36499983, -0.52954155
  VLOAD_32(v2, 0x3eab6762, 0xbe10b08d, 0xbf72df3d, 0x3f5604be, 0xbe90321d,
           0xbef4cf39, 0x3f462a6c, 0xbf0c591c, 0xbf39651b, 0x3e8cc6c1,
           0xbf44b31b, 0x3f3714db, 0x3ea5678f, 0xbf4417b2, 0xbebae142,
           0xbf079009);
  //               0.87184614,  0.40005061,  0.40118238,  0.97373396,
  //               0.74085194, -0.99458516, -0.73125440, -0.46319291,
  //               -0.76140571, -0.82557100,  0.15205561,  0.39971715,
  //               -0.32876521, -0.53106725,  0.84727478,  0.21940185
  VLOAD_32(v3, 0x3f5f314f, 0x3eccd36f, 0x3ecd67c7, 0x3f7946a1, 0x3f3da879,
           0xbf7e9d22, 0xbf3b337d, 0xbeed279f, 0xbf42eb7c, 0xbf53589f,
           0x3e1bb477, 0x3ecca7ba, 0xbea853ea, 0xbf07f406, 0x3f58e700,
           0x3e60aae1);
  asm volatile("vfmin.vv v1, v2, v3");
  //               0.33477312, -0.14129849, -0.94871885,  0.83600986,
  //               -0.28163233, -0.99458516, -0.73125440, -0.54823470,
  //               -0.76140571, -0.82557100, -0.76835793,  0.39971715,
  //               -0.32876521, -0.76598656, -0.36499983, -0.52954155
  VCMP_U32(2, v1, 0x3eab6762, 0xbe10b08d, 0xbf72df3d, 0x3f5604be, 0xbe90321d,
           0xbf7e9d22, 0xbf3b337d, 0xbf0c591c, 0xbf42eb7c, 0xbf53589f,
           0xbf44b31b, 0x3ecca7ba, 0xbea853ea, 0xbf4417b2, 0xbebae142,
           0xbf079009);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
