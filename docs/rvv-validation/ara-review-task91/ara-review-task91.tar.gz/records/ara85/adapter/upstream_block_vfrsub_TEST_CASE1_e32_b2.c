// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 30 "vfrsub.c"
  VSET(16, e32, m1);
  //               0.61218858,  0.50298065,  0.82400811, -0.50508654,
  //               -0.08447543, -0.66344708, -0.94741052,  0.85856712,
  //               -0.16725175, -0.36700448, -0.86911696,  0.82600677,
  //               -0.95377433,  0.06016647,  0.67027277,  0.08167093
  VLOAD_32(v2, 0x3f1cb864, 0x3f00c357, 0x3f52f232, 0xbf014d5a, 0xbdad0174,
           0xbf29d7ab, 0xbf72897f, 0x3f5bcb0e, 0xbe2b440b, 0xbebbe803,
           0xbf5e7e73, 0x3f53752e, 0xbf742a8e, 0x3d76711d, 0x3f2b96ff,
           0x3da74316);
  double dscalar_32;
  //                              -0.78482366
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbf48ea34);
  asm volatile("vfrsub.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //              -1.39701223, -1.28780437, -1.60883176, -0.27973711,
  //              -0.70034826, -0.12137657,  0.16258687, -1.64339077,
  //              -0.61757189, -0.41781917,  0.08429331, -1.61083043,
  //              0.16895068, -0.84499013, -1.45509648, -0.86649460
  VCMP_U32(2, v1, 0xbfb2d14c, 0xbfa4d6c6, 0xbfcdee33, 0xbe8f39b4, 0xbf334a06,
           0xbdf89448, 0x3e267d2c, 0xbfd25aa1, 0xbf1e1931, 0xbed5ec65,
           0x3daca1f8, 0xbfce2fb1, 0x3e2d0168, 0xbf585146, 0xbfba409a,
           0xbf5dd297);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
