// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 153 "vfmsub.c"
  VSET(16, e32, m1);
  //              -0.74553698, -0.16736358, -0.11869104, -0.85860848,
  //              -0.66138542, -0.68386567, -0.45389724, -0.12761629,
  //              -0.95652348,  0.71083277,  0.24187960,  0.01609672,
  //              -0.58867335, -0.55222940, -0.67417240, -0.06725668
  VLOAD_32(v2, 0xbf3edb83, 0xbe2b615c, 0xbdf3144a, 0xbf5bcdc4, 0xbf29508e,
           0xbf2f11d2, 0xbee86538, 0xbe02add8, 0xbf74deb9, 0x3f35f923,
           0x3e77af49, 0x3c83dd45, 0xbf16b34c, 0xbf0d5ee8, 0xbf2c9690,
           0xbd89bddf);
  //              -0.17500710, -0.81537211, -0.31956050,  0.22762603,
  //              0.49659184, -0.09389434,  0.05757815, -0.13087828,
  //              -0.73042232, -0.79662275, -0.96801740,  0.03017101,
  //              0.70759267, -0.35606241,  0.18037270, -0.35372722
  VLOAD_32(v3, 0xbe333510, 0xbf50bc3a, 0xbea39d6f, 0x3e6916cc, 0x3efe4149,
           0xbdc04bad, 0x3d6bd711, 0xbe0604f5, 0xbf3afcf5, 0xbf4bef78,
           0xbf77cffd, 0x3cf72932, 0x3f3524cb, 0xbeb64dd0, 0x3e38b39f,
           0xbeb51bbc);
  VLOAD_8(v0, 0xAA, 0xAA);
  //               0.92876774,  0.18572871, -0.42147154, -0.79289448,
  //               0.90907055,  0.07037155,  0.07339484,  0.17415307,
  //               -0.61978233, -0.04939311,  0.56138068, -0.51601994,
  //               -0.80625385, -0.31227911,  0.91474551,  0.78424871
  VLOAD_32(v1, 0x3f6dc3b9, 0x3e3e2fab, 0xbed7cb1e, 0xbf4afb22, 0x3f68b8d9,
           0x3d901ef6, 0x3d965009, 0x3e32552f, 0xbf1eaa0e, 0xbd4a506e,
           0x3f0fb6a5, 0xbf0419e2, 0xbf4e66a7, 0xbe9fe30c, 0x3f6a2cc3,
           0x3f48c486);
  asm volatile("vfmsub.vv v1, v2, v3, v0.t");
  //               0.92876774,  0.78428787, -0.42147154,  0.45315993,
  //               0.90907055,  0.04576965,  0.07339484,  0.10865352,
  //               -0.61978233,  0.76151252,  0.56138068, -0.03847724,
  //               -0.80625385,  0.52851212,  0.91474551,  0.30098125
  VCMP_U32(5, v1, 0x3f6dc3b9, 0x3f48c717, 0xbed7cb1e, 0x3ee80493, 0x3f68b8d9,
           0x3d3b78f5, 0x3d965009, 0x3dde85bc, 0xbf1eaa0e, 0x3f42f27c,
           0x3f0fb6a5, 0xbd1d9a4f, 0xbf4e66a7, 0x3f074c92, 0x3f6a2cc3,
           0x3e9a1a37);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
