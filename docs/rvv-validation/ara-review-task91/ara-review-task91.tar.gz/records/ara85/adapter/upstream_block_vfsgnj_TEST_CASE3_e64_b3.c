// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 235 "vfsgnj.c"
  VSET(16, e64, m1);
  double dscalar_64;
  //                                0.4863995754678485
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3fdf212baf5b0d68);
  //                0.4577518787562838, -0.0989909265811582,
  //                -0.5406373582107198, -0.6896639688670565,
  //                0.9053190721589099, -0.7617679756965072, 0.4649312111760273,
  //                0.6917063611214438,  0.2205644023843889, 0.1217272698758698,
  //                -0.3345487709580650,  0.1693366988903542,
  //                0.4095982059989967,  0.7157757577569959,
  //                -0.5339346851091937,  0.4946553559543683
  VLOAD_64(v2, 0x3fdd4bce893c3600, 0xbfb9577828444dc0, 0xbfe14ce6b790591e,
           0xbfe611ba2bf06f2a, 0x3fecf85fb3ebc33c, 0xbfe860673bd8363e,
           0x3fddc16ed6b90158, 0x3fe6227560ee74e0, 0x3fcc3b744f738cd0,
           0x3fbf2984b325f230, 0xbfd5693f3f8ba3fc, 0x3fc5acd32fdf92e8,
           0x3fda36db64d10584, 0x3fe6e7a28fdabfd2, 0xbfe115fe3157cf38,
           0x3fdfa86ef0276044);
  asm volatile("vfsgnj.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //               0.4577518787562838,  0.0989909265811582,  0.5406373582107198,
  //               0.6896639688670565,  0.9053190721589099,  0.7617679756965072,
  //               0.4649312111760273,  0.6917063611214438,  0.2205644023843889,
  //               0.1217272698758698,  0.3345487709580650,  0.1693366988903542,
  //               0.4095982059989967,  0.7157757577569959,  0.5339346851091937,
  //               0.4946553559543683
  VCMP_U64(9, v1, 0x3fdd4bce893c3600, 0x3fb9577828444dc0, 0x3fe14ce6b790591e,
           0x3fe611ba2bf06f2a, 0x3fecf85fb3ebc33c, 0x3fe860673bd8363e,
           0x3fddc16ed6b90158, 0x3fe6227560ee74e0, 0x3fcc3b744f738cd0,
           0x3fbf2984b325f230, 0x3fd5693f3f8ba3fc, 0x3fc5acd32fdf92e8,
           0x3fda36db64d10584, 0x3fe6e7a28fdabfd2, 0x3fe115fe3157cf38,
           0x3fdfa86ef0276044);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE3"); TEST_CASE3(); ara_case_end("TEST_CASE3",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
