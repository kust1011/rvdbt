// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 59 "vfsgnjx.c"
  VSET(16, e64, m1);
  //              -0.4085246287477386,  0.8681744372264055, -0.9782992825101422,
  //              0.9959576051606904, -0.7910104167136705,  0.0799315061445605,
  //              0.2562329212571202, -0.0401280831920132, -0.6164331117742006,
  //              0.0314794700215042, -0.2391312835511448,  0.2944948324466776,
  //              -0.3469257666022745,  0.3129356083924371,  0.1418123916338592,
  //              -0.2697778839142546
  VLOAD_64(v2, 0xbfda25447c0540c8, 0x3febc815c1e38a2c, 0xbfef4e3a4c029a38,
           0x3fefdee27bcbc3c2, 0xbfe94ff513d293d6, 0x3fb4766424cf97d0,
           0x3fd0661ec43d4dd0, 0xbfa48bab09ebf660, 0xbfe3b9d1eee7bc0a,
           0x3fa01e13bc79bd60, 0xbfce9bda9926bde0, 0x3fd2d900da8cc448,
           0xbfd63408216c936c, 0x3fd4072312f3290c, 0x3fc226e8901e1378,
           0xbfd1440a752621b8);
  //              -0.9042358342806300,  0.2953863994960662, -0.4373909703642964,
  //              0.1464626280814265, -0.5161207396769107, -0.3525096032632213,
  //              -0.0692332757289065, -0.9900711773455610,  0.6225050177521096,
  //              -0.1361158534833962,  0.1558021548512183,  0.9766583762298613,
  //              0.2768845956890595,  0.6672273199701737, -0.4444943981200347,
  //              0.5095574851608440
  VLOAD_64(v3, 0xbfecef7ffd03691e, 0x3fd2e79c5b6133f0, 0xbfdbfe36b251f164,
           0x3fc2bf4992d91480, 0xbfe0840fa43663a0, 0xbfd68f847062a774,
           0xbfb1b9459f0cf460, 0xbfefaea9bfed2a32, 0x3fe3eb8fa49aeb32,
           0xbfc16c3e8996d300, 0x3fc3f15333ddbc58, 0x3fef40c91128b1ea,
           0x3fd1b87a2ad00b5c, 0x3fe559ed1bc8a0c2, 0xbfdc7298a1cb9174,
           0x3fe04e4b7fc654a0);
  asm volatile("vfsgnjx.vv v1, v2, v3");
  //               0.4085246287477386,  0.8681744372264055,  0.9782992825101422,
  //               0.9959576051606904,  0.7910104167136705, -0.0799315061445605,
  //               -0.2562329212571202,  0.0401280831920132,
  //               -0.6164331117742006, -0.0314794700215042,
  //               -0.2391312835511448,  0.2944948324466776,
  //               -0.3469257666022745,  0.3129356083924371,
  //               -0.1418123916338592, -0.2697778839142546
  VCMP_U64(3, v1, 0x3fda25447c0540c8, 0x3febc815c1e38a2c, 0x3fef4e3a4c029a38,
           0x3fefdee27bcbc3c2, 0x3fe94ff513d293d6, 0xbfb4766424cf97d0,
           0xbfd0661ec43d4dd0, 0x3fa48bab09ebf660, 0xbfe3b9d1eee7bc0a,
           0xbfa01e13bc79bd60, 0xbfce9bda9926bde0, 0x3fd2d900da8cc448,
           0xbfd63408216c936c, 0x3fd4072312f3290c, 0xbfc226e8901e1378,
           0xbfd1440a752621b8);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
