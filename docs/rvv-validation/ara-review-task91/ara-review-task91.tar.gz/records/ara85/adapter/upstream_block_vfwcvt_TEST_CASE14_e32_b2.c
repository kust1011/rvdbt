// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE14(void) {
#line 609 "vfwcvt.c"
  VSET(16, e32, m1);
  //              -69280.273, -24625.789,   58970.254,   57986.516,   34031.016,
  //              61977.340, -84548.211,   89658.250,   4958.967, -73911.508,
  //              -83526.188, -59814.750,   71544.742,   93401.383,   79319.078,
  //              4639.214
  VLOAD_32(v2, 0xc7875023, 0xc6c06394, 0x47665a41, 0x47628284, 0x4704ef04,
           0x47721957, 0xc7a5221b, 0x47af1d20, 0x459af7bc, 0xc7905bc1,
           0xc7a32318, 0xc769a6c0, 0x478bbc5f, 0x47b66cb1, 0x479aeb8a,
           0x4590f9b7);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v4);
  asm volatile("vfwcvt.f.f.v v4, v2, v0.t");
  //                0.000, -24625.789,   0.000,   57986.516,   0.000, 61977.340,
  //                0.000,   89658.250,   0.000, -73911.508,   0.000,
  //                -59814.750,   0.000,   93401.383,   0.000,   4639.214
  VCMP_U64(28, v4, 0x0, 0xc0d80c7280000000, 0x0, 0x40ec505080000000, 0x0,
           0x40ee432ae0000000, 0x0, 0x40f5e3a400000000, 0x0, 0xc0f20b7820000000,
           0x0, 0xc0ed34d800000000, 0x0, 0x40f6cd9620000000, 0x0,
           0x40b21f36e0000000);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE14"); TEST_CASE14(); ara_case_end("TEST_CASE14",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
