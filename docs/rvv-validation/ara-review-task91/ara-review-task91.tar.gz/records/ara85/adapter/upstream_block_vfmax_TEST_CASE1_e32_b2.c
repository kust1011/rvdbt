// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfmax.c"
  VSET(16, e32, m1);
  //              -0.19589283,  0.64597517, -0.09556163,  0.96582597,
  //              0.93413597,  0.78331935, -0.18831402, -0.29520443, 0.09486515,
  //              0.96548969,  0.74523991,  0.81442171,  0.25644442,
  //              -0.92091519,  0.25139943, -0.77403748
  VLOAD_32(v2, 0xbe489821, 0x3f255ea1, 0xbdc3b5d1, 0x3f77405f, 0x3f6f2389,
           0x3f48879e, 0xbe40d564, 0xbe972509, 0x3dc248a9, 0x3f772a55,
           0x3f3ec80b, 0x3f507df1, 0x3e834caf, 0xbf6bc119, 0x3e80b76d,
           0xbf462752);
  //              -0.58921623,  0.69345474,  0.64817399, -0.00869324,
  //              0.15872470, -0.17028977, -0.99863762, -0.02739566,
  //              -0.08060763,  0.73060948,  0.62843031,  0.68798363,
  //              -0.35207590,  0.01353026,  0.25345275, -0.93635505
  VLOAD_32(v3, 0xbf16d6e0, 0x3f318640, 0x3f25eebb, 0xbc0e6e1c, 0x3e2288ba,
           0xbe2e6071, 0xbf7fa6b7, 0xbce06cdd, 0xbda5159d, 0x3f3b0939,
           0x3f20e0cf, 0x3f301fb2, 0xbeb4434b, 0x3c5dae02, 0x3e81c48f,
           0xbf6fb4f7);
  asm volatile("vfmax.vv v1, v2, v3");
  //              -0.19589283,  0.69345474,  0.64817399,  0.96582597,
  //              0.93413597,  0.78331935, -0.18831402, -0.02739566, 0.09486515,
  //              0.96548969,  0.74523991,  0.81442171,  0.25644442, 0.01353026,
  //              0.25345275, -0.77403748
  VCMP_U32(2, v1, 0xbe489821, 0x3f318640, 0x3f25eebb, 0x3f77405f, 0x3f6f2389,
           0x3f48879e, 0xbe40d564, 0xbce06cdd, 0x3dc248a9, 0x3f772a55,
           0x3f3ec80b, 0x3f507df1, 0x3e834caf, 0x3c5dae02, 0x3e81c48f,
           0xbf462752);
}
#line 10000 "ara85_wrapper.c"
int main(void) {
 enable_vec(); enable_fp();
 unsigned initial_fcsr, initial_vstart;
 asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
 printf("ARA85_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
 ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
 unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
 printf("ARA85_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
 EXIT_CHECK();
}
