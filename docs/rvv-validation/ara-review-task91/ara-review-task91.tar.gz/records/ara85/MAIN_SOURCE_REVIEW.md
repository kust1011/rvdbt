# Main review: outstanding Task85 failures

Reviewed 2026-10-12, while the finite campaign is still running. This is not
acceptance of the final batch or a replacement for its original failure records.

## Widening source overlap

Read the original `upstream/vfwadd.c` TEST_CASE5 and TEST_CASE6 and both extracted
e32 adapters. Both execute `vfwadd.wv v4, v2, v3` (TEST_CASE6 adds `v0.t`) with
SEW32/LMUL1. The wide source is EEW64/EMUL2, covering v2-v3; the narrow source
is EEW32/EMUL1 at v3. Thus v3 supplies two source EEWs in one instruction.
This is source-source overlap, not the permitted high-part destination overlap.

The original B receipt at
`remote-raw/upstream_block_vfwadd_TEST_CASE5_e32_b2/B/stderr` reports
`ILLEGAL_INSN ip=0001009c raw=d2219257`. Read production
`dbt/guest/rv32_vector_lower.h:1465`, especially the final wide-source versus
narrow-source overlap test, and its helper caller in `rv32_interp.cpp:1447`.
This condition explains the refusal. The independent reference PASS alone does
not require rvdbt to execute a reserved encoding.

Current official source checked online:
https://github.com/riscv/riscv-isa-manual/blob/main/src/unpriv/vector-common.adoc
under vector operand constraints. It reserves use of the same vector register
as source operands at different EEWs. This is the current manual source, not a
claim that the clause appears unchanged in the archived 2021 document. Pin the
version in the final adjudication. Related upstream discussion:
https://github.com/riscv-software-src/riscv-isa-sim/issues/2381
(the issue concerns an analogous integer `.wv` source overlap).

Final source pin checked by direct retrieval: ISA manual revision
`6b45f5c61aeaa6055b5422cdeb085f1cd055a8b5`,
`src/unpriv/vector-common.adoc:999-1006`, normative anchor
`norm:vreg_source_eew_rsv`. This is the revision already cited by the thesis.
Task85's separate two reference/eight DUT reproduction receipts report the same
instruction and refusal in all four configurations. Main inspected the
reproduction metadata in addition to the original source/code/raw trace.
Disposition: reserved source-source EEW encoding under this pinned rule;
retain the original failures, with no positive arithmetic-check credit. Do not
change production legality, source operands, or expected values merely to make
this original test pass. No legal-case regression is established by these two
observations.

## Shared floating-point assertion failures

MAIN CORRECTION: after reading the original main bodies, vfdiv.c:347,
vfrdiv.c:173 and vfsqrt.c:136 explicitly set CHANGE_RM(RM_RTZ). Task85 wrappers
omit this and run under RNE. This is an adapter-context defect, not an established
upstream oracle defect. All16 affected blocks (including one PASS) require a
new corrected-context execution. Original raw and source are preserved. Task86
is assigned the repair and all43 source-main audits. Do not accept these16
as valid original-context observations or replace expected literals.

Read original vfdiv TEST_CASE1 and vfsqrt TEST_CASE1, plus failure receipts in
FAILURE_CLASSIFICATION.json. Identical first failures and final flags across
Spike/rvdbt are insufficient to accept the original assertions or establish the
cause. These remain failed original predicates until separately adjudicated;
no tolerance, golden substitution, or new target-check coverage is approved.
The e64 printed mismatch fields also use an RV32 reporting interface, so the
diagnostic line alone must not be treated as the complete 64-bit result.

## Portable delivery

After final campaign review, integrate accepted block-level results without
claiming the FP16-containing original functions passed. Preserve the mask-object
overread limitation inherited from the upstream source. Register complete
source ranges, initialization, assertions and replay commands, not just PASS
summaries. No new correctness-form totals have been approved by this note.
