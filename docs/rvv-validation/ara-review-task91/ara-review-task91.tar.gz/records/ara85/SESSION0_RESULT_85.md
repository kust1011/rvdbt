# Task85: remaining applicable extracted upstream Ara floating-point blocks

Finite queue processed: **263/263 blocks across 40 families: 246 PASS, 17 FAIL, 0 execution-blocked; exact pending list is empty.** 263 independent same-ELF Spike calls and 1052 clean961 calls in B/M1/M2/Both. Failed original assertions are preserved; this is extracted upstream block execution, not original whole-function/file PASS or complete conformance.

Original Ara revision `34bd3bc152421b4601a7bf3d6e8e91ffb545c99e`. Branch `delivery/rvv-validation-20261012`, HEAD `69ce3f8683945ede6697353dca15248564b55348`; same clean961 executable/library as ara84. No ara84 block was rerun. No canonical count/binding edit, production/thesis edit, commit/push/reset, other-session action, host-setting change or P4-04 retry. Task82/83/84 and original raw are preserved. Launcher owns `rvv-ara-20261012-85`; worker does not emit it.

[PROGRESS.json](PROGRESS.json) records each family and exact pending list. [SCOPE.json](SCOPE.json) and [EXCLUDED_BLOCKS.json](EXCLUDED_BLOCKS.json) retain 182 excluded unsupported blocks; [ORIGINAL_WHOLE_FUNCTION_BLOCKERS.json](ORIGINAL_WHOLE_FUNCTION_BLOCKERS.json) keeps all 166 selected FP16-containing functions blocked for whole-function execution. Existing accepted conversion results reference different functions, documented in [ACCEPTED_BINDINGS_CHECK.json](ACCEPTED_BINDINGS_CHECK.json).

The statement lexer blanks comments, skips quoted literals, balances parentheses/brackets/braces, and accepts only top-level semicolon statements. It rejects control flow rather than crossing it. Every candidate has exactly one original target and one original vector assertion; compare blocks retain both the FP32/64 target VSET and the original e16/VL1 packed-mask checker VSET. That checker configuration uses integer bits, not FP16 arithmetic. Widening/narrowing blocks have supported operand/result types (including original vector integer32/64 interfaces); FP16 operands/results and RV64 GPR/index semantics remain excluded. No reduction is detached from predecessor buffer context.

[BLOCK_MAP.json](BLOCK_MAP.json), [PRESERVATION.json](PRESERVATION.json) and provenance diffs bind exact contiguous original block bytes, inputs, expected literals, instructions and assertions. Initial shape audits in [CONTEXT_AUDIT.json](CONTEXT_AUDIT.json) completed before execution, with the later VL metadata follow-up separately recorded: local loads/boxing, FMA old destination, mask and cleared destination, supported widths, rounding and flags. Twelve adapters additionally retain byte-identical explicit flag clear/initial assertion segments from required original context. [FLAG_CONTEXT_REFINEMENT.json](FLAG_CONTEXT_REFINEMENT.json) explains them; pre-context build artifacts were never executed and remain diagnostic. No guessed state, generated golden, renamed unsupported opcode, altered arithmetic, forced path or padded input.

[SLIDE_SETUP_CONTEXT.json](SLIDE_SETUP_CONTEXT.json) explains preserved slide-down AVL32 setup: at FP64/VLEN1024 it yields VL16; the original second load reloads all16 consumed source lanes and the last result uses the scalar. Extra initial tail literals are preserved but unobserved. The inherited actual_vl metadata correction and its initial audit failures are retained; no ELF/source/raw was changed. [COMPILED_AUDIT.json](COMPILED_AUDIT.json) confirms original target assembly, configurations, scalar FLEN64/fld, copied flag setup and allocated stack bounds. Original two-byte mask objects are still loaded by VL16 vle8: only their first two bytes define the checked mask bits, while the inherited extra-byte read stays within the observed allocated compiled frame. **This does not erase the source-level mask-object overread limitation or establish all-source-defined memory safety.** Original ma inactive-lane assertions retain their stricter cleared-value expectations; observed PASS is not a guarantee that every compliant implementation must preserve those values. Tail state is unchecked.

[AUDIT.json](AUDIT.json) and [AUDITED_RESULTS.json](AUDITED_RESULTS.json) independently recheck the original checker and exact configurations, initial fcsr/vstart, necessary final flags/rounding, same-ELF identity and before/after DUT/reference pins. Existing runner, checker and typed/FP headers remain byte-identical to ara84. Final fcsr comparison is an additional reference observation; it replaces no original assertion. [METHOD_ADMISSION.json](METHOD_ADMISSION.json) retains aggregate counters: target-specific M1/M2 admission remains UNOBSERVED without PC/form attribution. Configured-arm PASS does not prove optimized target execution.

Original typed comparison attempts: 12908 DUT and 3259 Spike elements; full expected capacity is 13832 DUT and 3458 Spike elements. Early assertion failures do not count as completed comparisons. Raw stdout, stderr, command, environment, observations, case results, exit and identities are under raw/ and remote-raw/. [LAUNCH_COMMANDS.json](LAUNCH_COMMANDS.json), [REMOTE_LAUNCH_COMMANDS.json](REMOTE_LAUNCH_COMMANDS.json) and [INFRASTRUCTURE_ATTEMPTS.json](INFRASTRUCTURE_ATTEMPTS.json) keep launcher/transfer errors separate from DUT mismatches. One DUT process at a time; existing immutable stage; private fs/cache; no other-user disruption.

Failures requiring main review:

- `upstream_block_vfdiv_TEST_CASE1_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 0 FAILED. Got bf8b2ed6, expected bf8b2ed5..
- `upstream_block_vfdiv_TEST_CASE1_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 1 FAILED. Got e464e0cb, expected bfe9a9df..
- `upstream_block_vfdiv_TEST_CASE2_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 3 FAILED. Got bedaa463, expected bedaa462..
- `upstream_block_vfdiv_TEST_CASE2_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 1 FAILED. Got e464e0cb, expected bfe9a9df..
- `upstream_block_vfdiv_TEST_CASE3_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 2 FAILED. Got bf0f3256, expected bf0f3255..
- `upstream_block_vfdiv_TEST_CASE3_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 0 FAILED. Got 99ce434c, expected c05d864f..
- `upstream_block_vfdiv_TEST_CASE4_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 3 FAILED. Got bf8fc577, expected bf8fc576..
- `upstream_block_vfdiv_TEST_CASE4_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 1 FAILED. Got eef36847, expected c0506e79..
- `upstream_block_vfrdiv_TEST_CASE1_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 1 FAILED. Got 3f7b51b0, expected 3f7b51af..
- `upstream_block_vfrdiv_TEST_CASE1_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 0 FAILED. Got c2e67960, expected 3fc02f42..
- `upstream_block_vfrdiv_TEST_CASE2_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 1 FAILED. Got 3f7b51b0, expected 3f7b51af..
- `upstream_block_vfrdiv_TEST_CASE2_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 1 FAILED. Got 2af3122c, expected bf986bb4..
- `upstream_block_vfsqrt_TEST_CASE1_e32_b2`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 6 FAILED. Got 430a5561, expected 430a5560..
- `upstream_block_vfsqrt_TEST_CASE1_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 3 FAILED. Got 64b8218a, expected 40a83a4b..
- `upstream_block_vfsqrt_TEST_CASE2_e64_b3`: SHARED_ORIGINAL_ASSERTION_FAILURE_IDENTICAL_OBSERVATION; Index 3 FAILED. Got 64b8218a, expected 40a83a4b..
- `upstream_block_vfwadd_TEST_CASE5_e32_b2`: DUT_ONLY_OR_DIFFERENT_FAILURE_REQUIRES_REPRODUCTION; see raw state/assertions.
- `upstream_block_vfwadd_TEST_CASE6_e32_b2`: DUT_ONLY_OR_DIFFERENT_FAILURE_REQUIRES_REPRODUCTION; see raw state/assertions.

The two vfwadd.wv discrepancies are reproduced separately in [REPRODUCTION_RESULTS.json](REPRODUCTION_RESULTS.json): two additional independent same-ELF Spike runs and eight additional DUT runs. [DUT_DIVERGENCE_REVIEW.json](DUT_DIVERGENCE_REVIEW.json) identifies overlapping wide-vs2 v2/v3 and narrow-vs1 v3 source groups. The existing clean961 legality rule rejects this source-EEW overlap; Spike accepts it. Architectural legality/reference-version adjudication is pending main review. TEST_CASE5 reproduces `ILLEGAL_INSN ip=0001009c raw=d2219257`; TEST_CASE6 reproduces `ILLEGAL_INSN ip=000100fc raw=d0219257`. These are retained FAIL, not a proven production bug or a proposed fix. vfwadd remains FAIL pending that review; execution/reproduction pending lists are empty.

[FAILURES.json](FAILURES.json), [FAILURE_CLASSIFICATION.json](FAILURE_CLASSIFICATION.json) and [REPRODUCTION_QUEUE.json](REPRODUCTION_QUEUE.json) preserve all failures. Shared reference/DUT failures do not establish a DUT bug and remain FAIL. Any DUT-only/different failures require unchanged same-ELF reproduction and main/general-fix review before the family can be treated as passing; no production edit is proposed here.

| Family | Planned | PASS | FAIL | BLOCKED |
| --- | ---: | ---: | ---: | ---: |
| vfclass | 4 | 4 | 0 | 0 |
| vfcvt | 24 | 24 | 0 | 0 |
| vfdiv | 8 | 0 | 8 | 0 |
| vfmacc | 8 | 8 | 0 | 0 |
| vfmadd | 8 | 8 | 0 | 0 |
| vfmax | 8 | 8 | 0 | 0 |
| vfmerge | 2 | 2 | 0 | 0 |
| vfmin | 8 | 8 | 0 | 0 |
| vfmsac | 8 | 8 | 0 | 0 |
| vfmsub | 8 | 8 | 0 | 0 |
| vfmv | 2 | 2 | 0 | 0 |
| vfncvt | 8 | 8 | 0 | 0 |
| vfnmacc | 4 | 4 | 0 | 0 |
| vfnmadd | 4 | 4 | 0 | 0 |
| vfnmsac | 4 | 4 | 0 | 0 |
| vfnmsub | 4 | 4 | 0 | 0 |
| vfrdiv | 4 | 0 | 4 | 0 |
| vfrec7 | 6 | 6 | 0 | 0 |
| vfrsqrt7 | 3 | 3 | 0 | 0 |
| vfrsub | 4 | 4 | 0 | 0 |
| vfsgnj | 10 | 10 | 0 | 0 |
| vfsgnjn | 8 | 8 | 0 | 0 |
| vfsgnjx | 8 | 8 | 0 | 0 |
| vfslide1down | 4 | 4 | 0 | 0 |
| vfslide1up | 4 | 4 | 0 | 0 |
| vfsqrt | 4 | 1 | 3 | 0 |
| vfwadd | 8 | 6 | 2 | 0 |
| vfwcvt | 10 | 10 | 0 | 0 |
| vfwmacc | 4 | 4 | 0 | 0 |
| vfwmsac | 4 | 4 | 0 | 0 |
| vfwmul | 4 | 4 | 0 | 0 |
| vfwnmacc | 4 | 4 | 0 | 0 |
| vfwnmsac | 4 | 4 | 0 | 0 |
| vfwsub | 8 | 8 | 0 | 0 |
| vmfeq | 13 | 13 | 0 | 0 |
| vmfge | 4 | 4 | 0 | 0 |
| vmfgt | 4 | 4 | 0 | 0 |
| vmfle | 8 | 8 | 0 | 0 |
| vmflt | 8 | 8 | 0 | 0 |
| vmfne | 13 | 13 | 0 | 0 |

Replay into a fresh isolated root (runner refuses existing raw directories):

```sh
python3 ara85/prepare.py
python3 ara85/context_audit.py
python3 ara85/retain_flag_context.py
python3 ara85/build.py
python3 ara85/configure.py
python3 ara85/compiled_audit.py
python3 ara85/preservation.py
# Deploy runner/bin/metadata to a fresh isolated xbd root and adjust launcher path.
python3 ara85/run_eligible.py
python3 ara85/classify_failures.py
python3 ara85/reproduce.py  # isolated unchanged-ELF DUT-only reproduction queue
python3 ara85/finish.py
```

Actual absolute commands/toolchain/reference/runtime hashes are retained. Spike uses rv32gcv_zvl1024b; DUT VLEN1024; both preserve all16 original target lanes, including64-bit widened values in the allocated physical register. Spike minimum-vector-length ISA configuration is not a claim of equal implementation maximum VLEN. Canonical source/binding authority hashes remain unchanged.
