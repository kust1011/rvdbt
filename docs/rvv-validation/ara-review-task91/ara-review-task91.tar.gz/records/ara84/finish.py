import json,hashlib,csv,subprocess,collections
from pathlib import Path
R=Path(__file__).resolve().parent;j=lambda p:json.loads(p.read_text());a=j(R/'AUDIT.json');bs=j(R/'BLOCK_MAP.json');ms=j(R/'METHOD_ADMISSION.json');rows=j(R/'EXECUTION_RESULTS.json')
assert a['all_150_receipts_present']and a['failures']==0
# Complete launch receipt inventory includes the successful two pilot runs (not repeated).
commands=j(R/'LAUNCH_COMMANDS.json')
for arm in ['reference','B']:
 name='upstream_block_vfadd_TEST_CASE1_e32';root=R/('raw'if arm=='reference'else'remote-raw')/name/arm
 commands.insert(0,dict(command=['python3',str(R/'runner.py'),name,arm]if arm=='reference'else['ssh','xbd','python3 /home/vick/ara84/runner.py '+name+' '+arm],returncode=0,stdout=name+' '+arm+' PASS\n',stderr='',elapsed=None,pilot=True,expanded_command=str(root/'command.json')))
(R/'ALL_LAUNCH_RECEIPTS.json').write_text(json.dumps(commands,indent=2)+'\n');assert len(commands)==150
with (R/'RESULT_MANIFEST.csv').open('w')as f:
 keys=['block','arm','status','scope','source_file','source_lines','original_function','adapter','elf_sha256','returncode','configuration_exact','initial_fcsr','initial_vstart','final_fcsr','original_fflags_expected','raw_stdout','raw_stderr','result_evidence'];w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
# Preserve workspace identity and prove no tracked review change.
p=subprocess.run(['git','status','--short','--branch'],capture_output=True,text=True);(R/'REVIEW_GIT_STATUS.txt').write_text(p.stdout)
p=subprocess.run(['git','diff','--stat'],capture_output=True,text=True);(R/'REVIEW_TRACKED_DIFF.txt').write_text(p.stdout);assert not p.stdout
q=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True);assert q.stdout.strip()=='69ce3f8683945ede6697353dca15248564b55348'
text='''# Task84: extracted upstream Ara FP32/FP64 blocks

Completed all **30 eligible extracted upstream blocks** from `vfadd.c` (14), `vfsub.c` (8), and `vfmul.c` (8). Each has its own one-target ELF: **30 independent same-ELF Spike runs and 120 clean961 DUT runs across B/M1/M2/Both, all PASS, exit0, no timeout**. This is extracted-block completion, **not original whole-function/file PASS or full conformance**. No DUT mismatch occurred; no production correction is proposed.

Review branch `delivery/rvv-validation-20261012`, HEAD `69ce3f8683945ede6697353dca15248564b55348`. Original Ara revision `34bd3bc152421b4601a7bf3d6e8e91ffb545c99e`. All 16 original mixed/FP16 function obligations remain under their original records. `vfadd.TEST_CASE5` has only two active FP16 rounding blocks (RTZ then RNE), so it supplies no FP32/FP64 block. There are no rejected FP32/FP64 candidates. Original source files and blockers are retained in [upstream](upstream) and [ORIGINAL_WHOLE_FUNCTION_BLOCKERS.json](ORIGINAL_WHOLE_FUNCTION_BLOCKERS.json).

The current accepted binding table had **zero records for these exact three pinned files**, checked before extraction; [ACCEPTED_BINDINGS_CHECK.json](ACCEPTED_BINDINGS_CHECK.json) retains authority hashes and all 16 original manifest records. No identical accepted block was rerun. Canonical source/binding/manifest hashes and all Task83 evidence hashes are unchanged. No global counts, Task83 records, thesis text, production, commit/push, quota, other sessions or P4-04 were changed. Launcher owns completion signal `rvv-ara-20261012-84`; worker does not send it.

## Preservation and context audit

[BLOCK_MAP.json](BLOCK_MAP.json) maps exact original source line ranges and SHA256s to adapters; every extracted contiguous block is byte-identical. Instructions, inputs, expected literals, assertion macro calls and original flag clear/check setup are preserved, including the decimal literal `8000000000000001` in the vfadd FP64 exception block. No goldens were computed and no scalar was truncated. Original source-line identities are retained with `#line`; wrappers add case spans and read-only initial/final fcsr observations. No added frm/fflags initialization writes occur.

The original typed vector checker, floating macros, runner and checker are byte-identical Task52 copies. This uses the established Linux-user environment adapter, including its existing RV32 CSR interfaces, without historical macro recovery. CHECK_FFLAGS retains its original compare, mismatch increment and return; silent success is supported by completed equality, zero `num_failed`, no FAILED output, and observed final fflags equal to the original last flag predicate. Four exception blocks retain eight original flag checks per arm. No new assertion values replace original checks.

All receipts show VL16, LMUL1, vtype208 for e32 or216 for e64 (`ta,ma`), initial frm=RNE/fflags0 and vstart0. Separate ELF startup supplies the observed RNE inherited by ordinary blocks. Earlier original vfadd TEST_CASE5 restores RNE; there is no remaining rounding predecessor dependency. All consumed vector inputs are loaded locally, vf scalar values are locally declared/boxed, masked blocks clear the old destination locally, and unmasked blocks overwrite all16 checked active lanes. Original fflags clears immediately preceding VSET are included wherever flag checks consume state. In ordinary blocks prior sticky flags are not consumed by the original value oracle; their final fcsr is additionally identical across Spike and DUT.

The vf blocks use original `double`, BOX_FLOAT_IN_DOUBLE/BOX_DOUBLE_IN_DOUBLE and `f` constraints under RV32 ilp32d with FLEN64. Disassembly retains `fld`; full FP64 scalar bits and FP32 NaN boxing are preserved. This interface is valid on RV32 with D, unlike a uint64 GPR scalar truncation.

Fourteen masked blocks retain the original two-byte mask object and VL16 `vle8.v`: all16 bytes read are within the allocated compiled stack frame; the first two bytes are original `0xAA,0xAA` and define mask bits0–15. The14 extra loaded bytes cannot affect the16 checked lanes; masks are not widened or padded. [COMPILED_AUDIT.json](COMPILED_AUDIT.json) retains every frame bound, load address and emitted instruction. The upstream `ma` setting permits agnostic inactive values; its checker nevertheless expects the cleared zero inactive lanes. The observed executions satisfy that original stricter predicate; this does not establish that every compliant implementation must preserve zero under `ma`. Tail state is outside the checker scope.

## Results and methods

[RESULT_MANIFEST.csv](RESULT_MANIFEST.csv) and [EXECUTION_RESULTS.json](EXECUTION_RESULTS.json) retain all150 block/arm receipts and source mappings. [AUDIT.json](AUDIT.json) checks configuration, initial state, flag predicates, final state against reference, identities, hashes and completeness. DUT comparison total is1920 elements; reference total480, with16 original typed element comparisons per block per arm. [FAILURES.json](FAILURES.json) is empty. Each one-target adapter/ELF already forms a minimal reproduction if future review finds a problem.

Configured method flags are in [CONFIGS.json](CONFIGS.json). Actual aggregate formation/direct/route evidence is separate in [METHOD_ADMISSION.json](METHOD_ADMISSION.json). M1/Both aggregate `(runs_formed,multi_member_runs,members_admitted)` distribution: '''+json.dumps(a['m1_both_aggregate_formation_distributions'])+'''. Formation counters count translation, not dynamic target execution. No multi-member runs were formed. Target-specific M1 and M2 admission is **UNOBSERVED**: global inline_hits includes VSET/load/store/clear, and single-member formation lacks a PC/form receipt. PASS means the configured semantic execution completed, not proof that each target ran an optimized lowering. No extra admission probe or forced path was run.

Reference and each DUT arm use the identical SHA256-pinned ELF. DUT commands use VLEN1024; Spike uses `--isa=rv32gcv_zvl1024b`. This is a Spike minimum-vector-length ISA setting, not a claim of equal implementation maximum VLEN. Both observed configurations retain all16 active lanes. Clean961 elfrun SHA256 `6fda0f9ab06c2c824b5301d1f302b76799842981b00a88fffa85fe43f1dbd84f`; library `1773ca2bf867b0d3bdd76f1b60b168cbeda6d620a71ebd0ae9653d6da6feea6d`. Compiler/runtime and independent Spike/pk/library pins are in [COMPILER_RUNTIME_IDENTITY.json](COMPILER_RUNTIME_IDENTITY.json), [REFERENCE_IDENTITY.json](REFERENCE_IDENTITY.json) and raw IDENTITY/IDENTITY_AFTER records.

Every raw run retains stdout/stderr, expanded command, environment, exit/result, typed checker case spans, state observations and identities before/after. Reference raw is under `raw/`; DUT copies under `remote-raw/`, matching isolated `/home/vick/ara84/raw` on xbd. One DUT at a time, private fs/cache, immutable existing clean961 stage; no DUT process found before/after. [ALL_LAUNCH_RECEIPTS.json](ALL_LAUNCH_RECEIPTS.json) includes150 successful launches without repeating the two pilot runs. [INFRASTRUCTURE_ATTEMPTS.json](INFRASTRUCTURE_ATTEMPTS.json) retains a corrected audit regex error and one missing-bin launcher failure before DUT loading; neither was a DUT mismatch. Nothing was discarded or relabeled as a DUT PASS.

## Exact extracted ranges

Each table row represents two separately built/running blocks. All five arms PASS for each block. Adapter names are `upstream_block_<file>_<function>_e<SEW>.c`; hashes and exact mappings are in BLOCK_MAP/GROUPS.

| File | Original function | FP32 original lines | FP64 original lines | Form / mask |
| --- | --- | --- | --- | --- |
'''
by=collections.defaultdict(dict)
for b in bs:by[(Path(b['source_file']).name,b['original_function'])][b['vset']['sew']]=b
for (file,fn),pair in by.items():
 b=pair[32];text+='| '+file+' | '+fn+' | '+'–'.join(map(str,pair[32]['source_lines']))+' | '+'–'.join(map(str,pair[64]['source_lines']))+' | '+b['target']['form']+' / '+b['target']['mask']+' |\n'
text+='''
## Reproduction

```sh
python3 artifacts/rvv_validation_delivery_20261009/ara84/prepare.py
python3 artifacts/rvv_validation_delivery_20261009/ara84/build.py
python3 artifacts/rvv_validation_delivery_20261009/ara84/configure.py
python3 artifacts/rvv_validation_delivery_20261009/ara84/compiled_audit.py
python3 artifacts/rvv_validation_delivery_20261009/ara84/runner.py upstream_block_vfadd_TEST_CASE1_e32 reference
ssh xbd 'python3 /home/vick/ara84/runner.py upstream_block_vfadd_TEST_CASE1_e32 B'
python3 artifacts/rvv_validation_delivery_20261009/ara84/run_eligible.py
python3 artifacts/rvv_validation_delivery_20261009/ara84/audit.py
```

Paths above are relative to the existing artifact host directory. Actual expanded absolute build/run commands are retained. Replays must use a fresh isolated root: runner refuses existing result directories. Review extracted-block preservation and the150 raw receipts before any new binding; original FP16 blockers and Task83 review remain independent. Completed eligible external blocks are the Task84 outcome.
'''
(R/'SESSION0_RESULT_84.md').write_text(text)
(R/'EVIDENCE_SHA256.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(R.rglob('*'))if p.is_file()and p.name!='EVIDENCE_SHA256.json'and '__pycache__'not in p.parts},indent=2)+'\n')
print('Task84 report and evidence manifest complete')
