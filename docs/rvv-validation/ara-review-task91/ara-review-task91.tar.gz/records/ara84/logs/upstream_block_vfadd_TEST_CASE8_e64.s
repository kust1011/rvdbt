	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"upstream_block_vfadd_TEST_CASE8_e64.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfadd_TEST_CASE8_e64.c" md5 0xc0674787e20d6e9cc9758bff3091fbad
	.file	1 "vfadd.c"
	.file	2 "ara84_wrapper.c"
	.file	3 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	4 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/dataset.h" md5 0x6e87c523f491ba527fcaa8da037d753f
	.file	5 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/vector_macros.h" md5 0xf0792279c410650ddf6b368633799e9a
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE8                      # -- Begin function TEST_CASE8
	.p2align	2
	.type	TEST_CASE8,@function
TEST_CASE8:                             # @TEST_CASE8
.Lfunc_begin0:
	.file	6 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfadd_TEST_CASE8_e64.c" md5 0xc0674787e20d6e9cc9758bff3091fbad
	.loc	6 4 0                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfadd_TEST_CASE8_e64.c:4:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -480
	.cfi_def_cfa_offset 480
	sw	ra, 476(sp)                     # 4-byte Folded Spill
	sw	s0, 472(sp)                     # 4-byte Folded Spill
	sw	s1, 468(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 480
	.cfi_def_cfa s0, 0
	li	a0, 0
.Ltmp0:
	.loc	1 434 3 prologue_end            # vfadd.c:434:3
	#APP
	fsflags a0
	#NO_APP
	.loc	1 435 3                         # vfadd.c:435:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # vfadd.c:0:3
	li	a0, 16
.Ltmp1:
	.loc	1 435 3                         # vfadd.c:435:3
	#APP
	vsetvli t0, a0,e64,m1, ta, ma 

	#NO_APP
	li	a0, 435
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 436 3 is_stmt 1               # vfadd.c:436:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 436 3 is_stmt 0               # vfadd.c:436:3
	sw	zero, -20(s0)
	sw	zero, -24(s0)
	#APP
	frflags a0
	#NO_APP
	sw	a0, -36(s0)
	lw	a0, -36(s0)
	sw	zero, -28(s0)
	sw	a0, -32(s0)
.Ltmp4:
	.loc	1 436 3                         # vfadd.c:436:3
	lw	a0, -32(s0)
	lw	a1, -28(s0)
	lw	a2, -24(s0)
	lw	a3, -20(s0)
	xor	a1, a1, a3
	xor	a0, a0, a2
	or	a0, a0, a1
	beqz	a0, .LBB0_5
	j	.LBB0_4
.LBB0_4:
.Ltmp5:
	.loc	1 436 3                         # vfadd.c:436:3
	lw	a3, -28(s0)
	lw	a2, -32(s0)
	lw	a5, -20(s0)
	lw	a4, -24(s0)
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	call	printf_
	lui	a0, %hi(num_failed)
	lw	a1, %lo(num_failed)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(num_failed)(a0)
	j	.LBB0_26
.Ltmp6:
.LBB0_5:
	.loc	1 436 3                         # vfadd.c:436:3
	j	.LBB0_6
.Ltmp7:
.LBB0_6:
	.loc	1 437 3 is_stmt 1               # vfadd.c:437:3
	j	.LBB0_7
.LBB0_7:
.Ltmp8:
	.loc	1 437 3 is_stmt 0               # vfadd.c:437:3
	lui	a1, %hi(.L__const.TEST_CASE8.Vv2)
	addi	a1, a1, %lo(.L__const.TEST_CASE8.Vv2)
	addi	s1, s0, -168
	addi	a0, s0, -168
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v2, (s1)  

	#NO_APP
	j	.LBB0_8
.Ltmp9:
.LBB0_8:
	.loc	1 439 3 is_stmt 1               # vfadd.c:439:3
	j	.LBB0_9
.LBB0_9:
.Ltmp10:
	.loc	1 439 3 is_stmt 0               # vfadd.c:439:3
	lui	a1, %hi(.L__const.TEST_CASE8.Vv3)
	addi	a1, a1, %lo(.L__const.TEST_CASE8.Vv3)
	addi	s1, s0, -296
	addi	a0, s0, -296
	li	a2, 128
	call	memcpy
	#APP
	vle64.v v3, (s1)  

	#NO_APP
	j	.LBB0_10
.Ltmp11:
.LBB0_10:
	.loc	1 441 3 is_stmt 1               # vfadd.c:441:3
	j	.LBB0_11
.LBB0_11:
.Ltmp12:
	.loc	1 441 3 is_stmt 0               # vfadd.c:441:3
	lui	a0, %hi(.L__const.TEST_CASE8.Vv0)
	lbu	a1, %lo(.L__const.TEST_CASE8.Vv0)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE8.Vv0)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -298(s0)
	addi	a0, s0, -298
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB0_12
.Ltmp13:
.LBB0_12:
	.loc	1 442 3 is_stmt 1               # vfadd.c:442:3
	j	.LBB0_13
.LBB0_13:
.Ltmp14:
	.loc	1 442 3 is_stmt 0               # vfadd.c:442:3
	#APP
	csrr a0, vtype
	#NO_APP
	sw	a0, -304(s0)
	#APP
	csrr a0, vl
	#NO_APP
	sw	a0, -308(s0)
	lw	a0, -304(s0)
	#APP
	vsetvl a0, zero, a0
	#NO_APP
	sw	a0, -312(s0)
	#APP
	vmv.v.i v1, 0
	#NO_APP
	lw	a0, -308(s0)
	lw	a1, -304(s0)
	#APP
	vsetvl zero, a0, a1
	#NO_APP
	j	.LBB0_14
.Ltmp15:
.LBB0_14:
	.loc	1 443 3 is_stmt 1               # vfadd.c:443:3
	#APP
	vfadd.vv v1, v2, v3, v0.t
	#NO_APP
.Ltmp16:
	.loc	1 444 3                         # vfadd.c:444:3
	j	.LBB0_15
.LBB0_15:
.Ltmp17:
	.loc	1 444 3 is_stmt 0               # vfadd.c:444:3
	lui	a0, %hi(Ru64)
	addi	a0, a0, %lo(Ru64)
	sw	a0, -316(s0)
	lw	a0, -316(s0)
	#APP
	vse64.v v1, (a0)

	#NO_APP
	sw	a0, -316(s0)
	j	.LBB0_16
.Ltmp18:
.LBB0_16:
	.loc	1 444 3                         # vfadd.c:444:3
	addi	a0, s0, -448
	li	a1, 0
	li	a2, 128
	call	memset
	li	a0, 23
	li	a1, 16
	li	a2, 8
	call	ara_assert_begin
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	li	a1, 23
	call	printf_
.Ltmp19:
	.loc	1 444 3                         # vfadd.c:444:3
	sw	zero, -452(s0)
	j	.LBB0_17
.LBB0_17:                               # =>This Inner Loop Header: Depth=1
.Ltmp20:
	.loc	1 444 3                         # vfadd.c:444:3
	lw	a0, -452(s0)
	li	a1, 15
.Ltmp21:
	.loc	1 444 3                         # vfadd.c:444:3
	bltu	a1, a0, .LBB0_22
	j	.LBB0_18
.LBB0_18:                               #   in Loop: Header=BB0_17 Depth=1
.Ltmp22:
	.loc	1 444 3                         # vfadd.c:444:3
	lw	a1, -452(s0)
	li	a0, 23
	call	ara_compare_step
.Ltmp23:
	.loc	1 444 3                         # vfadd.c:444:3
	lw	a0, -452(s0)
	slli	a0, a0, 3
	lui	a1, %hi(Ru64)
	addi	a1, a1, %lo(Ru64)
	add	a0, a1, a0
	lw	a1, 0(a0)
	lw	a0, 4(a0)
	lw	a2, -452(s0)
	slli	a2, a2, 3
	addi	a3, s0, -448
	add	a2, a3, a2
	lw	a3, 0(a2)
	lw	a2, 4(a2)
	xor	a0, a0, a2
	xor	a1, a1, a3
	or	a0, a1, a0
	beqz	a0, .LBB0_20
	j	.LBB0_19
.LBB0_19:
.Ltmp24:
	.loc	1 444 3                         # vfadd.c:444:3
	lw	a1, -452(s0)
	slli	a0, a1, 3
	lui	a2, %hi(Ru64)
	addi	a2, a2, %lo(Ru64)
	add	a0, a2, a0
	lw	a3, 4(a0)
	lw	a2, 0(a0)
	lw	a0, -452(s0)
	slli	a0, a0, 3
	addi	a4, s0, -448
	add	a0, a4, a0
	lw	a5, 4(a0)
	lw	a4, 0(a0)
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	lui	a0, %hi(num_failed)
	lw	a1, %lo(num_failed)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(num_failed)(a0)
	j	.LBB0_26
.Ltmp25:
.LBB0_20:                               #   in Loop: Header=BB0_17 Depth=1
	.loc	1 444 3                         # vfadd.c:444:3
	j	.LBB0_21
.Ltmp26:
.LBB0_21:                               #   in Loop: Header=BB0_17 Depth=1
	.loc	1 444 3                         # vfadd.c:444:3
	lw	a0, -452(s0)
	addi	a0, a0, 1
	sw	a0, -452(s0)
	j	.LBB0_17
.Ltmp27:
.LBB0_22:
	.loc	1 444 3                         # vfadd.c:444:3
	lui	a0, %hi(.L.str.3)
	addi	a0, a0, %lo(.L.str.3)
	call	printf_
	li	a0, 23
	call	ara_assert_end
.Ltmp28:
	.loc	1 445 3 is_stmt 1               # vfadd.c:445:3
	j	.LBB0_23
.LBB0_23:
.Ltmp29:
	.loc	1 445 3 is_stmt 0               # vfadd.c:445:3
	sw	zero, -460(s0)
	sw	zero, -464(s0)
	#APP
	frflags a0
	#NO_APP
	sw	a0, -476(s0)
	lw	a0, -476(s0)
	sw	zero, -468(s0)
	sw	a0, -472(s0)
.Ltmp30:
	.loc	1 445 3                         # vfadd.c:445:3
	lw	a0, -472(s0)
	lw	a1, -468(s0)
	lw	a2, -464(s0)
	lw	a3, -460(s0)
	xor	a1, a1, a3
	xor	a0, a0, a2
	or	a0, a0, a1
	beqz	a0, .LBB0_25
	j	.LBB0_24
.LBB0_24:
.Ltmp31:
	.loc	1 445 3                         # vfadd.c:445:3
	lw	a3, -468(s0)
	lw	a2, -472(s0)
	lw	a5, -460(s0)
	lw	a4, -464(s0)
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	call	printf_
	lui	a0, %hi(num_failed)
	lw	a1, %lo(num_failed)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(num_failed)(a0)
	j	.LBB0_26
.Ltmp32:
.LBB0_25:
	.loc	1 445 3                         # vfadd.c:445:3
	j	.LBB0_26
.Ltmp33:
.LBB0_26:
	.cfi_def_cfa sp, 480
	.loc	1 446 1 epilogue_begin is_stmt 1 # vfadd.c:446:1
	lw	ra, 476(sp)                     # 4-byte Folded Reload
	lw	s0, 472(sp)                     # 4-byte Folded Reload
	lw	s1, 468(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 480
	.cfi_def_cfa_offset 0
	ret
.Ltmp34:
.Lfunc_end0:
	.size	TEST_CASE8, .Lfunc_end0-TEST_CASE8
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin1:
	.loc	2 10000 0                       # ara84_wrapper.c:10000:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp35:
	.loc	2 10004 3 prologue_end          # ara84_wrapper.c:10004:3
	#APP
	frcsr a0; csrr a1, vstart
	#NO_APP
	sw	a0, -24(s0)
	sw	a1, -28(s0)
	.loc	2 10005 46                      # ara84_wrapper.c:10005:46
	lw	a1, -24(s0)
	.loc	2 10005 59 is_stmt 0            # ara84_wrapper.c:10005:59
	lw	a2, -28(s0)
	.loc	2 10005 3                       # ara84_wrapper.c:10005:3
	lui	a0, %hi(.L.str.4)
	addi	a0, a0, %lo(.L.str.4)
	call	printf_
	.loc	2 10006 3 is_stmt 1             # ara84_wrapper.c:10006:3
	lui	s1, %hi(.L.str.5)
	addi	s1, s1, %lo(.L.str.5)
	mv	a0, s1
	call	ara_case_begin
	.loc	2 10007 3                       # ara84_wrapper.c:10007:3
	call	TEST_CASE8
	.loc	2 10008 29                      # ara84_wrapper.c:10008:29
	lui	s2, %hi(num_failed)
	lw	a1, %lo(num_failed)(s2)
	.loc	2 10008 3 is_stmt 0             # ara84_wrapper.c:10008:3
	mv	a0, s1
	call	ara_case_end
	.loc	2 10009 24 is_stmt 1            # ara84_wrapper.c:10009:24
	#APP
	frcsr a0
	#NO_APP
	sw	a0, -32(s0)
	.loc	2 10010 46                      # ara84_wrapper.c:10010:46
	lw	a1, -32(s0)
	.loc	2 10010 57 is_stmt 0            # ara84_wrapper.c:10010:57
	lw	a2, %lo(num_failed)(s2)
	.loc	2 10010 3                       # ara84_wrapper.c:10010:3
	lui	a0, %hi(.L.str.6)
	addi	a0, a0, %lo(.L.str.6)
	call	printf_
	.loc	2 10011 3 is_stmt 1             # ara84_wrapper.c:10011:3
	j	.LBB1_1
.LBB1_1:
.Ltmp36:
	.loc	2 10011 3 is_stmt 0             # ara84_wrapper.c:10011:3
	lui	a0, %hi(num_failed)
	lw	a0, %lo(num_failed)(a0)
	blez	a0, .LBB1_3
	j	.LBB1_2
.LBB1_2:
.Ltmp37:
	.loc	2 10011 3                       # ara84_wrapper.c:10011:3
	lui	s1, %hi(num_failed)
	lw	a2, %lo(num_failed)(s1)
	lui	a0, %hi(.L.str.7)
	addi	a0, a0, %lo(.L.str.7)
	lui	a1, %hi(.L.str.8)
	addi	a1, a1, %lo(.L.str.8)
	call	printf_
	lw	a0, %lo(num_failed)(s1)
	sw	a0, -20(s0)
	j	.LBB1_4
.Ltmp38:
.LBB1_3:
	.loc	2 10011 3                       # ara84_wrapper.c:10011:3
	lui	a0, %hi(.L.str.9)
	addi	a0, a0, %lo(.L.str.9)
	lui	a1, %hi(.L.str.8)
	addi	a1, a1, %lo(.L.str.8)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB1_4
.Ltmp39:
.LBB1_4:
	.loc	2 10012 1 is_stmt 1             # ara84_wrapper.c:10012:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	2 10012 1 epilogue_begin is_stmt 0 # ara84_wrapper.c:10012:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp40:
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"fflags check FAILED. Current fflags is 0x%02lx, while expecting 0x%02lx.\n"
	.size	.L.str, 74

	.type	num_failed,@object              # @num_failed
	.bss
	.globl	num_failed
	.p2align	2, 0x0
num_failed:
	.word	0                               # 0x0
	.size	num_failed, 4

	.type	.L__const.TEST_CASE8.Vv2,@object # @__const.TEST_CASE8.Vv2
	.section	.rodata,"a",@progbits
	.p2align	3, 0x0
.L__const.TEST_CASE8.Vv2:
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405312             # 0x7ff0000000000000
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.size	.L__const.TEST_CASE8.Vv2, 128

	.type	.L__const.TEST_CASE8.Vv3,@object # @__const.TEST_CASE8.Vv3
	.p2align	3, 0x0
.L__const.TEST_CASE8.Vv3:
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	-4503599627370496               # 0xfff0000000000000
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.quad	9218868437227405311             # 0x7fefffffffffffff
	.quad	0                               # 0x0
	.size	.L__const.TEST_CASE8.Vv3, 128

	.type	.L__const.TEST_CASE8.Vv0,@object # @__const.TEST_CASE8.Vv0
.L__const.TEST_CASE8.Vv0:
	.zero	2,170
	.size	.L__const.TEST_CASE8.Vv0, 2

	.type	Ru64,@object                    # @Ru64
	.local	Ru64
	.comm	Ru64,8192,128
	.type	.L.str.1,@object                # @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str.1, 43

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"Index %d FAILED. Got %x, expected %x.\n"
	.size	.L.str.2, 39

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"PASSED.\n"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"ARA84_INITIAL fcsr=%u vstart=%u\n"
	.size	.L.str.4, 33

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"TEST_CASE8"
	.size	.L.str.5, 11

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"ARA84_FINAL fcsr=%u failures=%u\n"
	.size	.L.str.6, 33

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.7, 28

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"ara84_wrapper.c"
	.size	.L.str.8, 16

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.9, 13

	.type	test_case,@object               # @test_case
	.bss
	.globl	test_case
	.p2align	2, 0x0
test_case:
	.word	0                               # 0x0
	.size	test_case, 4

	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.ascii	"\210\001"                      # DW_AT_alignment
	.byte	15                              # DW_FORM_udata
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x2c7 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	13                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xb DW_TAG_variable
	.word	46                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	436                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2e:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x33:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	74                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x3a:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3e:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x42:0xb DW_TAG_variable
	.word	77                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	444                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4d:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x52:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x59:0xb DW_TAG_variable
	.word	100                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	444                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x64:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x69:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x70:0xb DW_TAG_variable
	.word	123                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	444                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x7b:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x80:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x87:0xb DW_TAG_variable
	.word	146                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10005                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	3                               # Abbrev [3] 0x92:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x97:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	33                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x9e:0xb DW_TAG_variable
	.word	169                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10006                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	3                               # Abbrev [3] 0xa9:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xae:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xb5:0xb DW_TAG_variable
	.word	146                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10010                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	2                               # Abbrev [2] 0xc0:0xb DW_TAG_variable
	.word	203                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	3                               # Abbrev [3] 0xcb:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xd0:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xd7:0xb DW_TAG_variable
	.word	226                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xe2:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xe7:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xee:0xb DW_TAG_variable
	.word	249                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	3                               # Abbrev [3] 0xf9:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xfe:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x105:0xd DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	274                             # DW_AT_type
	.byte	4                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	10
	.byte	3                               # Abbrev [3] 0x112:0xd DW_TAG_array_type
	.word	287                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x117:0x7 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x11f:0x5 DW_TAG_volatile_type
	.word	292                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x124:0x8 DW_TAG_typedef
	.word	300                             # DW_AT_type
	.byte	7                               # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x12c:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0x130:0xb DW_TAG_variable
	.byte	8                               # DW_AT_name
	.word	315                             # DW_AT_type
                                        # DW_AT_external
	.byte	5                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	5                               # Abbrev [5] 0x13b:0x4 DW_TAG_base_type
	.byte	9                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0x13f:0xb DW_TAG_variable
	.byte	10                              # DW_AT_name
	.word	315                             # DW_AT_type
                                        # DW_AT_external
	.byte	5                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	12
	.byte	12                              # Abbrev [12] 0x14a:0x5 DW_TAG_pointer_type
	.word	292                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x14f:0x10b DW_TAG_subprogram
	.byte	13                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	11                              # DW_AT_name
	.byte	6                               # DW_AT_decl_file
	.byte	4                               # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x15a:0x2b DW_TAG_lexical_block
	.byte	14                              # DW_AT_low_pc
	.word	.Ltmp7-.Ltmp3                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x160:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	436                             # DW_AT_decl_line
	.word	292                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x16c:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	14                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	436                             # DW_AT_decl_line
	.word	292                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x178:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	436                             # DW_AT_decl_line
	.word	655                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x185:0x14 DW_TAG_lexical_block
	.byte	15                              # DW_AT_low_pc
	.word	.Ltmp9-.Ltmp8                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x18b:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330~"
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	437                             # DW_AT_decl_line
	.word	668                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x199:0x14 DW_TAG_lexical_block
	.byte	16                              # DW_AT_low_pc
	.word	.Ltmp11-.Ltmp10                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x19f:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\330}"
	.byte	19                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	439                             # DW_AT_decl_line
	.word	668                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1ad:0x14 DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp13-.Ltmp12                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1b3:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\326}"
	.byte	20                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	441                             # DW_AT_decl_line
	.word	680                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1c1:0x2e DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp15-.Ltmp14                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1c7:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\320}"
	.byte	23                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	442                             # DW_AT_decl_line
	.word	655                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x1d4:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\314}"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	442                             # DW_AT_decl_line
	.word	655                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x1e1:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310}"
	.byte	25                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	442                             # DW_AT_decl_line
	.word	655                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1ef:0x3c DW_TAG_lexical_block
	.byte	19                              # DW_AT_low_pc
	.word	.Ltmp28-.Ltmp16                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1f5:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\300|"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	444                             # DW_AT_decl_line
	.word	710                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x202:0x14 DW_TAG_lexical_block
	.byte	20                              # DW_AT_low_pc
	.word	.Ltmp18-.Ltmp17                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x208:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\304}"
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	444                             # DW_AT_decl_line
	.word	330                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x216:0x14 DW_TAG_lexical_block
	.byte	21                              # DW_AT_low_pc
	.word	.Ltmp27-.Ltmp19                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x21c:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274|"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	444                             # DW_AT_decl_line
	.word	664                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x22b:0x2e DW_TAG_lexical_block
	.byte	22                              # DW_AT_low_pc
	.word	.Ltmp33-.Ltmp29                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x231:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260|"
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	445                             # DW_AT_decl_line
	.word	292                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x23e:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250|"
	.byte	14                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	445                             # DW_AT_decl_line
	.word	292                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x24b:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244|"
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	445                             # DW_AT_decl_line
	.word	655                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x25a:0x35 DW_TAG_subprogram
	.byte	23                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	12                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10000                           # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	315                             # DW_AT_type
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x26a:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	29                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10003                           # DW_AT_decl_line
	.word	664                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x276:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	30                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10003                           # DW_AT_decl_line
	.word	664                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x282:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	31                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10009                           # DW_AT_decl_line
	.word	664                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x28f:0x9 DW_TAG_typedef
	.word	664                             # DW_AT_type
	.byte	17                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x298:0x4 DW_TAG_base_type
	.byte	16                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x29c:0xc DW_TAG_array_type
	.word	287                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x2a1:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x2a8:0xc DW_TAG_array_type
	.word	692                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x2ad:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	2                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x2b4:0x5 DW_TAG_volatile_type
	.word	697                             # DW_AT_type
	.byte	17                              # Abbrev [17] 0x2b9:0x9 DW_TAG_typedef
	.word	706                             # DW_AT_type
	.byte	22                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	270                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x2c2:0x4 DW_TAG_base_type
	.byte	21                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x2c6:0xc DW_TAG_array_type
	.word	292                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x2cb:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	132                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfadd_TEST_CASE8_e64.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=231
.Linfo_string3:
	.asciz	"char"                          # string offset=283
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=288
.Linfo_string5:
	.asciz	"Ru64"                          # string offset=308
.Linfo_string6:
	.asciz	"unsigned long long"            # string offset=313
.Linfo_string7:
	.asciz	"uint64_t"                      # string offset=332
.Linfo_string8:
	.asciz	"num_failed"                    # string offset=341
.Linfo_string9:
	.asciz	"int"                           # string offset=352
.Linfo_string10:
	.asciz	"test_case"                     # string offset=356
.Linfo_string11:
	.asciz	"TEST_CASE8"                    # string offset=366
.Linfo_string12:
	.asciz	"main"                          # string offset=377
.Linfo_string13:
	.asciz	"gold_ff"                       # string offset=382
.Linfo_string14:
	.asciz	"ff"                            # string offset=390
.Linfo_string15:
	.asciz	"ara_ff"                        # string offset=393
.Linfo_string16:
	.asciz	"unsigned int"                  # string offset=400
.Linfo_string17:
	.asciz	"uintptr_t"                     # string offset=413
.Linfo_string18:
	.asciz	"Vv2"                           # string offset=423
.Linfo_string19:
	.asciz	"Vv3"                           # string offset=427
.Linfo_string20:
	.asciz	"Vv0"                           # string offset=431
.Linfo_string21:
	.asciz	"unsigned char"                 # string offset=435
.Linfo_string22:
	.asciz	"uint8_t"                       # string offset=449
.Linfo_string23:
	.asciz	"vtype"                         # string offset=457
.Linfo_string24:
	.asciz	"vl"                            # string offset=463
.Linfo_string25:
	.asciz	"vlmax"                         # string offset=466
.Linfo_string26:
	.asciz	"Ru64_t"                        # string offset=472
.Linfo_string27:
	.asciz	"vact"                          # string offset=479
.Linfo_string28:
	.asciz	"i"                             # string offset=484
.Linfo_string29:
	.asciz	"initial_fcsr"                  # string offset=486
.Linfo_string30:
	.asciz	"initial_vstart"                # string offset=499
.Linfo_string31:
	.asciz	"final_fcsr"                    # string offset=514
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.word	.Linfo_string25
	.word	.Linfo_string26
	.word	.Linfo_string27
	.word	.Linfo_string28
	.word	.Linfo_string29
	.word	.Linfo_string30
	.word	.Linfo_string31
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L.str.7
	.word	.L.str.8
	.word	.L.str.9
	.word	Ru64
	.word	num_failed
	.word	test_case
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp8
	.word	.Ltmp10
	.word	.Ltmp12
	.word	.Ltmp14
	.word	.Ltmp16
	.word	.Ltmp17
	.word	.Ltmp19
	.word	.Ltmp29
	.word	.Lfunc_begin1
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
