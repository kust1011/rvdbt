	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"upstream_block_vfmul_TEST_CASE4_e32.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfmul_TEST_CASE4_e32.c" md5 0xe711b15e483941eba23d27d621625239
	.file	1 "vfmul.c"
	.file	2 "ara84_wrapper.c"
	.file	3 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	4 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/dataset.h" md5 0x6e87c523f491ba527fcaa8da037d753f
	.file	5 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/vector_macros.h" md5 0xf0792279c410650ddf6b368633799e9a
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE4                      # -- Begin function TEST_CASE4
	.p2align	2
	.type	TEST_CASE4,@function
TEST_CASE4:                             # @TEST_CASE4
.Lfunc_begin0:
	.file	6 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfmul_TEST_CASE4_e32.c" md5 0xe711b15e483941eba23d27d621625239
	.loc	6 4 0                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfmul_TEST_CASE4_e32.c:4:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -192
	.cfi_def_cfa_offset 192
	sw	ra, 188(sp)                     # 4-byte Folded Spill
	sw	s0, 184(sp)                     # 4-byte Folded Spill
	sw	s1, 180(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 192
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 283 3 prologue_end            # vfmul.c:283:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # vfmul.c:0:3
	li	a0, 16
.Ltmp1:
	.loc	1 283 3                         # vfmul.c:283:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 283
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 288 3 is_stmt 1               # vfmul.c:288:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 288 3 is_stmt 0               # vfmul.c:288:3
	lui	a1, %hi(.L__const.TEST_CASE4.Vv2)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.Vv2)
	addi	s1, s0, -76
	addi	a0, s0, -76
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 294 3 is_stmt 1               # vfmul.c:294:3
	j	.LBB0_5
.LBB0_5:
	.loc	1 0 3 is_stmt 0                 # vfmul.c:0:3
	li	a0, -1
.Ltmp5:
	.loc	1 294 3                         # vfmul.c:294:3
	sw	a0, -92(s0)
	lui	a0, 259851
	addi	a0, a0, -193
	sw	a0, -96(s0)
	fld	fa5, -96(s0)
	fsd	fa5, -88(s0)
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 295 3 is_stmt 1               # vfmul.c:295:3
	j	.LBB0_7
.LBB0_7:
.Ltmp7:
	.loc	1 295 3 is_stmt 0               # vfmul.c:295:3
	lui	a0, %hi(.L__const.TEST_CASE4.Vv0)
	lbu	a1, %lo(.L__const.TEST_CASE4.Vv0)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE4.Vv0)
	lbu	a0, 1(a0)
	slli	a0, a0, 8
	or	a0, a0, a1
	sh	a0, -98(s0)
	addi	a0, s0, -98
	#APP
	vle8.v v0, (a0)  

	#NO_APP
	j	.LBB0_8
.Ltmp8:
.LBB0_8:
	.loc	1 296 3 is_stmt 1               # vfmul.c:296:3
	j	.LBB0_9
.LBB0_9:
.Ltmp9:
	.loc	1 296 3 is_stmt 0               # vfmul.c:296:3
	#APP
	csrr a0, vtype
	#NO_APP
	sw	a0, -104(s0)
	#APP
	csrr a0, vl
	#NO_APP
	sw	a0, -108(s0)
	lw	a0, -104(s0)
	#APP
	vsetvl a0, zero, a0
	#NO_APP
	sw	a0, -112(s0)
	#APP
	vmv.v.i v1, 0
	#NO_APP
	lw	a0, -108(s0)
	lw	a1, -104(s0)
	#APP
	vsetvl zero, a0, a1
	#NO_APP
	j	.LBB0_10
.Ltmp10:
.LBB0_10:
	.loc	1 297 56 is_stmt 1              # vfmul.c:297:56
	fld	fa5, -88(s0)
	.loc	1 297 3 is_stmt 0               # vfmul.c:297:3
	#APP
	vfmul.vf v1, v2, fa5, v0.t
	#NO_APP
.Ltmp11:
	.loc	1 302 3 is_stmt 1               # vfmul.c:302:3
	j	.LBB0_11
.LBB0_11:
.Ltmp12:
	.loc	1 302 3 is_stmt 0               # vfmul.c:302:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -116(s0)
	lw	a0, -116(s0)
	#APP
	vse32.v v1, (a0)

	#NO_APP
	sw	a0, -116(s0)
	j	.LBB0_12
.Ltmp13:
.LBB0_12:
	.loc	1 302 3                         # vfmul.c:302:3
	lui	a1, %hi(.L__const.TEST_CASE4.vact)
	addi	a1, a1, %lo(.L__const.TEST_CASE4.vact)
	addi	a0, s0, -180
	li	a2, 64
	call	memcpy
	li	a0, 11
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 11
	call	printf_
.Ltmp14:
	.loc	1 302 3                         # vfmul.c:302:3
	sw	zero, -184(s0)
	j	.LBB0_13
.LBB0_13:                               # =>This Inner Loop Header: Depth=1
.Ltmp15:
	.loc	1 302 3                         # vfmul.c:302:3
	lw	a0, -184(s0)
	li	a1, 15
.Ltmp16:
	.loc	1 302 3                         # vfmul.c:302:3
	bltu	a1, a0, .LBB0_18
	j	.LBB0_14
.LBB0_14:                               #   in Loop: Header=BB0_13 Depth=1
.Ltmp17:
	.loc	1 302 3                         # vfmul.c:302:3
	lw	a1, -184(s0)
	li	a0, 11
	call	ara_compare_step
.Ltmp18:
	.loc	1 302 3                         # vfmul.c:302:3
	lw	a0, -184(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -184(s0)
	slli	a1, a1, 2
	addi	a2, s0, -180
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB0_16
	j	.LBB0_15
.LBB0_15:
.Ltmp19:
	.loc	1 302 3                         # vfmul.c:302:3
	lw	a1, -184(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -184(s0)
	slli	a0, a0, 2
	addi	a3, s0, -180
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(num_failed)
	lw	a1, %lo(num_failed)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(num_failed)(a0)
	j	.LBB0_19
.Ltmp20:
.LBB0_16:                               #   in Loop: Header=BB0_13 Depth=1
	.loc	1 302 3                         # vfmul.c:302:3
	j	.LBB0_17
.Ltmp21:
.LBB0_17:                               #   in Loop: Header=BB0_13 Depth=1
	.loc	1 302 3                         # vfmul.c:302:3
	lw	a0, -184(s0)
	addi	a0, a0, 1
	sw	a0, -184(s0)
	j	.LBB0_13
.Ltmp22:
.LBB0_18:
	.loc	1 302 3                         # vfmul.c:302:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 11
	call	ara_assert_end
.Ltmp23:
	.loc	1 305 1 is_stmt 1               # vfmul.c:305:1
	j	.LBB0_19
.LBB0_19:
	.cfi_def_cfa sp, 192
	.loc	1 305 1 epilogue_begin is_stmt 0 # vfmul.c:305:1
	lw	ra, 188(sp)                     # 4-byte Folded Reload
	lw	s0, 184(sp)                     # 4-byte Folded Reload
	lw	s1, 180(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 192
	.cfi_def_cfa_offset 0
	ret
.Ltmp24:
.Lfunc_end0:
	.size	TEST_CASE4, .Lfunc_end0-TEST_CASE4
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin1:
	.loc	2 10000 0 is_stmt 1             # ara84_wrapper.c:10000:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp25:
	.loc	2 10004 3 prologue_end          # ara84_wrapper.c:10004:3
	#APP
	frcsr a0; csrr a1, vstart
	#NO_APP
	sw	a0, -24(s0)
	sw	a1, -28(s0)
	.loc	2 10005 46                      # ara84_wrapper.c:10005:46
	lw	a1, -24(s0)
	.loc	2 10005 59 is_stmt 0            # ara84_wrapper.c:10005:59
	lw	a2, -28(s0)
	.loc	2 10005 3                       # ara84_wrapper.c:10005:3
	lui	a0, %hi(.L.str.3)
	addi	a0, a0, %lo(.L.str.3)
	call	printf_
	.loc	2 10006 3 is_stmt 1             # ara84_wrapper.c:10006:3
	lui	s1, %hi(.L.str.4)
	addi	s1, s1, %lo(.L.str.4)
	mv	a0, s1
	call	ara_case_begin
	.loc	2 10007 3                       # ara84_wrapper.c:10007:3
	call	TEST_CASE4
	.loc	2 10008 29                      # ara84_wrapper.c:10008:29
	lui	s2, %hi(num_failed)
	lw	a1, %lo(num_failed)(s2)
	.loc	2 10008 3 is_stmt 0             # ara84_wrapper.c:10008:3
	mv	a0, s1
	call	ara_case_end
	.loc	2 10009 24 is_stmt 1            # ara84_wrapper.c:10009:24
	#APP
	frcsr a0
	#NO_APP
	sw	a0, -32(s0)
	.loc	2 10010 46                      # ara84_wrapper.c:10010:46
	lw	a1, -32(s0)
	.loc	2 10010 57 is_stmt 0            # ara84_wrapper.c:10010:57
	lw	a2, %lo(num_failed)(s2)
	.loc	2 10010 3                       # ara84_wrapper.c:10010:3
	lui	a0, %hi(.L.str.5)
	addi	a0, a0, %lo(.L.str.5)
	call	printf_
	.loc	2 10011 3 is_stmt 1             # ara84_wrapper.c:10011:3
	j	.LBB1_1
.LBB1_1:
.Ltmp26:
	.loc	2 10011 3 is_stmt 0             # ara84_wrapper.c:10011:3
	lui	a0, %hi(num_failed)
	lw	a0, %lo(num_failed)(a0)
	blez	a0, .LBB1_3
	j	.LBB1_2
.LBB1_2:
.Ltmp27:
	.loc	2 10011 3                       # ara84_wrapper.c:10011:3
	lui	s1, %hi(num_failed)
	lw	a2, %lo(num_failed)(s1)
	lui	a0, %hi(.L.str.6)
	addi	a0, a0, %lo(.L.str.6)
	lui	a1, %hi(.L.str.7)
	addi	a1, a1, %lo(.L.str.7)
	call	printf_
	lw	a0, %lo(num_failed)(s1)
	sw	a0, -20(s0)
	j	.LBB1_4
.Ltmp28:
.LBB1_3:
	.loc	2 10011 3                       # ara84_wrapper.c:10011:3
	lui	a0, %hi(.L.str.8)
	addi	a0, a0, %lo(.L.str.8)
	lui	a1, %hi(.L.str.7)
	addi	a1, a1, %lo(.L.str.7)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB1_4
.Ltmp29:
.LBB1_4:
	.loc	2 10012 1 is_stmt 1             # ara84_wrapper.c:10012:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	2 10012 1 epilogue_begin is_stmt 0 # ara84_wrapper.c:10012:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp30:
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE4.Vv2,@object # @__const.TEST_CASE4.Vv2
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE4.Vv2:
	.word	3186267723                      # 0xbdea964b
	.word	3203150716                      # 0xbeec337c
	.word	1032768858                      # 0x3d8ecd5a
	.word	1045508936                      # 0x3e513348
	.word	3212356131                      # 0xbf78aa23
	.word	3212118737                      # 0xbf750ad1
	.word	3185994578                      # 0xbde66b52
	.word	1056446312                      # 0x3ef81768
	.word	1058584658                      # 0x3f18b852
	.word	1055777764                      # 0x3eede3e4
	.word	1040823375                      # 0x3e09b44f
	.word	3198420447                      # 0xbea405df
	.word	1061178781                      # 0x3f404d9d
	.word	1063781941                      # 0x3f680635
	.word	1060916049                      # 0x3f3c4b51
	.word	3205044792                      # 0xbf091a38
	.size	.L__const.TEST_CASE4.Vv2, 64

	.type	.L__const.TEST_CASE4.Vv0,@object # @__const.TEST_CASE4.Vv0
.L__const.TEST_CASE4.Vv0:
	.zero	2,170
	.size	.L__const.TEST_CASE4.Vv0, 2

	.type	Ru32,@object                    # @Ru32
	.local	Ru32
	.comm	Ru32,4096,128
	.type	.L__const.TEST_CASE4.vact,@object # @__const.TEST_CASE4.vact
	.p2align	2, 0x0
.L__const.TEST_CASE4.vact:
	.word	0                               # 0x0
	.word	3202224630                      # 0xbede11f6
	.word	0                               # 0x0
	.word	1044688713                      # 0x3e44af49
	.word	0                               # 0x0
	.word	3211157987                      # 0xbf6661e3
	.word	0                               # 0x0
	.word	1055473607                      # 0x3ee93fc7
	.word	0                               # 0x0
	.word	1054845055                      # 0x3edfa87f
	.word	0                               # 0x0
	.word	3197777353                      # 0xbe9a35c9
	.word	0                               # 0x0
	.word	1062872231                      # 0x3f5a24a7
	.word	0                               # 0x0
	.word	3204507247                      # 0xbf00e66f
	.size	.L__const.TEST_CASE4.vact, 64

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %x, expected %x.\n"
	.size	.L.str.1, 39

	.type	num_failed,@object              # @num_failed
	.bss
	.globl	num_failed
	.p2align	2, 0x0
num_failed:
	.word	0                               # 0x0
	.size	num_failed, 4

	.type	.L.str.2,@object                # @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"ARA84_INITIAL fcsr=%u vstart=%u\n"
	.size	.L.str.3, 33

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"TEST_CASE4"
	.size	.L.str.4, 11

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"ARA84_FINAL fcsr=%u failures=%u\n"
	.size	.L.str.5, 33

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.6, 28

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"ara84_wrapper.c"
	.size	.L.str.7, 16

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.8, 13

	.type	test_case,@object               # @test_case
	.bss
	.globl	test_case
	.p2align	2, 0x0
test_case:
	.word	0                               # 0x0
	.size	test_case, 4

	.file	7 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/float_macros.h" md5 0xcdf4a4dd15bfbc9e76f797f51350b6cb
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.ascii	"\210\001"                      # DW_AT_alignment
	.byte	15                              # DW_FORM_udata
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	23                              # DW_TAG_union_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	18                              # Abbreviation Code
	.byte	13                              # DW_TAG_member
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	56                              # DW_AT_data_member_location
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	19                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x290 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	12                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xb DW_TAG_variable
	.word	46                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2e:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x33:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x3a:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3e:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x42:0xb DW_TAG_variable
	.word	77                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4d:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x52:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x59:0xb DW_TAG_variable
	.word	100                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x64:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x69:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x70:0xb DW_TAG_variable
	.word	123                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10005                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x7b:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x80:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	33                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x87:0xb DW_TAG_variable
	.word	146                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10006                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	3                               # Abbrev [3] 0x92:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x97:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x9e:0xb DW_TAG_variable
	.word	123                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10010                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	2                               # Abbrev [2] 0xa9:0xb DW_TAG_variable
	.word	180                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	3                               # Abbrev [3] 0xb4:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb9:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xc0:0xb DW_TAG_variable
	.word	203                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	3                               # Abbrev [3] 0xcb:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xd0:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xd7:0xb DW_TAG_variable
	.word	226                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xe2:0xc DW_TAG_array_type
	.word	58                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xe7:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xee:0xd DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	251                             # DW_AT_type
	.byte	4                               # DW_AT_decl_file
	.byte	26                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	3                               # Abbrev [3] 0xfb:0xd DW_TAG_array_type
	.word	264                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x100:0x7 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x108:0x5 DW_TAG_volatile_type
	.word	269                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x10d:0x8 DW_TAG_typedef
	.word	277                             # DW_AT_type
	.byte	7                               # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x115:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0x119:0xb DW_TAG_variable
	.byte	8                               # DW_AT_name
	.word	292                             # DW_AT_type
                                        # DW_AT_external
	.byte	5                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	10
	.byte	5                               # Abbrev [5] 0x124:0x4 DW_TAG_base_type
	.byte	9                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0x128:0xb DW_TAG_variable
	.byte	10                              # DW_AT_name
	.word	292                             # DW_AT_type
                                        # DW_AT_external
	.byte	5                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	10                              # Abbrev [10] 0x133:0x8 DW_TAG_typedef
	.word	315                             # DW_AT_type
	.byte	12                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x13b:0x4 DW_TAG_base_type
	.byte	11                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	12                              # Abbrev [12] 0x13f:0x5 DW_TAG_pointer_type
	.word	269                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x144:0xbf DW_TAG_subprogram
	.byte	12                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	13                              # DW_AT_name
	.byte	6                               # DW_AT_decl_file
	.byte	4                               # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x14f:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	292                             # DW_AT_decl_line
	.word	580                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x15c:0x14 DW_TAG_lexical_block
	.byte	13                              # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x162:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	288                             # DW_AT_decl_line
	.word	568                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x170:0x14 DW_TAG_lexical_block
	.byte	14                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x176:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\240\177"
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	294                             # DW_AT_decl_line
	.word	584                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x184:0x14 DW_TAG_lexical_block
	.byte	15                              # DW_AT_low_pc
	.word	.Ltmp8-.Ltmp7                   # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x18a:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\236\177"
	.byte	22                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	295                             # DW_AT_decl_line
	.word	616                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x198:0x2e DW_TAG_lexical_block
	.byte	16                              # DW_AT_low_pc
	.word	.Ltmp10-.Ltmp9                  # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x19e:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\230\177"
	.byte	25                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	296                             # DW_AT_decl_line
	.word	646                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x1ab:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\224\177"
	.byte	27                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	296                             # DW_AT_decl_line
	.word	646                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x1b8:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\220\177"
	.byte	28                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	296                             # DW_AT_decl_line
	.word	646                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x1c6:0x3c DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp23-.Ltmp11                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x1cc:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\314~"
	.byte	30                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.word	655                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x1d9:0x14 DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp13-.Ltmp12                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x1df:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\214\177"
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.word	319                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x1ed:0x14 DW_TAG_lexical_block
	.byte	19                              # DW_AT_low_pc
	.word	.Ltmp22-.Ltmp14                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x1f3:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\310~"
	.byte	31                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.word	277                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x203:0x35 DW_TAG_subprogram
	.byte	20                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	14                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10000                           # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	292                             # DW_AT_type
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x213:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	32                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10003                           # DW_AT_decl_line
	.word	277                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x21f:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	33                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10003                           # DW_AT_decl_line
	.word	277                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x22b:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	34                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10009                           # DW_AT_decl_line
	.word	277                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x238:0xc DW_TAG_array_type
	.word	264                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x23d:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x244:0x4 DW_TAG_base_type
	.byte	17                              # DW_AT_name
	.byte	4                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	10                              # Abbrev [10] 0x248:0x8 DW_TAG_typedef
	.word	592                             # DW_AT_type
	.byte	21                              # DW_AT_name
	.byte	7                               # DW_AT_decl_file
	.byte	78                              # DW_AT_decl_line
	.byte	17                              # Abbrev [17] 0x250:0x18 DW_TAG_union_type
	.byte	21                              # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_decl_file
	.byte	75                              # DW_AT_decl_line
	.byte	18                              # Abbrev [18] 0x255:0x9 DW_TAG_member
	.byte	19                              # DW_AT_name
	.word	580                             # DW_AT_type
	.byte	7                               # DW_AT_decl_file
	.byte	76                              # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	18                              # Abbrev [18] 0x25e:0x9 DW_TAG_member
	.byte	20                              # DW_AT_name
	.word	307                             # DW_AT_type
	.byte	7                               # DW_AT_decl_file
	.byte	77                              # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x268:0xc DW_TAG_array_type
	.word	628                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x26d:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	2                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x274:0x5 DW_TAG_volatile_type
	.word	633                             # DW_AT_type
	.byte	19                              # Abbrev [19] 0x279:0x9 DW_TAG_typedef
	.word	642                             # DW_AT_type
	.byte	24                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	270                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x282:0x4 DW_TAG_base_type
	.byte	23                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	19                              # Abbrev [19] 0x286:0x9 DW_TAG_typedef
	.word	277                             # DW_AT_type
	.byte	26                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	3                               # Abbrev [3] 0x28f:0xc DW_TAG_array_type
	.word	269                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x294:0x6 DW_TAG_subrange_type
	.word	62                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	144                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfmul_TEST_CASE4_e32.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=231
.Linfo_string3:
	.asciz	"char"                          # string offset=283
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=288
.Linfo_string5:
	.asciz	"Ru32"                          # string offset=308
.Linfo_string6:
	.asciz	"unsigned int"                  # string offset=313
.Linfo_string7:
	.asciz	"uint32_t"                      # string offset=326
.Linfo_string8:
	.asciz	"num_failed"                    # string offset=335
.Linfo_string9:
	.asciz	"int"                           # string offset=346
.Linfo_string10:
	.asciz	"test_case"                     # string offset=350
.Linfo_string11:
	.asciz	"unsigned long long"            # string offset=360
.Linfo_string12:
	.asciz	"uint64_t"                      # string offset=379
.Linfo_string13:
	.asciz	"TEST_CASE4"                    # string offset=388
.Linfo_string14:
	.asciz	"main"                          # string offset=399
.Linfo_string15:
	.asciz	"Vv2"                           # string offset=404
.Linfo_string16:
	.asciz	"dscalar_32"                    # string offset=408
.Linfo_string17:
	.asciz	"double"                        # string offset=419
.Linfo_string18:
	.asciz	"nan_boxed_val"                 # string offset=426
.Linfo_string19:
	.asciz	"d"                             # string offset=440
.Linfo_string20:
	.asciz	"ui64"                          # string offset=442
.Linfo_string21:
	.asciz	"double_hex"                    # string offset=447
.Linfo_string22:
	.asciz	"Vv0"                           # string offset=458
.Linfo_string23:
	.asciz	"unsigned char"                 # string offset=462
.Linfo_string24:
	.asciz	"uint8_t"                       # string offset=476
.Linfo_string25:
	.asciz	"vtype"                         # string offset=484
.Linfo_string26:
	.asciz	"uintptr_t"                     # string offset=490
.Linfo_string27:
	.asciz	"vl"                            # string offset=500
.Linfo_string28:
	.asciz	"vlmax"                         # string offset=503
.Linfo_string29:
	.asciz	"Ru32_t"                        # string offset=509
.Linfo_string30:
	.asciz	"vact"                          # string offset=516
.Linfo_string31:
	.asciz	"i"                             # string offset=521
.Linfo_string32:
	.asciz	"initial_fcsr"                  # string offset=523
.Linfo_string33:
	.asciz	"initial_vstart"                # string offset=536
.Linfo_string34:
	.asciz	"final_fcsr"                    # string offset=551
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.word	.Linfo_string25
	.word	.Linfo_string26
	.word	.Linfo_string27
	.word	.Linfo_string28
	.word	.Linfo_string29
	.word	.Linfo_string30
	.word	.Linfo_string31
	.word	.Linfo_string32
	.word	.Linfo_string33
	.word	.Linfo_string34
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L.str.7
	.word	.L.str.8
	.word	Ru32
	.word	num_failed
	.word	test_case
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Ltmp9
	.word	.Ltmp11
	.word	.Ltmp12
	.word	.Ltmp14
	.word	.Lfunc_begin1
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
