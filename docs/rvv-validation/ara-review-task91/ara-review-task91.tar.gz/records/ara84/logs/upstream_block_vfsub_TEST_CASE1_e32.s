	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"upstream_block_vfsub_TEST_CASE1_e32.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfsub_TEST_CASE1_e32.c" md5 0xde8ba43528beb21a5c50c84e8d1c8a5c
	.file	1 "vfsub.c"
	.file	2 "ara84_wrapper.c"
	.file	3 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	4 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/dataset.h" md5 0x6e87c523f491ba527fcaa8da037d753f
	.file	5 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/vector_macros.h" md5 0xf0792279c410650ddf6b368633799e9a
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE1                      # -- Begin function TEST_CASE1
	.p2align	2
	.type	TEST_CASE1,@function
TEST_CASE1:                             # @TEST_CASE1
.Lfunc_begin0:
	.file	6 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfsub_TEST_CASE1_e32.c" md5 0xde8ba43528beb21a5c50c84e8d1c8a5c
	.loc	6 4 0                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfsub_TEST_CASE1_e32.c:4:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -224
	.cfi_def_cfa_offset 224
	sw	ra, 220(sp)                     # 4-byte Folded Spill
	sw	s0, 216(sp)                     # 4-byte Folded Spill
	sw	s1, 212(sp)                     # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 224
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 32 3 prologue_end             # vfsub.c:32:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # vfsub.c:0:3
	li	a0, 16
.Ltmp1:
	.loc	1 32 3                          # vfsub.c:32:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 32
	li	a1, 16
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 37 3 is_stmt 1                # vfsub.c:37:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 37 3 is_stmt 0                # vfsub.c:37:3
	lui	a1, %hi(.L__const.TEST_CASE1.Vv2)
	addi	a1, a1, %lo(.L__const.TEST_CASE1.Vv2)
	addi	s1, s0, -76
	addi	a0, s0, -76
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v2, (s1)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 45 3 is_stmt 1                # vfsub.c:45:3
	j	.LBB0_5
.LBB0_5:
.Ltmp5:
	.loc	1 45 3 is_stmt 0                # vfsub.c:45:3
	lui	a1, %hi(.L__const.TEST_CASE1.Vv3)
	addi	a1, a1, %lo(.L__const.TEST_CASE1.Vv3)
	addi	s1, s0, -140
	addi	a0, s0, -140
	li	a2, 64
	call	memcpy
	#APP
	vle32.v v3, (s1)  

	#NO_APP
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 49 3 is_stmt 1                # vfsub.c:49:3
	#APP
	vfsub.vv v1, v2, v3
	#NO_APP
.Ltmp7:
	.loc	1 55 3                          # vfsub.c:55:3
	j	.LBB0_7
.LBB0_7:
.Ltmp8:
	.loc	1 55 3 is_stmt 0                # vfsub.c:55:3
	lui	a0, %hi(Ru32)
	addi	a0, a0, %lo(Ru32)
	sw	a0, -144(s0)
	lw	a0, -144(s0)
	#APP
	vse32.v v1, (a0)

	#NO_APP
	sw	a0, -144(s0)
	j	.LBB0_8
.Ltmp9:
.LBB0_8:
	.loc	1 55 3                          # vfsub.c:55:3
	lui	a1, %hi(.L__const.TEST_CASE1.vact)
	addi	a1, a1, %lo(.L__const.TEST_CASE1.vact)
	addi	a0, s0, -208
	li	a2, 64
	call	memcpy
	li	a0, 2
	li	a1, 16
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 2
	call	printf_
.Ltmp10:
	.loc	1 55 3                          # vfsub.c:55:3
	sw	zero, -212(s0)
	j	.LBB0_9
.LBB0_9:                                # =>This Inner Loop Header: Depth=1
.Ltmp11:
	.loc	1 55 3                          # vfsub.c:55:3
	lw	a0, -212(s0)
	li	a1, 15
.Ltmp12:
	.loc	1 55 3                          # vfsub.c:55:3
	bltu	a1, a0, .LBB0_14
	j	.LBB0_10
.LBB0_10:                               #   in Loop: Header=BB0_9 Depth=1
.Ltmp13:
	.loc	1 55 3                          # vfsub.c:55:3
	lw	a1, -212(s0)
	li	a0, 2
	call	ara_compare_step
.Ltmp14:
	.loc	1 55 3                          # vfsub.c:55:3
	lw	a0, -212(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ru32)
	addi	a1, a1, %lo(Ru32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -212(s0)
	slli	a1, a1, 2
	addi	a2, s0, -208
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB0_12
	j	.LBB0_11
.LBB0_11:
.Ltmp15:
	.loc	1 55 3                          # vfsub.c:55:3
	lw	a1, -212(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ru32)
	addi	a2, a2, %lo(Ru32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -212(s0)
	slli	a0, a0, 2
	addi	a3, s0, -208
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(num_failed)
	lw	a1, %lo(num_failed)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(num_failed)(a0)
	j	.LBB0_15
.Ltmp16:
.LBB0_12:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 55 3                          # vfsub.c:55:3
	j	.LBB0_13
.Ltmp17:
.LBB0_13:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 55 3                          # vfsub.c:55:3
	lw	a0, -212(s0)
	addi	a0, a0, 1
	sw	a0, -212(s0)
	j	.LBB0_9
.Ltmp18:
.LBB0_14:
	.loc	1 55 3                          # vfsub.c:55:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 2
	call	ara_assert_end
.Ltmp19:
	.loc	1 59 1 is_stmt 1                # vfsub.c:59:1
	j	.LBB0_15
.LBB0_15:
	.cfi_def_cfa sp, 224
	.loc	1 59 1 epilogue_begin is_stmt 0 # vfsub.c:59:1
	lw	ra, 220(sp)                     # 4-byte Folded Reload
	lw	s0, 216(sp)                     # 4-byte Folded Reload
	lw	s1, 212(sp)                     # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 224
	.cfi_def_cfa_offset 0
	ret
.Ltmp20:
.Lfunc_end0:
	.size	TEST_CASE1, .Lfunc_end0-TEST_CASE1
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin1:
	.loc	2 10000 0 is_stmt 1             # ara84_wrapper.c:10000:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp21:
	.loc	2 10004 3 prologue_end          # ara84_wrapper.c:10004:3
	#APP
	frcsr a0; csrr a1, vstart
	#NO_APP
	sw	a0, -24(s0)
	sw	a1, -28(s0)
	.loc	2 10005 46                      # ara84_wrapper.c:10005:46
	lw	a1, -24(s0)
	.loc	2 10005 59 is_stmt 0            # ara84_wrapper.c:10005:59
	lw	a2, -28(s0)
	.loc	2 10005 3                       # ara84_wrapper.c:10005:3
	lui	a0, %hi(.L.str.3)
	addi	a0, a0, %lo(.L.str.3)
	call	printf_
	.loc	2 10006 3 is_stmt 1             # ara84_wrapper.c:10006:3
	lui	s1, %hi(.L.str.4)
	addi	s1, s1, %lo(.L.str.4)
	mv	a0, s1
	call	ara_case_begin
	.loc	2 10007 3                       # ara84_wrapper.c:10007:3
	call	TEST_CASE1
	.loc	2 10008 29                      # ara84_wrapper.c:10008:29
	lui	s2, %hi(num_failed)
	lw	a1, %lo(num_failed)(s2)
	.loc	2 10008 3 is_stmt 0             # ara84_wrapper.c:10008:3
	mv	a0, s1
	call	ara_case_end
	.loc	2 10009 24 is_stmt 1            # ara84_wrapper.c:10009:24
	#APP
	frcsr a0
	#NO_APP
	sw	a0, -32(s0)
	.loc	2 10010 46                      # ara84_wrapper.c:10010:46
	lw	a1, -32(s0)
	.loc	2 10010 57 is_stmt 0            # ara84_wrapper.c:10010:57
	lw	a2, %lo(num_failed)(s2)
	.loc	2 10010 3                       # ara84_wrapper.c:10010:3
	lui	a0, %hi(.L.str.5)
	addi	a0, a0, %lo(.L.str.5)
	call	printf_
	.loc	2 10011 3 is_stmt 1             # ara84_wrapper.c:10011:3
	j	.LBB1_1
.LBB1_1:
.Ltmp22:
	.loc	2 10011 3 is_stmt 0             # ara84_wrapper.c:10011:3
	lui	a0, %hi(num_failed)
	lw	a0, %lo(num_failed)(a0)
	blez	a0, .LBB1_3
	j	.LBB1_2
.LBB1_2:
.Ltmp23:
	.loc	2 10011 3                       # ara84_wrapper.c:10011:3
	lui	s1, %hi(num_failed)
	lw	a2, %lo(num_failed)(s1)
	lui	a0, %hi(.L.str.6)
	addi	a0, a0, %lo(.L.str.6)
	lui	a1, %hi(.L.str.7)
	addi	a1, a1, %lo(.L.str.7)
	call	printf_
	lw	a0, %lo(num_failed)(s1)
	sw	a0, -20(s0)
	j	.LBB1_4
.Ltmp24:
.LBB1_3:
	.loc	2 10011 3                       # ara84_wrapper.c:10011:3
	lui	a0, %hi(.L.str.8)
	addi	a0, a0, %lo(.L.str.8)
	lui	a1, %hi(.L.str.7)
	addi	a1, a1, %lo(.L.str.7)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB1_4
.Ltmp25:
.LBB1_4:
	.loc	2 10012 1 is_stmt 1             # ara84_wrapper.c:10012:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	2 10012 1 epilogue_begin is_stmt 0 # ara84_wrapper.c:10012:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp26:
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE1.Vv2,@object # @__const.TEST_CASE1.Vv2
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv2:
	.word	3187918912                      # 0xbe03c840
	.word	1064824398                      # 0x3f77ee4e
	.word	3210456499                      # 0xbf5badb3
	.word	3193457422                      # 0xbe584b0e
	.word	3176452760                      # 0xbd54d298
	.word	1054921196                      # 0x3ee0d1ec
	.word	1063143346                      # 0x3f5e47b2
	.word	3211227560                      # 0xbf6771a8
	.word	1058992883                      # 0x3f1ef2f3
	.word	3207117073                      # 0xbf28b911
	.word	1063992001                      # 0x3f6b3ac1
	.word	3205722559                      # 0xbf1371bf
	.word	3199541898                      # 0xbeb5228a
	.word	3196615939                      # 0xbe887d03
	.word	1056680590                      # 0x3efbaa8e
	.word	1054494252                      # 0x3eda4e2c
	.size	.L__const.TEST_CASE1.Vv2, 64

	.type	.L__const.TEST_CASE1.Vv3,@object # @__const.TEST_CASE1.Vv3
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv3:
	.word	3204586021                      # 0xbf021a25
	.word	3205606176                      # 0xbf11ab20
	.word	3210931447                      # 0xbf62ecf7
	.word	1063864820                      # 0x3f6949f4
	.word	3146825859                      # 0xbb90c083
	.word	1060783608                      # 0x3f3a45f8
	.word	1062305526                      # 0x3f517ef6
	.word	3204440847                      # 0xbeffe30f
	.word	3211915344                      # 0xbf71f050
	.word	3206254613                      # 0xbf1b9015
	.word	1045938181                      # 0x3e57c005
	.word	1052147686                      # 0x3eb67fe6
	.word	3204723369                      # 0xbf0432a9
	.word	3208611050                      # 0xbf3f84ea
	.word	3212338361                      # 0xbf7864b9
	.word	1054498410                      # 0x3eda5e6a
	.size	.L__const.TEST_CASE1.Vv3, 64

	.type	Ru32,@object                    # @Ru32
	.local	Ru32
	.comm	Ru32,4096,128
	.type	.L__const.TEST_CASE1.vact,@object # @__const.TEST_CASE1.vact
	.p2align	2, 0x0
.L__const.TEST_CASE1.vact:
	.word	1052921898                      # 0x3ec2502a
	.word	1069862071                      # 0x3fc4ccb7
	.word	1021831296                      # 0x3ce7e880
	.word	3213864540                      # 0xbf8fae5c
	.word	3175266952                      # 0xbd42ba88
	.word	3197352452                      # 0xbe93ba04
	.word	1028426688                      # 0x3d4c8bc0
	.word	3201237057                      # 0xbecf0041
	.word	1070100898                      # 0x3fc871a2
	.word	3176304576                      # 0xbd528fc0
	.word	1060457152                      # 0x3f354ac0
	.word	3211702706                      # 0xbf6eb1b2
	.word	1042711952                      # 0x3e268590
	.word	1056345297                      # 0x3ef68cd1
	.word	1069227264                      # 0x3fbb1d00
	.word	3103911936                      # 0xb901f000
	.size	.L__const.TEST_CASE1.vact, 64

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %x, expected %x.\n"
	.size	.L.str.1, 39

	.type	num_failed,@object              # @num_failed
	.bss
	.globl	num_failed
	.p2align	2, 0x0
num_failed:
	.word	0                               # 0x0
	.size	num_failed, 4

	.type	.L.str.2,@object                # @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"ARA84_INITIAL fcsr=%u vstart=%u\n"
	.size	.L.str.3, 33

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"TEST_CASE1"
	.size	.L.str.4, 11

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"ARA84_FINAL fcsr=%u failures=%u\n"
	.size	.L.str.5, 33

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.6, 28

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"ara84_wrapper.c"
	.size	.L.str.7, 16

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.8, 13

	.type	test_case,@object               # @test_case
	.bss
	.globl	test_case
	.p2align	2, 0x0
test_case:
	.word	0                               # 0x0
	.size	test_case, 4

	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.ascii	"\210\001"                      # DW_AT_alignment
	.byte	15                              # DW_FORM_udata
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	18                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x1e2 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	12                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x6d:0xb DW_TAG_variable
	.word	120                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10005                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x78:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7d:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	33                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x84:0xb DW_TAG_variable
	.word	143                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10006                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	3                               # Abbrev [3] 0x8f:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x94:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x9b:0xb DW_TAG_variable
	.word	120                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10010                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	7                               # Abbrev [7] 0xa6:0xb DW_TAG_variable
	.word	177                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	3                               # Abbrev [3] 0xb1:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xbd:0xb DW_TAG_variable
	.word	200                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	3                               # Abbrev [3] 0xc8:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xcd:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xd4:0xb DW_TAG_variable
	.word	223                             # DW_AT_type
	.byte	2                               # DW_AT_decl_file
	.half	10011                           # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xdf:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xe4:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0xeb:0xd DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	248                             # DW_AT_type
	.byte	4                               # DW_AT_decl_file
	.byte	26                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	3                               # Abbrev [3] 0xf8:0xd DW_TAG_array_type
	.word	261                             # DW_AT_type
	.byte	9                               # Abbrev [9] 0xfd:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x105:0x5 DW_TAG_volatile_type
	.word	266                             # DW_AT_type
	.byte	11                              # Abbrev [11] 0x10a:0x8 DW_TAG_typedef
	.word	274                             # DW_AT_type
	.byte	7                               # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x112:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	12                              # Abbrev [12] 0x116:0xb DW_TAG_variable
	.byte	8                               # DW_AT_name
	.word	289                             # DW_AT_type
                                        # DW_AT_external
	.byte	5                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	10
	.byte	5                               # Abbrev [5] 0x121:0x4 DW_TAG_base_type
	.byte	9                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	12                              # Abbrev [12] 0x125:0xb DW_TAG_variable
	.byte	10                              # DW_AT_name
	.word	289                             # DW_AT_type
                                        # DW_AT_external
	.byte	5                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	13                              # Abbrev [13] 0x130:0x5 DW_TAG_pointer_type
	.word	266                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x135:0x6b DW_TAG_subprogram
	.byte	12                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	11                              # DW_AT_name
	.byte	6                               # DW_AT_decl_file
	.byte	4                               # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	15                              # Abbrev [15] 0x140:0x13 DW_TAG_lexical_block
	.byte	13                              # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x146:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	37                              # DW_AT_decl_line
	.word	469                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x153:0x13 DW_TAG_lexical_block
	.byte	14                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x159:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\364~"
	.byte	14                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	45                              # DW_AT_decl_line
	.word	469                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x166:0x39 DW_TAG_lexical_block
	.byte	15                              # DW_AT_low_pc
	.word	.Ltmp19-.Ltmp7                  # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x16c:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260~"
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.word	481                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x178:0x13 DW_TAG_lexical_block
	.byte	16                              # DW_AT_low_pc
	.word	.Ltmp9-.Ltmp8                   # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x17e:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\360~"
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.word	304                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x18b:0x13 DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp18-.Ltmp10                 # DW_AT_high_pc
	.byte	16                              # Abbrev [16] 0x191:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254~"
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.word	274                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x1a0:0x35 DW_TAG_subprogram
	.byte	18                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	12                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10000                           # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	289                             # DW_AT_type
                                        # DW_AT_external
	.byte	18                              # Abbrev [18] 0x1b0:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	18                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10003                           # DW_AT_decl_line
	.word	274                             # DW_AT_type
	.byte	18                              # Abbrev [18] 0x1bc:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	19                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10003                           # DW_AT_decl_line
	.word	274                             # DW_AT_type
	.byte	18                              # Abbrev [18] 0x1c8:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	20                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	10009                           # DW_AT_decl_line
	.word	274                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x1d5:0xc DW_TAG_array_type
	.word	261                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x1da:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x1e1:0xc DW_TAG_array_type
	.word	266                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x1e6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	16                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	88                              # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/upstream_block_vfsub_TEST_CASE1_e32.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=231
.Linfo_string3:
	.asciz	"char"                          # string offset=283
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=288
.Linfo_string5:
	.asciz	"Ru32"                          # string offset=308
.Linfo_string6:
	.asciz	"unsigned int"                  # string offset=313
.Linfo_string7:
	.asciz	"uint32_t"                      # string offset=326
.Linfo_string8:
	.asciz	"num_failed"                    # string offset=335
.Linfo_string9:
	.asciz	"int"                           # string offset=346
.Linfo_string10:
	.asciz	"test_case"                     # string offset=350
.Linfo_string11:
	.asciz	"TEST_CASE1"                    # string offset=360
.Linfo_string12:
	.asciz	"main"                          # string offset=371
.Linfo_string13:
	.asciz	"Vv2"                           # string offset=376
.Linfo_string14:
	.asciz	"Vv3"                           # string offset=380
.Linfo_string15:
	.asciz	"Ru32_t"                        # string offset=384
.Linfo_string16:
	.asciz	"vact"                          # string offset=391
.Linfo_string17:
	.asciz	"i"                             # string offset=396
.Linfo_string18:
	.asciz	"initial_fcsr"                  # string offset=398
.Linfo_string19:
	.asciz	"initial_vstart"                # string offset=411
.Linfo_string20:
	.asciz	"final_fcsr"                    # string offset=426
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L.str.7
	.word	.L.str.8
	.word	Ru32
	.word	num_failed
	.word	test_case
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Ltmp8
	.word	.Ltmp10
	.word	.Lfunc_begin1
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
