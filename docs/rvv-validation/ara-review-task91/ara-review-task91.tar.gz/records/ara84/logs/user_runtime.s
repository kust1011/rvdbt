	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"user_runtime.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c" md5 0xa1377a764ae01ea2e462845081246e37
	.file	1 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c" md5 0xa1377a764ae01ea2e462845081246e37
	.file	2 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	memcpy                          # -- Begin function memcpy
	.p2align	2
	.type	memcpy,@function
memcpy:                                 # @memcpy
.Lfunc_begin0:
	.loc	1 20 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:20:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
.Ltmp0:
	.loc	1 21 20 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:21:20
	lw	a0, -12(s0)
	.loc	1 21 18 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:21:18
	sw	a0, -24(s0)
	.loc	1 21 49                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:21:49
	lw	a0, -16(s0)
	.loc	1 21 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:21:47
	sw	a0, -28(s0)
.Ltmp1:
	.loc	1 22 17 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:17
	sw	zero, -32(s0)
	.loc	1 22 8 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:8
	j	.LBB0_1
.LBB0_1:                                # =>This Inner Loop Header: Depth=1
.Ltmp2:
	.loc	1 22 22                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:22
	lw	a0, -32(s0)
	.loc	1 22 24                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:24
	lw	a1, -20(s0)
.Ltmp3:
	.loc	1 22 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:3
	bgeu	a0, a1, .LBB0_4
	j	.LBB0_2
.LBB0_2:                                #   in Loop: Header=BB0_1 Depth=1
.Ltmp4:
	.loc	1 22 41                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:41
	lw	a0, -28(s0)
	.loc	1 22 43                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:43
	lw	a1, -32(s0)
	.loc	1 22 41                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:41
	add	a0, a0, a1
	lbu	a0, 0(a0)
	.loc	1 22 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:36
	lw	a2, -24(s0)
	add	a1, a2, a1
	.loc	1 22 40                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:40
	sb	a0, 0(a1)
	.loc	1 22 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:36
	j	.LBB0_3
.LBB0_3:                                #   in Loop: Header=BB0_1 Depth=1
	.loc	1 22 32                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:32
	lw	a0, -32(s0)
	addi	a0, a0, 1
	sw	a0, -32(s0)
	.loc	1 22 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:22:3
	j	.LBB0_1
.Ltmp5:
.LBB0_4:
	.loc	1 23 10 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:23:10
	lw	a0, -12(s0)
	.cfi_def_cfa sp, 32
	.loc	1 23 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:23:3
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp6:
.Lfunc_end0:
	.size	memcpy, .Lfunc_end0-memcpy
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	memset                          # -- Begin function memset
	.p2align	2
	.type	memset,@function
memset:                                 # @memset
.Lfunc_begin1:
	.loc	1 25 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:25:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
.Ltmp7:
	.loc	1 26 20 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:26:20
	lw	a0, -12(s0)
	.loc	1 26 18 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:26:18
	sw	a0, -24(s0)
.Ltmp8:
	.loc	1 27 17 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:17
	sw	zero, -28(s0)
	.loc	1 27 8 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:8
	j	.LBB1_1
.LBB1_1:                                # =>This Inner Loop Header: Depth=1
.Ltmp9:
	.loc	1 27 22                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:22
	lw	a0, -28(s0)
	.loc	1 27 24                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:24
	lw	a1, -20(s0)
.Ltmp10:
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:3
	bgeu	a0, a1, .LBB1_4
	j	.LBB1_2
.LBB1_2:                                #   in Loop: Header=BB1_1 Depth=1
.Ltmp11:
	.loc	1 27 56                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:56
	lw	a0, -16(s0)
	.loc	1 27 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:36
	lw	a1, -24(s0)
	.loc	1 27 38                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:38
	lw	a2, -28(s0)
	.loc	1 27 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:36
	add	a1, a1, a2
	.loc	1 27 40                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:40
	sb	a0, 0(a1)
	.loc	1 27 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:36
	j	.LBB1_3
.LBB1_3:                                #   in Loop: Header=BB1_1 Depth=1
	.loc	1 27 32                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:32
	lw	a0, -28(s0)
	addi	a0, a0, 1
	sw	a0, -28(s0)
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:27:3
	j	.LBB1_1
.Ltmp12:
.LBB1_4:
	.loc	1 28 10 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:28:10
	lw	a0, -12(s0)
	.cfi_def_cfa sp, 32
	.loc	1 28 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:28:3
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp13:
.Lfunc_end1:
	.size	memset, .Lfunc_end1-memset
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	_putchar                        # -- Begin function _putchar
	.p2align	2
	.type	_putchar,@function
_putchar:                               # @_putchar
.Lfunc_begin2:
	.loc	1 39 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:39:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sb	a0, -9(s0)
.Ltmp14:
	.loc	1 40 7 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:40:7
	lui	a0, %hi(used)
	lw	a0, %lo(used)(a0)
	lui	a1, 2
	.loc	1 40 12 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:40:12
	bne	a0, a1, .LBB2_2
	j	.LBB2_1
.LBB2_1:
	.loc	1 40 31                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:40:31
	call	flush
	j	.LBB2_2
.Ltmp15:
.LBB2_2:
	.loc	1 41 20 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:41:20
	lbu	a0, -9(s0)
	.loc	1 41 14 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:41:14
	lui	a1, %hi(used)
	lw	a2, %lo(used)(a1)
	addi	a3, a2, 1
	sw	a3, %lo(used)(a1)
	.loc	1 41 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:41:3
	lui	a1, %hi(output)
	addi	a1, a1, %lo(output)
	add	a1, a1, a2
	.loc	1 41 18                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:41:18
	sb	a0, 0(a1)
	.cfi_def_cfa sp, 16
	.loc	1 42 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:42:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp16:
.Lfunc_end2:
	.size	_putchar, .Lfunc_end2-_putchar
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function flush
	.type	flush,@function
flush:                                  # @flush
.Lfunc_begin3:
	.loc	1 31 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:31:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	li	a0, 1
.Ltmp17:
	.loc	1 32 21 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:32:21
	sw	a0, -12(s0)
	.loc	1 33 24                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:33:24
	lui	a0, %hi(output)
	addi	a0, a0, %lo(output)
	sw	a0, -16(s0)
	.loc	1 34 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:34:36
	lui	a0, %hi(used)
	lw	a1, %lo(used)(a0)
	.loc	1 34 21 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:34:21
	sw	a1, -20(s0)
	li	a1, 64
	.loc	1 35 21 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:35:21
	sw	a1, -24(s0)
.Ltmp18:
	.loc	1 36 7                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:36:7
	lw	a0, %lo(used)(a0)
	beqz	a0, .LBB3_2
	j	.LBB3_1
.LBB3_1:
	.loc	1 36 13 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:36:13
	lw	a0, -12(s0)
	.loc	1 36 51                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:36:51
	lw	a1, -16(s0)
	.loc	1 36 60                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:36:60
	lw	a2, -20(s0)
	.loc	1 36 69                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:36:69
	lw	a7, -24(s0)
	.loc	1 36 13                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:36:13
	#APP
	ecall
	#NO_APP
	sw	a0, -12(s0)
	j	.LBB3_2
.Ltmp19:
.LBB3_2:
	.loc	1 37 8 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:37:8
	lui	a0, %hi(used)
	sw	zero, %lo(used)(a0)
	.cfi_def_cfa sp, 32
	.loc	1 38 1 epilogue_begin           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:38:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp20:
.Lfunc_end3:
	.size	flush, .Lfunc_end3-flush
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_trace_vset                  # -- Begin function ara_trace_vset
	.p2align	2
	.type	ara_trace_vset,@function
ara_trace_vset:                         # @ara_trace_vset
.Lfunc_begin4:
	.loc	1 46 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:46:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
.Ltmp21:
	.loc	1 47 40 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:47:40
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a2, a1, 1
	sw	a2, %lo(.L_MergedGlobals)(a0)
	.loc	1 47 28 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:47:28
	slli	a1, a1, 4
	lui	a0, %hi(vsets)
	addi	a0, a0, %lo(vsets)
	add	a0, a0, a1
	.loc	1 47 23                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:47:23
	sw	a0, -20(s0)
	.loc	1 48 13 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:13
	lw	a0, -12(s0)
	.loc	1 48 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:3
	lw	a1, -20(s0)
	.loc	1 48 11                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:11
	sw	a0, 0(a1)
	.loc	1 48 28                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:28
	lw	a0, -16(s0)
	.loc	1 48 19                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:19
	lw	a1, -20(s0)
	.loc	1 48 26                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:26
	sw	a0, 4(a1)
	.loc	1 48 40                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:40
	lw	a1, -20(s0)
	.loc	1 48 43                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:43
	addi	a0, a1, 8
	.loc	1 48 51                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:51
	addi	a1, a1, 12
	.loc	1 48 33                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:48:33
	call	state
	.cfi_def_cfa sp, 32
	.loc	1 49 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:49:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp22:
.Lfunc_end4:
	.size	ara_trace_vset, .Lfunc_end4-ara_trace_vset
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function state
	.type	state,@function
state:                                  # @state
.Lfunc_begin5:
	.loc	1 43 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:43:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
.Ltmp23:
	.loc	1 44 54 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:44:54
	lw	a0, -12(s0)
	.loc	1 44 65 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:44:65
	lw	a1, -16(s0)
	.loc	1 44 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:44:3
	#APP
	csrr a2, vl
csrr a3, vtype
	#NO_APP
	sw	a2, 0(a0)
	sw	a3, 0(a1)
	.cfi_def_cfa sp, 16
	.loc	1 45 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:45:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp24:
.Lfunc_end5:
	.size	state, .Lfunc_end5-state
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_assert_begin                # -- Begin function ara_assert_begin
	.p2align	2
	.type	ara_assert_begin,@function
ara_assert_begin:                       # @ara_assert_begin
.Lfunc_begin6:
	.loc	1 50 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:50:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
.Ltmp25:
	.loc	1 51 55 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:51:55
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals+4)(a0)
	addi	a2, a1, 1
	sw	a2, %lo(.L_MergedGlobals+4)(a0)
	.loc	1 51 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:51:33
	slli	a0, a1, 2
	slli	a1, a1, 5
	sub	a1, a1, a0
	lui	a0, %hi(assertions)
	addi	a0, a0, %lo(assertions)
	add	a0, a0, a1
	.loc	1 51 28                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:51:28
	sw	a0, -24(s0)
	.loc	1 52 11 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:11
	lw	a0, -12(s0)
	.loc	1 52 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:3
	lw	a1, -24(s0)
	.loc	1 52 9                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:9
	sw	a0, 0(a1)
	.loc	1 52 29                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:29
	lw	a0, -16(s0)
	.loc	1 52 15                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:15
	lw	a1, -24(s0)
	.loc	1 52 27                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:27
	sw	a0, 4(a1)
	.loc	1 52 50                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:50
	lw	a0, -20(s0)
	.loc	1 52 39                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:39
	lw	a1, -24(s0)
	.loc	1 52 48                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:48
	sw	a0, 8(a1)
	.loc	1 52 64                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:64
	lw	a1, -24(s0)
	.loc	1 52 67                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:67
	addi	a0, a1, 12
	.loc	1 52 75                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:75
	addi	a1, a1, 16
	.loc	1 52 57                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:52:57
	call	state
	.cfi_def_cfa sp, 32
	.loc	1 53 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:53:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp26:
.Lfunc_end6:
	.size	ara_assert_begin, .Lfunc_end6-ara_assert_begin
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_compare_step                # -- Begin function ara_compare_step
	.p2align	2
	.type	ara_compare_step,@function
ara_compare_step:                       # @ara_compare_step
.Lfunc_begin7:
	.loc	1 54 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:54:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
.Ltmp27:
	.loc	1 56 14 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:56:14
	lui	a0, %hi(.L_MergedGlobals)
	addi	a1, a0, %lo(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals+4)(a0)
	.loc	1 56 25 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:56:25
	slli	a2, a0, 2
	slli	a0, a0, 5
	sub	a0, a0, a2
	.loc	1 56 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:56:3
	lui	a2, %hi(assertions)
	addi	a2, a2, %lo(assertions)
	add	a0, a0, a2
	.loc	1 56 40                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:56:40
	lw	a2, -8(a0)
	addi	a2, a2, 1
	sw	a2, -8(a0)
	.loc	1 56 56                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:56:56
	lw	a0, 8(a1)
	addi	a0, a0, 1
	sw	a0, 8(a1)
	.cfi_def_cfa sp, 16
	.loc	1 57 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:57:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp28:
.Lfunc_end7:
	.size	ara_compare_step, .Lfunc_end7-ara_compare_step
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_assert_end                  # -- Begin function ara_assert_end
	.p2align	2
	.type	ara_assert_end,@function
ara_assert_end:                         # @ara_assert_end
.Lfunc_begin8:
	.loc	1 58 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:58:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
.Ltmp29:
	.loc	1 59 24 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:59:24
	lui	a0, %hi(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals+4)(a0)
	.loc	1 59 35 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:59:35
	slli	a1, a0, 2
	slli	a0, a0, 5
	sub	a0, a0, a1
	.loc	1 59 13                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:59:13
	lui	a1, %hi(assertions)
	addi	a1, a1, %lo(assertions)
	add	a0, a0, a1
	li	a1, 1
	.loc	1 59 49                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:59:49
	sw	a1, -4(a0)
	.cfi_def_cfa sp, 16
	.loc	1 60 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:60:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp30:
.Lfunc_end8:
	.size	ara_assert_end, .Lfunc_end8-ara_assert_end
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_note_vxsat_read             # -- Begin function ara_note_vxsat_read
	.p2align	2
	.type	ara_note_vxsat_read,@function
ara_note_vxsat_read:                    # @ara_note_vxsat_read
.Lfunc_begin9:
	.loc	1 61 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:61:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
.Ltmp31:
	.loc	1 62 18 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:62:18
	lw	a0, -12(s0)
	.loc	1 62 17 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:62:17
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	sw	a0, 12(a1)
	.loc	1 62 37                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:62:37
	lw	a0, -16(s0)
	.loc	1 62 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:62:36
	sw	a0, 16(a1)
	.loc	1 62 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:62:47
	lw	a0, 20(a1)
	addi	a0, a0, 1
	sw	a0, 20(a1)
	.cfi_def_cfa sp, 16
	.loc	1 63 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:63:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp32:
.Lfunc_end9:
	.size	ara_note_vxsat_read, .Lfunc_end9-ara_note_vxsat_read
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_flag_begin                  # -- Begin function ara_flag_begin
	.p2align	2
	.type	ara_flag_begin,@function
ara_flag_begin:                         # @ara_flag_begin
.Lfunc_begin10:
	.loc	1 64 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:64:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sw	ra, 44(sp)                      # 4-byte Folded Spill
	sw	s0, 40(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 48
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a3, -20(s0)
	sw	a2, -24(s0)
	sw	a5, -28(s0)
	sw	a4, -32(s0)
	sw	a6, -36(s0)
.Ltmp33:
	.loc	1 65 38 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:65:38
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	lw	a1, 24(a0)
	addi	a2, a1, 1
	sw	a2, 24(a0)
	.loc	1 65 26 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:65:26
	slli	a2, a1, 4
	slli	a1, a1, 6
	sub	a1, a1, a2
	add	a1, a0, a1
	addi	a1, a1, 32
	.loc	1 65 23                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:65:23
	sw	a1, -40(s0)
	.loc	1 66 9 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:9
	lw	a1, -12(s0)
	.loc	1 66 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:3
	lw	a2, -40(s0)
	.loc	1 66 8                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:8
	sw	a1, 0(a2)
	.loc	1 66 21                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:21
	lw	a1, -16(s0)
	.loc	1 66 13                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:13
	lw	a2, -40(s0)
	.loc	1 66 20                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:20
	sw	a1, 4(a2)
	.loc	1 66 40                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:40
	lw	a1, 12(a0)
	.loc	1 66 27                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:27
	lw	a2, -40(s0)
	.loc	1 66 39                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:39
	sw	a1, 8(a2)
	.loc	1 66 67                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:67
	lw	a0, 16(a0)
	.loc	1 66 56                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:56
	lw	a1, -40(s0)
	.loc	1 66 66                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:66:66
	sw	a0, 12(a1)
	.loc	1 67 17 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:17
	lw	a0, -36(s0)
	.loc	1 67 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:3
	lw	a1, -40(s0)
	.loc	1 67 16                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:16
	sw	a0, 16(a1)
	.loc	1 67 31                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:31
	lw	a0, -24(s0)
	lw	a1, -20(s0)
	.loc	1 67 21                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:21
	lw	a2, -40(s0)
	.loc	1 67 30                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:30
	sw	a1, 28(a2)
	sw	a0, 24(a2)
	.loc	1 67 51                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:51
	lw	a0, -32(s0)
	lw	a1, -28(s0)
	.loc	1 67 39                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:39
	lw	a2, -40(s0)
	.loc	1 67 50                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:67:50
	sw	a1, 36(a2)
	sw	a0, 32(a2)
	.cfi_def_cfa sp, 48
	.loc	1 68 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:68:1
	lw	ra, 44(sp)                      # 4-byte Folded Reload
	lw	s0, 40(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Ltmp34:
.Lfunc_end10:
	.size	ara_flag_begin, .Lfunc_end10-ara_flag_begin
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_flag_end                    # -- Begin function ara_flag_end
	.p2align	2
	.type	ara_flag_end,@function
ara_flag_end:                           # @ara_flag_end
.Lfunc_begin11:
	.loc	1 69 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:69:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
.Ltmp35:
	.loc	1 70 19 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:70:19
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	lw	a1, 24(a0)
	.loc	1 70 25 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:70:25
	slli	a2, a1, 4
	slli	a1, a1, 6
	sub	a1, a1, a2
	.loc	1 70 13                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:70:13
	add	a0, a1, a0
	li	a1, 1
	.loc	1 70 38                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:70:38
	sw	a1, 24(a0)
	.cfi_def_cfa sp, 16
	.loc	1 71 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:71:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp36:
.Lfunc_end11:
	.size	ara_flag_end, .Lfunc_end11-ara_flag_end
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_scalar_begin                # -- Begin function ara_scalar_begin
	.p2align	2
	.type	ara_scalar_begin,@function
ara_scalar_begin:                       # @ara_scalar_begin
.Lfunc_begin12:
	.loc	1 72 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:72:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sw	ra, 44(sp)                      # 4-byte Folded Spill
	sw	s0, 40(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 48
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a3, -20(s0)
	sw	a2, -24(s0)
	sw	a5, -28(s0)
	sw	a4, -32(s0)
	sw	a6, -36(s0)
.Ltmp37:
	.loc	1 73 44 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:73:44
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	lw	a1, 28(a0)
	addi	a2, a1, 1
	sw	a2, 28(a0)
	.loc	1 73 28 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:73:28
	slli	a0, a1, 4
	slli	a1, a1, 6
	sub	a1, a1, a0
	lui	a0, %hi(scalars)
	addi	a0, a0, %lo(scalars)
	add	a0, a0, a1
	.loc	1 73 25                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:73:25
	sw	a0, -40(s0)
	.loc	1 74 9 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:9
	lw	a0, -12(s0)
	.loc	1 74 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:3
	lw	a1, -40(s0)
	.loc	1 74 8                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:8
	sw	a0, 0(a1)
	.loc	1 74 21                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:21
	lw	a0, -16(s0)
	.loc	1 74 13                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:13
	lw	a1, -40(s0)
	.loc	1 74 20                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:20
	sw	a0, 4(a1)
	.loc	1 74 37                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:37
	lw	a0, -24(s0)
	lw	a1, -20(s0)
	.loc	1 74 27                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:27
	lw	a2, -40(s0)
	.loc	1 74 36                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:36
	sw	a1, 28(a2)
	sw	a0, 24(a2)
	.loc	1 74 57                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:57
	lw	a0, -32(s0)
	lw	a1, -28(s0)
	.loc	1 74 45                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:45
	lw	a2, -40(s0)
	.loc	1 74 56                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:56
	sw	a1, 36(a2)
	sw	a0, 32(a2)
	.loc	1 74 81                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:81
	lw	a0, -36(s0)
	.loc	1 74 67                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:67
	lw	a1, -40(s0)
	.loc	1 74 80                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:74:80
	sw	a0, 8(a1)
	.loc	1 75 10 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:75:10
	lw	a1, -40(s0)
	.loc	1 75 13 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:75:13
	addi	a0, a1, 12
	.loc	1 75 20                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:75:20
	addi	a1, a1, 16
	.loc	1 75 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:75:3
	call	state
	.cfi_def_cfa sp, 48
	.loc	1 76 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:76:1
	lw	ra, 44(sp)                      # 4-byte Folded Reload
	lw	s0, 40(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Ltmp38:
.Lfunc_end12:
	.size	ara_scalar_begin, .Lfunc_end12-ara_scalar_begin
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_scalar_end                  # -- Begin function ara_scalar_end
	.p2align	2
	.type	ara_scalar_end,@function
ara_scalar_end:                         # @ara_scalar_end
.Lfunc_begin13:
	.loc	1 77 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:77:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
.Ltmp39:
	.loc	1 78 21 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:78:21
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	lw	a0, 28(a0)
	.loc	1 78 29 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:78:29
	slli	a1, a0, 4
	slli	a0, a0, 6
	sub	a0, a0, a1
	.loc	1 78 13                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:78:13
	lui	a1, %hi(scalars)
	addi	a1, a1, %lo(scalars)
	add	a0, a0, a1
	li	a1, 1
	.loc	1 78 42                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:78:42
	sw	a1, -8(a0)
	.cfi_def_cfa sp, 16
	.loc	1 79 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:79:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp40:
.Lfunc_end13:
	.size	ara_scalar_end, .Lfunc_end13-ara_scalar_end
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_case_begin                  # -- Begin function ara_case_begin
	.p2align	2
	.type	ara_case_begin,@function
ara_case_begin:                         # @ara_case_begin
.Lfunc_begin14:
	.loc	1 80 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:80:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
.Ltmp41:
	.loc	1 81 69 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:81:69
	lw	a1, -12(s0)
	.loc	1 81 74 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:81:74
	lui	a0, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(a0)
	addi	a4, a0, %lo(.L_MergedGlobals)
	.loc	1 81 81                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:81:81
	lw	a3, %lo(.L_MergedGlobals+4)(a0)
	.loc	1 81 93                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:81:93
	lw	a4, 8(a4)
	.loc	1 81 2                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:81:2
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	call	printf_
	.cfi_def_cfa sp, 16
	.loc	1 82 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:82:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp42:
.Lfunc_end14:
	.size	ara_case_begin, .Lfunc_end14-ara_case_begin
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_case_end                    # -- Begin function ara_case_end
	.p2align	2
	.type	ara_case_end,@function
ara_case_end:                           # @ara_case_end
.Lfunc_begin15:
	.loc	1 83 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:83:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
.Ltmp43:
	.loc	1 84 79 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:84:79
	lw	a1, -12(s0)
	.loc	1 84 84 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:84:84
	lw	a2, -16(s0)
	.loc	1 84 93                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:84:93
	lui	a0, %hi(.L_MergedGlobals)
	lw	a3, %lo(.L_MergedGlobals)(a0)
	addi	a5, a0, %lo(.L_MergedGlobals)
	.loc	1 84 100                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:84:100
	lw	a4, %lo(.L_MergedGlobals+4)(a0)
	.loc	1 84 112                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:84:112
	lw	a5, 8(a5)
	.loc	1 84 2                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:84:2
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	.cfi_def_cfa sp, 16
	.loc	1 85 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:85:1
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp44:
.Lfunc_end15:
	.size	ara_case_end, .Lfunc_end15-ara_case_end
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	ara_finish                      # -- Begin function ara_finish
	.p2align	2
	.type	ara_finish,@function
ara_finish:                             # @ara_finish
.Lfunc_begin16:
	.loc	1 86 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:86:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -80
	.cfi_def_cfa_offset 80
	sw	ra, 76(sp)                      # 4-byte Folded Spill
	sw	s0, 72(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 80
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
.Ltmp45:
	.loc	1 87 17 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:17
	sw	zero, -16(s0)
	.loc	1 87 8 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:8
	j	.LBB16_1
.LBB16_1:                               # =>This Inner Loop Header: Depth=1
.Ltmp46:
	.loc	1 87 22                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:22
	lw	a0, -16(s0)
	.loc	1 87 24                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:24
	lui	a1, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a1)
.Ltmp47:
	.loc	1 87 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:3
	bgeu	a0, a1, .LBB16_4
	j	.LBB16_2
.LBB16_2:                               #   in Loop: Header=BB16_1 Depth=1
.Ltmp48:
	.loc	1 88 34 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:88:34
	lw	a0, -16(s0)
	.loc	1 88 28 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:88:28
	slli	a0, a0, 4
	lui	a1, %hi(vsets)
	addi	a1, a1, %lo(vsets)
	add	a0, a1, a0
	.loc	1 88 25                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:88:25
	sw	a0, -20(s0)
	.loc	1 89 55 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:89:55
	lw	a0, -20(s0)
	.loc	1 89 58 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:89:58
	lw	a1, 0(a0)
	.loc	1 89 66                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:89:66
	lw	a2, 4(a0)
	.loc	1 89 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:89:73
	lw	a3, 8(a0)
	.loc	1 89 79                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:89:79
	lw	a4, 12(a0)
	.loc	1 89 5                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:89:5
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	.loc	1 90 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:90:3
	j	.LBB16_3
.Ltmp49:
.LBB16_3:                               #   in Loop: Header=BB16_1 Depth=1
	.loc	1 87 33                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:33
	lw	a0, -16(s0)
	addi	a0, a0, 1
	sw	a0, -16(s0)
	.loc	1 87 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:87:3
	j	.LBB16_1
.Ltmp50:
.LBB16_4:
	.loc	1 91 17 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:17
	sw	zero, -24(s0)
	.loc	1 91 8 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:8
	j	.LBB16_5
.LBB16_5:                               # =>This Inner Loop Header: Depth=1
.Ltmp51:
	.loc	1 91 22                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:22
	lw	a0, -24(s0)
	.loc	1 91 24                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:24
	lui	a1, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals+4)(a1)
.Ltmp52:
	.loc	1 91 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:3
	bgeu	a0, a1, .LBB16_8
	j	.LBB16_6
.LBB16_6:                               #   in Loop: Header=BB16_5 Depth=1
.Ltmp53:
	.loc	1 92 44 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:92:44
	lw	a0, -24(s0)
	.loc	1 92 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:92:33
	slli	a1, a0, 2
	slli	a0, a0, 5
	sub	a0, a0, a1
	lui	a1, %hi(assertions)
	addi	a1, a1, %lo(assertions)
	add	a0, a1, a0
	.loc	1 92 30                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:92:30
	sw	a0, -28(s0)
	.loc	1 94 12 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:12
	lw	a0, -28(s0)
	.loc	1 94 15 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:15
	lw	a1, 0(a0)
	.loc	1 94 21                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:21
	lw	a2, 4(a0)
	.loc	1 94 33                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:33
	lw	a3, 8(a0)
	.loc	1 94 42                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:42
	lw	a4, 12(a0)
	.loc	1 94 48                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:48
	lw	a5, 16(a0)
	.loc	1 94 57                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:57
	lw	a6, 20(a0)
	.loc	1 94 72                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:72
	lw	a7, 24(a0)
	.loc	1 94 82                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:82
	lw	a0, -24(s0)
	.loc	1 94 83                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:94:83
	addi	a0, a0, 1
	.loc	1 93 5 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:93:5
	sw	a0, 0(sp)
	lui	a0, %hi(.L.str.3)
	addi	a0, a0, %lo(.L.str.3)
	call	printf_
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:95:3
	j	.LBB16_7
.Ltmp54:
.LBB16_7:                               #   in Loop: Header=BB16_5 Depth=1
	.loc	1 91 38                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:38
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	1 91 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:91:3
	j	.LBB16_5
.Ltmp55:
.LBB16_8:
	.loc	1 96 74 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:96:74
	lw	a1, -12(s0)
	.loc	1 96 81 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:96:81
	lui	a0, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(a0)
	addi	a4, a0, %lo(.L_MergedGlobals)
	.loc	1 96 88                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:96:88
	lw	a3, %lo(.L_MergedGlobals+4)(a0)
	.loc	1 96 100                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:96:100
	lw	a4, 8(a4)
	.loc	1 96 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:96:3
	lui	a0, %hi(.L.str.4)
	addi	a0, a0, %lo(.L.str.4)
	call	printf_
	.loc	1 97 12 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:97:12
	sw	zero, -32(s0)
.Ltmp56:
	.loc	1 98 16                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:16
	sw	zero, -36(s0)
	.loc	1 98 7 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:7
	j	.LBB16_9
.LBB16_9:                               # =>This Inner Loop Header: Depth=1
.Ltmp57:
	.loc	1 98 20                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:20
	lw	a0, -36(s0)
	.loc	1 98 22                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:22
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	lw	a1, 24(a1)
.Ltmp58:
	.loc	1 98 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:3
	bgeu	a0, a1, .LBB16_12
	j	.LBB16_10
.LBB16_10:                              #   in Loop: Header=BB16_9 Depth=1
.Ltmp59:
	.loc	1 99 34 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:99:34
	lw	a0, -36(s0)
	.loc	1 99 28 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:99:28
	slli	a1, a0, 4
	slli	a0, a0, 6
	sub	a0, a0, a1
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	add	a0, a1, a0
	addi	a0, a0, 32
	.loc	1 99 25                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:99:25
	sw	a0, -40(s0)
	.loc	1 99 55                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:99:55
	lw	a0, -40(s0)
	.loc	1 99 58                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:99:58
	lw	a0, 40(a0)
	.loc	1 99 53                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:99:53
	lw	a1, -32(s0)
	add	a0, a1, a0
	sw	a0, -32(s0)
	.loc	1 101 12 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:12
	lw	a0, -40(s0)
	.loc	1 101 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:15
	lw	a1, 0(a0)
	.loc	1 101 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:21
	lw	a2, 4(a0)
	.loc	1 101 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:29
	lw	a3, 8(a0)
	.loc	1 101 42                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:42
	lw	a4, 12(a0)
	.loc	1 101 53                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:53
	lw	a5, 16(a0)
	.loc	1 101 77                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:101:77
	lw	a7, 28(a0)
	lw	a6, 24(a0)
	.loc	1 102 25 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:102:25
	lw	t0, 32(a0)
	lw	t1, 36(a0)
	.loc	1 102 65 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:102:65
	lw	a0, 40(a0)
	.loc	1 102 75                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:102:75
	lw	t2, -36(s0)
	.loc	1 102 76                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:102:76
	addi	t2, t2, 1
	.loc	1 100 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:100:5
	sw	t2, 12(sp)
	sw	a0, 8(sp)
	sw	t1, 4(sp)
	sw	t0, 0(sp)
	lui	a0, %hi(.L.str.5)
	addi	a0, a0, %lo(.L.str.5)
	call	printf_
	.loc	1 103 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:103:3
	j	.LBB16_11
.Ltmp60:
.LBB16_11:                              #   in Loop: Header=BB16_9 Depth=1
	.loc	1 98 30                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:30
	lw	a0, -36(s0)
	addi	a0, a0, 1
	sw	a0, -36(s0)
	.loc	1 98 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:98:3
	j	.LBB16_9
.Ltmp61:
.LBB16_12:
	.loc	1 104 77 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:104:77
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	lw	a1, 20(a0)
	.loc	1 104 84 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:104:84
	lw	a2, 24(a0)
	.loc	1 104 91                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:104:91
	lw	a3, -32(s0)
	.loc	1 104 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:104:3
	lui	a0, %hi(.L.str.6)
	addi	a0, a0, %lo(.L.str.6)
	mv	a4, a2
	call	printf_
	.loc	1 105 12 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:105:12
	sw	zero, -44(s0)
.Ltmp62:
	.loc	1 106 16                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:16
	sw	zero, -48(s0)
	.loc	1 106 7 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:7
	j	.LBB16_13
.LBB16_13:                              # =>This Inner Loop Header: Depth=1
.Ltmp63:
	.loc	1 106 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:20
	lw	a0, -48(s0)
	.loc	1 106 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:22
	lui	a1, %hi(.L_MergedGlobals)
	addi	a1, a1, %lo(.L_MergedGlobals)
	lw	a1, 28(a1)
.Ltmp64:
	.loc	1 106 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:3
	bgeu	a0, a1, .LBB16_16
	j	.LBB16_14
.LBB16_14:                              #   in Loop: Header=BB16_13 Depth=1
.Ltmp65:
	.loc	1 107 38 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:107:38
	lw	a0, -48(s0)
	.loc	1 107 30 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:107:30
	slli	a1, a0, 4
	slli	a0, a0, 6
	sub	a0, a0, a1
	lui	a1, %hi(scalars)
	addi	a1, a1, %lo(scalars)
	add	a0, a1, a0
	.loc	1 107 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:107:27
	sw	a0, -52(s0)
	.loc	1 107 61                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:107:61
	lw	a0, -52(s0)
	.loc	1 107 64                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:107:64
	lw	a0, 40(a0)
	.loc	1 107 59                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:107:59
	lw	a1, -44(s0)
	add	a0, a1, a0
	sw	a0, -44(s0)
	.loc	1 109 12 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:12
	lw	a0, -52(s0)
	.loc	1 109 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:15
	lw	a1, 0(a0)
	.loc	1 109 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:21
	lw	a2, 4(a0)
	.loc	1 109 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:29
	lw	a3, 8(a0)
	.loc	1 109 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:43
	lw	a4, 12(a0)
	.loc	1 109 49                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:49
	lw	a5, 16(a0)
	.loc	1 109 68                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:109:68
	lw	a7, 28(a0)
	lw	a6, 24(a0)
	.loc	1 110 25 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:110:25
	lw	t0, 32(a0)
	lw	t1, 36(a0)
	.loc	1 110 65 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:110:65
	lw	a0, 40(a0)
	.loc	1 110 75                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:110:75
	lw	t2, -48(s0)
	.loc	1 110 76                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:110:76
	addi	t2, t2, 1
	.loc	1 108 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:108:5
	sw	t2, 12(sp)
	sw	a0, 8(sp)
	sw	t1, 4(sp)
	sw	t0, 0(sp)
	lui	a0, %hi(.L.str.7)
	addi	a0, a0, %lo(.L.str.7)
	call	printf_
	.loc	1 111 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:111:3
	j	.LBB16_15
.Ltmp66:
.LBB16_15:                              #   in Loop: Header=BB16_13 Depth=1
	.loc	1 106 32                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:32
	lw	a0, -48(s0)
	addi	a0, a0, 1
	sw	a0, -48(s0)
	.loc	1 106 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:106:3
	j	.LBB16_13
.Ltmp67:
.LBB16_16:
	.loc	1 112 72 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:112:72
	lui	a0, %hi(.L_MergedGlobals)
	addi	a0, a0, %lo(.L_MergedGlobals)
	lw	a1, 28(a0)
	.loc	1 112 81 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:112:81
	lw	a2, -44(s0)
	.loc	1 112 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:112:3
	lui	a0, %hi(.L.str.8)
	addi	a0, a0, %lo(.L.str.8)
	mv	a3, a1
	call	printf_
	.loc	1 113 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:113:3
	call	flush
	.loc	1 114 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:114:34
	lw	a0, -12(s0)
	.loc	1 114 21 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:114:21
	sw	a0, -56(s0)
	li	a0, 93
	.loc	1 115 21 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:115:21
	sw	a0, -60(s0)
	.loc	1 116 32                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:116:32
	lw	a0, -56(s0)
	.loc	1 116 40 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:116:40
	lw	a7, -60(s0)
	.loc	1 116 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c:116:3
	#APP
	ecall
	#NO_APP
.Ltmp68:
.Lfunc_end16:
	.size	ara_finish, .Lfunc_end16-ara_finish
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	used,@object                    # @used
	.local	used
	.comm	used,4,4
	.type	output,@object                  # @output
	.local	output
	.comm	output,8192,1
	.type	vsets,@object                   # @vsets
	.local	vsets
	.comm	vsets,2048,4
	.type	assertions,@object              # @assertions
	.local	assertions
	.comm	assertions,7168,4
	.type	scalars,@object                 # @scalars
	.local	scalars
	.comm	scalars,1536,8
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"ARA_CASE_BEGIN %s vsets=%u assertions=%u comparisons=%u\n"
	.size	.L.str, 57

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"ARA_CASE_END %s failures=%u vsets=%u assertions=%u comparisons=%u\n"
	.size	.L.str.1, 67

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"ARA_VSET line=%u avl=%u vl=%u vtype=%u\n"
	.size	.L.str.2, 40

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"ARA_ASSERT id=%u elements=%u bytes=%u vl=%u vtype=%u comparisons=%u completed=%u sequence=%u\n"
	.size	.L.str.3, 94

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"ARA_SUMMARY status=%u vsets=%u assertions=%u comparisons=%u\n"
	.size	.L.str.4, 61

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"ARA_FLAG id=%u line=%u read_line=%u read_pc=%u checker_pc=%u actual_lo=%u actual_hi=%u expected_lo=%u expected_hi=%u compared=1 completed=%u sequence=%u\n"
	.size	.L.str.5, 154

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"ARA_FLAG_SUMMARY reads=%u flags=%u completed=%u comparisons=%u\n"
	.size	.L.str.6, 64

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"ARA_SCALAR id=%u line=%u checker_pc=%u vl=%u vtype=%u actual_lo=%u actual_hi=%u expected_lo=%u expected_hi=%u compared=1 completed=%u sequence=%u\n"
	.size	.L.str.7, 147

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"ARA_SCALAR_SUMMARY scalars=%u completed=%u comparisons=%u\n"
	.size	.L.str.8, 59

	.type	.L_MergedGlobals,@object        # @_MergedGlobals
	.local	.L_MergedGlobals
	.comm	.L_MergedGlobals,1568,8
.set nvsets, .L_MergedGlobals
	.size	nvsets, 4
.set nassertions, .L_MergedGlobals+4
	.size	nassertions, 4
.set ncomparisons, .L_MergedGlobals+8
	.size	ncomparisons, 4
.set last_read_line, .L_MergedGlobals+12
	.size	last_read_line, 4
.set last_read_pc, .L_MergedGlobals+16
	.size	last_read_pc, 4
.set nreads, .L_MergedGlobals+20
	.size	nreads, 4
.set nflags, .L_MergedGlobals+24
	.size	nflags, 4
.set nscalars, .L_MergedGlobals+28
	.size	nscalars, 4
.set flags, .L_MergedGlobals+32
	.size	flags, 1536
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	19                              # DW_TAG_structure_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	13                              # DW_TAG_member
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	56                              # DW_AT_data_member_location
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	5                               # DW_TAG_formal_parameter
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	18                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.ascii	"\207\001"                      # DW_AT_noreturn
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	19                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	20                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	21                              # Abbreviation Code
	.byte	38                              # DW_TAG_const_type
	.byte	0                               # DW_CHILDREN_no
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	22                              # Abbreviation Code
	.byte	38                              # DW_TAG_const_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	23                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x6e1 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	15                              # DW_AT_low_pc
	.word	.Lfunc_end16-.Lfunc_begin0      # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	81                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	57                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	84                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	67                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	89                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	40                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x6d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	93                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x77:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	94                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x83:0xa DW_TAG_variable
	.word	141                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	96                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	3                               # Abbrev [3] 0x8d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x92:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	61                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x99:0xa DW_TAG_variable
	.word	163                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	100                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	3                               # Abbrev [3] 0xa3:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xa8:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	154                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xaf:0xa DW_TAG_variable
	.word	185                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	104                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	3                               # Abbrev [3] 0xb9:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbe:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	64                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xc5:0xa DW_TAG_variable
	.word	207                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	108                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	3                               # Abbrev [3] 0xcf:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xd4:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	147                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xdb:0xa DW_TAG_variable
	.word	229                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	112                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xe5:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xea:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	59                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xf1:0xb DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	252                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	8                               # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	3                               # Abbrev [3] 0xfc:0xc DW_TAG_array_type
	.word	264                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x101:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	128                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0x108:0x2a DW_TAG_structure_type
	.byte	11                              # DW_AT_name
	.byte	16                              # DW_AT_byte_size
	.byte	1                               # DW_AT_decl_file
	.byte	6                               # DW_AT_decl_line
	.byte	9                               # Abbrev [9] 0x10d:0x9 DW_TAG_member
	.byte	6                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	6                               # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x116:0x9 DW_TAG_member
	.byte	8                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	6                               # DW_AT_decl_line
	.byte	4                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x11f:0x9 DW_TAG_member
	.byte	9                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	6                               # DW_AT_decl_line
	.byte	8                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x128:0x9 DW_TAG_member
	.byte	10                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	6                               # DW_AT_decl_line
	.byte	12                              # DW_AT_data_member_location
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x132:0x4 DW_TAG_base_type
	.byte	7                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x136:0xb DW_TAG_variable
	.byte	12                              # DW_AT_name
	.word	321                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	9                               # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	10
	.byte	3                               # Abbrev [3] 0x141:0xd DW_TAG_array_type
	.word	334                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x146:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	256                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0x14e:0x45 DW_TAG_structure_type
	.byte	18                              # DW_AT_name
	.byte	28                              # DW_AT_byte_size
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	9                               # Abbrev [9] 0x153:0x9 DW_TAG_member
	.byte	13                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x15c:0x9 DW_TAG_member
	.byte	14                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	4                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x165:0x9 DW_TAG_member
	.byte	15                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	8                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x16e:0x9 DW_TAG_member
	.byte	9                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	12                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x177:0x9 DW_TAG_member
	.byte	10                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	16                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x180:0x9 DW_TAG_member
	.byte	16                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	20                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x189:0x9 DW_TAG_member
	.byte	17                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	7                               # DW_AT_decl_line
	.byte	24                              # DW_AT_data_member_location
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x193:0xb DW_TAG_variable
	.byte	19                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	7                               # Abbrev [7] 0x19e:0xd DW_TAG_variable
	.byte	20                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	4
	.byte	7                               # Abbrev [7] 0x1ab:0xd DW_TAG_variable
	.byte	21                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	8
	.byte	7                               # Abbrev [7] 0x1b8:0xd DW_TAG_variable
	.byte	22                              # DW_AT_name
	.word	453                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	32
	.byte	3                               # Abbrev [3] 0x1c5:0xc DW_TAG_array_type
	.word	465                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x1ca:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	32                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0x1d1:0x4e DW_TAG_structure_type
	.byte	30                              # DW_AT_name
	.byte	48                              # DW_AT_byte_size
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	9                               # Abbrev [9] 0x1d6:0x9 DW_TAG_member
	.byte	13                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x1df:0x9 DW_TAG_member
	.byte	6                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	4                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x1e8:0x9 DW_TAG_member
	.byte	23                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	8                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x1f1:0x9 DW_TAG_member
	.byte	24                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	12                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x1fa:0x9 DW_TAG_member
	.byte	25                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	16                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x203:0x9 DW_TAG_member
	.byte	26                              # DW_AT_name
	.word	543                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	24                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x20c:0x9 DW_TAG_member
	.byte	29                              # DW_AT_name
	.word	543                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	32                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x215:0x9 DW_TAG_member
	.byte	17                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	11                              # DW_AT_decl_line
	.byte	40                              # DW_AT_data_member_location
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x21f:0x8 DW_TAG_typedef
	.word	551                             # DW_AT_type
	.byte	28                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x227:0x4 DW_TAG_base_type
	.byte	27                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0x22b:0xd DW_TAG_variable
	.byte	31                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	24
	.byte	7                               # Abbrev [7] 0x238:0xd DW_TAG_variable
	.byte	32                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	20
	.byte	7                               # Abbrev [7] 0x245:0xd DW_TAG_variable
	.byte	33                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	12
	.byte	7                               # Abbrev [7] 0x252:0xd DW_TAG_variable
	.byte	34                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	16
	.byte	7                               # Abbrev [7] 0x25f:0xb DW_TAG_variable
	.byte	35                              # DW_AT_name
	.word	618                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	12
	.byte	3                               # Abbrev [3] 0x26a:0xc DW_TAG_array_type
	.word	630                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x26f:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	32                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0x276:0x4e DW_TAG_structure_type
	.byte	36                              # DW_AT_name
	.byte	48                              # DW_AT_byte_size
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	9                               # Abbrev [9] 0x27b:0x9 DW_TAG_member
	.byte	13                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x284:0x9 DW_TAG_member
	.byte	6                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	4                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x28d:0x9 DW_TAG_member
	.byte	25                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	8                               # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x296:0x9 DW_TAG_member
	.byte	9                               # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	12                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x29f:0x9 DW_TAG_member
	.byte	10                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	16                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x2a8:0x9 DW_TAG_member
	.byte	26                              # DW_AT_name
	.word	543                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	24                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x2b1:0x9 DW_TAG_member
	.byte	29                              # DW_AT_name
	.word	543                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	32                              # DW_AT_data_member_location
	.byte	9                               # Abbrev [9] 0x2ba:0x9 DW_TAG_member
	.byte	17                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.byte	40                              # DW_AT_data_member_location
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x2c4:0xd DW_TAG_variable
	.byte	37                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	16                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	11
	.byte	35
	.byte	28
	.byte	7                               # Abbrev [7] 0x2d1:0xb DW_TAG_variable
	.byte	38                              # DW_AT_name
	.word	732                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	17                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	13
	.byte	3                               # Abbrev [3] 0x2dc:0xd DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	10                              # Abbrev [10] 0x2e1:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	8192                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0x2e9:0xb DW_TAG_variable
	.byte	39                              # DW_AT_name
	.word	306                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	18                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	14
	.byte	5                               # Abbrev [5] 0x2f4:0x4 DW_TAG_base_type
	.byte	40                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	12                              # Abbrev [12] 0x2f8:0x59 DW_TAG_subprogram
	.byte	15                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	41                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	1702                            # DW_AT_type
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x307:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	58                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.word	1702                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x312:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	59                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.word	1703                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x31d:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	60                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x328:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	61                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	1709                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x333:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	62                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	1714                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x33e:0x12 DW_TAG_lexical_block
	.byte	16                              # DW_AT_low_pc
	.word	.Ltmp5-.Ltmp1                   # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x344:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	63                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	22                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	12                              # Abbrev [12] 0x351:0x4e DW_TAG_subprogram
	.byte	17                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	42                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	1702                            # DW_AT_type
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x360:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	58                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	1702                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x36b:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	64                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	1724                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x376:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	60                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x381:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	61                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	26                              # DW_AT_decl_line
	.word	1709                            # DW_AT_type
	.byte	15                              # Abbrev [15] 0x38c:0x12 DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp12-.Ltmp8                  # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x392:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	63                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x39f:0x17 DW_TAG_subprogram
	.byte	19                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin2       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	43                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	39                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x3aa:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	119
	.byte	66                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	39                              # DW_AT_decl_line
	.word	57                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x3b6:0x38 DW_TAG_subprogram
	.byte	20                              # DW_AT_low_pc
	.word	.Lfunc_end3-.Lfunc_begin3       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	44                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	31                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.byte	14                              # Abbrev [14] 0x3c1:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	67                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	32                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x3cc:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	68                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	33                              # DW_AT_decl_line
	.word	1728                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x3d7:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	69                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	34                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x3e2:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	70                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	35                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x3ee:0x2d DW_TAG_subprogram
	.byte	21                              # DW_AT_low_pc
	.word	.Lfunc_end4-.Lfunc_begin4       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	45                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x3f9:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	6                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x404:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	8                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x40f:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	47                              # DW_AT_decl_line
	.word	1738                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x41b:0x22 DW_TAG_subprogram
	.byte	22                              # DW_AT_low_pc
	.word	.Lfunc_end5-.Lfunc_begin5       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	46                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	43                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.byte	13                              # Abbrev [13] 0x426:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	9                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	43                              # DW_AT_decl_line
	.word	1743                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x431:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	72                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	43                              # DW_AT_decl_line
	.word	1743                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x43d:0x38 DW_TAG_subprogram
	.byte	23                              # DW_AT_low_pc
	.word	.Lfunc_end6-.Lfunc_begin6       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	47                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x448:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x453:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	14                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x45e:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x469:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	51                              # DW_AT_decl_line
	.word	1748                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x475:0x22 DW_TAG_subprogram
	.byte	24                              # DW_AT_low_pc
	.word	.Lfunc_end7-.Lfunc_begin7       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	48                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	54                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x480:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	54                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x48b:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	73                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	54                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x497:0x17 DW_TAG_subprogram
	.byte	25                              # DW_AT_low_pc
	.word	.Lfunc_end8-.Lfunc_begin8       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	49                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	58                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x4a2:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	58                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x4ae:0x22 DW_TAG_subprogram
	.byte	26                              # DW_AT_low_pc
	.word	.Lfunc_end9-.Lfunc_begin9       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	50                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	61                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x4b9:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	6                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	61                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x4c4:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	74                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	61                              # DW_AT_decl_line
	.word	1753                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x4d0:0x4e DW_TAG_subprogram
	.byte	27                              # DW_AT_low_pc
	.word	.Lfunc_end10-.Lfunc_begin10     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	51                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x4db:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x4e6:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	6                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x4f1:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	543                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x4fc:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	543                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x507:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	74                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	64                              # DW_AT_decl_line
	.word	1753                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x512:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	65                              # DW_AT_decl_line
	.word	1762                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x51e:0x17 DW_TAG_subprogram
	.byte	28                              # DW_AT_low_pc
	.word	.Lfunc_end11-.Lfunc_begin11     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	52                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	69                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x529:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	69                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x535:0x4e DW_TAG_subprogram
	.byte	29                              # DW_AT_low_pc
	.word	.Lfunc_end12-.Lfunc_begin12     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	53                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x540:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x54b:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	6                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x556:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	26                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
	.word	543                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x561:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	29                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
	.word	543                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x56c:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	74                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	72                              # DW_AT_decl_line
	.word	1753                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x577:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	73                              # DW_AT_decl_line
	.word	1767                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x583:0x17 DW_TAG_subprogram
	.byte	30                              # DW_AT_low_pc
	.word	.Lfunc_end13-.Lfunc_begin13     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	54                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	77                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x58e:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	77                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x59a:0x17 DW_TAG_subprogram
	.byte	31                              # DW_AT_low_pc
	.word	.Lfunc_end14-.Lfunc_begin14     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	55                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	80                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x5a5:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	76                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	80                              # DW_AT_decl_line
	.word	1728                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x5b1:0x22 DW_TAG_subprogram
	.byte	32                              # DW_AT_low_pc
	.word	.Lfunc_end15-.Lfunc_begin15     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	56                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	83                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	13                              # Abbrev [13] 0x5bc:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	76                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	83                              # DW_AT_decl_line
	.word	1728                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x5c7:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	77                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	83                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	18                              # Abbrev [18] 0x5d3:0xd3 DW_TAG_subprogram
	.byte	33                              # DW_AT_low_pc
	.word	.Lfunc_end16-.Lfunc_begin16     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	57                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	86                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
                                        # DW_AT_noreturn
	.byte	13                              # Abbrev [13] 0x5de:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	78                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	86                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x5e9:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	79                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	97                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x5f4:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	80                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	105                             # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x5ff:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	72
	.byte	67                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	114                             # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x60a:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	70                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	115                             # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x615:0x24 DW_TAG_lexical_block
	.byte	34                              # DW_AT_low_pc
	.word	.Ltmp50-.Ltmp45                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x61b:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	63                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	87                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x626:0x12 DW_TAG_lexical_block
	.byte	35                              # DW_AT_low_pc
	.word	.Ltmp49-.Ltmp48                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x62c:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	88                              # DW_AT_decl_line
	.word	1738                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x639:0x24 DW_TAG_lexical_block
	.byte	36                              # DW_AT_low_pc
	.word	.Ltmp55-.Ltmp50                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x63f:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	63                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	91                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x64a:0x12 DW_TAG_lexical_block
	.byte	37                              # DW_AT_low_pc
	.word	.Ltmp54-.Ltmp53                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x650:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	92                              # DW_AT_decl_line
	.word	1748                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x65d:0x24 DW_TAG_lexical_block
	.byte	38                              # DW_AT_low_pc
	.word	.Ltmp61-.Ltmp56                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x663:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	63                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	98                              # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x66e:0x12 DW_TAG_lexical_block
	.byte	39                              # DW_AT_low_pc
	.word	.Ltmp60-.Ltmp59                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x674:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	99                              # DW_AT_decl_line
	.word	1762                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0x681:0x24 DW_TAG_lexical_block
	.byte	40                              # DW_AT_low_pc
	.word	.Ltmp67-.Ltmp62                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x687:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	63                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	106                             # DW_AT_decl_line
	.word	306                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x692:0x12 DW_TAG_lexical_block
	.byte	41                              # DW_AT_low_pc
	.word	.Ltmp66-.Ltmp65                 # DW_AT_high_pc
	.byte	14                              # Abbrev [14] 0x698:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	76
	.byte	71                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	107                             # DW_AT_decl_line
	.word	1767                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	19                              # Abbrev [19] 0x6a6:0x1 DW_TAG_pointer_type
	.byte	20                              # Abbrev [20] 0x6a7:0x5 DW_TAG_pointer_type
	.word	1708                            # DW_AT_type
	.byte	21                              # Abbrev [21] 0x6ac:0x1 DW_TAG_const_type
	.byte	20                              # Abbrev [20] 0x6ad:0x5 DW_TAG_pointer_type
	.word	756                             # DW_AT_type
	.byte	20                              # Abbrev [20] 0x6b2:0x5 DW_TAG_pointer_type
	.word	1719                            # DW_AT_type
	.byte	22                              # Abbrev [22] 0x6b7:0x5 DW_TAG_const_type
	.word	756                             # DW_AT_type
	.byte	5                               # Abbrev [5] 0x6bc:0x4 DW_TAG_base_type
	.byte	65                              # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	20                              # Abbrev [20] 0x6c0:0x5 DW_TAG_pointer_type
	.word	1733                            # DW_AT_type
	.byte	22                              # Abbrev [22] 0x6c5:0x5 DW_TAG_const_type
	.word	57                              # DW_AT_type
	.byte	20                              # Abbrev [20] 0x6ca:0x5 DW_TAG_pointer_type
	.word	264                             # DW_AT_type
	.byte	20                              # Abbrev [20] 0x6cf:0x5 DW_TAG_pointer_type
	.word	306                             # DW_AT_type
	.byte	20                              # Abbrev [20] 0x6d4:0x5 DW_TAG_pointer_type
	.word	334                             # DW_AT_type
	.byte	23                              # Abbrev [23] 0x6d9:0x9 DW_TAG_typedef
	.word	306                             # DW_AT_type
	.byte	75                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	20                              # Abbrev [20] 0x6e2:0x5 DW_TAG_pointer_type
	.word	465                             # DW_AT_type
	.byte	20                              # Abbrev [20] 0x6e7:0x5 DW_TAG_pointer_type
	.word	630                             # DW_AT_type
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	328                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/adapter/user_runtime.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=208
.Linfo_string3:
	.asciz	"char"                          # string offset=260
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=265
.Linfo_string5:
	.asciz	"vsets"                         # string offset=285
.Linfo_string6:
	.asciz	"line"                          # string offset=291
.Linfo_string7:
	.asciz	"unsigned int"                  # string offset=296
.Linfo_string8:
	.asciz	"avl"                           # string offset=309
.Linfo_string9:
	.asciz	"vl"                            # string offset=313
.Linfo_string10:
	.asciz	"vtype"                         # string offset=316
.Linfo_string11:
	.asciz	"vset_record"                   # string offset=322
.Linfo_string12:
	.asciz	"assertions"                    # string offset=334
.Linfo_string13:
	.asciz	"id"                            # string offset=345
.Linfo_string14:
	.asciz	"elements"                      # string offset=348
.Linfo_string15:
	.asciz	"bytes"                         # string offset=357
.Linfo_string16:
	.asciz	"comparisons"                   # string offset=363
.Linfo_string17:
	.asciz	"completed"                     # string offset=375
.Linfo_string18:
	.asciz	"assertion_record"              # string offset=385
.Linfo_string19:
	.asciz	"nvsets"                        # string offset=402
.Linfo_string20:
	.asciz	"nassertions"                   # string offset=409
.Linfo_string21:
	.asciz	"ncomparisons"                  # string offset=421
.Linfo_string22:
	.asciz	"flags"                         # string offset=434
.Linfo_string23:
	.asciz	"read_line"                     # string offset=440
.Linfo_string24:
	.asciz	"read_pc"                       # string offset=450
.Linfo_string25:
	.asciz	"checker_pc"                    # string offset=458
.Linfo_string26:
	.asciz	"actual"                        # string offset=469
.Linfo_string27:
	.asciz	"unsigned long long"            # string offset=476
.Linfo_string28:
	.asciz	"uint64_t"                      # string offset=495
.Linfo_string29:
	.asciz	"expected"                      # string offset=504
.Linfo_string30:
	.asciz	"flag_record"                   # string offset=513
.Linfo_string31:
	.asciz	"nflags"                        # string offset=525
.Linfo_string32:
	.asciz	"nreads"                        # string offset=532
.Linfo_string33:
	.asciz	"last_read_line"                # string offset=539
.Linfo_string34:
	.asciz	"last_read_pc"                  # string offset=554
.Linfo_string35:
	.asciz	"scalars"                       # string offset=567
.Linfo_string36:
	.asciz	"scalar_record"                 # string offset=575
.Linfo_string37:
	.asciz	"nscalars"                      # string offset=589
.Linfo_string38:
	.asciz	"output"                        # string offset=598
.Linfo_string39:
	.asciz	"used"                          # string offset=605
.Linfo_string40:
	.asciz	"unsigned char"                 # string offset=610
.Linfo_string41:
	.asciz	"memcpy"                        # string offset=624
.Linfo_string42:
	.asciz	"memset"                        # string offset=631
.Linfo_string43:
	.asciz	"_putchar"                      # string offset=638
.Linfo_string44:
	.asciz	"flush"                         # string offset=647
.Linfo_string45:
	.asciz	"ara_trace_vset"                # string offset=653
.Linfo_string46:
	.asciz	"state"                         # string offset=668
.Linfo_string47:
	.asciz	"ara_assert_begin"              # string offset=674
.Linfo_string48:
	.asciz	"ara_compare_step"              # string offset=691
.Linfo_string49:
	.asciz	"ara_assert_end"                # string offset=708
.Linfo_string50:
	.asciz	"ara_note_vxsat_read"           # string offset=723
.Linfo_string51:
	.asciz	"ara_flag_begin"                # string offset=743
.Linfo_string52:
	.asciz	"ara_flag_end"                  # string offset=758
.Linfo_string53:
	.asciz	"ara_scalar_begin"              # string offset=771
.Linfo_string54:
	.asciz	"ara_scalar_end"                # string offset=788
.Linfo_string55:
	.asciz	"ara_case_begin"                # string offset=803
.Linfo_string56:
	.asciz	"ara_case_end"                  # string offset=818
.Linfo_string57:
	.asciz	"ara_finish"                    # string offset=831
.Linfo_string58:
	.asciz	"dest"                          # string offset=842
.Linfo_string59:
	.asciz	"src"                           # string offset=847
.Linfo_string60:
	.asciz	"count"                         # string offset=851
.Linfo_string61:
	.asciz	"d"                             # string offset=857
.Linfo_string62:
	.asciz	"s"                             # string offset=859
.Linfo_string63:
	.asciz	"i"                             # string offset=861
.Linfo_string64:
	.asciz	"value"                         # string offset=863
.Linfo_string65:
	.asciz	"int"                           # string offset=869
.Linfo_string66:
	.asciz	"ch"                            # string offset=873
.Linfo_string67:
	.asciz	"a0"                            # string offset=876
.Linfo_string68:
	.asciz	"a1"                            # string offset=879
.Linfo_string69:
	.asciz	"a2"                            # string offset=882
.Linfo_string70:
	.asciz	"a7"                            # string offset=885
.Linfo_string71:
	.asciz	"r"                             # string offset=888
.Linfo_string72:
	.asciz	"vt"                            # string offset=890
.Linfo_string73:
	.asciz	"element"                       # string offset=893
.Linfo_string74:
	.asciz	"pc"                            # string offset=901
.Linfo_string75:
	.asciz	"uintptr_t"                     # string offset=904
.Linfo_string76:
	.asciz	"name"                          # string offset=914
.Linfo_string77:
	.asciz	"failures"                      # string offset=919
.Linfo_string78:
	.asciz	"status"                        # string offset=928
.Linfo_string79:
	.asciz	"completed_flags"               # string offset=935
.Linfo_string80:
	.asciz	"completed_scalars"             # string offset=951
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.word	.Linfo_string25
	.word	.Linfo_string26
	.word	.Linfo_string27
	.word	.Linfo_string28
	.word	.Linfo_string29
	.word	.Linfo_string30
	.word	.Linfo_string31
	.word	.Linfo_string32
	.word	.Linfo_string33
	.word	.Linfo_string34
	.word	.Linfo_string35
	.word	.Linfo_string36
	.word	.Linfo_string37
	.word	.Linfo_string38
	.word	.Linfo_string39
	.word	.Linfo_string40
	.word	.Linfo_string41
	.word	.Linfo_string42
	.word	.Linfo_string43
	.word	.Linfo_string44
	.word	.Linfo_string45
	.word	.Linfo_string46
	.word	.Linfo_string47
	.word	.Linfo_string48
	.word	.Linfo_string49
	.word	.Linfo_string50
	.word	.Linfo_string51
	.word	.Linfo_string52
	.word	.Linfo_string53
	.word	.Linfo_string54
	.word	.Linfo_string55
	.word	.Linfo_string56
	.word	.Linfo_string57
	.word	.Linfo_string58
	.word	.Linfo_string59
	.word	.Linfo_string60
	.word	.Linfo_string61
	.word	.Linfo_string62
	.word	.Linfo_string63
	.word	.Linfo_string64
	.word	.Linfo_string65
	.word	.Linfo_string66
	.word	.Linfo_string67
	.word	.Linfo_string68
	.word	.Linfo_string69
	.word	.Linfo_string70
	.word	.Linfo_string71
	.word	.Linfo_string72
	.word	.Linfo_string73
	.word	.Linfo_string74
	.word	.Linfo_string75
	.word	.Linfo_string76
	.word	.Linfo_string77
	.word	.Linfo_string78
	.word	.Linfo_string79
	.word	.Linfo_string80
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L.str.7
	.word	.L.str.8
	.word	vsets
	.word	assertions
	.word	.L_MergedGlobals
	.word	scalars
	.word	output
	.word	used
	.word	.Lfunc_begin0
	.word	.Ltmp1
	.word	.Lfunc_begin1
	.word	.Ltmp8
	.word	.Lfunc_begin2
	.word	.Lfunc_begin3
	.word	.Lfunc_begin4
	.word	.Lfunc_begin5
	.word	.Lfunc_begin6
	.word	.Lfunc_begin7
	.word	.Lfunc_begin8
	.word	.Lfunc_begin9
	.word	.Lfunc_begin10
	.word	.Lfunc_begin11
	.word	.Lfunc_begin12
	.word	.Lfunc_begin13
	.word	.Lfunc_begin14
	.word	.Lfunc_begin15
	.word	.Lfunc_begin16
	.word	.Ltmp45
	.word	.Ltmp48
	.word	.Ltmp50
	.word	.Ltmp53
	.word	.Ltmp56
	.word	.Ltmp59
	.word	.Ltmp62
	.word	.Ltmp65
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
