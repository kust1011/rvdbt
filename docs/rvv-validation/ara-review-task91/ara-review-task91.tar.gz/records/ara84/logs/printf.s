	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"printf.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c" md5 0xae94f79e11c599c1044f5017ef948074
	.file	1 "/usr/lib/llvm-20/lib/clang/20/include" "__stddef_size_t.h" md5 0x2c44e821a2b1951cde2eb0fb2e656867
	.file	2 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	3 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c" md5 0xae94f79e11c599c1044f5017ef948074
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	printf_                         # -- Begin function printf_
	.p2align	2
	.type	printf_,@function
printf_:                                # @printf_
.Lfunc_begin0:
	.loc	3 754 0                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:754:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -64
	.cfi_def_cfa_offset 64
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -36
	.cfi_offset s0, -40
	addi	s0, sp, 32
	.cfi_def_cfa s0, 32
	sw	a7, 28(s0)
	sw	a6, 24(s0)
	sw	a5, 20(s0)
	sw	a4, 16(s0)
	sw	a3, 12(s0)
	sw	a2, 8(s0)
	sw	a1, 4(s0)
	sw	a0, -12(s0)
	addi	a0, s0, 4
.Ltmp0:
	.loc	3 756 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:756:3
	sw	a0, -16(s0)
	.loc	3 758 61                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:758:61
	lw	a3, -12(s0)
	.loc	3 758 69 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:758:69
	lw	a4, -16(s0)
	.loc	3 758 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:758:19
	lui	a0, %hi(_out_char)
	addi	a0, a0, %lo(_out_char)
	addi	a1, s0, -17
	li	a2, -1
	call	_vsnprintf
	.loc	3 758 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:758:13
	sw	a0, -24(s0)
	.loc	3 760 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:760:10
	lw	a0, -24(s0)
	.cfi_def_cfa sp, 64
	.loc	3 760 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:760:3
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 64
	.cfi_def_cfa_offset 0
	ret
.Ltmp1:
.Lfunc_end0:
	.size	printf_, .Lfunc_end0-printf_
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _vsnprintf
	.type	_vsnprintf,@function
_vsnprintf:                             # @_vsnprintf
.Lfunc_begin1:
	.loc	3 451 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:451:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -96
	.cfi_def_cfa_offset 96
	sw	ra, 92(sp)                      # 4-byte Folded Spill
	sw	s0, 88(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 96
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
	sw	a4, -28(s0)
.Ltmp2:
	.loc	3 453 10 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:453:10
	sw	zero, -48(s0)
.Ltmp3:
	.loc	3 455 8                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:455:8
	lw	a0, -16(s0)
	.loc	3 455 7 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:455:7
	bnez	a0, .LBB1_2
	j	.LBB1_1
.LBB1_1:
.Ltmp4:
	.loc	3 457 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:457:9
	lui	a0, %hi(_out_null)
	addi	a0, a0, %lo(_out_null)
	sw	a0, -12(s0)
	.loc	3 458 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:458:3
	j	.LBB1_2
.Ltmp5:
.LBB1_2:
	.loc	3 460 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:460:3
	j	.LBB1_3
.LBB1_3:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_9 Depth 2
                                        #     Child Loop BB1_124 Depth 2
                                        #     Child Loop BB1_128 Depth 2
                                        #     Child Loop BB1_136 Depth 2
                                        #     Child Loop BB1_105 Depth 2
                                        #     Child Loop BB1_110 Depth 2
	.loc	3 460 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:460:11
	lw	a0, -24(s0)
	.loc	3 460 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:460:10
	lbu	a0, 0(a0)
	.loc	3 460 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:460:3
	beqz	a0, .LBB1_144
	j	.LBB1_4
.LBB1_4:                                #   in Loop: Header=BB1_3 Depth=1
.Ltmp6:
	.loc	3 462 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:462:10
	lw	a0, -24(s0)
	.loc	3 462 9 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:462:9
	lbu	a0, 0(a0)
	li	a1, 37
	.loc	3 462 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:462:17
	beq	a0, a1, .LBB1_7
	j	.LBB1_5
.LBB1_5:                                #   in Loop: Header=BB1_3 Depth=1
.Ltmp7:
	.loc	3 464 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:7
	lw	a4, -12(s0)
	.loc	3 464 12 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:12
	lw	a0, -24(s0)
	.loc	3 464 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:11
	lbu	a0, 0(a0)
	.loc	3 464 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:20
	lw	a1, -16(s0)
	.loc	3 464 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:31
	lw	a2, -48(s0)
	addi	a3, a2, 1
	sw	a3, -48(s0)
	.loc	3 464 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:35
	lw	a3, -20(s0)
	.loc	3 464 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:464:7
	jalr	a4
	.loc	3 465 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:465:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 466 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:466:7
	j	.LBB1_6
.Ltmp8:
.LBB1_6:                                # %.backedge
                                        #   in Loop: Header=BB1_3 Depth=1
	.loc	3 460 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:460:11
	j	.LBB1_3
.LBB1_7:                                #   in Loop: Header=BB1_3 Depth=1
.Ltmp9:
	.loc	3 469 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:469:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	j	.LBB1_8
.Ltmp10:
.LBB1_8:                                #   in Loop: Header=BB1_3 Depth=1
	.loc	3 473 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:473:11
	sw	zero, -32(s0)
	.loc	3 474 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:474:5
	j	.LBB1_9
.LBB1_9:                                #   Parent Loop BB1_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
.Ltmp11:
	.loc	3 475 16                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:475:16
	lw	a0, -24(s0)
	.loc	3 475 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:475:15
	lbu	a0, 0(a0)
	.loc	3 475 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:475:7
	addi	a0, a0, -32
	li	a1, 16
	bltu	a1, a0, .LBB1_16
# %bb.10:                               #   in Loop: Header=BB1_9 Depth=2
	slli	a0, a0, 2
	lui	a1, %hi(.LJTI1_0)
	addi	a1, a1, %lo(.LJTI1_0)
	add	a0, a0, a1
	lw	a0, 0(a0)
	jr	a0
.LBB1_11:                               #   in Loop: Header=BB1_9 Depth=2
.Ltmp12:
	.loc	3 477 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:477:15
	lw	a0, -32(s0)
	ori	a0, a0, 1
	sw	a0, -32(s0)
	.loc	3 478 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:478:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	li	a0, 1
	.loc	3 479 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:479:11
	sw	a0, -44(s0)
	.loc	3 480 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:480:9
	j	.LBB1_17
.LBB1_12:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 482 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:482:15
	lw	a0, -32(s0)
	ori	a0, a0, 2
	sw	a0, -32(s0)
	.loc	3 483 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:483:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	li	a0, 1
	.loc	3 484 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:484:11
	sw	a0, -44(s0)
	.loc	3 485 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:485:9
	j	.LBB1_17
.LBB1_13:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 487 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:487:15
	lw	a0, -32(s0)
	ori	a0, a0, 4
	sw	a0, -32(s0)
	.loc	3 488 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:488:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	li	a0, 1
	.loc	3 489 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:489:11
	sw	a0, -44(s0)
	.loc	3 490 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:490:9
	j	.LBB1_17
.LBB1_14:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 492 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:492:15
	lw	a0, -32(s0)
	ori	a0, a0, 8
	sw	a0, -32(s0)
	.loc	3 493 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:493:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	li	a0, 1
	.loc	3 494 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:494:11
	sw	a0, -44(s0)
	.loc	3 495 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:495:9
	j	.LBB1_17
.LBB1_15:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 497 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:497:15
	lw	a0, -32(s0)
	ori	a0, a0, 16
	sw	a0, -32(s0)
	.loc	3 498 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:498:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	li	a0, 1
	.loc	3 499 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:499:11
	sw	a0, -44(s0)
	.loc	3 500 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:500:9
	j	.LBB1_17
.LBB1_16:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 502 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:502:11
	sw	zero, -44(s0)
	.loc	3 503 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:503:9
	j	.LBB1_17
.Ltmp13:
.LBB1_17:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 505 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:505:5
	j	.LBB1_18
.Ltmp14:
.LBB1_18:                               #   in Loop: Header=BB1_9 Depth=2
	.loc	3 505 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:505:14
	lw	a0, -44(s0)
.Ltmp15:
	.loc	3 505 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:505:5
	bnez	a0, .LBB1_9
	j	.LBB1_19
.Ltmp16:
.LBB1_19:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 508 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:508:11
	sw	zero, -36(s0)
.Ltmp17:
	.loc	3 509 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:509:20
	lw	a0, -24(s0)
	.loc	3 509 19 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:509:19
	lbu	a0, 0(a0)
	.loc	3 509 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:509:9
	call	_is_digit
	beqz	a0, .LBB1_21
	j	.LBB1_20
.LBB1_20:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp18:
	.loc	3 510 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:510:15
	addi	a0, s0, -24
	call	_atoi
	.loc	3 510 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:510:13
	sw	a0, -36(s0)
	.loc	3 511 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:511:5
	j	.LBB1_27
.Ltmp19:
.LBB1_21:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 511 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:511:17
	lw	a0, -24(s0)
	.loc	3 511 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:511:16
	lbu	a0, 0(a0)
	li	a1, 42
	.loc	3 511 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:511:24
	bne	a0, a1, .LBB1_26
	j	.LBB1_22
.LBB1_22:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp20:
	.loc	3 512 21 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:512:21
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lw	a0, 0(a0)
	.loc	3 512 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:512:17
	sw	a0, -52(s0)
.Ltmp21:
	.loc	3 513 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:513:11
	lw	a0, -52(s0)
	.loc	3 513 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:513:13
	bgez	a0, .LBB1_24
	j	.LBB1_23
.LBB1_23:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp22:
	.loc	3 514 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:514:15
	lw	a0, -32(s0)
	ori	a0, a0, 2
	sw	a0, -32(s0)
	.loc	3 515 32                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:515:32
	lw	a0, -52(s0)
	.loc	3 515 31 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:515:31
	neg	a0, a0
	.loc	3 515 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:515:15
	sw	a0, -36(s0)
	.loc	3 516 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:516:7
	j	.LBB1_25
.Ltmp23:
.LBB1_24:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 517 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:517:31
	lw	a0, -52(s0)
	.loc	3 517 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:517:15
	sw	a0, -36(s0)
	j	.LBB1_25
.Ltmp24:
.LBB1_25:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 519 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:519:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 520 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:520:5
	j	.LBB1_26
.Ltmp25:
.LBB1_26:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 5 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:5
	j	.LBB1_27
.LBB1_27:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 523 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:523:15
	sw	zero, -40(s0)
.Ltmp26:
	.loc	3 524 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:524:10
	lw	a0, -24(s0)
	.loc	3 524 9 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:524:9
	lbu	a0, 0(a0)
	li	a1, 46
	.loc	3 524 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:524:17
	bne	a0, a1, .LBB1_37
	j	.LBB1_28
.LBB1_28:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp27:
	.loc	3 525 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:525:13
	lw	a0, -32(s0)
	ori	a0, a0, 1024
	sw	a0, -32(s0)
	.loc	3 526 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:526:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
.Ltmp28:
	.loc	3 527 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:527:22
	lw	a0, -24(s0)
	.loc	3 527 21 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:527:21
	lbu	a0, 0(a0)
	.loc	3 527 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:527:11
	call	_is_digit
	beqz	a0, .LBB1_30
	j	.LBB1_29
.LBB1_29:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp29:
	.loc	3 528 21 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:528:21
	addi	a0, s0, -24
	call	_atoi
	.loc	3 528 19 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:528:19
	sw	a0, -40(s0)
	.loc	3 529 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:529:7
	j	.LBB1_36
.Ltmp30:
.LBB1_30:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 529 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:529:19
	lw	a0, -24(s0)
	.loc	3 529 18 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:529:18
	lbu	a0, 0(a0)
	li	a1, 42
	.loc	3 529 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:529:26
	bne	a0, a1, .LBB1_35
	j	.LBB1_31
.LBB1_31:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp31:
	.loc	3 530 31 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:530:31
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lw	a0, 0(a0)
	.loc	3 530 19 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:530:19
	sw	a0, -56(s0)
	.loc	3 531 21 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:531:21
	lw	a0, -56(s0)
	blez	a0, .LBB1_33
	j	.LBB1_32
.LBB1_32:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 531 46 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:531:46
	lw	a0, -56(s0)
	.loc	3 531 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:531:21
	j	.LBB1_34
.LBB1_33:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 21                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:21
	li	a0, 0
	.loc	3 531 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:531:21
	j	.LBB1_34
.LBB1_34:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 531 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:531:19
	sw	a0, -40(s0)
	.loc	3 532 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:532:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 533 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:533:7
	j	.LBB1_35
.Ltmp32:
.LBB1_35:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 7 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:7
	j	.LBB1_36
.LBB1_36:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 534 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:534:5
	j	.LBB1_37
.Ltmp33:
.LBB1_37:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 537 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:537:14
	lw	a0, -24(s0)
	.loc	3 537 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:537:13
	lbu	a0, 0(a0)
	.loc	3 537 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:537:5
	addi	a0, a0, -104
	li	a1, 18
	bltu	a1, a0, .LBB1_48
# %bb.38:                               #   in Loop: Header=BB1_3 Depth=1
	slli	a0, a0, 2
	lui	a1, %hi(.LJTI1_1)
	addi	a1, a1, %lo(.LJTI1_1)
	add	a0, a0, a1
	lw	a0, 0(a0)
	jr	a0
.LBB1_39:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp34:
	.loc	3 539 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:539:13
	lw	a0, -32(s0)
	ori	a0, a0, 256
	sw	a0, -32(s0)
	.loc	3 540 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:540:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
.Ltmp35:
	.loc	3 541 12                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:541:12
	lw	a0, -24(s0)
	.loc	3 541 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:541:11
	lbu	a0, 0(a0)
	li	a1, 108
	.loc	3 541 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:541:19
	bne	a0, a1, .LBB1_41
	j	.LBB1_40
.LBB1_40:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp36:
	.loc	3 542 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:542:15
	lw	a0, -32(s0)
	ori	a0, a0, 512
	sw	a0, -32(s0)
	.loc	3 543 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:543:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 544 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:544:7
	j	.LBB1_41
.Ltmp37:
.LBB1_41:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 545 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:545:7
	j	.LBB1_49
.LBB1_42:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 547 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:547:13
	lw	a0, -32(s0)
	ori	a0, a0, 128
	sw	a0, -32(s0)
	.loc	3 548 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:548:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
.Ltmp38:
	.loc	3 549 12                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:549:12
	lw	a0, -24(s0)
	.loc	3 549 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:549:11
	lbu	a0, 0(a0)
	li	a1, 104
	.loc	3 549 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:549:19
	bne	a0, a1, .LBB1_44
	j	.LBB1_43
.LBB1_43:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp39:
	.loc	3 550 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:550:15
	lw	a0, -32(s0)
	ori	a0, a0, 64
	sw	a0, -32(s0)
	.loc	3 551 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:551:15
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 552 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:552:7
	j	.LBB1_44
.Ltmp40:
.LBB1_44:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 553 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:553:7
	j	.LBB1_49
.LBB1_45:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 556 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:556:13
	lw	a0, -32(s0)
	ori	a0, a0, 256
	sw	a0, -32(s0)
	.loc	3 558 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:558:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 559 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:559:7
	j	.LBB1_49
.LBB1_46:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 562 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:562:13
	lw	a0, -32(s0)
	ori	a0, a0, 512
	sw	a0, -32(s0)
	.loc	3 564 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:564:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 565 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:565:7
	j	.LBB1_49
.LBB1_47:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 567 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:567:13
	lw	a0, -32(s0)
	ori	a0, a0, 256
	sw	a0, -32(s0)
	.loc	3 568 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:568:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 569 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:569:7
	j	.LBB1_49
.LBB1_48:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 571 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:571:7
	j	.LBB1_49
.Ltmp41:
.LBB1_49:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 575 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:575:14
	lw	a0, -24(s0)
	.loc	3 575 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:575:13
	lbu	a0, 0(a0)
	.loc	3 575 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:575:5
	addi	a0, a0, -37
	li	a1, 83
	bltu	a1, a0, .LBB1_142
# %bb.50:                               #   in Loop: Header=BB1_3 Depth=1
	slli	a0, a0, 2
	lui	a1, %hi(.LJTI1_2)
	addi	a1, a1, %lo(.LJTI1_2)
	add	a0, a0, a1
	lw	a0, 0(a0)
	jr	a0
.LBB1_51:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp42:
	.loc	3 585 12 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:585:12
	lw	a0, -24(s0)
	.loc	3 585 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:585:11
	lbu	a0, 0(a0)
	li	a1, 120
	.loc	3 585 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:585:26
	beq	a0, a1, .LBB1_53
	j	.LBB1_52
.LBB1_52:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 585 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:585:30
	lw	a0, -24(s0)
	.loc	3 585 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:585:29
	lbu	a0, 0(a0)
	li	a1, 88
	.loc	3 585 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:585:26
	bne	a0, a1, .LBB1_54
	j	.LBB1_53
.LBB1_53:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 26                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:26
	li	a0, 16
.Ltmp43:
	.loc	3 586 14 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:586:14
	sw	a0, -60(s0)
	.loc	3 587 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:587:7
	j	.LBB1_61
.Ltmp44:
.LBB1_54:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 587 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:587:19
	lw	a0, -24(s0)
	.loc	3 587 18 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:587:18
	lbu	a0, 0(a0)
	li	a1, 111
	.loc	3 587 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:587:26
	bne	a0, a1, .LBB1_56
	j	.LBB1_55
.LBB1_55:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 26                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:26
	li	a0, 8
.Ltmp45:
	.loc	3 588 14 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:588:14
	sw	a0, -60(s0)
	.loc	3 589 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:589:7
	j	.LBB1_60
.Ltmp46:
.LBB1_56:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 589 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:589:19
	lw	a0, -24(s0)
	.loc	3 589 18 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:589:18
	lbu	a0, 0(a0)
	li	a1, 98
	.loc	3 589 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:589:26
	bne	a0, a1, .LBB1_58
	j	.LBB1_57
.LBB1_57:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 26                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:26
	li	a0, 2
.Ltmp47:
	.loc	3 590 14 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:590:14
	sw	a0, -60(s0)
	.loc	3 591 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:591:7
	j	.LBB1_59
.Ltmp48:
.LBB1_58:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 7 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:7
	li	a0, 10
.Ltmp49:
	.loc	3 592 14 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:592:14
	sw	a0, -60(s0)
	.loc	3 593 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:593:15
	lw	a0, -32(s0)
	andi	a0, a0, -17
	sw	a0, -32(s0)
	j	.LBB1_59
.Ltmp50:
.LBB1_59:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 15 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:15
	j	.LBB1_60
.LBB1_60:                               #   in Loop: Header=BB1_3 Depth=1
	j	.LBB1_61
.LBB1_61:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp51:
	.loc	3 596 12 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:596:12
	lw	a0, -24(s0)
	.loc	3 596 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:596:11
	lbu	a0, 0(a0)
	li	a1, 88
	.loc	3 596 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:596:19
	bne	a0, a1, .LBB1_63
	j	.LBB1_62
.LBB1_62:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp52:
	.loc	3 597 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:597:15
	lw	a0, -32(s0)
	ori	a0, a0, 32
	sw	a0, -32(s0)
	.loc	3 598 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:598:7
	j	.LBB1_63
.Ltmp53:
.LBB1_63:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 601 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:601:13
	lw	a0, -24(s0)
	.loc	3 601 12 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:601:12
	lbu	a0, 0(a0)
	li	a1, 105
	.loc	3 601 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:601:28
	beq	a0, a1, .LBB1_66
	j	.LBB1_64
.LBB1_64:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 601 33                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:601:33
	lw	a0, -24(s0)
	.loc	3 601 32                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:601:32
	lbu	a0, 0(a0)
	li	a1, 100
	.loc	3 601 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:601:28
	beq	a0, a1, .LBB1_66
	j	.LBB1_65
.LBB1_65:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp54:
	.loc	3 602 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:602:15
	lw	a0, -32(s0)
	andi	a0, a0, -13
	sw	a0, -32(s0)
	.loc	3 603 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:603:7
	j	.LBB1_66
.Ltmp55:
.LBB1_66:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 606 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:606:17
	lbu	a0, -31(s0)
	andi	a0, a0, 4
	beqz	a0, .LBB1_68
	j	.LBB1_67
.LBB1_67:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp56:
	.loc	3 607 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:607:15
	lw	a0, -32(s0)
	andi	a0, a0, -2
	sw	a0, -32(s0)
	.loc	3 608 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:608:7
	j	.LBB1_68
.Ltmp57:
.LBB1_68:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 611 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:611:13
	lw	a0, -24(s0)
	.loc	3 611 12 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:611:12
	lbu	a0, 0(a0)
	li	a1, 105
	.loc	3 611 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:611:28
	beq	a0, a1, .LBB1_70
	j	.LBB1_69
.LBB1_69:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 611 33                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:611:33
	lw	a0, -24(s0)
	.loc	3 611 32                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:611:32
	lbu	a0, 0(a0)
	li	a1, 100
	.loc	3 611 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:611:28
	bne	a0, a1, .LBB1_89
	j	.LBB1_70
.LBB1_70:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp58:
	.loc	3 613 19 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:613:19
	lbu	a0, -31(s0)
	andi	a0, a0, 2
	beqz	a0, .LBB1_72
	j	.LBB1_71
.LBB1_71:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp59:
	.loc	3 621 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:621:9
	j	.LBB1_88
.Ltmp60:
.LBB1_72:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 621 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:621:26
	lbu	a0, -31(s0)
	andi	a0, a0, 1
	beqz	a0, .LBB1_77
	j	.LBB1_73
.LBB1_73:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp61:
	.loc	3 622 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:622:30
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lw	a0, 0(a0)
	.loc	3 622 22 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:622:22
	sw	a0, -64(s0)
	.loc	3 623 28 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:623:28
	lw	a0, -12(s0)
	.loc	3 623 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:623:33
	lw	a1, -16(s0)
	.loc	3 623 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:623:41
	lw	a2, -48(s0)
	.loc	3 623 46                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:623:46
	lw	a3, -20(s0)
	.loc	3 624 44 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:624:44
	lw	a4, -64(s0)
	blez	a4, .LBB1_75
	j	.LBB1_74
.LBB1_74:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 624 56 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:624:56
	lw	a4, -64(s0)
	.loc	3 624 44                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:624:44
	j	.LBB1_76
.LBB1_75:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 624 68                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:624:68
	lw	a4, -64(s0)
	.loc	3 624 66                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:624:66
	neg	a4, a4
	.loc	3 624 44                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:624:44
	j	.LBB1_76
.LBB1_76:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 625 28 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:625:28
	lw	a5, -64(s0)
	.loc	3 625 39 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:625:39
	lw	a6, -60(s0)
	.loc	3 625 45                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:625:45
	lw	a7, -40(s0)
	.loc	3 625 56                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:625:56
	lw	t0, -36(s0)
	.loc	3 625 63                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:625:63
	lw	t1, -32(s0)
	.loc	3 623 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:623:17
	sw	t1, 4(sp)
	sw	t0, 0(sp)
	srli	a5, a5, 31
	call	_ntoa_long
	.loc	3 623 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:623:15
	sw	a0, -48(s0)
	.loc	3 626 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:626:9
	j	.LBB1_87
.Ltmp62:
.LBB1_77:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 627 36                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:627:36
	lbu	a0, -32(s0)
	andi	a0, a0, 64
	.loc	3 627 29 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:627:29
	beqz	a0, .LBB1_79
	j	.LBB1_78
.LBB1_78:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 627 61                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:627:61
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lbu	a0, 0(a0)
	.loc	3 627 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:627:29
	j	.LBB1_83
.LBB1_79:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 628 38 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:628:38
	lbu	a0, -32(s0)
	andi	a0, a0, 128
	.loc	3 628 31 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:628:31
	beqz	a0, .LBB1_81
	j	.LBB1_80
.LBB1_80:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 628 66                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:628:66
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lh	a0, 0(a0)
	.loc	3 628 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:628:31
	j	.LBB1_82
.LBB1_81:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 629 55 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:629:55
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lw	a0, 0(a0)
	.loc	3 628 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:628:31
	j	.LBB1_82
.LBB1_82:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 627 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:627:29
	j	.LBB1_83
.LBB1_83:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 627 21 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:627:21
	sw	a0, -68(s0)
	.loc	3 630 28 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:630:28
	lw	a0, -12(s0)
	.loc	3 630 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:630:33
	lw	a1, -16(s0)
	.loc	3 630 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:630:41
	lw	a2, -48(s0)
	.loc	3 630 46                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:630:46
	lw	a3, -20(s0)
	.loc	3 631 43 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:631:43
	lw	a4, -68(s0)
	blez	a4, .LBB1_85
	j	.LBB1_84
.LBB1_84:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 631 55 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:631:55
	lw	a4, -68(s0)
	.loc	3 631 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:631:43
	j	.LBB1_86
.LBB1_85:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 631 67                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:631:67
	lw	a4, -68(s0)
	.loc	3 631 65                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:631:65
	neg	a4, a4
	.loc	3 631 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:631:43
	j	.LBB1_86
.LBB1_86:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 632 28 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:632:28
	lw	a5, -68(s0)
	.loc	3 632 39 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:632:39
	lw	a6, -60(s0)
	.loc	3 632 45                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:632:45
	lw	a7, -40(s0)
	.loc	3 632 56                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:632:56
	lw	t0, -36(s0)
	.loc	3 632 63                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:632:63
	lw	t1, -32(s0)
	.loc	3 630 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:630:17
	sw	t1, 4(sp)
	sw	t0, 0(sp)
	srli	a5, a5, 31
	call	_ntoa_long
	.loc	3 630 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:630:15
	sw	a0, -48(s0)
	j	.LBB1_87
.Ltmp63:
.LBB1_87:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 15                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:15
	j	.LBB1_88
.LBB1_88:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 634 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:634:7
	j	.LBB1_102
.Ltmp64:
.LBB1_89:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 636 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:636:19
	lbu	a0, -31(s0)
	andi	a0, a0, 2
	beqz	a0, .LBB1_91
	j	.LBB1_90
.LBB1_90:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp65:
	.loc	3 642 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:642:9
	j	.LBB1_101
.Ltmp66:
.LBB1_91:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 642 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:642:26
	lbu	a0, -31(s0)
	andi	a0, a0, 1
	beqz	a0, .LBB1_93
	j	.LBB1_92
.LBB1_92:                               #   in Loop: Header=BB1_3 Depth=1
.Ltmp67:
	.loc	3 643 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:28
	lw	a0, -12(s0)
	.loc	3 643 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:33
	lw	a1, -16(s0)
	.loc	3 643 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:41
	lw	a2, -48(s0)
	.loc	3 643 46                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:46
	lw	a3, -20(s0)
	.loc	3 643 54                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:54
	lw	a4, -28(s0)
	addi	a5, a4, 4
	sw	a5, -28(s0)
	lw	a4, 0(a4)
	.loc	3 644 35 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:644:35
	lw	a6, -60(s0)
	.loc	3 644 41 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:644:41
	lw	a7, -40(s0)
	.loc	3 644 52                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:644:52
	lw	a5, -36(s0)
	.loc	3 644 59                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:644:59
	lw	t0, -32(s0)
	.loc	3 643 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:17
	sw	t0, 4(sp)
	sw	a5, 0(sp)
	li	a5, 0
	call	_ntoa_long
	.loc	3 643 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:643:15
	sw	a0, -48(s0)
	.loc	3 645 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:645:9
	j	.LBB1_100
.Ltmp68:
.LBB1_93:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 647 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:647:22
	lbu	a0, -32(s0)
	andi	a0, a0, 64
	.loc	3 647 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:647:15
	beqz	a0, .LBB1_95
	j	.LBB1_94
.LBB1_94:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 647 53                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:647:53
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lbu	a0, 0(a0)
	.loc	3 647 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:647:15
	j	.LBB1_99
.LBB1_95:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 648 24 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:648:24
	lbu	a0, -32(s0)
	andi	a0, a0, 128
	.loc	3 648 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:648:17
	beqz	a0, .LBB1_97
	j	.LBB1_96
.LBB1_96:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 649 41 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:649:41
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lhu	a0, 0(a0)
	.loc	3 648 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:648:17
	j	.LBB1_98
.LBB1_97:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 650 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:650:21
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lw	a0, 0(a0)
	.loc	3 648 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:648:17
	j	.LBB1_98
.LBB1_98:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 647 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:647:15
	j	.LBB1_99
.LBB1_99:                               #   in Loop: Header=BB1_3 Depth=1
	.loc	3 646 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:646:30
	sw	a0, -72(s0)
	.loc	3 651 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:28
	lw	a0, -12(s0)
	.loc	3 651 33 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:33
	lw	a1, -16(s0)
	.loc	3 651 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:41
	lw	a2, -48(s0)
	.loc	3 651 46                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:46
	lw	a3, -20(s0)
	.loc	3 651 54                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:54
	lw	a4, -72(s0)
	.loc	3 651 68                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:68
	lw	a6, -60(s0)
	.loc	3 652 28 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:652:28
	lw	a7, -40(s0)
	.loc	3 652 39 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:652:39
	lw	a5, -36(s0)
	.loc	3 652 46                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:652:46
	lw	t0, -32(s0)
	.loc	3 651 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:17
	sw	t0, 4(sp)
	sw	a5, 0(sp)
	li	a5, 0
	call	_ntoa_long
	.loc	3 651 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:651:15
	sw	a0, -48(s0)
	j	.LBB1_100
.Ltmp69:
.LBB1_100:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 15                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:15
	j	.LBB1_101
.LBB1_101:                              #   in Loop: Header=BB1_3 Depth=1
	j	.LBB1_102
.LBB1_102:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 655 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:655:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 656 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:656:7
	j	.LBB1_143
.Ltmp70:
.LBB1_103:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 7 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:7
	li	a0, 1
.Ltmp71:
	.loc	3 667 20 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:667:20
	sw	a0, -76(s0)
.Ltmp72:
	.loc	3 669 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:669:19
	lbu	a0, -32(s0)
	andi	a0, a0, 2
	.loc	3 669 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:669:11
	bnez	a0, .LBB1_108
	j	.LBB1_104
.LBB1_104:                              #   in Loop: Header=BB1_3 Depth=1
.Ltmp73:
	.loc	3 670 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:670:9
	j	.LBB1_105
.LBB1_105:                              #   Parent Loop BB1_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	.loc	3 670 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:670:17
	lw	a0, -76(s0)
	addi	a1, a0, 1
	sw	a1, -76(s0)
	.loc	3 670 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:670:22
	lw	a1, -36(s0)
	.loc	3 670 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:670:9
	bgeu	a0, a1, .LBB1_107
	j	.LBB1_106
.LBB1_106:                              #   in Loop: Header=BB1_105 Depth=2
.Ltmp74:
	.loc	3 671 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:671:11
	lw	a4, -12(s0)
	.loc	3 671 20 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:671:20
	lw	a1, -16(s0)
	.loc	3 671 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:671:31
	lw	a2, -48(s0)
	addi	a0, a2, 1
	sw	a0, -48(s0)
	.loc	3 671 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:671:35
	lw	a3, -20(s0)
	.loc	3 671 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:671:11
	li	a0, 32
	jalr	a4
.Ltmp75:
	.loc	3 670 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:670:9
	j	.LBB1_105
.LBB1_107:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 673 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:673:7
	j	.LBB1_108
.Ltmp76:
.LBB1_108:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 675 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:675:7
	lw	a4, -12(s0)
	.loc	3 675 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:675:17
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lbu	a0, 0(a0)
	.loc	3 675 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:675:34
	lw	a1, -16(s0)
	.loc	3 675 45                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:675:45
	lw	a2, -48(s0)
	addi	a3, a2, 1
	sw	a3, -48(s0)
	.loc	3 675 49                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:675:49
	lw	a3, -20(s0)
	.loc	3 675 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:675:7
	jalr	a4
.Ltmp77:
	.loc	3 677 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:677:17
	lbu	a0, -32(s0)
	andi	a0, a0, 2
	beqz	a0, .LBB1_113
	j	.LBB1_109
.LBB1_109:                              #   in Loop: Header=BB1_3 Depth=1
.Ltmp78:
	.loc	3 678 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:678:9
	j	.LBB1_110
.LBB1_110:                              #   Parent Loop BB1_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	.loc	3 678 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:678:17
	lw	a0, -76(s0)
	addi	a1, a0, 1
	sw	a1, -76(s0)
	.loc	3 678 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:678:22
	lw	a1, -36(s0)
	.loc	3 678 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:678:9
	bgeu	a0, a1, .LBB1_112
	j	.LBB1_111
.LBB1_111:                              #   in Loop: Header=BB1_110 Depth=2
.Ltmp79:
	.loc	3 679 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:679:11
	lw	a4, -12(s0)
	.loc	3 679 20 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:679:20
	lw	a1, -16(s0)
	.loc	3 679 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:679:31
	lw	a2, -48(s0)
	addi	a0, a2, 1
	sw	a0, -48(s0)
	.loc	3 679 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:679:35
	lw	a3, -20(s0)
	.loc	3 679 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:679:11
	li	a0, 32
	jalr	a4
.Ltmp80:
	.loc	3 678 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:678:9
	j	.LBB1_110
.LBB1_112:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 681 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:681:7
	j	.LBB1_113
.Ltmp81:
.LBB1_113:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 682 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:682:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 683 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:683:7
	j	.LBB1_143
.Ltmp82:
.LBB1_114:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 687 23                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:687:23
	lw	a0, -28(s0)
	addi	a1, a0, 4
	sw	a1, -28(s0)
	lw	a0, 0(a0)
	.loc	3 687 19 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:687:19
	sw	a0, -80(s0)
	.loc	3 688 35 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:35
	lw	a0, -80(s0)
	.loc	3 688 38 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:38
	lw	a1, -40(s0)
	beqz	a1, .LBB1_116
	j	.LBB1_115
.LBB1_115:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 688 50                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:50
	lw	a1, -40(s0)
	.loc	3 688 38                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:38
	j	.LBB1_117
.LBB1_116:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 38                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:38
	li	a1, -1
	.loc	3 688 38                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:38
	j	.LBB1_117
.LBB1_117:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 688 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:24
	call	_strnlen_s
	.loc	3 688 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:688:20
	sw	a0, -84(s0)
.Ltmp83:
	.loc	3 690 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:690:17
	lbu	a0, -31(s0)
	andi	a0, a0, 4
	beqz	a0, .LBB1_122
	j	.LBB1_118
.LBB1_118:                              #   in Loop: Header=BB1_3 Depth=1
.Ltmp84:
	.loc	3 691 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:14
	lw	a0, -84(s0)
	.loc	3 691 18 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:18
	lw	a1, -40(s0)
	.loc	3 691 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:14
	bgeu	a0, a1, .LBB1_120
	j	.LBB1_119
.LBB1_119:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 691 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:30
	lw	a0, -84(s0)
	.loc	3 691 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:14
	j	.LBB1_121
.LBB1_120:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 691 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:34
	lw	a0, -40(s0)
	.loc	3 691 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:14
	j	.LBB1_121
.LBB1_121:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 691 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:691:11
	sw	a0, -84(s0)
	.loc	3 692 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:692:7
	j	.LBB1_122
.Ltmp85:
.LBB1_122:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 693 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:693:19
	lbu	a0, -32(s0)
	andi	a0, a0, 2
	.loc	3 693 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:693:11
	bnez	a0, .LBB1_127
	j	.LBB1_123
.LBB1_123:                              #   in Loop: Header=BB1_3 Depth=1
.Ltmp86:
	.loc	3 694 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:694:9
	j	.LBB1_124
.LBB1_124:                              #   Parent Loop BB1_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	.loc	3 694 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:694:17
	lw	a0, -84(s0)
	addi	a1, a0, 1
	sw	a1, -84(s0)
	.loc	3 694 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:694:22
	lw	a1, -36(s0)
	.loc	3 694 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:694:9
	bgeu	a0, a1, .LBB1_126
	j	.LBB1_125
.LBB1_125:                              #   in Loop: Header=BB1_124 Depth=2
.Ltmp87:
	.loc	3 695 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:695:11
	lw	a4, -12(s0)
	.loc	3 695 20 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:695:20
	lw	a1, -16(s0)
	.loc	3 695 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:695:31
	lw	a2, -48(s0)
	addi	a0, a2, 1
	sw	a0, -48(s0)
	.loc	3 695 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:695:35
	lw	a3, -20(s0)
	.loc	3 695 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:695:11
	li	a0, 32
	jalr	a4
.Ltmp88:
	.loc	3 694 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:694:9
	j	.LBB1_124
.LBB1_126:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 697 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:697:7
	j	.LBB1_127
.Ltmp89:
.LBB1_127:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 699 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:7
	j	.LBB1_128
.LBB1_128:                              #   Parent Loop BB1_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	.loc	3 699 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:16
	lw	a0, -80(s0)
	.loc	3 699 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:15
	lbu	a1, 0(a0)
	li	a0, 0
	.loc	3 699 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:24
	beqz	a1, .LBB1_132
	j	.LBB1_129
.LBB1_129:                              #   in Loop: Header=BB1_128 Depth=2
	.loc	3 699 36                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:36
	lbu	a0, -31(s0)
	andi	a1, a0, 4
	li	a0, 1
	.loc	3 699 55                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:55
	beqz	a1, .LBB1_131
	j	.LBB1_130
.LBB1_130:                              #   in Loop: Header=BB1_128 Depth=2
	.loc	3 699 67                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:67
	lw	a0, -40(s0)
	addi	a1, a0, -1
	sw	a1, -40(s0)
	.loc	3 699 55                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:55
	snez	a0, a0
	j	.LBB1_131
.LBB1_131:                              #   in Loop: Header=BB1_128 Depth=2
	.loc	3 0 55                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:55
	j	.LBB1_132
.LBB1_132:                              #   in Loop: Header=BB1_128 Depth=2
	.loc	3 699 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:7
	andi	a0, a0, 1
	beqz	a0, .LBB1_134
	j	.LBB1_133
.LBB1_133:                              #   in Loop: Header=BB1_128 Depth=2
.Ltmp90:
	.loc	3 700 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:9
	lw	a4, -12(s0)
	.loc	3 700 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:16
	lw	a0, -80(s0)
	addi	a1, a0, 1
	sw	a1, -80(s0)
	.loc	3 700 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:13
	lbu	a0, 0(a0)
	.loc	3 700 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:21
	lw	a1, -16(s0)
	.loc	3 700 32                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:32
	lw	a2, -48(s0)
	addi	a3, a2, 1
	sw	a3, -48(s0)
	.loc	3 700 36                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:36
	lw	a3, -20(s0)
	.loc	3 700 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:700:9
	jalr	a4
.Ltmp91:
	.loc	3 699 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:699:7
	j	.LBB1_128
.LBB1_134:                              #   in Loop: Header=BB1_3 Depth=1
.Ltmp92:
	.loc	3 703 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:703:17
	lbu	a0, -32(s0)
	andi	a0, a0, 2
	beqz	a0, .LBB1_139
	j	.LBB1_135
.LBB1_135:                              #   in Loop: Header=BB1_3 Depth=1
.Ltmp93:
	.loc	3 704 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:704:9
	j	.LBB1_136
.LBB1_136:                              #   Parent Loop BB1_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	.loc	3 704 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:704:17
	lw	a0, -84(s0)
	addi	a1, a0, 1
	sw	a1, -84(s0)
	.loc	3 704 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:704:22
	lw	a1, -36(s0)
	.loc	3 704 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:704:9
	bgeu	a0, a1, .LBB1_138
	j	.LBB1_137
.LBB1_137:                              #   in Loop: Header=BB1_136 Depth=2
.Ltmp94:
	.loc	3 705 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:705:11
	lw	a4, -12(s0)
	.loc	3 705 20 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:705:20
	lw	a1, -16(s0)
	.loc	3 705 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:705:31
	lw	a2, -48(s0)
	addi	a0, a2, 1
	sw	a0, -48(s0)
	.loc	3 705 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:705:35
	lw	a3, -20(s0)
	.loc	3 705 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:705:11
	li	a0, 32
	jalr	a4
.Ltmp95:
	.loc	3 704 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:704:9
	j	.LBB1_136
.LBB1_138:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 707 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:707:7
	j	.LBB1_139
.Ltmp96:
.LBB1_139:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 708 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:708:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 709 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:709:7
	j	.LBB1_143
.Ltmp97:
.LBB1_140:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 0 7 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:7
	li	a0, 8
.Ltmp98:
	.loc	3 713 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:713:13
	sw	a0, -36(s0)
	.loc	3 714 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:714:13
	lw	a0, -32(s0)
	ori	a0, a0, 33
	sw	a0, -32(s0)
	.loc	3 723 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:723:26
	lw	a0, -12(s0)
	.loc	3 723 31 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:723:31
	lw	a1, -16(s0)
	.loc	3 723 39                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:723:39
	lw	a2, -48(s0)
	.loc	3 723 44                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:723:44
	lw	a3, -20(s0)
	.loc	3 724 53 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:724:53
	lw	a4, -28(s0)
	addi	a5, a4, 4
	sw	a5, -28(s0)
	lw	a4, 0(a4)
	.loc	3 725 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:725:31
	lw	a7, -40(s0)
	.loc	3 725 42 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:725:42
	lw	a5, -36(s0)
	.loc	3 725 49                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:725:49
	lw	a6, -32(s0)
	.loc	3 723 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:723:15
	sw	a6, 4(sp)
	sw	a5, 0(sp)
	li	a5, 0
	li	a6, 16
	call	_ntoa_long
	.loc	3 723 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:723:13
	sw	a0, -48(s0)
	.loc	3 729 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:729:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 730 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:730:7
	j	.LBB1_143
.Ltmp99:
.LBB1_141:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 734 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:734:7
	lw	a4, -12(s0)
	.loc	3 734 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:734:16
	lw	a1, -16(s0)
	.loc	3 734 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:734:27
	lw	a2, -48(s0)
	addi	a0, a2, 1
	sw	a0, -48(s0)
	.loc	3 734 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:734:31
	lw	a3, -20(s0)
	.loc	3 734 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:734:7
	li	a0, 37
	jalr	a4
	.loc	3 735 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:735:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 736 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:736:7
	j	.LBB1_143
.LBB1_142:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 739 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:7
	lw	a4, -12(s0)
	.loc	3 739 12 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:12
	lw	a0, -24(s0)
	.loc	3 739 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:11
	lbu	a0, 0(a0)
	.loc	3 739 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:20
	lw	a1, -16(s0)
	.loc	3 739 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:31
	lw	a2, -48(s0)
	addi	a3, a2, 1
	sw	a3, -48(s0)
	.loc	3 739 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:35
	lw	a3, -20(s0)
	.loc	3 739 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:739:7
	jalr	a4
	.loc	3 740 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:740:13
	lw	a0, -24(s0)
	addi	a0, a0, 1
	sw	a0, -24(s0)
	.loc	3 741 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:741:7
	j	.LBB1_143
.Ltmp100:
.LBB1_143:                              #   in Loop: Header=BB1_3 Depth=1
	.loc	3 460 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:460:3
	j	.LBB1_6
.LBB1_144:
	.loc	3 746 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:3
	lw	a4, -12(s0)
	.loc	3 746 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:16
	lw	a1, -16(s0)
	.loc	3 746 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:24
	lw	a0, -48(s0)
	.loc	3 746 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:30
	lw	a2, -20(s0)
	.loc	3 746 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:24
	bgeu	a0, a2, .LBB1_146
	j	.LBB1_145
.LBB1_145:
	.loc	3 746 39                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:39
	lw	a2, -48(s0)
	.loc	3 746 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:24
	j	.LBB1_147
.LBB1_146:
	.loc	3 746 45                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:45
	lw	a2, -20(s0)
	.loc	3 746 52                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:52
	addi	a2, a2, -1
	.loc	3 746 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:24
	j	.LBB1_147
.LBB1_147:
	.loc	3 746 58                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:58
	lw	a3, -20(s0)
	.loc	3 746 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:746:3
	li	a0, 0
	jalr	a4
	.loc	3 749 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:749:15
	lw	a0, -48(s0)
	.cfi_def_cfa sp, 96
	.loc	3 749 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:749:3
	lw	ra, 92(sp)                      # 4-byte Folded Reload
	lw	s0, 88(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 96
	.cfi_def_cfa_offset 0
	ret
.Ltmp101:
.Lfunc_end1:
	.size	_vsnprintf, .Lfunc_end1-_vsnprintf
	.cfi_endproc
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.LJTI1_0:
	.word	.LBB1_14
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_15
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_13
	.word	.LBB1_16
	.word	.LBB1_12
	.word	.LBB1_16
	.word	.LBB1_16
	.word	.LBB1_11
.LJTI1_1:
	.word	.LBB1_42
	.word	.LBB1_48
	.word	.LBB1_46
	.word	.LBB1_48
	.word	.LBB1_39
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_45
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_48
	.word	.LBB1_47
.LJTI1_2:
	.word	.LBB1_141
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_51
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_51
	.word	.LBB1_103
	.word	.LBB1_51
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_51
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_51
	.word	.LBB1_140
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_114
	.word	.LBB1_142
	.word	.LBB1_51
	.word	.LBB1_142
	.word	.LBB1_142
	.word	.LBB1_51
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.p2align	2                               # -- Begin function _out_char
	.type	_out_char,@function
_out_char:                              # @_out_char
.Lfunc_begin2:
	.loc	3 122 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:122:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sb	a0, -9(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
.Ltmp102:
	.loc	3 126 7 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:126:7
	lbu	a0, -9(s0)
	beqz	a0, .LBB2_2
	j	.LBB2_1
.LBB2_1:
.Ltmp103:
	.loc	3 127 14                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:127:14
	lbu	a0, -9(s0)
	.loc	3 127 5 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:127:5
	call	_putchar
	.loc	3 128 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:128:3
	j	.LBB2_2
.Ltmp104:
.LBB2_2:
	.cfi_def_cfa sp, 32
	.loc	3 129 1 epilogue_begin          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:129:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp105:
.Lfunc_end2:
	.size	_out_char, .Lfunc_end2-_out_char
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	sprintf_                        # -- Begin function sprintf_
	.p2align	2
	.type	sprintf_,@function
sprintf_:                               # @sprintf_
.Lfunc_begin3:
	.loc	3 763 0                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:763:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sw	ra, 20(sp)                      # 4-byte Folded Spill
	sw	s0, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -28
	.cfi_offset s0, -32
	addi	s0, sp, 24
	.cfi_def_cfa s0, 24
	sw	a7, 20(s0)
	sw	a6, 16(s0)
	sw	a5, 12(s0)
	sw	a4, 8(s0)
	sw	a3, 4(s0)
	sw	a2, 0(s0)
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	mv	a0, s0
.Ltmp106:
	.loc	3 765 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:765:3
	sw	a0, -20(s0)
	.loc	3 766 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:766:43
	lw	a1, -12(s0)
	.loc	3 766 63 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:766:63
	lw	a3, -16(s0)
	.loc	3 766 71                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:766:71
	lw	a4, -20(s0)
	.loc	3 766 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:766:19
	lui	a0, %hi(_out_buffer)
	addi	a0, a0, %lo(_out_buffer)
	li	a2, -1
	call	_vsnprintf
	.loc	3 766 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:766:13
	sw	a0, -24(s0)
	.loc	3 768 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:768:10
	lw	a0, -24(s0)
	.cfi_def_cfa sp, 48
	.loc	3 768 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:768:3
	lw	ra, 20(sp)                      # 4-byte Folded Reload
	lw	s0, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Ltmp107:
.Lfunc_end3:
	.size	sprintf_, .Lfunc_end3-sprintf_
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _out_buffer
	.type	_out_buffer,@function
_out_buffer:                            # @_out_buffer
.Lfunc_begin4:
	.loc	3 105 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:105:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sb	a0, -9(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
.Ltmp108:
	.loc	3 106 7 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:106:7
	lw	a0, -20(s0)
	.loc	3 106 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:106:13
	lw	a1, -24(s0)
	.loc	3 106 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:106:11
	bgeu	a0, a1, .LBB4_2
	j	.LBB4_1
.LBB4_1:
.Ltmp109:
	.loc	3 107 29 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:107:29
	lbu	a0, -9(s0)
	.loc	3 107 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:107:14
	lw	a1, -16(s0)
	.loc	3 107 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:107:22
	lw	a2, -20(s0)
	.loc	3 107 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:107:5
	add	a1, a1, a2
	.loc	3 107 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:107:27
	sb	a0, 0(a1)
	.loc	3 108 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:108:3
	j	.LBB4_2
.Ltmp110:
.LBB4_2:
	.cfi_def_cfa sp, 32
	.loc	3 109 1 epilogue_begin          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:109:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp111:
.Lfunc_end4:
	.size	_out_buffer, .Lfunc_end4-_out_buffer
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	snprintf_                       # -- Begin function snprintf_
	.p2align	2
	.type	snprintf_,@function
snprintf_:                              # @snprintf_
.Lfunc_begin5:
	.loc	3 771 0                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:771:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -64
	.cfi_def_cfa_offset 64
	sw	ra, 36(sp)                      # 4-byte Folded Spill
	sw	s0, 32(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -28
	.cfi_offset s0, -32
	addi	s0, sp, 40
	.cfi_def_cfa s0, 24
	sw	a7, 20(s0)
	sw	a6, 16(s0)
	sw	a5, 12(s0)
	sw	a4, 8(s0)
	sw	a3, 4(s0)
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	addi	a0, s0, 4
.Ltmp112:
	.loc	3 773 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:773:3
	sw	a0, -24(s0)
	.loc	3 774 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:774:43
	lw	a1, -12(s0)
	.loc	3 774 51 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:774:51
	lw	a2, -16(s0)
	.loc	3 774 58                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:774:58
	lw	a3, -20(s0)
	.loc	3 774 66                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:774:66
	lw	a4, -24(s0)
	.loc	3 774 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:774:19
	lui	a0, %hi(_out_buffer)
	addi	a0, a0, %lo(_out_buffer)
	call	_vsnprintf
	.loc	3 774 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:774:13
	sw	a0, -28(s0)
	.loc	3 776 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:776:10
	lw	a0, -28(s0)
	.cfi_def_cfa sp, 64
	.loc	3 776 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:776:3
	lw	ra, 36(sp)                      # 4-byte Folded Reload
	lw	s0, 32(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 64
	.cfi_def_cfa_offset 0
	ret
.Ltmp113:
.Lfunc_end5:
	.size	snprintf_, .Lfunc_end5-snprintf_
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	vsnprintf_                      # -- Begin function vsnprintf_
	.p2align	2
	.type	vsnprintf_,@function
vsnprintf_:                             # @vsnprintf_
.Lfunc_begin6:
	.loc	3 779 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:779:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
.Ltmp114:
	.loc	3 780 34 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:780:34
	lw	a1, -12(s0)
	.loc	3 780 42 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:780:42
	lw	a2, -16(s0)
	.loc	3 780 49                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:780:49
	lw	a3, -20(s0)
	.loc	3 780 57                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:780:57
	lw	a4, -24(s0)
	.loc	3 780 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:780:10
	lui	a0, %hi(_out_buffer)
	addi	a0, a0, %lo(_out_buffer)
	call	_vsnprintf
	.cfi_def_cfa sp, 32
	.loc	3 780 3 epilogue_begin          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:780:3
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp115:
.Lfunc_end6:
	.size	vsnprintf_, .Lfunc_end6-vsnprintf_
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	fctprintf                       # -- Begin function fctprintf
	.p2align	2
	.type	fctprintf,@function
fctprintf:                              # @fctprintf
.Lfunc_begin7:
	.loc	3 784 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:784:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -64
	.cfi_def_cfa_offset 64
	sw	ra, 36(sp)                      # 4-byte Folded Spill
	sw	s0, 32(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -28
	.cfi_offset s0, -32
	addi	s0, sp, 40
	.cfi_def_cfa s0, 24
	sw	a7, 20(s0)
	sw	a6, 16(s0)
	sw	a5, 12(s0)
	sw	a4, 8(s0)
	sw	a3, 4(s0)
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	addi	a0, s0, 4
.Ltmp116:
	.loc	3 786 3 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:786:3
	sw	a0, -24(s0)
	.loc	3 787 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:787:43
	lw	a0, -12(s0)
	.loc	3 787 42 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:787:42
	sw	a0, -32(s0)
	.loc	3 787 48                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:787:48
	lw	a0, -16(s0)
	.loc	3 787 42                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:787:42
	sw	a0, -28(s0)
	.loc	3 789 42 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:789:42
	lw	a3, -20(s0)
	.loc	3 789 50 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:789:50
	lw	a4, -24(s0)
	.loc	3 788 19 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:788:19
	lui	a0, %hi(_out_fct)
	addi	a0, a0, %lo(_out_fct)
	addi	a1, s0, -32
	li	a2, -1
	call	_vsnprintf
	.loc	3 788 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:788:13
	sw	a0, -36(s0)
	.loc	3 791 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:791:10
	lw	a0, -36(s0)
	.cfi_def_cfa sp, 64
	.loc	3 791 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:791:3
	lw	ra, 36(sp)                      # 4-byte Folded Reload
	lw	s0, 32(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 64
	.cfi_def_cfa_offset 0
	ret
.Ltmp117:
.Lfunc_end7:
	.size	fctprintf, .Lfunc_end7-fctprintf
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _out_fct
	.type	_out_fct,@function
_out_fct:                               # @_out_fct
.Lfunc_begin8:
	.loc	3 133 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:133:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sb	a0, -9(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
.Ltmp118:
	.loc	3 136 7 prologue_end            # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:136:7
	lbu	a0, -9(s0)
	beqz	a0, .LBB8_2
	j	.LBB8_1
.LBB8_1:
.Ltmp119:
	.loc	3 138 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:138:27
	lw	a1, -16(s0)
	.loc	3 139 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:139:11
	lw	a2, 0(a1)
	.loc	3 139 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:139:15
	lbu	a0, -9(s0)
	.loc	3 139 57                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:139:57
	lw	a1, 4(a1)
	.loc	3 138 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:138:5
	jalr	a2
	.loc	3 140 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:140:3
	j	.LBB8_2
.Ltmp120:
.LBB8_2:
	.cfi_def_cfa sp, 32
	.loc	3 141 1 epilogue_begin          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:141:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp121:
.Lfunc_end8:
	.size	_out_fct, .Lfunc_end8-_out_fct
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _out_null
	.type	_out_null,@function
_out_null:                              # @_out_null
.Lfunc_begin9:
	.loc	3 113 0                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:113:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sb	a0, -9(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
	.cfi_def_cfa sp, 32
.Ltmp122:
	.loc	3 118 1 prologue_end epilogue_begin # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:118:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp123:
.Lfunc_end9:
	.size	_out_null, .Lfunc_end9-_out_null
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _is_digit
	.type	_is_digit,@function
_is_digit:                              # @_is_digit
.Lfunc_begin10:
	.loc	3 155 0                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sb	a0, -9(s0)
.Ltmp124:
	.loc	3 155 49 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:49
	lbu	a1, -9(s0)
	li	a2, 48
	li	a0, 0
	.loc	3 155 60 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:60
	blt	a1, a2, .LBB10_2
	j	.LBB10_1
.LBB10_1:
	.loc	3 155 64                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:64
	lbu	a0, -9(s0)
	.loc	3 155 67                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:67
	slti	a0, a0, 58
	j	.LBB10_2
.LBB10_2:
	.loc	3 155 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:41
	andi	a0, a0, 1
	.cfi_def_cfa sp, 16
	.loc	3 155 41 epilogue_begin         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:155:41
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp125:
.Lfunc_end10:
	.size	_is_digit, .Lfunc_end10-_is_digit
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _atoi
	.type	_atoi,@function
_atoi:                                  # @_atoi
.Lfunc_begin11:
	.loc	3 158 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:158:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sw	ra, 12(sp)                      # 4-byte Folded Spill
	sw	s0, 8(sp)                       # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 16
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
.Ltmp126:
	.loc	3 159 16 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:159:16
	sw	zero, -16(s0)
	.loc	3 160 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:3
	j	.LBB11_1
.LBB11_1:                               # =>This Inner Loop Header: Depth=1
	.loc	3 160 22 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:22
	lw	a0, -12(s0)
	.loc	3 160 21                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:21
	lw	a0, 0(a0)
	.loc	3 160 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:20
	lbu	a0, 0(a0)
	.loc	3 160 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:10
	call	_is_digit
	.loc	3 160 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:3
	beqz	a0, .LBB11_3
	j	.LBB11_2
.LBB11_2:                               #   in Loop: Header=BB11_1 Depth=1
.Ltmp127:
	.loc	3 161 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:9
	lw	a0, -16(s0)
	li	a1, 10
	.loc	3 161 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:11
	mul	a0, a0, a1
	.loc	3 161 38                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:38
	lw	a1, -12(s0)
	.loc	3 161 42                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:42
	lw	a2, 0(a1)
	addi	a3, a2, 1
	sw	a3, 0(a1)
	.loc	3 161 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:34
	lbu	a1, 0(a2)
	.loc	3 161 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:17
	add	a0, a1, a0
	addi	a0, a0, -48
	.loc	3 161 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:161:7
	sw	a0, -16(s0)
.Ltmp128:
	.loc	3 160 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:160:3
	j	.LBB11_1
.LBB11_3:
	.loc	3 163 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:163:10
	lw	a0, -16(s0)
	.cfi_def_cfa sp, 16
	.loc	3 163 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:163:3
	lw	ra, 12(sp)                      # 4-byte Folded Reload
	lw	s0, 8(sp)                       # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Ltmp129:
.Lfunc_end11:
	.size	_atoi, .Lfunc_end11-_atoi
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _ntoa_long
	.type	_ntoa_long,@function
_ntoa_long:                             # @_ntoa_long
.Lfunc_begin12:
	.loc	3 247 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:247:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -96
	.cfi_def_cfa_offset 96
	sw	ra, 92(sp)                      # 4-byte Folded Spill
	sw	s0, 88(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 96
	.cfi_def_cfa s0, 0
	lw	t0, 4(s0)
	lw	t0, 0(s0)
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
	sw	a4, -28(s0)
	sb	a5, -29(s0)
	sw	a6, -36(s0)
	sw	a7, -40(s0)
.Ltmp130:
	.loc	3 249 10 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:249:10
	sw	zero, -76(s0)
.Ltmp131:
	.loc	3 252 8                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:252:8
	lw	a0, -28(s0)
	.loc	3 252 7 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:252:7
	bnez	a0, .LBB12_2
	j	.LBB12_1
.LBB12_1:
.Ltmp132:
	.loc	3 253 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:253:11
	lw	a0, 4(s0)
	andi	a0, a0, -17
	sw	a0, 4(s0)
	.loc	3 254 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:254:3
	j	.LBB12_2
.Ltmp133:
.LBB12_2:
	.loc	3 257 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:257:15
	lbu	a0, 5(s0)
	andi	a0, a0, 4
	.loc	3 257 34 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:257:34
	beqz	a0, .LBB12_4
	j	.LBB12_3
.LBB12_3:
	.loc	3 257 37                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:257:37
	lw	a0, -28(s0)
	.loc	3 257 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:257:34
	beqz	a0, .LBB12_13
	j	.LBB12_4
.LBB12_4:
.Ltmp134:
	.loc	3 258 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:258:5
	j	.LBB12_5
.LBB12_5:                               # =>This Inner Loop Header: Depth=1
.Ltmp135:
	.loc	3 259 33                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:259:33
	lw	a0, -28(s0)
	.loc	3 259 41 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:259:41
	lw	a1, -36(s0)
	.loc	3 259 39                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:259:39
	remu	a0, a0, a1
	.loc	3 259 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:259:18
	sb	a0, -77(s0)
	.loc	3 260 27 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:27
	lbu	a0, -77(s0)
	li	a1, 9
	blt	a1, a0, .LBB12_7
	j	.LBB12_6
.LBB12_6:                               #   in Loop: Header=BB12_5 Depth=1
	.loc	3 260 46 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:46
	lbu	a0, -77(s0)
	.loc	3 260 44                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:44
	addi	a0, a0, 48
	.loc	3 260 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:27
	j	.LBB12_8
.LBB12_7:                               #   in Loop: Header=BB12_5 Depth=1
	.loc	3 261 41 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:261:41
	lbu	a0, 4(s0)
	slli	a0, a0, 26
	srai	a0, a0, 31
	andi	a0, a0, -32
	.loc	3 262 44                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:262:44
	lbu	a1, -77(s0)
	.loc	3 261 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:261:41
	add	a0, a0, a1
	.loc	3 262 50                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:262:50
	addi	a0, a0, 87
	.loc	3 260 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:27
	j	.LBB12_8
.LBB12_8:                               #   in Loop: Header=BB12_5 Depth=1
	.loc	3 260 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:14
	lw	a1, -76(s0)
	addi	a2, a1, 1
	sw	a2, -76(s0)
	addi	a2, s0, -72
	.loc	3 260 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:7
	add	a1, a2, a1
	.loc	3 260 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:260:18
	sb	a0, 0(a1)
	.loc	3 263 16 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:263:16
	lw	a0, -36(s0)
	.loc	3 263 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:263:13
	lw	a1, -28(s0)
	divu	a0, a1, a0
	sw	a0, -28(s0)
	.loc	3 264 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:264:5
	j	.LBB12_9
.Ltmp136:
.LBB12_9:                               #   in Loop: Header=BB12_5 Depth=1
	.loc	3 264 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:264:14
	lw	a1, -28(s0)
	li	a0, 0
	.loc	3 264 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:264:20
	beqz	a1, .LBB12_11
	j	.LBB12_10
.LBB12_10:                              #   in Loop: Header=BB12_5 Depth=1
	.loc	3 264 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:264:24
	lw	a0, -76(s0)
	.loc	3 264 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:264:28
	sltiu	a0, a0, 32
	j	.LBB12_11
.LBB12_11:                              #   in Loop: Header=BB12_5 Depth=1
.Ltmp137:
	.loc	3 264 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:264:5
	andi	a0, a0, 1
	bnez	a0, .LBB12_5
	j	.LBB12_12
.Ltmp138:
.LBB12_12:
	.loc	3 265 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:265:3
	j	.LBB12_13
.Ltmp139:
.LBB12_13:
	.loc	3 267 23                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:23
	lw	a0, -12(s0)
	.loc	3 267 28 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:28
	lw	a1, -16(s0)
	.loc	3 267 36                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:36
	lw	a2, -20(s0)
	.loc	3 267 41                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:41
	lw	a3, -24(s0)
	.loc	3 267 54                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:54
	lw	a5, -76(s0)
	.loc	3 268 37 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:268:37
	lw	a7, -36(s0)
	.loc	3 268 43 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:268:43
	lw	a4, -40(s0)
	.loc	3 268 49                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:268:49
	lw	a6, 0(s0)
	.loc	3 268 56                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:268:56
	lw	t0, 4(s0)
	.loc	3 267 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:10
	lbu	t1, -29(s0)
	sw	t0, 8(sp)
	sw	a6, 4(sp)
	sw	a4, 0(sp)
	andi	a6, t1, 1
	addi	a4, s0, -72
	call	_ntoa_format
	.cfi_def_cfa sp, 96
	.loc	3 267 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:267:3
	lw	ra, 92(sp)                      # 4-byte Folded Reload
	lw	s0, 88(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 96
	.cfi_def_cfa_offset 0
	ret
.Ltmp140:
.Lfunc_end12:
	.size	_ntoa_long, .Lfunc_end12-_ntoa_long
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _strnlen_s
	.type	_strnlen_s,@function
_strnlen_s:                             # @_strnlen_s
.Lfunc_begin13:
	.loc	3 146 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:146:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
	sw	a0, -12(s0)
	sw	a1, -16(s0)
.Ltmp141:
	.loc	3 148 12 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:12
	lw	a0, -12(s0)
	.loc	3 148 10 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:10
	sw	a0, -20(s0)
	.loc	3 148 8                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:8
	j	.LBB13_1
.LBB13_1:                               # =>This Inner Loop Header: Depth=1
.Ltmp142:
	.loc	3 148 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:18
	lw	a0, -20(s0)
	.loc	3 148 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:17
	lbu	a1, 0(a0)
	li	a0, 0
	.loc	3 148 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:20
	beqz	a1, .LBB13_3
	j	.LBB13_2
.LBB13_2:                               #   in Loop: Header=BB13_1 Depth=1
	.loc	3 148 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:30
	lw	a0, -16(s0)
	addi	a1, a0, -1
	sw	a1, -16(s0)
	.loc	3 148 20                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:20
	snez	a0, a0
	j	.LBB13_3
.Ltmp143:
.LBB13_3:                               #   in Loop: Header=BB13_1 Depth=1
	.loc	3 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:3
	andi	a0, a0, 1
	beqz	a0, .LBB13_6
	j	.LBB13_4
.LBB13_4:                               #   in Loop: Header=BB13_1 Depth=1
	j	.LBB13_5
.LBB13_5:                               #   in Loop: Header=BB13_1 Depth=1
.Ltmp144:
	.loc	3 148 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:34
	lw	a0, -20(s0)
	addi	a0, a0, 1
	sw	a0, -20(s0)
	.loc	3 148 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:148:3
	j	.LBB13_1
.Ltmp145:
.LBB13_6:
	.loc	3 150 25 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:150:25
	lw	a0, -20(s0)
	.loc	3 150 29 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:150:29
	lw	a1, -12(s0)
	.loc	3 150 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:150:27
	sub	a0, a0, a1
	.cfi_def_cfa sp, 32
	.loc	3 150 3 epilogue_begin          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:150:3
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp146:
.Lfunc_end13:
	.size	_strnlen_s, .Lfunc_end13-_strnlen_s
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.p2align	2                               # -- Begin function _ntoa_format
	.type	_ntoa_format,@function
_ntoa_format:                           # @_ntoa_format
.Lfunc_begin14:
	.loc	3 170 0 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:170:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -64
	.cfi_def_cfa_offset 64
	sw	ra, 60(sp)                      # 4-byte Folded Spill
	sw	s0, 56(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 64
	.cfi_def_cfa s0, 0
	lw	t0, 8(s0)
	lw	t0, 4(s0)
	lw	t0, 0(s0)
	sw	a0, -12(s0)
	sw	a1, -16(s0)
	sw	a2, -20(s0)
	sw	a3, -24(s0)
	sw	a4, -28(s0)
	sw	a5, -32(s0)
	sb	a6, -33(s0)
	sw	a7, -40(s0)
.Ltmp147:
	.loc	3 171 28 prologue_end           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:171:28
	lw	a0, -20(s0)
	.loc	3 171 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:171:16
	sw	a0, -44(s0)
.Ltmp148:
	.loc	3 174 15 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:174:15
	lbu	a0, 8(s0)
	andi	a0, a0, 2
	.loc	3 174 7 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:174:7
	bnez	a0, .LBB14_18
	j	.LBB14_1
.LBB14_1:
.Ltmp149:
	.loc	3 175 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:175:9
	lw	a0, 4(s0)
	.loc	3 175 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:175:15
	beqz	a0, .LBB14_6
	j	.LBB14_2
.LBB14_2:
	.loc	3 175 25                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:175:25
	lbu	a0, 8(s0)
	andi	a0, a0, 1
	.loc	3 175 42                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:175:42
	beqz	a0, .LBB14_6
	j	.LBB14_3
.LBB14_3:
	.loc	3 176 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:176:10
	lbu	a0, -33(s0)
	andi	a0, a0, 1
	.loc	3 176 19 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:176:19
	bnez	a0, .LBB14_5
	j	.LBB14_4
.LBB14_4:
	.loc	3 176 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:176:29
	lbu	a0, 8(s0)
	andi	a0, a0, 12
	.loc	3 175 42 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:175:42
	beqz	a0, .LBB14_6
	j	.LBB14_5
.LBB14_5:
.Ltmp150:
	.loc	3 177 12                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:177:12
	lw	a0, 4(s0)
	addi	a0, a0, -1
	sw	a0, 4(s0)
	.loc	3 178 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:178:5
	j	.LBB14_6
.Ltmp151:
.LBB14_6:
	.loc	3 179 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:5
	j	.LBB14_7
.LBB14_7:                               # =>This Inner Loop Header: Depth=1
	.loc	3 179 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:13
	lw	a1, -32(s0)
	.loc	3 179 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:19
	lw	a2, 0(s0)
	li	a0, 0
	.loc	3 179 25                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:25
	bgeu	a1, a2, .LBB14_9
	j	.LBB14_8
.LBB14_8:                               #   in Loop: Header=BB14_7 Depth=1
	.loc	3 179 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:29
	lw	a0, -32(s0)
	.loc	3 179 33                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:33
	sltiu	a0, a0, 32
	j	.LBB14_9
.LBB14_9:                               #   in Loop: Header=BB14_7 Depth=1
	.loc	3 179 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:5
	andi	a0, a0, 1
	beqz	a0, .LBB14_11
	j	.LBB14_10
.LBB14_10:                              #   in Loop: Header=BB14_7 Depth=1
.Ltmp152:
	.loc	3 180 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:180:7
	lw	a0, -28(s0)
	.loc	3 180 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:180:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 180 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:180:7
	add	a0, a0, a1
	li	a1, 48
	.loc	3 180 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:180:18
	sb	a1, 0(a0)
.Ltmp153:
	.loc	3 179 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:179:5
	j	.LBB14_7
.LBB14_11:
	.loc	3 182 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:5
	j	.LBB14_12
.LBB14_12:                              # =>This Inner Loop Header: Depth=1
	.loc	3 182 19 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:19
	lbu	a0, 8(s0)
	andi	a1, a0, 1
	li	a0, 0
	.loc	3 182 36                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:36
	beqz	a1, .LBB14_15
	j	.LBB14_13
.LBB14_13:                              #   in Loop: Header=BB14_12 Depth=1
	.loc	3 182 40                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:40
	lw	a1, -32(s0)
	.loc	3 182 46                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:46
	lw	a2, 4(s0)
	li	a0, 0
	.loc	3 182 53                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:53
	bgeu	a1, a2, .LBB14_15
	j	.LBB14_14
.LBB14_14:                              #   in Loop: Header=BB14_12 Depth=1
	.loc	3 183 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:183:13
	lw	a0, -32(s0)
	.loc	3 183 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:183:17
	sltiu	a0, a0, 32
	j	.LBB14_15
.LBB14_15:                              #   in Loop: Header=BB14_12 Depth=1
	.loc	3 182 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:5
	andi	a0, a0, 1
	beqz	a0, .LBB14_17
	j	.LBB14_16
.LBB14_16:                              #   in Loop: Header=BB14_12 Depth=1
.Ltmp154:
	.loc	3 184 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:184:7
	lw	a0, -28(s0)
	.loc	3 184 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:184:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 184 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:184:7
	add	a0, a0, a1
	li	a1, 48
	.loc	3 184 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:184:18
	sb	a1, 0(a0)
.Ltmp155:
	.loc	3 182 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:182:5
	j	.LBB14_12
.LBB14_17:
	.loc	3 186 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:186:3
	j	.LBB14_18
.Ltmp156:
.LBB14_18:
	.loc	3 189 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:189:13
	lbu	a0, 8(s0)
	andi	a0, a0, 16
	beqz	a0, .LBB14_43
	j	.LBB14_19
.LBB14_19:
.Ltmp157:
	.loc	3 190 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:190:17
	lbu	a0, 9(s0)
	andi	a0, a0, 4
	.loc	3 190 36 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:190:36
	bnez	a0, .LBB14_27
	j	.LBB14_20
.LBB14_20:
	.loc	3 190 39                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:190:39
	lw	a0, -32(s0)
	.loc	3 190 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:190:43
	beqz	a0, .LBB14_27
	j	.LBB14_21
.LBB14_21:
	.loc	3 191 11 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:191:11
	lw	a0, -32(s0)
	.loc	3 191 18 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:191:18
	lw	a1, 0(s0)
	.loc	3 191 24                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:191:24
	beq	a0, a1, .LBB14_23
	j	.LBB14_22
.LBB14_22:
	.loc	3 191 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:191:28
	lw	a0, -32(s0)
	.loc	3 191 35                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:191:35
	lw	a1, 4(s0)
	.loc	3 190 43 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:190:43
	bne	a0, a1, .LBB14_27
	j	.LBB14_23
.LBB14_23:
.Ltmp158:
	.loc	3 192 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:192:10
	lw	a0, -32(s0)
	addi	a0, a0, -1
	sw	a0, -32(s0)
.Ltmp159:
	.loc	3 193 11                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:193:11
	lw	a0, -32(s0)
	.loc	3 193 15 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:193:15
	beqz	a0, .LBB14_26
	j	.LBB14_24
.LBB14_24:
	.loc	3 193 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:193:19
	lw	a0, -40(s0)
	li	a1, 16
	.loc	3 193 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:193:15
	bne	a0, a1, .LBB14_26
	j	.LBB14_25
.LBB14_25:
.Ltmp160:
	.loc	3 194 12 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:194:12
	lw	a0, -32(s0)
	addi	a0, a0, -1
	sw	a0, -32(s0)
	.loc	3 195 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:195:7
	j	.LBB14_26
.Ltmp161:
.LBB14_26:
	.loc	3 196 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:196:5
	j	.LBB14_27
.Ltmp162:
.LBB14_27:
	.loc	3 197 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:197:10
	lw	a0, -40(s0)
	li	a1, 16
	.loc	3 197 23 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:197:23
	bne	a0, a1, .LBB14_31
	j	.LBB14_28
.LBB14_28:
	.loc	3 197 34                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:197:34
	lbu	a0, 8(s0)
	andi	a0, a0, 32
	.loc	3 197 53                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:197:53
	bnez	a0, .LBB14_31
	j	.LBB14_29
.LBB14_29:
	.loc	3 198 10 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:198:10
	lw	a0, -32(s0)
	li	a1, 31
	.loc	3 197 53                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:197:53
	bltu	a1, a0, .LBB14_31
	j	.LBB14_30
.LBB14_30:
.Ltmp163:
	.loc	3 199 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:199:7
	lw	a0, -28(s0)
	.loc	3 199 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:199:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 199 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:199:7
	add	a0, a0, a1
	li	a1, 120
	.loc	3 199 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:199:18
	sb	a1, 0(a0)
	.loc	3 200 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:200:5
	j	.LBB14_40
.Ltmp164:
.LBB14_31:
	.loc	3 200 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:200:17
	lw	a0, -40(s0)
	li	a1, 16
	.loc	3 200 30 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:200:30
	bne	a0, a1, .LBB14_35
	j	.LBB14_32
.LBB14_32:
	.loc	3 200 40                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:200:40
	lbu	a0, 8(s0)
	andi	a0, a0, 32
	.loc	3 200 59                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:200:59
	beqz	a0, .LBB14_35
	j	.LBB14_33
.LBB14_33:
	.loc	3 201 17 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:201:17
	lw	a0, -32(s0)
	li	a1, 31
	.loc	3 200 59                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:200:59
	bltu	a1, a0, .LBB14_35
	j	.LBB14_34
.LBB14_34:
.Ltmp165:
	.loc	3 202 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:202:7
	lw	a0, -28(s0)
	.loc	3 202 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:202:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 202 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:202:7
	add	a0, a0, a1
	li	a1, 88
	.loc	3 202 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:202:18
	sb	a1, 0(a0)
	.loc	3 203 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:203:5
	j	.LBB14_39
.Ltmp166:
.LBB14_35:
	.loc	3 203 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:203:17
	lw	a0, -40(s0)
	li	a1, 2
	.loc	3 203 29 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:203:29
	bne	a0, a1, .LBB14_38
	j	.LBB14_36
.LBB14_36:
	.loc	3 203 33                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:203:33
	lw	a0, -32(s0)
	li	a1, 31
	.loc	3 203 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:203:29
	bltu	a1, a0, .LBB14_38
	j	.LBB14_37
.LBB14_37:
.Ltmp167:
	.loc	3 204 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:204:7
	lw	a0, -28(s0)
	.loc	3 204 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:204:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 204 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:204:7
	add	a0, a0, a1
	li	a1, 98
	.loc	3 204 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:204:18
	sb	a1, 0(a0)
	.loc	3 205 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:205:5
	j	.LBB14_38
.Ltmp168:
.LBB14_38:
	.loc	3 0 5 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:5
	j	.LBB14_39
.LBB14_39:
	j	.LBB14_40
.LBB14_40:
.Ltmp169:
	.loc	3 206 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:206:9
	lw	a0, -32(s0)
	li	a1, 31
	.loc	3 206 13 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:206:13
	bltu	a1, a0, .LBB14_42
	j	.LBB14_41
.LBB14_41:
.Ltmp170:
	.loc	3 207 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:207:7
	lw	a0, -28(s0)
	.loc	3 207 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:207:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 207 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:207:7
	add	a0, a0, a1
	li	a1, 48
	.loc	3 207 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:207:18
	sb	a1, 0(a0)
	.loc	3 208 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:208:5
	j	.LBB14_42
.Ltmp171:
.LBB14_42:
	.loc	3 209 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:209:3
	j	.LBB14_43
.Ltmp172:
.LBB14_43:
	.loc	3 211 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:211:7
	lw	a0, -32(s0)
	li	a1, 31
	.loc	3 211 11 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:211:11
	bltu	a1, a0, .LBB14_53
	j	.LBB14_44
.LBB14_44:
.Ltmp173:
	.loc	3 212 9 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:212:9
	lbu	a0, -33(s0)
	andi	a0, a0, 1
	beqz	a0, .LBB14_46
	j	.LBB14_45
.LBB14_45:
.Ltmp174:
	.loc	3 213 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:213:7
	lw	a0, -28(s0)
	.loc	3 213 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:213:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 213 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:213:7
	add	a0, a0, a1
	li	a1, 45
	.loc	3 213 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:213:18
	sb	a1, 0(a0)
	.loc	3 214 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:214:5
	j	.LBB14_52
.Ltmp175:
.LBB14_46:
	.loc	3 214 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:214:22
	lbu	a0, 8(s0)
	andi	a0, a0, 4
	beqz	a0, .LBB14_48
	j	.LBB14_47
.LBB14_47:
.Ltmp176:
	.loc	3 215 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:215:7
	lw	a0, -28(s0)
	.loc	3 215 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:215:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 215 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:215:7
	add	a0, a0, a1
	li	a1, 43
	.loc	3 215 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:215:18
	sb	a1, 0(a0)
	.loc	3 216 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:216:5
	j	.LBB14_51
.Ltmp177:
.LBB14_48:
	.loc	3 216 22                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:216:22
	lbu	a0, 8(s0)
	andi	a0, a0, 8
	beqz	a0, .LBB14_50
	j	.LBB14_49
.LBB14_49:
.Ltmp178:
	.loc	3 217 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:217:7
	lw	a0, -28(s0)
	.loc	3 217 14 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:217:14
	lw	a1, -32(s0)
	addi	a2, a1, 1
	sw	a2, -32(s0)
	.loc	3 217 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:217:7
	add	a0, a0, a1
	li	a1, 32
	.loc	3 217 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:217:18
	sb	a1, 0(a0)
	.loc	3 218 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:218:5
	j	.LBB14_50
.Ltmp179:
.LBB14_50:
	.loc	3 0 5 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:0:5
	j	.LBB14_51
.LBB14_51:
	j	.LBB14_52
.LBB14_52:
	.loc	3 219 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:219:3
	j	.LBB14_53
.Ltmp180:
.LBB14_53:
	.loc	3 222 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:222:15
	lbu	a0, 8(s0)
	andi	a0, a0, 2
	.loc	3 222 29 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:222:29
	bnez	a0, .LBB14_60
	j	.LBB14_54
.LBB14_54:
	.loc	3 222 40                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:222:40
	lbu	a0, 8(s0)
	andi	a0, a0, 1
	.loc	3 222 29                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:222:29
	bnez	a0, .LBB14_60
	j	.LBB14_55
.LBB14_55:
.Ltmp181:
	.loc	3 223 21 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:21
	lw	a0, -32(s0)
	.loc	3 223 17 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:17
	sw	a0, -48(s0)
	.loc	3 223 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:10
	j	.LBB14_56
.LBB14_56:                              # =>This Inner Loop Header: Depth=1
.Ltmp182:
	.loc	3 223 26                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:26
	lw	a0, -48(s0)
	.loc	3 223 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:30
	lw	a1, 4(s0)
.Ltmp183:
	.loc	3 223 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:5
	bgeu	a0, a1, .LBB14_59
	j	.LBB14_57
.LBB14_57:                              #   in Loop: Header=BB14_56 Depth=1
.Ltmp184:
	.loc	3 224 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:224:7
	lw	a4, -12(s0)
	.loc	3 224 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:224:16
	lw	a1, -16(s0)
	.loc	3 224 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:224:27
	lw	a2, -20(s0)
	addi	a0, a2, 1
	sw	a0, -20(s0)
	.loc	3 224 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:224:31
	lw	a3, -24(s0)
	.loc	3 224 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:224:7
	li	a0, 32
	jalr	a4
	.loc	3 225 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:225:5
	j	.LBB14_58
.Ltmp185:
.LBB14_58:                              #   in Loop: Header=BB14_56 Depth=1
	.loc	3 223 38                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:38
	lw	a0, -48(s0)
	addi	a0, a0, 1
	sw	a0, -48(s0)
	.loc	3 223 5 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:223:5
	j	.LBB14_56
.Ltmp186:
.LBB14_59:
	.loc	3 226 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:226:3
	j	.LBB14_60
.Ltmp187:
.LBB14_60:
	.loc	3 229 15                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:15
	sw	zero, -52(s0)
	.loc	3 229 8 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:8
	j	.LBB14_61
.LBB14_61:                              # =>This Inner Loop Header: Depth=1
.Ltmp188:
	.loc	3 229 23                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:23
	lw	a0, -52(s0)
	.loc	3 229 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:27
	lw	a1, -32(s0)
.Ltmp189:
	.loc	3 229 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:3
	bgeu	a0, a1, .LBB14_64
	j	.LBB14_62
.LBB14_62:                              #   in Loop: Header=BB14_61 Depth=1
.Ltmp190:
	.loc	3 230 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:5
	lw	a4, -12(s0)
	.loc	3 230 9 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:9
	lw	a0, -28(s0)
	.loc	3 230 13                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:13
	lw	a1, -32(s0)
	.loc	3 230 19                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:19
	lw	a2, -52(s0)
	.loc	3 230 17                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:17
	sub	a1, a1, a2
	.loc	3 230 9                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:9
	add	a0, a1, a0
	lbu	a0, -1(a0)
	.loc	3 230 28                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:28
	lw	a1, -16(s0)
	.loc	3 230 39                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:39
	lw	a2, -20(s0)
	addi	a3, a2, 1
	sw	a3, -20(s0)
	.loc	3 230 43                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:43
	lw	a3, -24(s0)
	.loc	3 230 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:230:5
	jalr	a4
	.loc	3 231 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:231:3
	j	.LBB14_63
.Ltmp191:
.LBB14_63:                              #   in Loop: Header=BB14_61 Depth=1
	.loc	3 229 33                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:33
	lw	a0, -52(s0)
	addi	a0, a0, 1
	sw	a0, -52(s0)
	.loc	3 229 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:229:3
	j	.LBB14_61
.Ltmp192:
.LBB14_64:
	.loc	3 234 13 is_stmt 1              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:234:13
	lbu	a0, 8(s0)
	andi	a0, a0, 2
	beqz	a0, .LBB14_69
	j	.LBB14_65
.LBB14_65:
.Ltmp193:
	.loc	3 235 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:5
	j	.LBB14_66
.LBB14_66:                              # =>This Inner Loop Header: Depth=1
	.loc	3 235 12 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:12
	lw	a0, -20(s0)
	.loc	3 235 18                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:18
	lw	a1, -44(s0)
	.loc	3 235 16                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:16
	sub	a0, a0, a1
	.loc	3 235 30                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:30
	lw	a1, 4(s0)
	.loc	3 235 5                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:5
	bgeu	a0, a1, .LBB14_68
	j	.LBB14_67
.LBB14_67:                              #   in Loop: Header=BB14_66 Depth=1
.Ltmp194:
	.loc	3 236 7 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:236:7
	lw	a4, -12(s0)
	.loc	3 236 16 is_stmt 0              # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:236:16
	lw	a1, -16(s0)
	.loc	3 236 27                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:236:27
	lw	a2, -20(s0)
	addi	a0, a2, 1
	sw	a0, -20(s0)
	.loc	3 236 31                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:236:31
	lw	a3, -24(s0)
	.loc	3 236 7                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:236:7
	li	a0, 32
	jalr	a4
.Ltmp195:
	.loc	3 235 5 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:235:5
	j	.LBB14_66
.LBB14_68:
	.loc	3 238 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:238:3
	j	.LBB14_69
.Ltmp196:
.LBB14_69:
	.loc	3 240 10                        # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:240:10
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 64
	.loc	3 240 3 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c:240:3
	lw	ra, 60(sp)                      # 4-byte Folded Reload
	lw	s0, 56(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 64
	.cfi_def_cfa_offset 0
	ret
.Ltmp197:
.Lfunc_end14:
	.size	_ntoa_format, .Lfunc_end14-_ntoa_format
	.cfi_endproc
                                        # -- End function
	.option	pop
	.file	4 "/usr/lib/llvm-20/lib/clang/20/include" "__stdarg_va_list.h" md5 0x7bd78a282b99fcfe41a9e3c566d14f7d
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	116                             # DW_AT_rnglists_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	19                              # DW_TAG_structure_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	13                              # DW_TAG_member
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	56                              # DW_AT_data_member_location
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	21                              # DW_TAG_subroutine_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	5                               # DW_TAG_formal_parameter
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	5                               # DW_TAG_formal_parameter
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	24                              # DW_TAG_unspecified_parameters
	.byte	0                               # DW_CHILDREN_no
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	18                              # Abbreviation Code
	.byte	5                               # DW_TAG_formal_parameter
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	19                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	20                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	21                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	85                              # DW_AT_ranges
	.byte	35                              # DW_FORM_rnglistx
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	22                              # Abbreviation Code
	.byte	38                              # DW_TAG_const_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	23                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	24                              # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	25                              # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	26                              # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x650 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	0                               # DW_AT_low_pc
	.word	.Lfunc_end14-.Lfunc_begin0      # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.word	.Lrnglists_table_base0          # DW_AT_rnglists_base
	.byte	2                               # Abbrev [2] 0x27:0x8 DW_TAG_typedef
	.word	47                              # DW_AT_type
	.byte	4                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	18                              # DW_AT_decl_line
	.byte	3                               # Abbrev [3] 0x2f:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	4                               # Abbrev [4] 0x33:0x5 DW_TAG_pointer_type
	.word	56                              # DW_AT_type
	.byte	3                               # Abbrev [3] 0x38:0x4 DW_TAG_base_type
	.byte	5                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	5                               # Abbrev [5] 0x3c:0x9 DW_TAG_typedef
	.word	47                              # DW_AT_type
	.byte	6                               # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	3                               # Abbrev [3] 0x45:0x4 DW_TAG_base_type
	.byte	7                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x49:0x4 DW_TAG_base_type
	.byte	8                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x4d:0x4 DW_TAG_base_type
	.byte	9                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	2                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x51:0x4 DW_TAG_base_type
	.byte	10                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x55:0x4 DW_TAG_base_type
	.byte	11                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	2                               # DW_AT_byte_size
	.byte	4                               # Abbrev [4] 0x59:0x5 DW_TAG_pointer_type
	.word	94                              # DW_AT_type
	.byte	2                               # Abbrev [2] 0x5e:0x8 DW_TAG_typedef
	.word	102                             # DW_AT_type
	.byte	14                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	101                             # DW_AT_decl_line
	.byte	6                               # Abbrev [6] 0x66:0x17 DW_TAG_structure_type
	.byte	8                               # DW_AT_byte_size
	.byte	3                               # DW_AT_decl_file
	.byte	98                              # DW_AT_decl_line
	.byte	7                               # Abbrev [7] 0x6a:0x9 DW_TAG_member
	.byte	12                              # DW_AT_name
	.word	125                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	99                              # DW_AT_decl_line
	.byte	0                               # DW_AT_data_member_location
	.byte	7                               # Abbrev [7] 0x73:0x9 DW_TAG_member
	.byte	13                              # DW_AT_name
	.word	142                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	100                             # DW_AT_decl_line
	.byte	4                               # DW_AT_data_member_location
	.byte	0                               # End Of Children Mark
	.byte	4                               # Abbrev [4] 0x7d:0x5 DW_TAG_pointer_type
	.word	130                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x82:0xc DW_TAG_subroutine_type
                                        # DW_AT_prototyped
	.byte	9                               # Abbrev [9] 0x83:0x5 DW_TAG_formal_parameter
	.word	56                              # DW_AT_type
	.byte	9                               # Abbrev [9] 0x88:0x5 DW_TAG_formal_parameter
	.word	142                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x8e:0x1 DW_TAG_pointer_type
	.byte	11                              # Abbrev [11] 0x8f:0x42 DW_TAG_subprogram
	.byte	0                               # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	15                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	754                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	69                              # DW_AT_type
                                        # DW_AT_external
	.byte	12                              # Abbrev [12] 0x9f:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	31                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	754                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0xab:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	32                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	755                             # DW_AT_decl_line
	.word	1516                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0xb7:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	111
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	757                             # DW_AT_decl_line
	.word	1530                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0xc3:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	37                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	758                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0xcf:0x1 DW_TAG_unspecified_parameters
	.byte	0                               # End Of Children Mark
	.byte	15                              # Abbrev [15] 0xd1:0x132 DW_TAG_subprogram
	.byte	1                               # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	16                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	450                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	69                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0xe1:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	38                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	450                             # DW_AT_decl_line
	.word	1551                            # DW_AT_type
	.byte	12                              # Abbrev [12] 0xed:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	450                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0xf9:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	450                             # DW_AT_decl_line
	.word	1586                            # DW_AT_type
	.byte	12                              # Abbrev [12] 0x105:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	31                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	451                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	12                              # Abbrev [12] 0x111:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	32                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	451                             # DW_AT_decl_line
	.word	1516                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x11d:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	41                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	452                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	13                              # Abbrev [13] 0x129:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	42                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	452                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	13                              # Abbrev [13] 0x135:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	43                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	452                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	13                              # Abbrev [13] 0x141:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	44                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	452                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	13                              # Abbrev [13] 0x14d:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	453                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	16                              # Abbrev [16] 0x159:0x13 DW_TAG_lexical_block
	.byte	2                               # DW_AT_low_pc
	.word	.Ltmp25-.Ltmp20                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x15f:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	76
	.byte	46                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	512                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x16c:0x13 DW_TAG_lexical_block
	.byte	3                               # DW_AT_low_pc
	.word	.Ltmp32-.Ltmp31                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x172:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	72
	.byte	47                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	530                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x17f:0x4e DW_TAG_lexical_block
	.byte	4                               # DW_AT_low_pc
	.word	.Ltmp70-.Ltmp42                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x185:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	48                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	584                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	16                              # Abbrev [16] 0x191:0x13 DW_TAG_lexical_block
	.byte	5                               # DW_AT_low_pc
	.word	.Ltmp62-.Ltmp61                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x197:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	49                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	622                             # DW_AT_decl_line
	.word	1591                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x1a4:0x14 DW_TAG_lexical_block
	.byte	6                               # DW_AT_low_pc
	.word	.Ltmp63-.Ltmp62                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x1aa:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274\177"
	.byte	49                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	627                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x1b8:0x14 DW_TAG_lexical_block
	.byte	7                               # DW_AT_low_pc
	.word	.Ltmp69-.Ltmp68                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x1be:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\270\177"
	.byte	49                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	646                             # DW_AT_decl_line
	.word	1600                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x1cd:0x14 DW_TAG_lexical_block
	.byte	8                               # DW_AT_low_pc
	.word	.Ltmp82-.Ltmp71                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x1d3:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	51                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	667                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x1e1:0x21 DW_TAG_lexical_block
	.byte	9                               # DW_AT_low_pc
	.word	.Ltmp97-.Ltmp82                 # DW_AT_high_pc
	.byte	13                              # Abbrev [13] 0x1e7:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\260\177"
	.byte	52                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	687                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x1f4:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\254\177"
	.byte	51                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	688                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x203:0x38 DW_TAG_subprogram
	.byte	10                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin2       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	17                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.byte	18                              # Abbrev [18] 0x20e:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	119
	.byte	53                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	56                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x219:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	142                             # DW_AT_type
	.byte	18                              # Abbrev [18] 0x224:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	121                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x22f:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	122                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x23b:0x42 DW_TAG_subprogram
	.byte	11                              # DW_AT_low_pc
	.word	.Lfunc_end3-.Lfunc_begin3       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	18                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	763                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	69                              # DW_AT_type
                                        # DW_AT_external
	.byte	12                              # Abbrev [12] 0x24b:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	763                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0x257:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	31                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	763                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x263:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	32                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	764                             # DW_AT_decl_line
	.word	1516                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x26f:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	37                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	766                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x27b:0x1 DW_TAG_unspecified_parameters
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x27d:0x38 DW_TAG_subprogram
	.byte	12                              # DW_AT_low_pc
	.word	.Lfunc_end4-.Lfunc_begin4       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	19                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	104                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.byte	18                              # Abbrev [18] 0x288:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	119
	.byte	53                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	104                             # DW_AT_decl_line
	.word	56                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x293:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	104                             # DW_AT_decl_line
	.word	142                             # DW_AT_type
	.byte	18                              # Abbrev [18] 0x29e:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	104                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x2a9:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	105                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x2b5:0x4e DW_TAG_subprogram
	.byte	13                              # DW_AT_low_pc
	.word	.Lfunc_end5-.Lfunc_begin5       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	20                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	771                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	69                              # DW_AT_type
                                        # DW_AT_external
	.byte	12                              # Abbrev [12] 0x2c5:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	771                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0x2d1:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	54                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	771                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0x2dd:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	31                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	771                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x2e9:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	32                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	772                             # DW_AT_decl_line
	.word	1516                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x2f5:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	37                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	774                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x301:0x1 DW_TAG_unspecified_parameters
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x303:0x41 DW_TAG_subprogram
	.byte	14                              # DW_AT_low_pc
	.word	.Lfunc_end6-.Lfunc_begin6       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	21                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	779                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	69                              # DW_AT_type
                                        # DW_AT_external
	.byte	12                              # Abbrev [12] 0x313:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	779                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0x31f:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	54                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	779                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	12                              # Abbrev [12] 0x32b:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	31                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	779                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	12                              # Abbrev [12] 0x337:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	32                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	779                             # DW_AT_decl_line
	.word	1516                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x344:0x5a DW_TAG_subprogram
	.byte	15                              # DW_AT_low_pc
	.word	.Lfunc_end7-.Lfunc_begin7       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	22                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	783                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	69                              # DW_AT_type
                                        # DW_AT_external
	.byte	12                              # Abbrev [12] 0x354:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	38                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	783                             # DW_AT_decl_line
	.word	125                             # DW_AT_type
	.byte	12                              # Abbrev [12] 0x360:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	13                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	783                             # DW_AT_decl_line
	.word	142                             # DW_AT_type
	.byte	12                              # Abbrev [12] 0x36c:0xc DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	31                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	784                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x378:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	32                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	785                             # DW_AT_decl_line
	.word	1516                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x384:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	55                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	787                             # DW_AT_decl_line
	.word	1605                            # DW_AT_type
	.byte	13                              # Abbrev [13] 0x390:0xc DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	37                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	788                             # DW_AT_decl_line
	.word	1546                            # DW_AT_type
	.byte	14                              # Abbrev [14] 0x39c:0x1 DW_TAG_unspecified_parameters
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x39e:0x38 DW_TAG_subprogram
	.byte	16                              # DW_AT_low_pc
	.word	.Lfunc_end8-.Lfunc_begin8       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	23                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	132                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.byte	18                              # Abbrev [18] 0x3a9:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	119
	.byte	53                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	132                             # DW_AT_decl_line
	.word	56                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x3b4:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	132                             # DW_AT_decl_line
	.word	142                             # DW_AT_type
	.byte	18                              # Abbrev [18] 0x3bf:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	132                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x3ca:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	133                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x3d6:0x38 DW_TAG_subprogram
	.byte	17                              # DW_AT_low_pc
	.word	.Lfunc_end9-.Lfunc_begin9       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	24                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	112                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.byte	18                              # Abbrev [18] 0x3e1:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	119
	.byte	53                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	112                             # DW_AT_decl_line
	.word	56                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x3ec:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	112                             # DW_AT_decl_line
	.word	142                             # DW_AT_type
	.byte	18                              # Abbrev [18] 0x3f7:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	112                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x402:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	113                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	19                              # Abbrev [19] 0x40e:0x1b DW_TAG_subprogram
	.byte	18                              # DW_AT_low_pc
	.word	.Lfunc_end10-.Lfunc_begin10     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	25                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	155                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	1502                            # DW_AT_type
	.byte	18                              # Abbrev [18] 0x41d:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	119
	.byte	56                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	155                             # DW_AT_decl_line
	.word	56                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	19                              # Abbrev [19] 0x429:0x26 DW_TAG_subprogram
	.byte	19                              # DW_AT_low_pc
	.word	.Lfunc_end11-.Lfunc_begin11     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	27                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	158                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x438:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	57                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	158                             # DW_AT_decl_line
	.word	1610                            # DW_AT_type
	.byte	20                              # Abbrev [20] 0x443:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	58                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	159                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	19                              # Abbrev [19] 0x44f:0xa6 DW_TAG_subprogram
	.byte	20                              # DW_AT_low_pc
	.word	.Lfunc_end12-.Lfunc_begin12     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	28                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	244                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x45e:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	38                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	244                             # DW_AT_decl_line
	.word	1551                            # DW_AT_type
	.byte	18                              # Abbrev [18] 0x469:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	244                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x474:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	244                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x47f:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	245                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x48a:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	49                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	245                             # DW_AT_decl_line
	.word	73                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x495:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	99
	.byte	59                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	245                             # DW_AT_decl_line
	.word	1502                            # DW_AT_type
	.byte	18                              # Abbrev [18] 0x4a0:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	92
	.byte	48                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	246                             # DW_AT_decl_line
	.word	73                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x4ab:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	47                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	246                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x4b6:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	0
	.byte	42                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	247                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x4c1:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	4
	.byte	41                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	247                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	20                              # Abbrev [20] 0x4cc:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\270\177"
	.byte	60                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	248                             # DW_AT_decl_line
	.word	1615                            # DW_AT_type
	.byte	20                              # Abbrev [20] 0x4d8:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	61                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	249                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	21                              # Abbrev [21] 0x4e4:0x10 DW_TAG_lexical_block
	.byte	0                               # DW_AT_ranges
	.byte	13                              # Abbrev [13] 0x4e6:0xd DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\263\177"
	.byte	62                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	259                             # DW_AT_decl_line
	.word	1511                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	19                              # Abbrev [19] 0x4f5:0x31 DW_TAG_subprogram
	.byte	21                              # DW_AT_low_pc
	.word	.Lfunc_end13-.Lfunc_begin13     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	29                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	146                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x504:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	57                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	146                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	18                              # Abbrev [18] 0x50f:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	63                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	146                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	20                              # Abbrev [20] 0x51a:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	64                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	147                             # DW_AT_decl_line
	.word	1506                            # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	19                              # Abbrev [19] 0x526:0xb8 DW_TAG_subprogram
	.byte	22                              # DW_AT_low_pc
	.word	.Lfunc_end14-.Lfunc_begin14     # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	30                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	167                             # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x535:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	38                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	167                             # DW_AT_decl_line
	.word	1551                            # DW_AT_type
	.byte	18                              # Abbrev [18] 0x540:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	35                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	167                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x54b:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	45                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	167                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x556:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	40                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	168                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x561:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	60                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	168                             # DW_AT_decl_line
	.word	51                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x56c:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	61                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	168                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x577:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	95
	.byte	59                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	168                             # DW_AT_decl_line
	.word	1502                            # DW_AT_type
	.byte	18                              # Abbrev [18] 0x582:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	48                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	169                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x58d:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	0
	.byte	47                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	169                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x598:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	4
	.byte	42                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	170                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	18                              # Abbrev [18] 0x5a3:0xb DW_TAG_formal_parameter
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	8
	.byte	41                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	170                             # DW_AT_decl_line
	.word	47                              # DW_AT_type
	.byte	20                              # Abbrev [20] 0x5ae:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	65                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	171                             # DW_AT_decl_line
	.word	1586                            # DW_AT_type
	.byte	16                              # Abbrev [16] 0x5b9:0x12 DW_TAG_lexical_block
	.byte	23                              # DW_AT_low_pc
	.word	.Ltmp186-.Ltmp181               # DW_AT_high_pc
	.byte	20                              # Abbrev [20] 0x5bf:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	58                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	223                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x5cb:0x12 DW_TAG_lexical_block
	.byte	24                              # DW_AT_low_pc
	.word	.Ltmp192-.Ltmp187               # DW_AT_high_pc
	.byte	20                              # Abbrev [20] 0x5d1:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	76
	.byte	58                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	229                             # DW_AT_decl_line
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x5de:0x4 DW_TAG_base_type
	.byte	26                              # DW_AT_name
	.byte	2                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	4                               # Abbrev [4] 0x5e2:0x5 DW_TAG_pointer_type
	.word	1511                            # DW_AT_type
	.byte	22                              # Abbrev [22] 0x5e7:0x5 DW_TAG_const_type
	.word	56                              # DW_AT_type
	.byte	2                               # Abbrev [2] 0x5ec:0x8 DW_TAG_typedef
	.word	1524                            # DW_AT_type
	.byte	34                              # DW_AT_name
	.byte	4                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.byte	23                              # Abbrev [23] 0x5f4:0x6 DW_TAG_typedef
	.word	142                             # DW_AT_type
	.byte	33                              # DW_AT_name
	.byte	24                              # Abbrev [24] 0x5fa:0xc DW_TAG_array_type
	.word	56                              # DW_AT_type
	.byte	25                              # Abbrev [25] 0x5ff:0x6 DW_TAG_subrange_type
	.word	1542                            # DW_AT_type
	.byte	1                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	26                              # Abbrev [26] 0x606:0x4 DW_TAG_base_type
	.byte	36                              # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	22                              # Abbrev [22] 0x60a:0x5 DW_TAG_const_type
	.word	69                              # DW_AT_type
	.byte	2                               # Abbrev [2] 0x60f:0x8 DW_TAG_typedef
	.word	1559                            # DW_AT_type
	.byte	39                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	94                              # DW_AT_decl_line
	.byte	4                               # Abbrev [4] 0x617:0x5 DW_TAG_pointer_type
	.word	1564                            # DW_AT_type
	.byte	8                               # Abbrev [8] 0x61c:0x16 DW_TAG_subroutine_type
                                        # DW_AT_prototyped
	.byte	9                               # Abbrev [9] 0x61d:0x5 DW_TAG_formal_parameter
	.word	56                              # DW_AT_type
	.byte	9                               # Abbrev [9] 0x622:0x5 DW_TAG_formal_parameter
	.word	142                             # DW_AT_type
	.byte	9                               # Abbrev [9] 0x627:0x5 DW_TAG_formal_parameter
	.word	39                              # DW_AT_type
	.byte	9                               # Abbrev [9] 0x62c:0x5 DW_TAG_formal_parameter
	.word	39                              # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	22                              # Abbrev [22] 0x632:0x5 DW_TAG_const_type
	.word	39                              # DW_AT_type
	.byte	22                              # Abbrev [22] 0x637:0x5 DW_TAG_const_type
	.word	1596                            # DW_AT_type
	.byte	3                               # Abbrev [3] 0x63c:0x4 DW_TAG_base_type
	.byte	50                              # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	22                              # Abbrev [22] 0x640:0x5 DW_TAG_const_type
	.word	47                              # DW_AT_type
	.byte	22                              # Abbrev [22] 0x645:0x5 DW_TAG_const_type
	.word	94                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x64a:0x5 DW_TAG_pointer_type
	.word	1506                            # DW_AT_type
	.byte	24                              # Abbrev [24] 0x64f:0xc DW_TAG_array_type
	.word	56                              # DW_AT_type
	.byte	25                              # Abbrev [25] 0x654:0x6 DW_TAG_subrange_type
	.word	1542                            # DW_AT_type
	.byte	32                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_rnglists,"",@progbits
	.word	.Ldebug_list_header_end0-.Ldebug_list_header_start0 # Length
.Ldebug_list_header_start0:
	.half	5                               # Version
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
	.word	1                               # Offset entry count
.Lrnglists_table_base0:
	.word	.Ldebug_ranges0-.Lrnglists_table_base0
.Ldebug_ranges0:
	.byte	4                               # DW_RLE_offset_pair
	.uleb128 .Ltmp135-.Lfunc_begin0         #   starting offset
	.uleb128 .Ltmp136-.Lfunc_begin0         #   ending offset
	.byte	4                               # DW_RLE_offset_pair
	.uleb128 .Ltmp137-.Lfunc_begin0         #   starting offset
	.uleb128 .Ltmp138-.Lfunc_begin0         #   ending offset
	.byte	0                               # DW_RLE_end_of_list
.Ldebug_list_header_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	268                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara84/upstream/printf.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=203
.Linfo_string3:
	.asciz	"unsigned int"                  # string offset=255
.Linfo_string4:
	.asciz	"size_t"                        # string offset=268
.Linfo_string5:
	.asciz	"char"                          # string offset=275
.Linfo_string6:
	.asciz	"uintptr_t"                     # string offset=280
.Linfo_string7:
	.asciz	"int"                           # string offset=290
.Linfo_string8:
	.asciz	"unsigned long"                 # string offset=294
.Linfo_string9:
	.asciz	"short"                         # string offset=308
.Linfo_string10:
	.asciz	"unsigned char"                 # string offset=314
.Linfo_string11:
	.asciz	"unsigned short"                # string offset=328
.Linfo_string12:
	.asciz	"fct"                           # string offset=343
.Linfo_string13:
	.asciz	"arg"                           # string offset=347
.Linfo_string14:
	.asciz	"out_fct_wrap_type"             # string offset=351
.Linfo_string15:
	.asciz	"printf_"                       # string offset=369
.Linfo_string16:
	.asciz	"_vsnprintf"                    # string offset=377
.Linfo_string17:
	.asciz	"_out_char"                     # string offset=388
.Linfo_string18:
	.asciz	"sprintf_"                      # string offset=398
.Linfo_string19:
	.asciz	"_out_buffer"                   # string offset=407
.Linfo_string20:
	.asciz	"snprintf_"                     # string offset=419
.Linfo_string21:
	.asciz	"vsnprintf_"                    # string offset=429
.Linfo_string22:
	.asciz	"fctprintf"                     # string offset=440
.Linfo_string23:
	.asciz	"_out_fct"                      # string offset=450
.Linfo_string24:
	.asciz	"_out_null"                     # string offset=459
.Linfo_string25:
	.asciz	"_is_digit"                     # string offset=469
.Linfo_string26:
	.asciz	"_Bool"                         # string offset=479
.Linfo_string27:
	.asciz	"_atoi"                         # string offset=485
.Linfo_string28:
	.asciz	"_ntoa_long"                    # string offset=491
.Linfo_string29:
	.asciz	"_strnlen_s"                    # string offset=502
.Linfo_string30:
	.asciz	"_ntoa_format"                  # string offset=513
.Linfo_string31:
	.asciz	"format"                        # string offset=526
.Linfo_string32:
	.asciz	"va"                            # string offset=533
.Linfo_string33:
	.asciz	"__builtin_va_list"             # string offset=536
.Linfo_string34:
	.asciz	"va_list"                       # string offset=554
.Linfo_string35:
	.asciz	"buffer"                        # string offset=562
.Linfo_string36:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=569
.Linfo_string37:
	.asciz	"ret"                           # string offset=589
.Linfo_string38:
	.asciz	"out"                           # string offset=593
.Linfo_string39:
	.asciz	"out_fct_type"                  # string offset=597
.Linfo_string40:
	.asciz	"maxlen"                        # string offset=610
.Linfo_string41:
	.asciz	"flags"                         # string offset=617
.Linfo_string42:
	.asciz	"width"                         # string offset=623
.Linfo_string43:
	.asciz	"precision"                     # string offset=629
.Linfo_string44:
	.asciz	"n"                             # string offset=639
.Linfo_string45:
	.asciz	"idx"                           # string offset=641
.Linfo_string46:
	.asciz	"w"                             # string offset=645
.Linfo_string47:
	.asciz	"prec"                          # string offset=647
.Linfo_string48:
	.asciz	"base"                          # string offset=652
.Linfo_string49:
	.asciz	"value"                         # string offset=657
.Linfo_string50:
	.asciz	"long"                          # string offset=663
.Linfo_string51:
	.asciz	"l"                             # string offset=668
.Linfo_string52:
	.asciz	"p"                             # string offset=670
.Linfo_string53:
	.asciz	"character"                     # string offset=672
.Linfo_string54:
	.asciz	"count"                         # string offset=682
.Linfo_string55:
	.asciz	"out_fct_wrap"                  # string offset=688
.Linfo_string56:
	.asciz	"ch"                            # string offset=701
.Linfo_string57:
	.asciz	"str"                           # string offset=704
.Linfo_string58:
	.asciz	"i"                             # string offset=708
.Linfo_string59:
	.asciz	"negative"                      # string offset=710
.Linfo_string60:
	.asciz	"buf"                           # string offset=719
.Linfo_string61:
	.asciz	"len"                           # string offset=723
.Linfo_string62:
	.asciz	"digit"                         # string offset=727
.Linfo_string63:
	.asciz	"maxsize"                       # string offset=733
.Linfo_string64:
	.asciz	"s"                             # string offset=741
.Linfo_string65:
	.asciz	"start_idx"                     # string offset=743
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.word	.Linfo_string25
	.word	.Linfo_string26
	.word	.Linfo_string27
	.word	.Linfo_string28
	.word	.Linfo_string29
	.word	.Linfo_string30
	.word	.Linfo_string31
	.word	.Linfo_string32
	.word	.Linfo_string33
	.word	.Linfo_string34
	.word	.Linfo_string35
	.word	.Linfo_string36
	.word	.Linfo_string37
	.word	.Linfo_string38
	.word	.Linfo_string39
	.word	.Linfo_string40
	.word	.Linfo_string41
	.word	.Linfo_string42
	.word	.Linfo_string43
	.word	.Linfo_string44
	.word	.Linfo_string45
	.word	.Linfo_string46
	.word	.Linfo_string47
	.word	.Linfo_string48
	.word	.Linfo_string49
	.word	.Linfo_string50
	.word	.Linfo_string51
	.word	.Linfo_string52
	.word	.Linfo_string53
	.word	.Linfo_string54
	.word	.Linfo_string55
	.word	.Linfo_string56
	.word	.Linfo_string57
	.word	.Linfo_string58
	.word	.Linfo_string59
	.word	.Linfo_string60
	.word	.Linfo_string61
	.word	.Linfo_string62
	.word	.Linfo_string63
	.word	.Linfo_string64
	.word	.Linfo_string65
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.Lfunc_begin0
	.word	.Lfunc_begin1
	.word	.Ltmp20
	.word	.Ltmp31
	.word	.Ltmp42
	.word	.Ltmp61
	.word	.Ltmp62
	.word	.Ltmp68
	.word	.Ltmp71
	.word	.Ltmp82
	.word	.Lfunc_begin2
	.word	.Lfunc_begin3
	.word	.Lfunc_begin4
	.word	.Lfunc_begin5
	.word	.Lfunc_begin6
	.word	.Lfunc_begin7
	.word	.Lfunc_begin8
	.word	.Lfunc_begin9
	.word	.Lfunc_begin10
	.word	.Lfunc_begin11
	.word	.Lfunc_begin12
	.word	.Lfunc_begin13
	.word	.Lfunc_begin14
	.word	.Ltmp181
	.word	.Ltmp187
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
