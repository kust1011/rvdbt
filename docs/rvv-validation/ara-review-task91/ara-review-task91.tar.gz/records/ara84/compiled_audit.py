import json,re,hashlib,shutil
from pathlib import Path
R=Path(__file__).resolve().parent;j=lambda p:json.loads(p.read_text());out=[]
for b in j(R/'BLOCK_MAP.json'):
 s=(R/'logs'/(b['name']+'.s')).read_text();fn=b['original_function'];code=s[s.index(fn+':'):s.index('.Lfunc_end0:')];ins=[x.strip()for x in code.splitlines()if re.search(r'\b(vf(?:add|sub|mul)\.|vsetvli|vle8.v|fld|fsflags|frflags)',x)]
 assert len(re.findall(r'^\s*vf(?:add|sub|mul)\.(?:vv|vf)\s',code,re.M))==1
 assert f"e{b['vset']['sew']},m1, ta, ma"in code
 row=dict(name=b['name'],instructions=ins,ELF_sha256=hashlib.sha256((R/'bin'/(b['name']+'.elf')).read_bytes()).hexdigest())
 if b['target']['mask']=='masked':
  m=re.search(r'addi\s+(\w+),\s*s0,\s*(-\d+)\s*\n\s*#APP\s*\n\s*vle8.v v0, \(\1\)',code);assert m
  offset=int(m[2]);frame=int(re.search(r'addi\s+sp,\s*sp,\s*(-\d+)',code)[1]);assert frame<=offset and offset+16<=0
  row['mask_memory']=dict(frame_bytes=-frame,base='s0',offset=offset,read_bytes=16,object_bytes=2,read_range_within_allocated_frame=True,checked_mask_bits=[0,15],consumed_bytes=[0,1],extra_bytes_loaded_not_consumed_by_target=True,inputs_not_padded=True,assembly_context=code[max(0,m.start()-260):m.end()+30])
 if '.vf' in b['target']['form']:
  assert re.search(r'\bfld\s+',code);row['scalar_interface']=dict(FLEN=64,C_type='double',constraint='f',emitted_load='fld',original_boxing_preserved=True)
 row['flag_checks']=b['flag_checks'];row['flag_clear_preserved']=b['flag_clear_preserved'];out.append(row)
(R/'COMPILED_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
paths=[Path(shutil.which(x))for x in ['clang-20','llc-20','llvm-objdump-20','llvm-nm-20']];paths += [Path('/home/user/opt/xpack-riscv-none-elf-gcc-14.2.0-1/lib/gcc/riscv-none-elf/14.2.0/rv32imafd_zicsr/ilp32d/libgcc.a')]
(R/'COMPILER_RUNTIME_IDENTITY.json').write_text(json.dumps({str(x):hashlib.sha256(x.read_bytes()).hexdigest()for x in paths},indent=2)+'\n')
print('compiled audit',len(out),'blocks; masks',sum('mask_memory'in x for x in out))
