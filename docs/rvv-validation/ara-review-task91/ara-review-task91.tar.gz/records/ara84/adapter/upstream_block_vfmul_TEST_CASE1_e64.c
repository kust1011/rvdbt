// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 59 "vfmul.c"
  VSET(16, e64, m1);
  //              -0.7493892241714462,  0.7026559207451004,  0.6475697152132245,
  //              0.0771197585157644, -0.2238692303359540,  0.8998213782649329,
  //              -0.9446193329247832,  0.8596730101791072, -0.0254417293392082,
  //              0.1965035124326171, -0.4709662077579637, -0.2875069600640039,
  //              -0.4671574223295827,  0.3105385724706418,  0.1703390668980564,
  //              0.1487690137320270
  VLOAD_64(v2, 0xbfe7faff1c39514c, 0x3fe67c2844fe1c76, 0x3fe4b8e41f971110,
           0x3fb3be1ed8b35c30, 0xbfcca7bf376fd290, 0x3feccb5633fc770c,
           0xbfee3a5252c299d8, 0x3feb8270f8ff23f8, 0xbf9a0d658ddcc1c0,
           0x3fc92706efb93e80, 0xbfde244f72f5dcb4, 0xbfd2668397b639c0,
           0xbfdde5e83ebf4f58, 0x3fd3dfdd2d3a1b90, 0x3fc5cdaba8c776a8,
           0x3fc30adcf05190c8);
  //               0.6932733143704406, -0.2687556191190688,  0.2528829246597466,
  //               0.7287253758892476, -0.5682564905667424,  0.0092122398882537,
  //               -0.5132517188156311, -0.0178020357545405, 0.0816988280997786,
  //               0.6297663200296084,  0.3637508978200528,  0.6003193921430929,
  //               -0.9089688764960682,  0.1595578103621622, 0.2113473996516566,
  //               -0.4586515678904381
  VLOAD_64(v3, 0x3fe62f4b848d2362, 0xbfd1334ac4aee374, 0x3fd02f3bdcc85930,
           0x3fe751b7e126b540, 0xbfe22f283c572a1e, 0x3f82dddde857f980,
           0xbfe06c8ede5db9be, 0xbf923ab26578ce40, 0x3fb4ea36e2cf6110,
           0x3fe4270bb294c832, 0x3fd747b1d881c6e4, 0x3fe335d1038d1808,
           0xbfed1645e5b43d3e, 0x3fc46c63eca9d670, 0x3fcb0d6e7ccc9be0,
           0xbfdd5a8c1b164ebc);
  asm volatile("vfmul.vv v1, v2, v3");
  //              -0.5195315511948315, -0.1888427270075288,  0.1637593235041994,
  //              0.0561991250128884,  0.1272151431765869,  0.0082893703931556,
  //              0.4848274962501199, -0.0153039296644220, -0.0020785594718451,
  //              0.1237512938975817, -0.1713143809148648, -0.1725960035025313,
  //              0.4246315573217200,  0.0495488546564072,  0.0360007188479938,
  //              -0.0682331414017083
  VCMP_U64(3, v1, 0xbfe0a000a1b3e706, 0xbfc82bff9c4ada77, 0x3fc4f610c56ecca8,
           0x3facc621b7fd0401, 0x3fc04895f7bfec49, 0x3f80fa0475f1bbe1,
           0x3fdf0769e826220a, 0xbf8f57aaab459580, 0xbf61070e1e8a29ae,
           0x3fbfae2a3020b759, 0xbfc5eda12fae9203, 0xbfc617a0373b59a7,
           0x3fdb2d29d6e2f72e, 0x3fa95e77ac9b67ce, 0x3fa26eafac2b53dd,
           0xbfb177ba26d2dcbe);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE1");
  TEST_CASE1();
  ara_case_end("TEST_CASE1",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
