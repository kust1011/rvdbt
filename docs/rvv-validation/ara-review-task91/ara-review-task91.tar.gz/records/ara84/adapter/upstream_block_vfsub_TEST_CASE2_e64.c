// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 152 "vfsub.c"
  VSET(16, e64, m1);
  //              -0.5053356652713634, -0.6291854947278097,  0.6181258713941662,
  //              -0.6097328085365348,  0.8960683065358290,  0.1233825892982841,
  //              -0.7071646124826323, -0.6783334309218909,  0.3533001486660008,
  //              0.4732651306122215, -0.7335080825789513, -0.9296500813876505,
  //              0.5349827137885166, -0.0621174552558810, -0.8122743533756343,
  //              -0.8908485518923974
  VLOAD_64(v2, 0xbfe02bb5b37af91c, 0xbfe422499e5f271a, 0x3fe3c7afe84e61dc,
           0xbfe382ee60fece00, 0x3fecac9770f1b62e, 0x3fbf960059ee92f0,
           0xbfe6a117ae700ba0, 0xbfe5b4e84fb2f9d4, 0x3fd69c783a0c5078,
           0x3fde49f9d4944428, 0xbfe778e5f140e788, 0xbfedbfb18709140c,
           0x3fe11e941174b448, 0xbfafcddbedab64a0, 0xbfe9fe26c8e417ba,
           0xbfec81d4d2822346);
  //              -0.6041772411195545,  0.1691588460867453, -0.3855578735230800,
  //              -0.9206749118255901,  0.7025181961160538, -0.9905598942344518,
  //              0.9510997049380876,  0.2754176494545910,  0.5271936205102918,
  //              0.8778238674058336,  0.9294006140978470, -0.8775508592745904,
  //              0.7472392658861982, -0.3880038279796372, -0.6483706997783654,
  //              -0.1530785884604509
  VLOAD_64(v3, 0xbfe3556b82731260, 0x3fc5a6ff3fe2c608, 0xbfd8acfaee5fcdc0,
           0xbfed762b3b913c28, 0x3fe67b0770a53a4a, 0xbfefb2aaa9ceeb06,
           0x3fee6f68a5fe3800, 0x3fd1a071594983a8, 0x3fe0dec527d80c9a,
           0x3fec172214450060, 0x3fedbda65b4dd79c, 0xbfec14e58a252770,
           0x3fe7e962522895aa, 0xbfd8d50e01f94d70, 0xbfe4bf73e8e77264,
           0xbfc398144593e6c0);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfsub.vv v1, v2, v3, v0.t");
  //               0.0000000000000000, -0.7983443408145550,  0.0000000000000000,
  //               0.3109421032890554,  0.0000000000000000,  1.1139424835327358,
  //               0.0000000000000000, -0.9537510803764819,  0.0000000000000000,
  //               -0.4045587367936121,  0.0000000000000000,
  //               -0.0520992221130601,  0.0000000000000000, 0.3258863727237562,
  //               0.0000000000000000, -0.7377699634319466
  VCMP_U64(6, v1, 0x0, 0xbfe98c096e57d89c, 0x0, 0x3fd3e679b524dc50, 0x0,
           0x3ff1d2b55a865eb2, 0x0, 0xbfee8520fc57bba8, 0x0, 0xbfd9e44a53f5bc98,
           0x0, 0xbfaaacbfce3ec9c0, 0x0, 0x3fd4db528443e0dc, 0x0,
           0xbfe79bcfc11d2996);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE2");
  TEST_CASE2();
  ara_case_end("TEST_CASE2",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
