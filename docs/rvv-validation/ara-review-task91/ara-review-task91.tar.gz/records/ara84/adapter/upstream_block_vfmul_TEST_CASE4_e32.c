// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE4(void) {
#line 283 "vfmul.c"
  VSET(16, e32, m1);
  //               -0.11454447, -0.46133029,  0.06972761,  0.20429718,
  //               -0.97134608, -0.95719630, -0.11250938,  0.48455358,
  //               0.59656250,  0.46462929,  0.13447689, -0.32035729,
  //               0.75118428,  0.90634471,  0.73552424, -0.53555632
  VLOAD_32(v2, 0xbdea964b, 0xbeec337c, 0x3d8ecd5a, 0x3e513348, 0xbf78aa23,
           0xbf750ad1, 0xbde66b52, 0x3ef81768, 0x3f18b852, 0x3eede3e4,
           0x3e09b44f, 0xbea405df, 0x3f404d9d, 0x3f680635, 0x3f3c4b51,
           0xbf091a38);
  double dscalar_32;
  //                               0.94017404
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0x3f70af3f);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfmul.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_32));
  //                0.00000000, -0.43373078,  0.00000000,  0.19207491,
  //                0.00000000, -0.89993113,  0.00000000,  0.45556471,
  //                0.00000000,  0.43683240,  0.00000000, -0.30119160,
  //                0.00000000,  0.85212177,  0.00000000, -0.50351614
  VCMP_U32(11, v1, 0x0, 0xbede11f6, 0x0, 0x3e44af49, 0x0, 0xbf6661e3, 0x0,
           0x3ee93fc7, 0x0, 0x3edfa87f, 0x0, 0xbe9a35c9, 0x0, 0x3f5a24a7, 0x0,
           0xbf00e66f);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE4");
  TEST_CASE4();
  ara_case_end("TEST_CASE4",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
