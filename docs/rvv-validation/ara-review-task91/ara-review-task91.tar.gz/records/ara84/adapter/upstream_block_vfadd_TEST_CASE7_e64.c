// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE7(void) {
#line 384 "vfadd.c"
  VSET(16, e64, m1);
  VLOAD_64(v2, 0xbfd6543dea86cb60, 0xbfdccf40105d6e5c, 0x3febf098bf37400c,
           0x3fd4d756ceb279f4, 0x3fe4ceec35a6a266, 0xbfd448ad61fd7c88,
           0xbfe144f8f7861540, 0xbfe1564491a616b8, 0xbfe9825047ca1cd6,
           0xbfc696e097352100, 0x3fd6cfb5ac55edec, 0xbfd8074a7158dd78,
           0x3fe50f1ca5268668, 0xbfd54dffe23d0eec, 0x3fc68b25c63dcaf0,
           0x3fc24d1575fbd080);
  double dscalar_64;
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3fed25da5d7296fe);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfadd.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_64));
  VCMP_U64(20, v1, 0, 0x3fdd7c74aa87bfa0, 0, 0x3ff3c8c2e265e9fc, 0,
           0x3fe30183ac73d8ba, 0, 0x3fd79f2b9799008c, 0, 0x3fe7802237a54ebe, 0,
           0x3fe1223524c62842, 0, 0x3fe27eda6c540f88, 0, 0x3ff0dc8fdd78c58f);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE7");
  TEST_CASE7();
  ara_case_end("TEST_CASE7",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
