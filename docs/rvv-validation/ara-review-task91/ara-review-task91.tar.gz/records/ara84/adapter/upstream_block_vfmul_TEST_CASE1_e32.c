// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfmul.c"
  VSET(16, e32, m1);
  //               0.48805356,  0.30350628, -0.10483003,  0.61108905,
  //               -0.09161828,  0.83353645, -0.55006021, -0.78635991,
  //               0.49253011, -0.03583150, -0.77662903,  0.57397723,
  //               -0.54674339,  0.86299890,  0.65402901, -0.16832402
  VLOAD_32(v2, 0x3ef9e228, 0x3e9b652d, 0xbdd6b121, 0x3f1c7055, 0xbdbba25d,
           0x3f5562a5, 0xbf0cd0bf, 0xbf494ee2, 0x3efc2ce8, 0xbd12c40e,
           0xbf46d129, 0x3f12f02c, 0xbf0bf760, 0x3f5ced7f, 0x3f276e72,
           0xbe2c5d22);
  //               0.87142652, -0.32756421,  0.76706660, -0.54420376,
  //               -0.99424285,  0.31885657,  0.18092929, -0.68290263,
  //               0.45391774, -0.45151946, -0.08929581,  0.80524033,
  //               0.81978256, -0.28325567, -0.53026456, -0.21847765
  VLOAD_32(v3, 0x3f5f15cf, 0xbea7b67f, 0x3f445e7a, 0xbf0b50f0, 0xbf7e86b3,
           0x3ea3412b, 0x3e394587, 0xbf2ed2b5, 0x3ee867e8, 0xbee72d8f,
           0xbdb6e0b9, 0x3f4e243b, 0x3f51dd45, 0xbe9106e3, 0xbf07bf6b,
           0xbe5fb89b);
  asm volatile("vfmul.vv v1, v2, v3");
  //               0.42530280, -0.09941780, -0.08041162, -0.33255696,
  //               0.09109081,  0.26577857, -0.09952200,  0.53700727,
  //               0.22356816,  0.01617862,  0.06934972,  0.46218961,
  //               -0.44821069, -0.24444933, -0.34680840,  0.03677504
  VCMP_U32(2, v1, 0x3ed9c14a, 0xbdcb9b8f, 0xbda4aed9, 0xbeaa44e8, 0x3dba8dd2,
           0x3e881421, 0xbdcbd231, 0x3f09794f, 0x3e64ef0d, 0x3c848907,
           0x3d8e073a, 0x3eeca41e, 0xbee57bdf, 0xbe7a50ed, 0xbeb190df,
           0x3d16a16c);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE1");
  TEST_CASE1();
  ara_case_end("TEST_CASE1",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
