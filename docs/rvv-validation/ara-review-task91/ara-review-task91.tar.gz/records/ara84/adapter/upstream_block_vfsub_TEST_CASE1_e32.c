// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 32 "vfsub.c"
  VSET(16, e32, m1);
  //              -0.12869358,  0.96847999, -0.85811919, -0.21122381,
  //              -0.05195865,  0.43910158,  0.86828148, -0.90407801,
  //              0.62089461, -0.65907389,  0.91886526, -0.57595438,
  //              -0.35377914, -0.26657876,  0.49153560,  0.42637765
  VLOAD_32(v2, 0xbe03c840, 0x3f77ee4e, 0xbf5badb3, 0xbe584b0e, 0xbd54d298,
           0x3ee0d1ec, 0x3f5e47b2, 0xbf6771a8, 0x3f1ef2f3, 0xbf28b911,
           0x3f6b3ac1, 0xbf1371bf, 0xbeb5228a, 0xbe887d03, 0x3efbaa8e,
           0x3eda4e2c);
  //              -0.50821143, -0.56901741, -0.88642830,  0.91128469,
  //              -0.00441748,  0.72763014,  0.81834352, -0.49977919,
  //              -0.94507313, -0.60766727,  0.21069343,  0.35644454,
  //              -0.51639801, -0.74812186, -0.97028691,  0.42650157
  VLOAD_32(v3, 0xbf021a25, 0xbf11ab20, 0xbf62ecf7, 0x3f6949f4, 0xbb90c083,
           0x3f3a45f8, 0x3f517ef6, 0xbeffe30f, 0xbf71f050, 0xbf1b9015,
           0x3e57c005, 0x3eb67fe6, 0xbf0432a9, 0xbf3f84ea, 0xbf7864b9,
           0x3eda5e6a);
  asm volatile("vfsub.vv v1, v2, v3");
  //               0.37951785,  1.53749740,  0.02830911, -1.12250853,
  //               -0.04754117, -0.28852856,  0.04993796,
  //               -0.40429881,  1.56596780, -0.05140662,  0.70817184,
  //               -0.93239892,  0.16261888,  0.48154309,  1.46182251,
  //               -0.00012392
  VCMP_U32(2, v1, 0x3ec2502a, 0x3fc4ccb7, 0x3ce7e880, 0xbf8fae5c, 0xbd42ba88,
           0xbe93ba04, 0x3d4c8bc0, 0xbecf0041, 0x3fc871a2, 0xbd528fc0,
           0x3f354ac0, 0xbf6eb1b2, 0x3e268590, 0x3ef68cd1, 0x3fbb1d00,
           0xb901f000);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE1");
  TEST_CASE1();
  ara_case_end("TEST_CASE1",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
