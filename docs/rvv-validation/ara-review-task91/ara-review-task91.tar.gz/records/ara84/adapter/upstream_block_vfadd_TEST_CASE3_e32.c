// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 178 "vfadd.c"
  VSET(16, e32, m1);
  VLOAD_32(v2, pInff, pInff, mInff, qNaNf, pMaxf, pMaxf, pZero, mZerof, pZero,
           pMaxf, pZero, qNaNf, mInff, pInff, qNaNf, qNaNf);
  VLOAD_32(v3, mInff, pInff, mInff, pZero, pMaxf, mMaxf, pZero, mZerof, mZerof,
           mZerof, mMaxf, 0x1, 0xbf48f0f0, pZero, qNaNf, 0xbf48f0f0);
  asm volatile("vfadd.vv v1, v2, v3");
  VCMP_U32(8, v1, qNaNf, pInff, mInff, qNaNf, pInff, pZero, pZero, mZerof,
           pZero, pMaxf, mMaxf, qNaNf, mInff, pInff, qNaNf, qNaNf);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE3");
  TEST_CASE3();
  ara_case_end("TEST_CASE3",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
