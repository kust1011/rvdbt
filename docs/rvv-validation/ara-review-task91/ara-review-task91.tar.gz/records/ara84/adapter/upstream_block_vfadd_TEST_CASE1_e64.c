// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 77 "vfadd.c"
  VSET(16, e64, m1);
  //             -0.1192486190170796,  0.7099687505713703, -0.6001652243371716,
  //             -0.9559723926483070,  0.7987976623002717, -0.3314459653039117,
  //             0.7678805321182058, -0.3118871679402779, -0.7580588930783800,
  //             0.5940681950113129,  0.6471754222100761,  0.4175915562917139,
  //             -0.3690504607938143,  0.0740574148132984, -0.1493616685664843,
  //             0.3560295367616439
  VLOAD_64(v2, 0xbfbe8713d6c58260, 0x3fe6b810629c5a40, 0xbfe3348db3573060,
           0xbfee97536a49b50a, 0x3fe98fc01d766dee, 0xbfd536692357c5dc,
           0x3fe8927a3195d944, 0xbfd3f5f598961d8c, 0xbfe84204b946d5d6,
           0x3fe3029b4da55ad8, 0x3fe4b5a93b255a44, 0x3fdab9d1ef56f430,
           0xbfd79e85d2ebb8f0, 0x3fb2f56d3ea64090, 0xbfc31e487ce26ff0,
           0x3fd6c9301c334858);
  //             -0.7765903295164327,  0.4195489676706889, -0.3911414124398265,
  //             0.6922029856623244,  0.5664741772288600, -0.1412820433489181,
  //             -0.1847941224896075, -0.4907136082532593, -0.9146160877742129,
  //             -0.7130864084314152, -0.5516927493459973, -0.4203081001100177,
  //             0.6487326796833275, -0.5631384800254344, -0.0996872955425372,
  //             -0.4382844162164241
  VLOAD_64(v3, 0xbfe8d9d3f67536d2, 0x3fdad9e3e9cdd5bc, 0xbfd90875fda29450,
           0x3fe62686e0339faa, 0x3fe2208e74273f2c, 0xbfc21587add90b50,
           0xbfc7a755744afe30, 0xbfdf67da0cc99808, 0xbfed4488f52c57bc,
           0xbfe6d19a966debbe, 0xbfe1a7778d7c344c, 0xbfdae653f20dd9d4,
           0x3fe4c26b0962c342, 0xbfe2053afd5a822c, 0xbfb9851b4a2e8ff0,
           0xbfdc0cda147fbe5c);
  asm volatile("vfadd.vv v1, v2, v3");
  //             -0.8958389485335123,  1.1295177182420593, -0.9913066367769980,
  //             -0.2637694069859826,  1.3652718395291317, -0.4727280086528298,
  //             0.5830864096285984, -0.8026007761935372, -1.6726749808525929,
  //             -0.1190182134201023,  0.0954826728640787, -0.0027165438183039,
  //             0.2796822188895132, -0.4890810652121360, -0.2490489641090214,
  //             -0.0822548794547802
  VCMP_U64(3, v1, 0xbfecaab6714de71e, 0x3ff212812bc1a28f, 0xbfefb8c8b2287a88,
           0xbfd0e199142c2ac0, 0x3ff5d82748ced68d, 0xbfde412cfa444b84,
           0x3fe2a8a4d48319b8, 0xbfe9aee7d2afdaca, 0xbffac346d73996c9,
           0xbfbe77fa46448730, 0x3fb8718d6d492fc0, 0xbf6641015b72d200,
           0x3fd1e6503fd9cd94, 0xbfdf4d1aab0b7434, 0xbfcfe0d621f9b7e8,
           0xbfb50ea7e131d810);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE1");
  TEST_CASE1();
  ara_case_end("TEST_CASE1",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
