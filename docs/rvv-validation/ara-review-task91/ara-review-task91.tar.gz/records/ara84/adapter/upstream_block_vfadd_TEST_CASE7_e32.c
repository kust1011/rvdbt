// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE7(void) {
#line 371 "vfadd.c"
  VSET(16, e32, m1);
  VLOAD_32(v2, 0x3f5d8a7f, 0xbf0a0c89, 0xbef14c9d, 0x3f7e1eaa, 0x3ea47f0b,
           0xbef25bbc, 0xbe99bf6c, 0x3ee34c20, 0xbf39b46b, 0xbe877ff1,
           0x3f46050b, 0xbe5e78a0, 0xbe80fb14, 0xbf07ff20, 0x3f4dd62f,
           0x3f5183c2);
  double dscalar_32;
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbf75e762);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfadd.vf v1, v2, %[A], v0.t" ::[A] "f"(dscalar_32));
  VCMP_U32(19, v1, 0, 0xbfbff9f6, 0, 0x3d037480, 0, 0xbfb78aa0, 0, 0xbf044152,
           0, 0xbf9cd3ad, 0, 0xbf96c2c5, 0, 0xbfbef341, 0, 0xbe118e80);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE7");
  TEST_CASE7();
  ara_case_end("TEST_CASE7",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
