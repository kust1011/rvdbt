// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 211 "vfsub.c"
  VSET(16, e32, m1);
  //               0.85933530, -0.31821987,  0.18340160, -0.58902484,
  //               -0.83326858, -0.98716992, -0.74268776, -0.50486410,
  //               0.91496444, -0.46108878, -0.75265163, -0.17853038,
  //               0.09909800, -0.22828153,  0.31248060,  0.70940411
  VLOAD_32(v2, 0x3f5bfd66, 0xbea2edb7, 0x3e3bcda1, 0xbf16ca55, 0xbf555117,
           0xbf7cb72b, 0xbf3e20c9, 0xbf013ec6, 0x3f6a3b1c, 0xbeec13d4,
           0xbf40adc7, 0xbe36d0ab, 0x3dcaf3e5, 0xbe69c2a2, 0x3e9ffd75,
           0x3f359b82);
  double dscalar_32;
  //                              -0.16449618
  BOX_FLOAT_IN_DOUBLE(dscalar_32, 0xbe2871b0);
  asm volatile("vfsub.vf v1, v2, %[A]" ::[A] "f"(dscalar_32));
  //               1.02383149, -0.15372369,  0.34789777, -0.42452866,
  //               -0.66877240, -0.82267374, -0.57819158,
  //               -0.34036791,  1.07946062, -0.29659259, -0.58815545,
  //               -0.01403420,  0.26359418, -0.06378534,  0.47697678,
  //               0.87390029
  VCMP_U32(8, v1, 0x3f830ce9, 0xbe1d69be, 0x3eb21fa8, 0xbed95bd2, 0xbf2b34ab,
           0xbf529abf, 0xbf14045d, 0xbeae44b4, 0x3f8a2bc4, 0xbe97dafc,
           0xbf16915b, 0xbc65efb0, 0x3e86f5d1, 0xbd82a1e4, 0x3ef4364d,
           0x3f5fb7ee);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE3");
  TEST_CASE3();
  ara_case_end("TEST_CASE3",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
