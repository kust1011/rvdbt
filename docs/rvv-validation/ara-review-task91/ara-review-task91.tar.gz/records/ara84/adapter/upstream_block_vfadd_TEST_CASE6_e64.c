// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE6(void) {
#line 327 "vfadd.c"
  VSET(16, e64, m1);
  //               -0.3488917150781869, -0.4501495513738740, 0.8731197104152684,
  //               0.3256432550932964,  0.6502591178769535, -0.3169358689246526,
  //               -0.5396694979141685, -0.5417807430937591,
  //               -0.7971574213160249, -0.1764794100111047, 0.3564275916066595,
  //               -0.3754449946313438,  0.6580947137446858,
  //               -0.3328857144699515,  0.1761214464164236,  0.1429774118511240
  VLOAD_64(v2, 0xbfd6543dea86cb60, 0xbfdccf40105d6e5c, 0x3febf098bf37400c,
           0x3fd4d756ceb279f4, 0x3fe4ceec35a6a266, 0xbfd448ad61fd7c88,
           0xbfe144f8f7861540, 0xbfe1564491a616b8, 0xbfe9825047ca1cd6,
           0xbfc696e097352100, 0x3fd6cfb5ac55edec, 0xbfd8074a7158dd78,
           0x3fe50f1ca5268668, 0xbfd54dffe23d0eec, 0x3fc68b25c63dcaf0,
           0x3fc24d1575fbd080);
  double dscalar_64;
  //                               0.9108707261227378
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0x3fed25da5d7296fe);
  asm volatile("vfadd.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //                0.5619790110445508, 0.4607211747488638,  1.7839904365380062,
  //                1.2365139812160342,  1.5611298439996912, 0.5939348571980851,
  //                0.3712012282085693,  0.3690899830289787, 0.1137133048067129,
  //                0.7343913161116331,  1.2672983177293973, 0.5354257314913939,
  //                1.5689654398674235, 0.5779850116527863,  1.0869921725391614,
  //                1.0538481379738618
  VCMP_U64(17, v1, 0x3fe1fbbb682f314e, 0x3fdd7c74aa87bfa0, 0x3ffc8b398e54eb85,
           0x3ff3c8c2e265e9fc, 0x3ff8fa63498c9cb2, 0x3fe30183ac73d8ba,
           0x3fd7c1c2cbd9037c, 0x3fd79f2b9799008c, 0x3fbd1c50ad43d140,
           0x3fe7802237a54ebe, 0x3ff446da99cec6fa, 0x3fe1223524c62842,
           0x3ff91a7b814c8eb3, 0x3fe27eda6c540f88, 0x3ff16451e78104dd,
           0x3ff0dc8fdd78c58f);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE6");
  TEST_CASE6();
  ara_case_end("TEST_CASE6",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
