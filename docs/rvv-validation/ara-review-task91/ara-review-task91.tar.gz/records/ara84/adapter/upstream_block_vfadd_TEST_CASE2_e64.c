// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE2(void) {
#line 146 "vfadd.c"
  VSET(16, e64, m1);
  VLOAD_64(v2, 0xbfbe8713d6c58260, 0x3fe6b810629c5a40, 0xbfe3348db3573060,
           0xbfee97536a49b50a, 0x3fe98fc01d766dee, 0xbfd536692357c5dc,
           0x3fe8927a3195d944, 0xbfd3f5f598961d8c, 0xbfe84204b946d5d6,
           0x3fe3029b4da55ad8, 0x3fe4b5a93b255a44, 0x3fdab9d1ef56f430,
           0xbfd79e85d2ebb8f0, 0x3fb2f56d3ea64090, 0xbfc31e487ce26ff0,
           0x3fd6c9301c334858);
  VLOAD_64(v3, 0xbfe8d9d3f67536d2, 0x3fdad9e3e9cdd5bc, 0xbfd90875fda29450,
           0x3fe62686e0339faa, 0x3fe2208e74273f2c, 0xbfc21587add90b50,
           0xbfc7a755744afe30, 0xbfdf67da0cc99808, 0xbfed4488f52c57bc,
           0xbfe6d19a966debbe, 0xbfe1a7778d7c344c, 0xbfdae653f20dd9d4,
           0x3fe4c26b0962c342, 0xbfe2053afd5a822c, 0xbfb9851b4a2e8ff0,
           0xbfdc0cda147fbe5c);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfadd.vv v1, v2, v3, v0.t");
  VCMP_U64(6, v1, 0, 0x3ff212812bc1a28f, 0, 0xbfd0e199142c2ac0, 0,
           0xbfde412cfa444b84, 0, 0xbfe9aee7d2afdaca, 0, 0xbfbe77fa46448730, 0,
           0xbf6641015b72d200, 0, 0xbfdf4d1aab0b7434, 0, 0xbfb50ea7e131d810);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE2");
  TEST_CASE2();
  ara_case_end("TEST_CASE2",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
