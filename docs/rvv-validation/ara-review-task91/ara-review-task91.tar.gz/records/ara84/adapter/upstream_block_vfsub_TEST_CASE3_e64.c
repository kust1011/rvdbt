// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 234 "vfsub.c"
  VSET(16, e64, m1);
  //               -0.5270370833343294, -0.3892108170289901, 0.3278104985181656,
  //               0.8978904717616114,  0.2838388271052681,  0.1890152734369528,
  //               -0.5587120809764872,  0.0329118609761476, 0.2661042157694802,
  //               0.4284631655495406,  0.3525175873513684, -0.7218762878034530,
  //               -0.1902187411555145,  0.0621279131630217,
  //               -0.3175600204168794,  0.2653267716685161
  VLOAD_64(v2, 0xbfe0dd7cdf9667ce, 0xbfd8e8d47c98e498, 0x3fd4fad8e29af14c,
           0x3fecbb84cc736570, 0x3fd22a6a53f022d0, 0x3fc831a708ed9848,
           0xbfe1e0f82875925c, 0x3fa0d9d2cd160b00, 0x3fd107d9fa03b074,
           0x3fdb6bf0c4e4dbb8, 0x3fd68fa5ed3c17c4, 0xbfe7199c4cfbf578,
           0xbfc85916742cb360, 0x3fafcf3ad6686660, 0xbfd452e7438d4924,
           0x3fd0fb1d23c47348);
  double dscalar_64;
  //                               -0.3447987329466446
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfd6112eb46d5120);
  asm volatile("vfsub.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //              -0.1822383503876848, -0.0444120840823454,
  //              0.6726092314648102,  1.2426892047082561,  0.6286375600519127,
  //              0.5338140063835974, -0.2139133480298425,  0.3777105939227923,
  //              0.6109029487161248,  0.7732618984961852,  0.6973163202980130,
  //              -0.3770775548568084,  0.1545799917911301,  0.4069266461096663,
  //              0.0272387125297653,  0.6101255046151608
  VCMP_U64(9, v1, 0xbfc75396157efcf8, 0xbfa6bd2e415c9bc0, 0x3fe58603cb842136,
           0x3ff3e20e13550700, 0x3fe41dcc842eb9f8, 0x3fe115011c720ea2,
           0xbfcb618338fba730, 0x3fd82c690e101280, 0x3fe38c84573880ca,
           0x3fe8be8fbca9166c, 0x3fe6506a50d4b472, 0xbfd82209e58a99d0,
           0x3fc3c946f4adeee0, 0x3fda0b160f3a5dec, 0x3f9be4770e007fc0,
           0x3fe38625ec18e234);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE3");
  TEST_CASE3();
  ara_case_end("TEST_CASE3",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
