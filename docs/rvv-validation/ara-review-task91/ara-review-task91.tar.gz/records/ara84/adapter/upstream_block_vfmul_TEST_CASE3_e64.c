// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE3(void) {
#line 231 "vfmul.c"
  VSET(16, e64, m1);
  //               -0.3344965024132001, -0.2497404698970234, 0.3402338726452623,
  //               -0.5885400342262450, -0.7135559920290824, 0.1114442794173345,
  //               -0.9541638058007114,  0.1021679621951177,
  //               -0.1364702451627324, -0.9351295729000717,
  //               -0.2701320849999789,  0.3582375365191053,
  //               -0.6137661452178358,  0.6195430637830983, 0.2731869234335833,
  //               -0.4075196944877124
  VLOAD_64(v2, 0xbfd56864049f6dd8, 0xbfcff77ee7590278, 0x3fd5c6644b002e60,
           0xbfe2d551e8ec6e20, 0xbfe6d573603426e0, 0x3fbc879cbf6c7a10,
           0xbfee8882889e1c44, 0x3fba27adf853b5f0, 0xbfc177db63eceed0,
           0xbfedec94daa41aac, 0xbfd149d815ab3680, 0x3fd6ed5d21e3257c,
           0xbfe3a3f8e623486e, 0x3fe3d34bf9ad2f82, 0x3fd17be50175e4e8,
           0xbfda14cd7c133da0);
  double dscalar_64;
  //                               -0.7970907277742201
  BOX_DOUBLE_IN_DOUBLE(dscalar_64, 0xbfe981c469f7860e);
  asm volatile("vfmul.vf v1, v2, %[A]" ::[A] "f"(dscalar_64));
  //               0.2666240605464688,  0.1990658129048941, -0.2711972651602534,
  //               0.4691198042056620,  0.5687688649941168, -0.0888312017870367,
  //               0.7605551223815086, -0.0814371353413154,  0.1087791670362886,
  //               0.7453831118261137,  0.2153197802278006, -0.2855478187000574,
  //               0.4892273033748624, -0.4938320315983399, -0.2177547636180751,
  //               0.3248301698615385
  VCMP_U64(9, v1, 0x3fd1105e5d17ec76, 0x3fc97afd1216ce6e, 0xbfd15b4bc6282ffc,
           0x3fde060f123e080e, 0x3fe2335ac3443fa9, 0xbfb6bda4428a29bb,
           0x3fe85677b22de228, 0xbfb4d91068f88b49, 0x3fbbd8f394e82fe7,
           0x3fe7da2daf091575, 0x3fcb8f993b2151e0, 0xbfd2466a5bb0b251,
           0x3fdf4f8009138a1b, 0xbfdf9af1aa5ba7aa, 0xbfcbdf635a24d80a,
           0x3fd4ca047b13cdbf);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE3");
  TEST_CASE3();
  ara_case_end("TEST_CASE3",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
