// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matteo Perotti <mperotti@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
#include "float_macros.h"
#include "vector_macros.h"
// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.
void TEST_CASE1(void) {
#line 50 "vfadd.c"
  VSET(16, e32, m1);
  //             -0.28968573,  0.40292332,  0.33936000,  0.53889370, 0.39942014,
  //             -0.27004066,  0.78120714, -0.15632398, -0.49984047,
  //             -0.69259918, -0.03384063, -0.62385744,  0.00338853, 0.33711585,
  //             -0.34673852,  0.11450682
  VLOAD_32(v2, 0xbe9451b0, 0x3ece4bf7, 0x3eadc098, 0x3f09f4f0, 0x3ecc80cc,
           0xbe8a42c5, 0x3f47fd31, 0xbe201365, 0xbeffeb17, 0xbf314e2e,
           0xbd0a9c78, 0xbf1fb51f, 0x3b5e1209, 0x3eac9a73, 0xbeb187b6,
           0x3dea828d);
  //             -0.62142891,  0.63306540,  0.26511025,  0.85738784,
  //             -0.78492641, -0.44331804, -0.84668529,  0.13981950, 0.84909225,
  //             0.23569171,  0.34283128,  0.56619811,  0.22596644,  0.55843508,
  //             0.53194439,  0.02510819
  VLOAD_32(v3, 0xbf1f15f7, 0x3f221093, 0x3e87bc88, 0x3f5b7dc5, 0xbf48f0f0,
           0xbee2fa95, 0xbf58c05e, 0x3e0f2cd8, 0x3f595e1c, 0x3e71592b,
           0x3eaf8795, 0x3f10f25c, 0x3e6763bf, 0x3f0ef59a, 0x3f082d82,
           0x3ccdafb0);
  asm volatile("vfadd.vv v1, v2, v3");
  //             -0.91111463,  1.03598869,  0.60447025,  1.39628148,
  //             -0.38550627, -0.71335870, -0.06547815, -0.01650448, 0.34925178,
  //             -0.45690745,  0.30899066, -0.05765933,  0.22935496, 0.89555097,
  //             0.18520588,  0.13961500
  VCMP_U32(2, v1, 0xbf693ecf, 0x3f849b47, 0x3f1abe90, 0x3fb2b95a, 0xbec56114,
           0xbf369ead, 0xbd861968, 0xbc873468, 0x3eb2d121, 0xbee9efc6,
           0x3e9e3406, 0xbd6c2c30, 0x3e6adc07, 0x3f6542d4, 0x3e3da69c,
           0x3e0ef73c);
}
#line 10000 "ara84_wrapper.c"
int main(void) {
  enable_vec();
  enable_fp();
  unsigned initial_fcsr, initial_vstart;
  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));
  printf("ARA84_INITIAL fcsr=%u vstart=%u\n",initial_fcsr,initial_vstart);
  ara_case_begin("TEST_CASE1");
  TEST_CASE1();
  ara_case_end("TEST_CASE1",num_failed);
  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));
  printf("ARA84_FINAL fcsr=%u failures=%u\n",final_fcsr,num_failed);
  EXIT_CHECK();
}
