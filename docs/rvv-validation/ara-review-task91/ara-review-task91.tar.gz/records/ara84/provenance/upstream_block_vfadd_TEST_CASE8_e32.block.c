  CLEAR_FFLAGS;
  VSET(16, e32, m1);
  CHECK_FFLAGS(0);
  VLOAD_32(v2, pMaxf, pInff, pMaxf, pInff, pMaxf, pInff, pMaxf, pInff, pMaxf,
           pInff, pMaxf, pInff, pMaxf, pInff, pMaxf, pInff);
  VLOAD_32(v3, pMaxf, mInff, pMaxf, mInff, pMaxf, mInff, pMaxf, mInff, pMaxf,
           mInff, pMaxf, mInff, pMaxf, mInff, pMaxf, mInff);
  VLOAD_8(v0, 0xAA, 0xAA);
  VCLEAR(v1);
  asm volatile("vfadd.vv v1, v2, v3, v0.t");
  VCMP_U32(22, v1, 0, qNaNf, 0, qNaNf, 0, qNaNf, 0, qNaNf, 0, qNaNf, 0, qNaNf,
           0, qNaNf, 0, qNaNf);
  CHECK_FFLAGS(NV);
