  VSET(16, e32, m1);
  VLOAD_32(v2, pInff, pInff, mInff, qNaNf, pMaxf, pMaxf, pZero, mZerof, pZero,
           pMaxf, pZero, qNaNf, mInff, pInff, qNaNf, qNaNf);
  VLOAD_32(v3, mInff, pInff, mInff, pZero, pMaxf, mMaxf, pZero, mZerof, mZerof,
           mZerof, mMaxf, 0x1, 0xbf48f0f0, pZero, qNaNf, 0xbf48f0f0);
  asm volatile("vfadd.vv v1, v2, v3");
  VCMP_U32(8, v1, qNaNf, pInff, mInff, qNaNf, pInff, pZero, pZero, mZerof,
           pZero, pMaxf, mMaxf, qNaNf, mInff, pInff, qNaNf, qNaNf);
