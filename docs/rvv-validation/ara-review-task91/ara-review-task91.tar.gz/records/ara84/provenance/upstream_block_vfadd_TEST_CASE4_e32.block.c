  CLEAR_FFLAGS;
  VSET(16, e32, m1);
  CHECK_FFLAGS(0);
  VLOAD_32(v2, pInff, pInff, pInff, pInff, pInff, pInff, pInff, pInff, pInff,
           pInff, pInff, pInff, pInff, pInff, pInff, pInff);
  VLOAD_32(v3, mInff, mInff, mInff, mInff, mInff, mInff, mInff, mInff, mInff,
           mInff, mInff, mInff, mInff, mInff, mInff, mInff);
  asm volatile("vfadd.vv v1, v2, v3");
  VCMP_U32(11, v1, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf,
           qNaNf, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf, qNaNf);
  CHECK_FFLAGS(NV);
