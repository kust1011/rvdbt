  CLEAR_FFLAGS;
  VSET(16, e64, m1);
  CHECK_FFLAGS(0);
  VLOAD_64(v2, pMaxd, pInfd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd,
           pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd);
  VLOAD_64(v3, pMaxd, mInfd, 8000000000000001, pMaxd, pMaxd, pMaxd, pMaxd,
           pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd, pMaxd);
  asm volatile("vfadd.vv v1, v2, v3");
  VCMP_U64(12, v1, pInfd, qNaNd, pMaxd, pInfd, pInfd, pInfd, pInfd, pInfd,
           pInfd, pInfd, pInfd, pInfd, pInfd, pInfd, pInfd, pInfd);
  CHECK_FFLAGS(NV | OF | NX);
