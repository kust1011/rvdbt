  VSET(16, e64, m1);
  VLOAD_64(v2, pInfd, pInfd, mInfd, qNaNd, pMaxd, pMaxd, pZero, mZerod, pZero,
           pMaxd, pZero, qNaNd, mInfd, pInfd, qNaNd, qNaNd);
  VLOAD_64(v3, mInfd, pInfd, mInfd, pZero, pMaxd, mMaxd, pZero, mZerod, mZerod,
           mZerod, mMaxd, 0x1, 0xbfd90875fda29450, pZero, qNaNd,
           0xbfd90875fda29450);
  asm volatile("vfadd.vv v1, v2, v3");
  VCMP_U64(9, v1, qNaNd, pInfd, mInfd, qNaNd, pInfd, pZero, pZero, mZerod,
           pZero, pMaxd, mMaxd, qNaNd, mInfd, pInfd, qNaNd, qNaNd);
