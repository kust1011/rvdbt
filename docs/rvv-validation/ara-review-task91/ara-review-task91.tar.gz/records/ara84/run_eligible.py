import subprocess,json,time
from pathlib import Path
R=Path(__file__).resolve().parent
records=[]
def run(cmd):
 t=time.time();p=subprocess.run(cmd,capture_output=True);records.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),elapsed=time.time()-t));(R/'LAUNCH_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n');print(p.stdout.decode(),end='',flush=True)
 if p.returncode:print(p.stderr.decode(),flush=True)
for g in json.loads((R/'GROUPS.json').read_text()):
 if 'elf_sha256'not in g:continue
 name=g['name']
 for arm in ['reference','B','M1','M2','BOTH']:
  if name=='upstream_block_vfadd_TEST_CASE1_e32'and arm in ['reference','B']:continue
  if arm=='reference':run(['python3',str(R/'runner.py'),name,arm])
  else:run(['ssh','xbd','python3 /home/vick/ara84/runner.py '+name+' '+arm])
