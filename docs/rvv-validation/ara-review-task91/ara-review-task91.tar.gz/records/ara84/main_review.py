"""Audit extracted source ranges and independently replay original predicates."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
THESIS = ROOT.parents[2]
sys.path.insert(0, str(ROOT))
from checker import check_cases

groups = {g['name']: g for g in json.loads((ROOT / 'GROUPS.json').read_text())}
blocks = json.loads((ROOT / 'BLOCK_MAP.json').read_text())
rows = []
for block in blocks:
    source = (THESIS / block['source_file']).read_text().splitlines(keepends=True)
    first, last = block['source_lines']
    original = ''.join(source[first - 1:last])
    adapter = Path(block['adapter']).read_text()
    assert original in adapter and 'e16' not in original
    assert block['target']['opcode'] in original
    assert block['target']['checker'] in original
    group = groups[block['name']]
    reference_fcsr = None
    for arm in ['reference', 'B', 'M1', 'M2', 'BOTH']:
        base = ROOT / ('raw' if arm == 'reference' else 'remote-raw') / block['name'] / arm
        result = json.loads((base / 'result.json').read_text())
        raw = (base / 'stdout').read_bytes()
        ok, _, cases = check_cases(group, result['returncode'], raw)
        assert ok and result['returncode'] == 0 and len(cases) == 1
        assert b'FAILED' not in raw and b'ERROR' not in raw
        assert cases[0]['comparisons'] == 16
        initial = re.findall(rb'ARA84_INITIAL fcsr=(\d+) vstart=(\d+)', raw)
        final = re.findall(rb'ARA84_FINAL fcsr=(\d+) failures=(\d+)', raw)
        assert initial == [(b'0', b'0')] and len(final) == 1 and final[0][1] == b'0'
        if arm == 'reference':
            reference_fcsr = int(final[0][0])
        else:
            assert int(final[0][0]) == reference_fcsr
        assert not check_cases(group, 0, raw.replace(b'PASSED.', b'FAILED.', 1))[0]
        assert not check_cases(group, 1, raw)[0]
        rows.append({'case': block['name'], 'arm': arm, 'original_comparisons': 16,
                     'final_fcsr': int(final[0][0]), 'raw_rechecked': True})
assert len(rows) == 150
report = {'source_blocks': 30, 'DUT_raw_rechecked': 120, 'reference_raw_rechecked': 30,
          'parser_negative_checks': 300, 'rows': rows,
          'scope': 'Original extracted FP32/64 value predicates and recorded final fcsr, not whole-file PASS',
          'source_limit': 'Masked upstream blocks load beyond two-byte mask objects; compiled allocation audit is not a source-language bounds guarantee.'}
(ROOT / 'MAIN_REVIEW.json').write_text(json.dumps(report, indent=2) + '\n')
print('Source ranges + 150 stored raw comparisons accepted; no new DUT execution.')
