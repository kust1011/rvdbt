import sys,json,shutil,re,csv,hashlib,difflib
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';W=R.parents[2];A=W/'artifacts/external_suite_coverage_20261007'
sys.path.insert(0,str(P));from common import funcs,body,parser
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
for d in ['adapter','upstream','logs','bin','provenance']:(R/d).mkdir(exist_ok=True)
# Snapshot authoritative bindings BEFORE deciding what to execute.
files=[A/'ara/FORM_COVERAGE.csv',A/'ara/ASSERTION_TARGETS.csv',A/'SUITE_RUN_MANIFEST.csv',A/'ACTUAL_FORM_VALIDATION_BINDINGS.csv']
save('CANONICAL_BEFORE.json',{str(p):sha(p) for p in files})
hits={}
for p in files[2:]:
 rows=list(csv.DictReader(p.open()));hits[p.name]=[x for x in rows if any('/'+n+'.c' in str(x) for n in ['vfadd','vfsub','vfmul'])]
save('ACCEPTED_BINDINGS_CHECK.json',dict(authority_hashes={str(p):sha(p)for p in files[2:]},matching_records=hits,identical_accepted_blocks=0,decision='No accepted binding references any of these three pinned files. Execute all eligible extracted blocks; no canonical mutation.'))
assert not hits['ACTUAL_FORM_VALIDATION_BINDINGS.csv']
for f in ['runner.py','checker.py','run.original.py.txt','REFERENCE_IDENTITY.json','build.py']:shutil.copy2(P/f,R/f)
for p in (P/'upstream').iterdir():
 if p.suffix in ['.h','.c']:shutil.copy2(p,R/'upstream'/p.name)
for f in ['vector_macros.h','float_macros.h','user_runtime.c','user_runtime.h','start.S','link.ld','asm_environment.h']:shutil.copy2(P/'adapter'/f,R/'adapter'/f)
(R/'common.py').write_text('from pathlib import Path\nimport json,subprocess,hashlib\nR=Path(__file__).resolve().parent\nj=lambda p:json.loads(p.read_text())\nsha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()\ndef save(n,x):(R/n).write_text(json.dumps(x,indent=2)+"\\n")\n')
cs=json.loads((P/'CASES.json').read_text());groups=[];blocks=[];whole=[]
for c in cs:
 if c['file'] not in ['vfadd','vfsub','vfmul']:continue
 src=W/c['source_file'];s=src.read_text();assert sha(src)==c['source_sha256'];shutil.copy2(src,R/'upstream'/src.name)
 f=funcs(s)[c['function']];clean=parser['clean'](s);whole.append({k:c[k]for k in ['name','source_row_id','source_file','source_sha256','body_sha256','reasons','disposition','targets']})
 vsets=c['vsets']
 for vi,v in enumerate(vsets):
  if v['sew'] not in [32,64]:continue
  a=next(a for a in c['assertions']if a['avl']==v['avl']and a['vtype']==v['vtype']);target=next(t for t in c['targets']if int(t['config_line'])==v['line'])
  # Preserve full contiguous original block, including local pre-VSET flag clear.
  start=sum(len(x)for x in s.splitlines(True)[:v['line']-1]);limit=sum(len(x)for x in s.splitlines(True)[:vsets[vi+1]['line']-1])if vi+1<len(vsets)else f['end']-1
  prior=sum(len(x)for x in s.splitlines(True)[:vsets[vi-1]['line']-1])if vi else f['start']
  clears=list(re.finditer(r'\bCLEAR_FFLAGS\s*;',clean[prior:start]))
  if clears:start=prior+clears[-1].start();start=s.rfind('\n',0,start)+1
  # End after last assertion and any CHECK_FFLAGS, before next block's CLEAR.
  assertion_start=sum(len(x)for x in s.splitlines(True)[:a['assertion_line']-1]);m=re.search(r'\bVCMP_U'+str(v['sew'])+r'\(',clean[assertion_start:]);op=assertion_start+m.end()-1;end=parser['matching'](clean,op,'(',')')+1;end=clean.index(';',end)+1
  flag=re.match(r'\s*CHECK_FFLAGS\s*\(',clean[end:limit])
  if flag:
   op=end+flag.end()-1;end=parser['matching'](clean,op,'(',')')+1;end=clean.index(';',end)+1
  end=s.index('\n',end)+1
  b=s[start:end];assert 'e16' not in parser['clean'](b);assert f"VCMP_U{v['sew']}"in b
  name=f"upstream_block_{c['file']}_{c['function']}_e{v['sew']}";first=s.count('\n',0,start)+1;last=s.count('\n',0,end)
  fn=c['function'];new='#include "float_macros.h"\n#include "vector_macros.h"\n// EXTRACTED UPSTREAM BLOCK; not whole-function/file PASS.\nvoid '+fn+'(void) {\n#line '+str(first)+' "'+src.name+'"\n'+b+'}\n#line 10000 "ara84_wrapper.c"\nint main(void) {\n  enable_vec();\n  enable_fp();\n  unsigned initial_fcsr, initial_vstart;\n  asm volatile("frcsr %0; csrr %1, vstart" : "=r"(initial_fcsr), "=r"(initial_vstart));\n  printf("ARA84_INITIAL fcsr=%u vstart=%u\\n",initial_fcsr,initial_vstart);\n  ara_case_begin("'+fn+'");\n  '+fn+'();\n  ara_case_end("'+fn+'",num_failed);\n  unsigned final_fcsr; asm volatile("frcsr %0" : "=r"(final_fcsr));\n  printf("ARA84_FINAL fcsr=%u failures=%u\\n",final_fcsr,num_failed);\n  EXIT_CHECK();\n}\n'
  dest=R/'adapter'/(name+'.c');dest.write_text(new)
  assert new[new.index(b):new.index(b)+len(b)]==s[start:end]
  (R/'provenance'/(name+'.block.c')).write_text(b);(R/'provenance'/(name+'.diff')).write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile=c['source_file'],tofile=str(dest))))
  meta=dict(c);meta.update(function=fn,runtime_group=name,vsets=[v],assertions=[a],expected_vector_ids=[a['id']],expected_long_elements={},expected_scalar_ids=[],checker_calls=1,vector_assertions=1,comparisons=a['elements'],reasons=[],targets=[target],predecessors=[],disposition='EXTRACTED_UPSTREAM_BLOCK',no_oracle=False)
  g=dict(name=name,file=c['file'],functions=[fn],source_row_ids=[c['source_row_id']],case_metadata=[meta],vlen=1024,vsets=[v],assertions=[a],vector_assertions=1,comparisons=a['elements'],reasons=[],disposition='READY',observer='case-spans-v2',source_status='EXTRACTED_UPSTREAM_BLOCK; NOT ORIGINAL WHOLE-FUNCTION/FILE PASS')
  groups.append(g)
  blocks.append(dict(name=name,source_file=c['source_file'],original_function=fn,original_source_row_id=c['source_row_id'],source_sha256=sha(src),source_lines=[first,last],adapter=str(dest),adapter_block_lines=[6,6+last-first],block_sha256=hashlib.sha256(b.encode()).hexdigest(),block_byte_identical=True,target=target,vset=v,assertion=a,flag_checks=re.findall(r'CHECK_FFLAGS\((.*?)\)',parser['clean'](b)),flag_clear_preserved='CLEAR_FFLAGS' in b,frm_setup='none in original block; startup RNE observed, no added CSR writes',predecessor_dependence='none for checked values: VSET and all consumed vector/scalar operands initialized locally; inherited fflags not consumed unless original clear/check present; earlier vfadd TEST_CASE5 restores RNE',old_destination='original VCLEAR(v1) preserved'if 'VCLEAR' in b else'fully overwritten active destination; old value not consumed',mask='original 0xAA,0xAA bytes define all 16 checked mask bits; extra loaded bytes unconsumed; compiled stack bounds require audit'if 'v0.t'in b else'unmasked',scalar_interface='original double + BOX_FLOAT/DOUBLE + f constraint; RV32 ilp32d FLEN64; bits never truncated'if '.vf'in b else'vv; no scalar operand',status='ELIGIBLE_PENDING_BUILD'))
save('GROUPS.json',groups);save('BLOCK_MAP.json',blocks);save('ORIGINAL_WHOLE_FUNCTION_BLOCKERS.json',whole)
save('SCOPE.json',dict(pinned_ara_revision='34bd3bc152421b4601a7bf3d6e8e91ffb545c99e',eligible_blocks=len(blocks),rejected_blocks=[],excluded_original_functions=[dict(file='vfadd.c',function='TEST_CASE5',reason='Both active blocks are original FP16 e16; no FP32/64 block exists. Original RTZ then RNE changes are retained in upstream, no adapted FP32 invention.')],runner_checker_copied_from=str(P),production_changed=False))
print('eligible blocks',len(blocks))
