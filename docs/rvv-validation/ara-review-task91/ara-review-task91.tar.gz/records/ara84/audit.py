import json,re,hashlib,collections,csv,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
blocks=j(R/'BLOCK_MAP.json');groups={g['name']:g for g in j(R/'GROUPS.json')};rows=[];methods=[];failures=[]
for b in blocks:
 name=b['name'];g=groups[name];ref=None
 for arm in ['reference','B','M1','M2','BOTH']:
  root=R/('raw'if arm=='reference'else'remote-raw')/name/arm
  if not (root/'result.json').exists():failures.append(dict(name=name,arm=arm,status='MISSING'));continue
  result=j(root/'result.json');text=(root/'stdout').read_text();stderr=(root/'stderr').read_text();obs=j(root/'observations.json');cases=j(root/'case-results.json')
  v=b['vset'];a=b['assertion'];cfg_ok=obs['vsets']==[[v['line'],16,16,v['vtype']]]and obs['assertions']==[[a['id'],16,v['sew']//8,16,v['vtype'],16,1]]
  initial=re.search(r'ARA84_INITIAL fcsr=(\d+) vstart=(\d+)',text);final=re.search(r'ARA84_FINAL fcsr=(\d+) failures=(\d+)',text)
  initial_ok=bool(initial and initial.groups()==('0','0'));final_ok=bool(final and final[2]=='0'and int(final[1])>>5==0)
  flag_value=None
  if b['flag_checks']:
   flag_value=eval(b['flag_checks'][-1],{'NV':16,'DZ':8,'OF':4,'UF':2,'NX':1});final_ok &= int(final[1])&31==flag_value
  if arm=='reference':ref=dict(final_fcsr=int(final[1]),assertions=obs['assertions'],vsets=obs['vsets'])
  else:final_ok &= ref is not None and int(final[1])==ref['final_fcsr']
  identities_ok=j(root/'IDENTITY.json')==j(root/'IDENTITY_AFTER.json');elf_ok=result['elf_sha256']==g['elf_sha256']==sha(R/'bin'/(name+'.elf'))
  ok=result['status']=='PASS'and result['returncode']==0 and all(c['status']=='PASS'for c in cases)and cfg_ok and initial_ok and final_ok and identities_ok and elf_ok
  row=dict(block=name,arm=arm,status='PASS'if ok else'FAILURE_RETAINED',runner_status=result['status'],returncode=result['returncode'],scope='EXTRACTED_UPSTREAM_BLOCK; NOT ORIGINAL WHOLE-FUNCTION/FILE PASS',source_file=b['source_file'],source_lines=b['source_lines'],target_line=b['target']['line'],original_function=b['original_function'],adapter=b['adapter'],elf_sha256=g['elf_sha256'],original_typed_checker_accepted=result['original_checker_accepted'],configuration_exact=cfg_ok,initial_fcsr=int(initial[1])if initial else None,initial_vstart=int(initial[2])if initial else None,final_fcsr=int(final[1])if final else None,original_fflags_expected=flag_value,original_flag_checks_preserved=b['flag_checks'],original_flag_success_inferred='CHECK_FFLAGS original silent success: no FAILED/return, completed vector comparison, num_failed=0 and observed final fflags equality'if b['flag_checks']else'fflags not asserted upstream; final fcsr additionally compared to independent same-ELF reference',identity_before_after_equal=identities_ok,raw_root=str(root),raw_stdout=str(root/'stdout'),raw_stderr=str(root/'stderr'),result_evidence=str(root/'result.json'))
  rows.append(row)
  if not ok:failures.append(row)
  if arm!='reference':
   def fields(label):
    m=re.search(r'^'+label+r' (.*)$',stderr,re.M);return {k:int(v)if re.fullmatch(r'\d+',v)else v for k,v in re.findall(r'(\w+)=([^ ]+)',m[1])}if m else None
   conf=next(c for c in j(R/'CONFIGS.json')if c['case']==name and c['arm']==arm)
   methods.append(dict(block=name,arm=arm,configured_flags=conf['flags'],aggregate_run_formation=fields('RVV_RUN'),aggregate_direct=fields('RVV_DIRECT'),aggregate_fast=fields('RVV_FAST'),route_lines=[x for x in stderr.splitlines()if x.startswith('RVV_ROUTE ')],target_M1_admission='UNOBSERVED; aggregate translation counts do not identify target PC/form; multi-member census excludes singles',target_M2_admission='UNOBSERVED; global inline_hits includes setup/load/store/clear operations; no target-PC receipt',configured_method_PASS=ok))
save('EXECUTION_RESULTS.json',rows);save('METHOD_ADMISSION.json',methods);save('FAILURES.json',failures)
canonical=j(R/'CANONICAL_BEFORE.json');unchanged={p:sha(Path(p))==h for p,h in canonical.items()};task83=j(R/'TASK83_BEFORE.json');t83ok=all(sha(Path(p))==h for p,h in task83.items())
same={f:sha(R/f)==sha(P/f) for f in ['runner.py','checker.py','run.original.py.txt']};same.update({f'header:{f}':sha(R/'adapter'/f)==sha(P/'adapter'/f)for f in ['vector_macros.h','float_macros.h']})
counts=collections.Counter(x['status']for x in rows);runs=[m['aggregate_run_formation']for m in methods if m['aggregate_run_formation']and m['arm']in ['M1','BOTH']]
audit=dict(eligible_blocks=len(blocks),executed_blocks=len({x['block']for x in rows}),reference_calls=sum(x['arm']=='reference'for x in rows),DUT_calls=sum(x['arm']!='reference'for x in rows),statuses=dict(counts),all_150_receipts_present=len(rows)==150,all_source_blocks_byte_identical=all(b['block_byte_identical']for b in blocks),unchanged_runner_checker_headers=same,canonical_hashes_unchanged=unchanged,task83_evidence_hashes_unchanged=t83ok,DUT_vector_comparisons=sum(16 for x in rows if x['arm']!='reference'),reference_vector_comparisons=sum(16 for x in rows if x['arm']=='reference'),original_fflags_checks_per_arm=sum(len(b['flag_checks'])for b in blocks),m1_both_aggregate_formation_distributions=dict(collections.Counter(str((r['runs_formed'],r['multi_member_runs'],r['members_admitted']))for r in runs)),actual_target_admission='UNOBSERVED in retained instrumentation; configured arm completion is established',production_changed=False,whole_function_or_file_PASS_claimed=False,failures=len(failures))
save('AUDIT.json',audit)
assert len(rows)==150 and not failures and all(unchanged.values())and t83ok and all(same.values())
print(json.dumps(audit,indent=2))
