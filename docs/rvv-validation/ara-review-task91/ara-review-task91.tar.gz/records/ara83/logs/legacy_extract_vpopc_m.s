	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"legacy_extract_vpopc_m.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c" md5 0x6d2019ac7cc9c18654336d392ad36ccc
	.file	1 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c" md5 0x6d2019ac7cc9c18654336d392ad36ccc
	.file	2 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/vector_macros.h" md5 0x6c3abc442927920f23bf6bda6c68847c
	.file	3 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE1                      # -- Begin function TEST_CASE1
	.p2align	2
	.type	TEST_CASE1,@function
TEST_CASE1:                             # @TEST_CASE1
.Lfunc_begin0:
	.loc	1 10 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:10:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -80
	.cfi_def_cfa_offset 80
	sw	ra, 76(sp)                      # 4-byte Folded Spill
	sw	s0, 72(sp)                      # 4-byte Folded Spill
	sw	s1, 68(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	addi	s0, sp, 80
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 11 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:11:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:0:3
	li	a0, 4
.Ltmp1:
	.loc	1 11 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:11:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 11
	li	a1, 4
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 12 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:12:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 12 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:12:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2)
	lw	a1, %lo(.L__const.TEST_CASE1.Vv2)(a0)
	sw	a1, -28(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.Vv2)
	lw	a1, 12(a0)
	sw	a1, -16(s0)
	lw	a1, 8(a0)
	sw	a1, -20(s0)
	lw	a0, 4(a0)
	sw	a0, -24(s0)
	addi	a0, s0, -28
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 13 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:13:3
	j	.LBB0_5
.LBB0_5:
.Ltmp5:
	.loc	1 13 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:13:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv0)
	lw	a1, %lo(.L__const.TEST_CASE1.Vv0)(a0)
	sw	a1, -44(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.Vv0)
	lw	a1, 12(a0)
	sw	a1, -32(s0)
	lw	a1, 8(a0)
	sw	a1, -36(s0)
	lw	a0, 4(a0)
	sw	a0, -40(s0)
	addi	a0, s0, -44
	#APP
	vle32.v v0, (a0)  

	#NO_APP
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:0:3
	li	a0, 1337
	.loc	1 14 21 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:14:21
	sw	a0, -48(s0)
	.loc	1 15 21                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:15:21
	sw	zero, -52(s0)
	sw	zero, -56(s0)
	sw	zero, -60(s0)
	sw	zero, -64(s0)
	.loc	1 19 30                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:19:30
	lw	a0, -48(s0)
	addi	a1, s0, -64
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:16:3
	#APP
	vpopc.m a0, v2, v0.t 
sw a0, (a1) 

	#NO_APP
	.loc	1 20 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:20:3
	j	.LBB0_7
.LBB0_7:
.Ltmp7:
	.loc	1 20 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:20:3
	#APP
	.Lara_scalar_check_0:
la a0, .Lara_scalar_check_0
	#NO_APP
	sw	a0, -68(s0)
	lw	a2, -64(s0)
	lw	a6, -68(s0)
	li	s1, 2
	li	a0, 1
	li	a1, 20
	li	a3, 0
	li	a4, 2
	li	a5, 0
	call	ara_scalar_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 1
	call	printf_
.Ltmp8:
	.loc	1 20 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:20:3
	lw	a0, -64(s0)
	beq	a0, s1, .LBB0_9
	j	.LBB0_8
.LBB0_8:
.Ltmp9:
	.loc	1 20 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:20:3
	lw	a2, -64(s0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	li	a1, 1
	li	a3, 2
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_10
.Ltmp10:
.LBB0_9:
	.loc	1 20 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:20:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 1
	call	ara_scalar_end
	j	.LBB0_10
.Ltmp11:
.LBB0_10:
	.cfi_def_cfa sp, 80
	.loc	1 21 1 epilogue_begin is_stmt 1 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:21:1
	lw	ra, 76(sp)                      # 4-byte Folded Reload
	lw	s0, 72(sp)                      # 4-byte Folded Reload
	lw	s1, 68(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 80
	.cfi_def_cfa_offset 0
	ret
.Ltmp12:
.Lfunc_end0:
	.size	TEST_CASE1, .Lfunc_end0-TEST_CASE1
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin1:
	.loc	1 23 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:23:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp13:
	.loc	1 24 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:24:3
	lui	s2, %hi(.L_MergedGlobals)
	sw	zero, %lo(.L_MergedGlobals)(s2)
	addi	a0, s2, %lo(.L_MergedGlobals)
	sw	zero, 4(a0)
	.loc	1 27 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:27:3
	lui	s1, %hi(.L.str.3)
	addi	s1, s1, %lo(.L.str.3)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 27 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:27:33
	call	TEST_CASE1
	.loc	1 27 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:27:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 27 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:27:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 28 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:28:3
	j	.LBB1_1
.LBB1_1:
.Ltmp14:
	.loc	1 28 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:28:3
	lui	a0, %hi(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals)(a0)
	blez	a0, .LBB1_3
	j	.LBB1_2
.LBB1_2:
.Ltmp15:
	.loc	1 28 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:28:3
	lui	s1, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(s1)
	lui	a0, %hi(.L.str.4)
	addi	a0, a0, %lo(.L.str.4)
	lui	a1, %hi(.L.str.5)
	addi	a1, a1, %lo(.L.str.5)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	sw	a0, -20(s0)
	j	.LBB1_4
.Ltmp16:
.LBB1_3:
	.loc	1 28 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:28:3
	lui	a0, %hi(.L.str.6)
	addi	a0, a0, %lo(.L.str.6)
	lui	a1, %hi(.L.str.5)
	addi	a1, a1, %lo(.L.str.5)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB1_4
.Ltmp17:
.LBB1_4:
	.loc	1 29 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:29:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	1 29 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c:29:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp18:
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE1.Vv2,@object # @__const.TEST_CASE1.Vv2
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv2:
	.word	7                               # 0x7
	.word	0                               # 0x0
	.word	0                               # 0x0
	.word	0                               # 0x0
	.size	.L__const.TEST_CASE1.Vv2, 16

	.type	.L__const.TEST_CASE1.Vv0,@object # @__const.TEST_CASE1.Vv0
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv0:
	.word	5                               # 0x5
	.word	0                               # 0x0
	.word	0                               # 0x0
	.word	0                               # 0x0
	.size	.L__const.TEST_CASE1.Vv0, 16

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %d, expected %d.\n"
	.size	.L.str.1, 39

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"TEST_CASE1"
	.size	.L.str.3, 11

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.4, 28

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c"
	.size	.L.str.5, 132

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.6, 13

	.type	.L_MergedGlobals,@object        # @_MergedGlobals
	.local	.L_MergedGlobals
	.comm	.L_MergedGlobals,8,4
	.globl	num_failed
.set num_failed, .L_MergedGlobals
	.size	num_failed, 4
	.globl	test_case
.set test_case, .L_MergedGlobals+4
	.size	test_case, 4
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	0                               # DW_CHILDREN_no
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x170 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	8                               # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x6d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	27                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x77:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x83:0xa DW_TAG_variable
	.word	141                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	28                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	3                               # Abbrev [3] 0x8d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x92:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x99:0xa DW_TAG_variable
	.word	163                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	28                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	3                               # Abbrev [3] 0xa3:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xa8:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	132                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xaf:0xa DW_TAG_variable
	.word	185                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	28                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	3                               # Abbrev [3] 0xb9:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbe:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xc5:0xb DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	208                             # DW_AT_type
                                        # DW_AT_external
	.byte	2                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	5                               # Abbrev [5] 0xd0:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0xd4:0xd DW_TAG_variable
	.byte	7                               # DW_AT_name
	.word	208                             # DW_AT_type
                                        # DW_AT_external
	.byte	2                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	35
	.byte	4
	.byte	8                               # Abbrev [8] 0xe1:0x8 DW_TAG_typedef
	.word	233                             # DW_AT_type
	.byte	9                               # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	102                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0xe9:0x4 DW_TAG_base_type
	.byte	8                               # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	8                               # DW_AT_byte_size
	.byte	9                               # Abbrev [9] 0xed:0x59 DW_TAG_subprogram
	.byte	8                               # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	10                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
                                        # DW_AT_external
	.byte	10                              # Abbrev [10] 0xf8:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	80
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.word	353                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x103:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	341                             # DW_AT_type
	.byte	11                              # Abbrev [11] 0x10e:0x12 DW_TAG_lexical_block
	.byte	9                               # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	10                              # Abbrev [10] 0x114:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	12                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.word	341                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x120:0x12 DW_TAG_lexical_block
	.byte	10                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	10                              # Abbrev [10] 0x126:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.word	341                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x132:0x13 DW_TAG_lexical_block
	.byte	11                              # DW_AT_low_pc
	.word	.Ltmp11-.Ltmp7                  # DW_AT_high_pc
	.byte	10                              # Abbrev [10] 0x138:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274\177"
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.word	370                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	12                              # Abbrev [12] 0x146:0xf DW_TAG_subprogram
	.byte	12                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	11                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	23                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	208                             # DW_AT_type
                                        # DW_AT_external
	.byte	3                               # Abbrev [3] 0x155:0xc DW_TAG_array_type
	.word	353                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x15a:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x161:0x5 DW_TAG_volatile_type
	.word	358                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0x166:0x8 DW_TAG_typedef
	.word	366                             # DW_AT_type
	.byte	14                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x16e:0x4 DW_TAG_base_type
	.byte	13                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	14                              # Abbrev [14] 0x172:0x9 DW_TAG_typedef
	.word	366                             # DW_AT_type
	.byte	19                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	84                              # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vpopc_m.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=218
.Linfo_string3:
	.asciz	"char"                          # string offset=270
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=275
.Linfo_string5:
	.asciz	"num_failed"                    # string offset=295
.Linfo_string6:
	.asciz	"int"                           # string offset=306
.Linfo_string7:
	.asciz	"test_case"                     # string offset=310
.Linfo_string8:
	.asciz	"unsigned long long"            # string offset=320
.Linfo_string9:
	.asciz	"uint64_t"                      # string offset=339
.Linfo_string10:
	.asciz	"TEST_CASE1"                    # string offset=348
.Linfo_string11:
	.asciz	"main"                          # string offset=359
.Linfo_string12:
	.asciz	"Vv2"                           # string offset=364
.Linfo_string13:
	.asciz	"unsigned int"                  # string offset=368
.Linfo_string14:
	.asciz	"uint32_t"                      # string offset=381
.Linfo_string15:
	.asciz	"Vv0"                           # string offset=390
.Linfo_string16:
	.asciz	"scalar"                        # string offset=394
.Linfo_string17:
	.asciz	"OUP"                           # string offset=401
.Linfo_string18:
	.asciz	"ara_scalar_pc"                 # string offset=405
.Linfo_string19:
	.asciz	"uintptr_t"                     # string offset=419
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L_MergedGlobals
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Lfunc_begin1
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
