	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"legacy_extract_vsux.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c" md5 0x97518fd20515804c5133cfa6a5b85291
	.file	1 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c" md5 0x97518fd20515804c5133cfa6a5b85291
	.file	2 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/vector_macros.h" md5 0x6c3abc442927920f23bf6bda6c68847c
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE1                      # -- Begin function TEST_CASE1
	.p2align	2
	.type	TEST_CASE1,@function
TEST_CASE1:                             # @TEST_CASE1
.Lfunc_begin0:
	.loc	1 10 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:10:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 11 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:11:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:0:3
	li	a0, 4
.Ltmp1:
	.loc	1 11 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:11:3
	#APP
	vsetvli t0, a0,e8,m1, ta, ma 

	#NO_APP
	li	a0, 11
	li	a1, 4
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 12 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:12:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 12 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:12:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2)
	lbu	a1, %lo(.L__const.TEST_CASE1.Vv2)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.Vv2)
	lbu	a2, 1(a0)
	slli	a2, a2, 8
	or	a1, a2, a1
	lbu	a2, 2(a0)
	slli	a2, a2, 16
	lbu	a0, 3(a0)
	slli	a0, a0, 24
	or	a0, a0, a2
	or	a0, a0, a1
	sw	a0, -12(s0)
	addi	a0, s0, -12
	#APP
	vle8.v v2, (a0)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 13 20 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:13:20
	lui	a0, %hi(.L__const.TEST_CASE1.OUP)
	lbu	a1, %lo(.L__const.TEST_CASE1.OUP)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.OUP)
	lbu	a2, 1(a0)
	slli	a2, a2, 8
	or	a1, a2, a1
	lbu	a2, 2(a0)
	slli	a2, a2, 16
	lbu	a0, 3(a0)
	slli	a0, a0, 24
	or	a0, a0, a2
	or	a0, a0, a1
	sw	a0, -16(s0)
	.loc	1 14 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:14:3
	j	.LBB0_5
.LBB0_5:
.Ltmp5:
	.loc	1 14 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:14:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv1)
	lbu	a1, %lo(.L__const.TEST_CASE1.Vv1)(a0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.Vv1)
	lbu	a2, 1(a0)
	slli	a2, a2, 8
	or	a1, a2, a1
	lbu	a2, 2(a0)
	slli	a2, a2, 16
	lbu	a0, 3(a0)
	slli	a0, a0, 24
	or	a0, a0, a2
	or	a0, a0, a1
	sw	a0, -20(s0)
	addi	a0, s0, -20
	#APP
	vle8.v v1, (a0)  

	#NO_APP
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:0:3
	addi	a0, s0, -16
	.loc	1 15 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:15:3
	#APP
	vsuxei8.v v1, (a0), v2
	#NO_APP
	lui	a0, 65280
	addi	a0, a0, 255
.Ltmp7:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	sw	a0, -24(s0)
	li	a0, 1
	li	a1, 4
	li	a2, 1
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 1
	call	printf_
.Ltmp8:
	.loc	1 16 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	sw	zero, -28(s0)
	j	.LBB0_7
.LBB0_7:                                # =>This Inner Loop Header: Depth=1
.Ltmp9:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	lw	a0, -28(s0)
	li	a1, 3
.Ltmp10:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	bltu	a1, a0, .LBB0_12
	j	.LBB0_8
.LBB0_8:                                #   in Loop: Header=BB0_7 Depth=1
.Ltmp11:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	lw	a1, -28(s0)
	li	a0, 1
	call	ara_compare_step
.Ltmp12:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	lw	a0, -28(s0)
	addi	a1, s0, -16
	add	a0, a1, a0
	lbu	a0, 0(a0)
	lw	a1, -28(s0)
	addi	a2, s0, -24
	add	a1, a2, a1
	lbu	a1, 0(a1)
	beq	a0, a1, .LBB0_10
	j	.LBB0_9
.LBB0_9:
.Ltmp13:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	lw	a1, -28(s0)
	addi	a0, s0, -16
	add	a0, a0, a1
	lbu	a2, 0(a0)
	lw	a0, -28(s0)
	addi	a3, s0, -24
	add	a0, a3, a0
	lbu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_13
.Ltmp14:
.LBB0_10:                               #   in Loop: Header=BB0_7 Depth=1
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	j	.LBB0_11
.Ltmp15:
.LBB0_11:                               #   in Loop: Header=BB0_7 Depth=1
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	lw	a0, -28(s0)
	addi	a0, a0, 1
	sw	a0, -28(s0)
	j	.LBB0_7
.Ltmp16:
.LBB0_12:
	.loc	1 16 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:16:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 1
	call	ara_assert_end
.Ltmp17:
	.loc	1 17 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:17:1
	j	.LBB0_13
.LBB0_13:
	.cfi_def_cfa sp, 32
	.loc	1 17 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:17:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp18:
.Lfunc_end0:
	.size	TEST_CASE1, .Lfunc_end0-TEST_CASE1
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE3                      # -- Begin function TEST_CASE3
	.p2align	2
	.type	TEST_CASE3,@function
TEST_CASE3:                             # @TEST_CASE3
.Lfunc_begin1:
	.loc	1 29 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:29:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sw	ra, 44(sp)                      # 4-byte Folded Spill
	sw	s0, 40(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 48
	.cfi_def_cfa s0, 0
.Ltmp19:
	.loc	1 30 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:30:3
	j	.LBB1_1
.LBB1_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:0:3
	li	a0, 4
.Ltmp20:
	.loc	1 30 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:30:3
	#APP
	vsetvli t0, a0,e16,m1, ta, ma 

	#NO_APP
	li	a0, 30
	li	a1, 4
	call	ara_trace_vset
	j	.LBB1_2
.Ltmp21:
.LBB1_2:
	.loc	1 31 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:31:3
	j	.LBB1_3
.LBB1_3:
.Ltmp22:
	.loc	1 31 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:31:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv2)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv2)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -12(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv2)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -16(s0)
	addi	a0, s0, -16
	#APP
	vle16.v v2, (a0)  

	#NO_APP
	j	.LBB1_4
.Ltmp23:
.LBB1_4:
	.loc	1 32 21 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:32:21
	lui	a0, %hi(.L__const.TEST_CASE3.OUP)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.OUP)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -20(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.OUP)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -24(s0)
	.loc	1 33 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:33:3
	j	.LBB1_5
.LBB1_5:
.Ltmp24:
	.loc	1 33 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:33:3
	lui	a0, %hi(.L__const.TEST_CASE3.Vv1)
	addi	a1, a0, %lo(.L__const.TEST_CASE3.Vv1)
	lhu	a2, 4(a1)
	lhu	a3, 6(a1)
	slli	a3, a3, 16
	or	a2, a3, a2
	sw	a2, -28(s0)
	lhu	a0, %lo(.L__const.TEST_CASE3.Vv1)(a0)
	lhu	a1, 2(a1)
	slli	a1, a1, 16
	or	a0, a1, a0
	sw	a0, -32(s0)
	addi	a0, s0, -32
	#APP
	vle16.v v1, (a0)  

	#NO_APP
	j	.LBB1_6
.Ltmp25:
.LBB1_6:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:0:3
	addi	a0, s0, -24
	.loc	1 34 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:34:3
	#APP
	vsuxei16.v v1, (a0), v2
	#NO_APP
	lui	a0, 61695
	addi	a0, a0, 240
.Ltmp26:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	sw	a0, -36(s0)
	lui	a0, 16
	addi	a0, a0, -1
	sw	a0, -40(s0)
	li	a0, 3
	li	a1, 4
	li	a2, 2
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 3
	call	printf_
.Ltmp27:
	.loc	1 35 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	sw	zero, -44(s0)
	j	.LBB1_7
.LBB1_7:                                # =>This Inner Loop Header: Depth=1
.Ltmp28:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	lw	a0, -44(s0)
	li	a1, 3
.Ltmp29:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	bltu	a1, a0, .LBB1_12
	j	.LBB1_8
.LBB1_8:                                #   in Loop: Header=BB1_7 Depth=1
.Ltmp30:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	lw	a1, -44(s0)
	li	a0, 3
	call	ara_compare_step
.Ltmp31:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	lw	a0, -44(s0)
	slli	a0, a0, 1
	addi	a1, s0, -24
	add	a0, a1, a0
	lhu	a0, 0(a0)
	lw	a1, -44(s0)
	slli	a1, a1, 1
	addi	a2, s0, -40
	add	a1, a2, a1
	lhu	a1, 0(a1)
	beq	a0, a1, .LBB1_10
	j	.LBB1_9
.LBB1_9:
.Ltmp32:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	lw	a1, -44(s0)
	slli	a0, a1, 1
	addi	a2, s0, -24
	add	a0, a2, a0
	lhu	a2, 0(a0)
	lw	a0, -44(s0)
	slli	a0, a0, 1
	addi	a3, s0, -40
	add	a0, a3, a0
	lhu	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_13
.Ltmp33:
.LBB1_10:                               #   in Loop: Header=BB1_7 Depth=1
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	j	.LBB1_11
.Ltmp34:
.LBB1_11:                               #   in Loop: Header=BB1_7 Depth=1
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	lw	a0, -44(s0)
	addi	a0, a0, 1
	sw	a0, -44(s0)
	j	.LBB1_7
.Ltmp35:
.LBB1_12:
	.loc	1 35 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:35:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 3
	call	ara_assert_end
.Ltmp36:
	.loc	1 36 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:36:1
	j	.LBB1_13
.LBB1_13:
	.cfi_def_cfa sp, 48
	.loc	1 36 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:36:1
	lw	ra, 44(sp)                      # 4-byte Folded Reload
	lw	s0, 40(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Ltmp37:
.Lfunc_end1:
	.size	TEST_CASE3, .Lfunc_end1-TEST_CASE3
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE5                      # -- Begin function TEST_CASE5
	.p2align	2
	.type	TEST_CASE5,@function
TEST_CASE5:                             # @TEST_CASE5
.Lfunc_begin2:
	.loc	1 49 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:49:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -80
	.cfi_def_cfa_offset 80
	sw	ra, 76(sp)                      # 4-byte Folded Spill
	sw	s0, 72(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 80
	.cfi_def_cfa s0, 0
.Ltmp38:
	.loc	1 50 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:50:3
	j	.LBB2_1
.LBB2_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:0:3
	li	a0, 4
.Ltmp39:
	.loc	1 50 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:50:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 50
	li	a1, 4
	call	ara_trace_vset
	j	.LBB2_2
.Ltmp40:
.LBB2_2:
	.loc	1 51 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:51:3
	j	.LBB2_3
.LBB2_3:
.Ltmp41:
	.loc	1 51 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:51:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv2)
	lw	a1, %lo(.L__const.TEST_CASE5.Vv2)(a0)
	sw	a1, -24(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv2)
	lw	a1, 12(a0)
	sw	a1, -12(s0)
	lw	a1, 8(a0)
	sw	a1, -16(s0)
	lw	a0, 4(a0)
	sw	a0, -20(s0)
	addi	a0, s0, -24
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB2_4
.Ltmp42:
.LBB2_4:
	.loc	1 52 21 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:52:21
	lui	a0, %hi(.L__const.TEST_CASE5.OUP)
	lw	a1, %lo(.L__const.TEST_CASE5.OUP)(a0)
	sw	a1, -40(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.OUP)
	lw	a1, 12(a0)
	sw	a1, -28(s0)
	lw	a1, 8(a0)
	sw	a1, -32(s0)
	lw	a0, 4(a0)
	sw	a0, -36(s0)
	.loc	1 53 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:53:3
	j	.LBB2_5
.LBB2_5:
.Ltmp43:
	.loc	1 53 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:53:3
	lui	a0, %hi(.L__const.TEST_CASE5.Vv1)
	lw	a1, %lo(.L__const.TEST_CASE5.Vv1)(a0)
	sw	a1, -56(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE5.Vv1)
	lw	a1, 12(a0)
	sw	a1, -44(s0)
	lw	a1, 8(a0)
	sw	a1, -48(s0)
	lw	a0, 4(a0)
	sw	a0, -52(s0)
	addi	a0, s0, -56
	#APP
	vle32.v v1, (a0)  

	#NO_APP
	j	.LBB2_6
.Ltmp44:
.LBB2_6:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:0:3
	addi	a0, s0, -40
	.loc	1 54 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:54:3
	#APP
	vsuxei32.v v1, (a0), v2
	#NO_APP
	lui	a0, 61681
	addi	a0, a0, -241
.Ltmp45:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	sw	a0, -60(s0)
	lui	a0, 986895
	addi	a0, a0, 240
	sw	a0, -64(s0)
	sw	zero, -68(s0)
	li	a0, -1
	sw	a0, -72(s0)
	li	a0, 5
	li	a1, 4
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 5
	call	printf_
.Ltmp46:
	.loc	1 55 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	sw	zero, -76(s0)
	j	.LBB2_7
.LBB2_7:                                # =>This Inner Loop Header: Depth=1
.Ltmp47:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	lw	a0, -76(s0)
	li	a1, 3
.Ltmp48:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	bltu	a1, a0, .LBB2_12
	j	.LBB2_8
.LBB2_8:                                #   in Loop: Header=BB2_7 Depth=1
.Ltmp49:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	lw	a1, -76(s0)
	li	a0, 5
	call	ara_compare_step
.Ltmp50:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	lw	a0, -76(s0)
	slli	a0, a0, 2
	addi	a1, s0, -40
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -76(s0)
	slli	a1, a1, 2
	addi	a2, s0, -72
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB2_10
	j	.LBB2_9
.LBB2_9:
.Ltmp51:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	lw	a1, -76(s0)
	slli	a0, a1, 2
	addi	a2, s0, -40
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -76(s0)
	slli	a0, a0, 2
	addi	a3, s0, -72
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB2_13
.Ltmp52:
.LBB2_10:                               #   in Loop: Header=BB2_7 Depth=1
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	j	.LBB2_11
.Ltmp53:
.LBB2_11:                               #   in Loop: Header=BB2_7 Depth=1
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	lw	a0, -76(s0)
	addi	a0, a0, 1
	sw	a0, -76(s0)
	j	.LBB2_7
.Ltmp54:
.LBB2_12:
	.loc	1 55 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:55:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 5
	call	ara_assert_end
.Ltmp55:
	.loc	1 56 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:56:1
	j	.LBB2_13
.LBB2_13:
	.cfi_def_cfa sp, 80
	.loc	1 56 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:56:1
	lw	ra, 76(sp)                      # 4-byte Folded Reload
	lw	s0, 72(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 80
	.cfi_def_cfa_offset 0
	ret
.Ltmp56:
.Lfunc_end2:
	.size	TEST_CASE5, .Lfunc_end2-TEST_CASE5
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin3:
	.loc	1 92 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:92:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp57:
	.loc	1 93 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:93:3
	lui	s2, %hi(.L_MergedGlobals)
	sw	zero, %lo(.L_MergedGlobals)(s2)
	addi	a0, s2, %lo(.L_MergedGlobals)
	sw	zero, 4(a0)
	.loc	1 95 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:95:3
	lui	s1, %hi(.L.str.3)
	addi	s1, s1, %lo(.L.str.3)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 95 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:95:33
	call	TEST_CASE1
	.loc	1 95 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:95:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 95 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:95:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 96 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:96:3
	lui	s1, %hi(.L.str.4)
	addi	s1, s1, %lo(.L.str.4)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 96 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:96:33
	call	TEST_CASE3
	.loc	1 96 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:96:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 96 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:96:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 97 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:97:3
	lui	s1, %hi(.L.str.5)
	addi	s1, s1, %lo(.L.str.5)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 97 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:97:33
	call	TEST_CASE5
	.loc	1 97 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:97:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 97 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:97:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 103 3 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:103:3
	j	.LBB3_1
.LBB3_1:
.Ltmp58:
	.loc	1 103 3 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:103:3
	lui	a0, %hi(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals)(a0)
	blez	a0, .LBB3_3
	j	.LBB3_2
.LBB3_2:
.Ltmp59:
	.loc	1 103 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:103:3
	lui	s1, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(s1)
	lui	a0, %hi(.L.str.6)
	addi	a0, a0, %lo(.L.str.6)
	lui	a1, %hi(.L.str.7)
	addi	a1, a1, %lo(.L.str.7)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	sw	a0, -20(s0)
	j	.LBB3_4
.Ltmp60:
.LBB3_3:
	.loc	1 103 3                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:103:3
	lui	a0, %hi(.L.str.8)
	addi	a0, a0, %lo(.L.str.8)
	lui	a1, %hi(.L.str.7)
	addi	a1, a1, %lo(.L.str.7)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB3_4
.Ltmp61:
.LBB3_4:
	.loc	1 104 1 is_stmt 1               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:104:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	1 104 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c:104:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp62:
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE1.Vv2,@object # @__const.TEST_CASE1.Vv2
	.section	.rodata.cst4,"aM",@progbits,4
.L__const.TEST_CASE1.Vv2:
	.ascii	"\000\001\002\003"
	.size	.L__const.TEST_CASE1.Vv2, 4

	.type	.L__const.TEST_CASE1.OUP,@object # @__const.TEST_CASE1.OUP
.L__const.TEST_CASE1.OUP:
	.zero	4,239
	.size	.L__const.TEST_CASE1.OUP, 4

	.type	.L__const.TEST_CASE1.Vv1,@object # @__const.TEST_CASE1.Vv1
.L__const.TEST_CASE1.Vv1:
	.ascii	"\377\000\360\017"
	.size	.L__const.TEST_CASE1.Vv1, 4

	.type	.L__const.TEST_CASE1.vact,@object # @__const.TEST_CASE1.vact
.L__const.TEST_CASE1.vact:
	.ascii	"\377\000\360\017"
	.size	.L__const.TEST_CASE1.vact, 4

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %x, expected %x.\n"
	.size	.L.str.1, 39

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L__const.TEST_CASE3.Vv2,@object # @__const.TEST_CASE3.Vv2
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv2:
	.half	0                               # 0x0
	.half	2                               # 0x2
	.half	4                               # 0x4
	.half	6                               # 0x6
	.size	.L__const.TEST_CASE3.Vv2, 8

	.type	.L__const.TEST_CASE3.OUP,@object # @__const.TEST_CASE3.OUP
	.p2align	1, 0x0
.L__const.TEST_CASE3.OUP:
	.half	57005                           # 0xdead
	.half	48879                           # 0xbeef
	.half	57005                           # 0xdead
	.half	48879                           # 0xbeef
	.size	.L__const.TEST_CASE3.OUP, 8

	.type	.L__const.TEST_CASE3.Vv1,@object # @__const.TEST_CASE3.Vv1
	.p2align	1, 0x0
.L__const.TEST_CASE3.Vv1:
	.half	65535                           # 0xffff
	.half	0                               # 0x0
	.half	61680                           # 0xf0f0
	.half	3855                            # 0xf0f
	.size	.L__const.TEST_CASE3.Vv1, 8

	.type	.L__const.TEST_CASE3.vact,@object # @__const.TEST_CASE3.vact
	.p2align	1, 0x0
.L__const.TEST_CASE3.vact:
	.half	65535                           # 0xffff
	.half	0                               # 0x0
	.half	61680                           # 0xf0f0
	.half	3855                            # 0xf0f
	.size	.L__const.TEST_CASE3.vact, 8

	.type	.L__const.TEST_CASE5.Vv2,@object # @__const.TEST_CASE5.Vv2
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv2:
	.word	0                               # 0x0
	.word	4                               # 0x4
	.word	8                               # 0x8
	.word	12                              # 0xc
	.size	.L__const.TEST_CASE5.Vv2, 16

	.type	.L__const.TEST_CASE5.OUP,@object # @__const.TEST_CASE5.OUP
	.p2align	2, 0x0
.L__const.TEST_CASE5.OUP:
	.word	3735928559                      # 0xdeadbeef
	.word	3735928559                      # 0xdeadbeef
	.word	3735928559                      # 0xdeadbeef
	.word	3735928559                      # 0xdeadbeef
	.size	.L__const.TEST_CASE5.OUP, 16

	.type	.L__const.TEST_CASE5.Vv1,@object # @__const.TEST_CASE5.Vv1
	.p2align	2, 0x0
.L__const.TEST_CASE5.Vv1:
	.word	4294967295                      # 0xffffffff
	.word	0                               # 0x0
	.word	4042322160                      # 0xf0f0f0f0
	.word	252645135                       # 0xf0f0f0f
	.size	.L__const.TEST_CASE5.Vv1, 16

	.type	.L__const.TEST_CASE5.vact,@object # @__const.TEST_CASE5.vact
	.p2align	2, 0x0
.L__const.TEST_CASE5.vact:
	.word	4294967295                      # 0xffffffff
	.word	0                               # 0x0
	.word	4042322160                      # 0xf0f0f0f0
	.word	252645135                       # 0xf0f0f0f
	.size	.L__const.TEST_CASE5.vact, 16

	.type	.L.str.3,@object                # @.str.3
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.3:
	.asciz	"TEST_CASE1"
	.size	.L.str.3, 11

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"TEST_CASE3"
	.size	.L.str.4, 11

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"TEST_CASE5"
	.size	.L.str.5, 11

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.6, 28

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c"
	.size	.L.str.7, 129

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.8, 13

	.type	.L_MergedGlobals,@object        # @_MergedGlobals
	.local	.L_MergedGlobals
	.comm	.L_MergedGlobals,8,4
	.globl	num_failed
.set num_failed, .L_MergedGlobals
	.size	num_failed, 4
	.globl	test_case
.set test_case, .L_MergedGlobals+4
	.size	test_case, 4
	.file	3 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	0                               # DW_CHILDREN_no
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x294 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	10                              # DW_AT_low_pc
	.word	.Lfunc_end3-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	16                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	16                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	16                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x6d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	95                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x77:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x83:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	96                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	2                               # Abbrev [2] 0x8d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	97                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	2                               # Abbrev [2] 0x97:0xa DW_TAG_variable
	.word	161                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	103                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	3                               # Abbrev [3] 0xa1:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xa6:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xad:0xa DW_TAG_variable
	.word	183                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	103                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	3                               # Abbrev [3] 0xb7:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xbc:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	129                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xc3:0xa DW_TAG_variable
	.word	205                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	103                             # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xcd:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xd2:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xd9:0xb DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	228                             # DW_AT_type
                                        # DW_AT_external
	.byte	2                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	5                               # Abbrev [5] 0xe4:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	7                               # Abbrev [7] 0xe8:0xd DW_TAG_variable
	.byte	7                               # DW_AT_name
	.word	228                             # DW_AT_type
                                        # DW_AT_external
	.byte	2                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	35
	.byte	4
	.byte	8                               # Abbrev [8] 0xf5:0x5f DW_TAG_subprogram
	.byte	10                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	8                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	9                               # Abbrev [9] 0x100:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.word	547                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x10b:0x12 DW_TAG_lexical_block
	.byte	11                              # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x111:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	116
	.byte	12                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.word	547                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x11d:0x12 DW_TAG_lexical_block
	.byte	12                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x123:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	108
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	14                              # DW_AT_decl_line
	.word	547                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x12f:0x24 DW_TAG_lexical_block
	.byte	13                              # DW_AT_low_pc
	.word	.Ltmp17-.Ltmp7                  # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x135:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	16                              # DW_AT_decl_line
	.word	577                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x140:0x12 DW_TAG_lexical_block
	.byte	14                              # DW_AT_low_pc
	.word	.Ltmp16-.Ltmp8                  # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x146:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	100
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	16                              # DW_AT_decl_line
	.word	589                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0x154:0x5f DW_TAG_subprogram
	.byte	15                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	9                               # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	29                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	9                               # Abbrev [9] 0x15f:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	32                              # DW_AT_decl_line
	.word	593                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x16a:0x12 DW_TAG_lexical_block
	.byte	16                              # DW_AT_low_pc
	.word	.Ltmp23-.Ltmp22                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x170:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	112
	.byte	12                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	31                              # DW_AT_decl_line
	.word	593                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x17c:0x12 DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp25-.Ltmp24                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x182:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	96
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	33                              # DW_AT_decl_line
	.word	593                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x18e:0x24 DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp36-.Ltmp26                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x194:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	35                              # DW_AT_decl_line
	.word	622                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x19f:0x12 DW_TAG_lexical_block
	.byte	19                              # DW_AT_low_pc
	.word	.Ltmp35-.Ltmp27                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x1a5:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	35                              # DW_AT_decl_line
	.word	589                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	8                               # Abbrev [8] 0x1b3:0x61 DW_TAG_subprogram
	.byte	20                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin2       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	10                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	49                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	9                               # Abbrev [9] 0x1be:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	15                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	52                              # DW_AT_decl_line
	.word	634                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x1c9:0x12 DW_TAG_lexical_block
	.byte	21                              # DW_AT_low_pc
	.word	.Ltmp42-.Ltmp41                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x1cf:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	12                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	51                              # DW_AT_decl_line
	.word	634                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x1db:0x12 DW_TAG_lexical_block
	.byte	22                              # DW_AT_low_pc
	.word	.Ltmp44-.Ltmp43                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x1e1:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	72
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	53                              # DW_AT_decl_line
	.word	634                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	10                              # Abbrev [10] 0x1ed:0x26 DW_TAG_lexical_block
	.byte	23                              # DW_AT_low_pc
	.word	.Ltmp55-.Ltmp45                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x1f3:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\270\177"
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.word	659                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x1ff:0x13 DW_TAG_lexical_block
	.byte	24                              # DW_AT_low_pc
	.word	.Ltmp54-.Ltmp46                 # DW_AT_high_pc
	.byte	9                               # Abbrev [9] 0x205:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\264\177"
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	55                              # DW_AT_decl_line
	.word	589                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	11                              # Abbrev [11] 0x214:0xf DW_TAG_subprogram
	.byte	25                              # DW_AT_low_pc
	.word	.Lfunc_end3-.Lfunc_begin3       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	11                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	92                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	228                             # DW_AT_type
                                        # DW_AT_external
	.byte	3                               # Abbrev [3] 0x223:0xc DW_TAG_array_type
	.word	559                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x228:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	12                              # Abbrev [12] 0x22f:0x5 DW_TAG_volatile_type
	.word	564                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x234:0x9 DW_TAG_typedef
	.word	573                             # DW_AT_type
	.byte	14                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.half	270                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x23d:0x4 DW_TAG_base_type
	.byte	13                              # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x241:0xc DW_TAG_array_type
	.word	564                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x246:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x24d:0x4 DW_TAG_base_type
	.byte	19                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x251:0xc DW_TAG_array_type
	.word	605                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x256:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	12                              # Abbrev [12] 0x25d:0x5 DW_TAG_volatile_type
	.word	610                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x262:0x8 DW_TAG_typedef
	.word	618                             # DW_AT_type
	.byte	21                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	247                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x26a:0x4 DW_TAG_base_type
	.byte	20                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	2                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x26e:0xc DW_TAG_array_type
	.word	610                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x273:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	3                               # Abbrev [3] 0x27a:0xc DW_TAG_array_type
	.word	646                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x27f:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	12                              # Abbrev [12] 0x286:0x5 DW_TAG_volatile_type
	.word	651                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x28b:0x8 DW_TAG_typedef
	.word	589                             # DW_AT_type
	.byte	22                              # DW_AT_name
	.byte	3                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	3                               # Abbrev [3] 0x293:0xc DW_TAG_array_type
	.word	651                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x298:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	96                              # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vsux.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=215
.Linfo_string3:
	.asciz	"char"                          # string offset=267
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=272
.Linfo_string5:
	.asciz	"num_failed"                    # string offset=292
.Linfo_string6:
	.asciz	"int"                           # string offset=303
.Linfo_string7:
	.asciz	"test_case"                     # string offset=307
.Linfo_string8:
	.asciz	"TEST_CASE1"                    # string offset=317
.Linfo_string9:
	.asciz	"TEST_CASE3"                    # string offset=328
.Linfo_string10:
	.asciz	"TEST_CASE5"                    # string offset=339
.Linfo_string11:
	.asciz	"main"                          # string offset=350
.Linfo_string12:
	.asciz	"Vv2"                           # string offset=355
.Linfo_string13:
	.asciz	"unsigned char"                 # string offset=359
.Linfo_string14:
	.asciz	"uint8_t"                       # string offset=373
.Linfo_string15:
	.asciz	"OUP"                           # string offset=381
.Linfo_string16:
	.asciz	"Vv1"                           # string offset=385
.Linfo_string17:
	.asciz	"vact"                          # string offset=389
.Linfo_string18:
	.asciz	"i"                             # string offset=394
.Linfo_string19:
	.asciz	"unsigned int"                  # string offset=396
.Linfo_string20:
	.asciz	"unsigned short"                # string offset=409
.Linfo_string21:
	.asciz	"uint16_t"                      # string offset=424
.Linfo_string22:
	.asciz	"uint32_t"                      # string offset=433
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L.str.7
	.word	.L.str.8
	.word	.L_MergedGlobals
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Ltmp8
	.word	.Lfunc_begin1
	.word	.Ltmp22
	.word	.Ltmp24
	.word	.Ltmp26
	.word	.Ltmp27
	.word	.Lfunc_begin2
	.word	.Ltmp41
	.word	.Ltmp43
	.word	.Ltmp45
	.word	.Ltmp46
	.word	.Lfunc_begin3
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
