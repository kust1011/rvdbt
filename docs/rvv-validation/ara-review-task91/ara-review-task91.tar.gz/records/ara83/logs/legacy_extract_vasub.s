	.attribute	4, 16
	.attribute	5, "rv32i2p1_m2p0_a2p1_f2p2_d2p2_zicsr2p0_zifencei2p0_zmmul1p0_zaamo1p0_zalrsc1p0"
	.file	"legacy_extract_vasub.c"
                                        # Start of file scope inline assembly
.option arch, +v
.option norvc

                                        # End of file scope inline assembly
	.file	0 "/home/user/research/materials/rvdbt-review-20261010" "/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c" md5 0x6d3e297022df2e63977805a3672d084c
	.file	1 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c" md5 0x6d3e297022df2e63977805a3672d084c
	.file	2 "/usr/lib/llvm-20/lib/clang/20/include" "stdint.h" md5 0xcd0b4737a870b7e85bf9cf24813fb26c
	.file	3 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/upstream/dataset.h" md5 0x6e87c523f491ba527fcaa8da037d753f
	.file	4 "/home/user/research/materials" "thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/vector_macros.h" md5 0x6c3abc442927920f23bf6bda6c68847c
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.text
	.globl	TEST_CASE1                      # -- Begin function TEST_CASE1
	.p2align	2
	.type	TEST_CASE1,@function
TEST_CASE1:                             # @TEST_CASE1
.Lfunc_begin0:
	.loc	1 10 0                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:10:0
	.cfi_sections .debug_frame
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -64
	.cfi_def_cfa_offset 64
	sw	ra, 60(sp)                      # 4-byte Folded Spill
	sw	s0, 56(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 64
	.cfi_def_cfa s0, 0
.Ltmp0:
	.loc	1 11 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:11:3
	j	.LBB0_1
.LBB0_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:0:3
	li	a0, 4
.Ltmp1:
	.loc	1 11 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:11:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 11
	li	a1, 4
	call	ara_trace_vset
	j	.LBB0_2
.Ltmp2:
.LBB0_2:
	.loc	1 12 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:12:3
	j	.LBB0_3
.LBB0_3:
.Ltmp3:
	.loc	1 12 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:12:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv1)
	lw	a1, %lo(.L__const.TEST_CASE1.Vv1)(a0)
	sw	a1, -24(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.Vv1)
	lw	a1, 12(a0)
	sw	a1, -12(s0)
	lw	a1, 8(a0)
	sw	a1, -16(s0)
	lw	a0, 4(a0)
	sw	a0, -20(s0)
	addi	a0, s0, -24
	#APP
	vle32.v v1, (a0)  

	#NO_APP
	j	.LBB0_4
.Ltmp4:
.LBB0_4:
	.loc	1 13 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:13:3
	j	.LBB0_5
.LBB0_5:
.Ltmp5:
	.loc	1 13 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:13:3
	lui	a0, %hi(.L__const.TEST_CASE1.Vv2)
	lw	a1, %lo(.L__const.TEST_CASE1.Vv2)(a0)
	sw	a1, -40(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE1.Vv2)
	lw	a1, 12(a0)
	sw	a1, -28(s0)
	lw	a1, 8(a0)
	sw	a1, -32(s0)
	lw	a0, 4(a0)
	sw	a0, -36(s0)
	addi	a0, s0, -40
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB0_6
.Ltmp6:
.LBB0_6:
	.loc	1 14 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:14:3
	#APP
	vasub.vv v3, v1, v2
	#NO_APP
.Ltmp7:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	j	.LBB0_7
.LBB0_7:
.Ltmp8:
	.loc	1 15 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lui	a0, %hi(Ri32)
	addi	a0, a0, %lo(Ri32)
	sw	a0, -44(s0)
	lw	a0, -44(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -44(s0)
	j	.LBB0_8
.Ltmp9:
.LBB0_8:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:0:3
	li	a0, 8
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	sw	a0, -48(s0)
	li	a0, 9
	sw	a0, -52(s0)
	li	a0, 4
	sw	a0, -56(s0)
	li	a0, 3
	sw	a0, -60(s0)
	li	a0, 1
	li	a1, 4
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 1
	call	printf_
.Ltmp10:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	sw	zero, -64(s0)
	j	.LBB0_9
.LBB0_9:                                # =>This Inner Loop Header: Depth=1
.Ltmp11:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lw	a0, -64(s0)
	li	a1, 3
.Ltmp12:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	bltu	a1, a0, .LBB0_14
	j	.LBB0_10
.LBB0_10:                               #   in Loop: Header=BB0_9 Depth=1
.Ltmp13:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lw	a1, -64(s0)
	li	a0, 1
	call	ara_compare_step
.Ltmp14:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lw	a0, -64(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ri32)
	addi	a1, a1, %lo(Ri32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -64(s0)
	slli	a1, a1, 2
	addi	a2, s0, -60
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB0_12
	j	.LBB0_11
.LBB0_11:
.Ltmp15:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lw	a1, -64(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ri32)
	addi	a2, a2, %lo(Ri32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -64(s0)
	slli	a0, a0, 2
	addi	a3, s0, -60
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB0_15
.Ltmp16:
.LBB0_12:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	j	.LBB0_13
.Ltmp17:
.LBB0_13:                               #   in Loop: Header=BB0_9 Depth=1
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lw	a0, -64(s0)
	addi	a0, a0, 1
	sw	a0, -64(s0)
	j	.LBB0_9
.Ltmp18:
.LBB0_14:
	.loc	1 15 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:15:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 1
	call	ara_assert_end
.Ltmp19:
	.loc	1 16 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:16:1
	j	.LBB0_15
.LBB0_15:
	.cfi_def_cfa sp, 64
	.loc	1 16 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:16:1
	lw	ra, 60(sp)                      # 4-byte Folded Reload
	lw	s0, 56(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 64
	.cfi_def_cfa_offset 0
	ret
.Ltmp20:
.Lfunc_end0:
	.size	TEST_CASE1, .Lfunc_end0-TEST_CASE1
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	TEST_CASE2                      # -- Begin function TEST_CASE2
	.p2align	2
	.type	TEST_CASE2,@function
TEST_CASE2:                             # @TEST_CASE2
.Lfunc_begin1:
	.loc	1 18 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:18:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -96
	.cfi_def_cfa_offset 96
	sw	ra, 92(sp)                      # 4-byte Folded Spill
	sw	s0, 88(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	addi	s0, sp, 96
	.cfi_def_cfa s0, 0
.Ltmp21:
	.loc	1 19 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:19:3
	j	.LBB1_1
.LBB1_1:
	.loc	1 0 3 is_stmt 0                 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:0:3
	li	a0, 4
.Ltmp22:
	.loc	1 19 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:19:3
	#APP
	vsetvli t0, a0,e32,m1, ta, ma 

	#NO_APP
	li	a0, 19
	li	a1, 4
	call	ara_trace_vset
	j	.LBB1_2
.Ltmp23:
.LBB1_2:
	.loc	1 20 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:20:3
	j	.LBB1_3
.LBB1_3:
.Ltmp24:
	.loc	1 20 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:20:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv1)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv1)(a0)
	sw	a1, -24(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv1)
	lw	a1, 12(a0)
	sw	a1, -12(s0)
	lw	a1, 8(a0)
	sw	a1, -16(s0)
	lw	a0, 4(a0)
	sw	a0, -20(s0)
	addi	a0, s0, -24
	#APP
	vle32.v v1, (a0)  

	#NO_APP
	j	.LBB1_4
.Ltmp25:
.LBB1_4:
	.loc	1 21 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:21:3
	j	.LBB1_5
.LBB1_5:
.Ltmp26:
	.loc	1 21 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:21:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv2)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv2)(a0)
	sw	a1, -40(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv2)
	lw	a1, 12(a0)
	sw	a1, -28(s0)
	lw	a1, 8(a0)
	sw	a1, -32(s0)
	lw	a0, 4(a0)
	sw	a0, -36(s0)
	addi	a0, s0, -40
	#APP
	vle32.v v2, (a0)  

	#NO_APP
	j	.LBB1_6
.Ltmp27:
.LBB1_6:
	.loc	1 22 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:22:3
	j	.LBB1_7
.LBB1_7:
.Ltmp28:
	.loc	1 22 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:22:3
	lui	a0, %hi(.L__const.TEST_CASE2.Vv0)
	lw	a1, %lo(.L__const.TEST_CASE2.Vv0)(a0)
	sw	a1, -56(s0)
	addi	a0, a0, %lo(.L__const.TEST_CASE2.Vv0)
	lw	a1, 12(a0)
	sw	a1, -44(s0)
	lw	a1, 8(a0)
	sw	a1, -48(s0)
	lw	a0, 4(a0)
	sw	a0, -52(s0)
	addi	a0, s0, -56
	#APP
	vle32.v v0, (a0)  

	#NO_APP
	j	.LBB1_8
.Ltmp29:
.LBB1_8:
	.loc	1 23 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:23:3
	j	.LBB1_9
.LBB1_9:
.Ltmp30:
	.loc	1 23 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:23:3
	#APP
	csrr a0, vtype
	#NO_APP
	sw	a0, -60(s0)
	#APP
	csrr a0, vl
	#NO_APP
	sw	a0, -64(s0)
	lw	a0, -60(s0)
	#APP
	vsetvl a0, zero, a0
	#NO_APP
	sw	a0, -68(s0)
	#APP
	vmv.v.i v3, 0
	#NO_APP
	lw	a0, -64(s0)
	lw	a1, -60(s0)
	#APP
	vsetvl zero, a0, a1
	#NO_APP
	j	.LBB1_10
.Ltmp31:
.LBB1_10:
	.loc	1 24 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:24:3
	#APP
	vasub.vv v3, v1, v2, v0.t
	#NO_APP
.Ltmp32:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	j	.LBB1_11
.LBB1_11:
.Ltmp33:
	.loc	1 25 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lui	a0, %hi(Ri32)
	addi	a0, a0, %lo(Ri32)
	sw	a0, -72(s0)
	lw	a0, -72(s0)
	#APP
	vse32.v v3, (a0)

	#NO_APP
	sw	a0, -72(s0)
	j	.LBB1_12
.Ltmp34:
.LBB1_12:
	.loc	1 0 3                           # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:0:3
	li	a0, 12
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	sw	a0, -76(s0)
	sw	zero, -80(s0)
	li	a0, 4
	sw	a0, -84(s0)
	sw	zero, -88(s0)
	li	a0, 2
	li	a1, 4
	li	a2, 4
	call	ara_assert_begin
	lui	a0, %hi(.L.str)
	addi	a0, a0, %lo(.L.str)
	li	a1, 2
	call	printf_
.Ltmp35:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	sw	zero, -92(s0)
	j	.LBB1_13
.LBB1_13:                               # =>This Inner Loop Header: Depth=1
.Ltmp36:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lw	a0, -92(s0)
	li	a1, 3
.Ltmp37:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	bltu	a1, a0, .LBB1_18
	j	.LBB1_14
.LBB1_14:                               #   in Loop: Header=BB1_13 Depth=1
.Ltmp38:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lw	a1, -92(s0)
	li	a0, 2
	call	ara_compare_step
.Ltmp39:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lw	a0, -92(s0)
	slli	a0, a0, 2
	lui	a1, %hi(Ri32)
	addi	a1, a1, %lo(Ri32)
	add	a0, a1, a0
	lw	a0, 0(a0)
	lw	a1, -92(s0)
	slli	a1, a1, 2
	addi	a2, s0, -88
	add	a1, a2, a1
	lw	a1, 0(a1)
	beq	a0, a1, .LBB1_16
	j	.LBB1_15
.LBB1_15:
.Ltmp40:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lw	a1, -92(s0)
	slli	a0, a1, 2
	lui	a2, %hi(Ri32)
	addi	a2, a2, %lo(Ri32)
	add	a0, a2, a0
	lw	a2, 0(a0)
	lw	a0, -92(s0)
	slli	a0, a0, 2
	addi	a3, s0, -88
	add	a0, a3, a0
	lw	a3, 0(a0)
	lui	a0, %hi(.L.str.1)
	addi	a0, a0, %lo(.L.str.1)
	call	printf_
	lui	a0, %hi(.L_MergedGlobals)
	lw	a1, %lo(.L_MergedGlobals)(a0)
	addi	a1, a1, 1
	sw	a1, %lo(.L_MergedGlobals)(a0)
	j	.LBB1_19
.Ltmp41:
.LBB1_16:                               #   in Loop: Header=BB1_13 Depth=1
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	j	.LBB1_17
.Ltmp42:
.LBB1_17:                               #   in Loop: Header=BB1_13 Depth=1
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lw	a0, -92(s0)
	addi	a0, a0, 1
	sw	a0, -92(s0)
	j	.LBB1_13
.Ltmp43:
.LBB1_18:
	.loc	1 25 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:25:3
	lui	a0, %hi(.L.str.2)
	addi	a0, a0, %lo(.L.str.2)
	call	printf_
	li	a0, 2
	call	ara_assert_end
.Ltmp44:
	.loc	1 26 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:26:1
	j	.LBB1_19
.LBB1_19:
	.cfi_def_cfa sp, 96
	.loc	1 26 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:26:1
	lw	ra, 92(sp)                      # 4-byte Folded Reload
	lw	s0, 88(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	addi	sp, sp, 96
	.cfi_def_cfa_offset 0
	ret
.Ltmp45:
.Lfunc_end1:
	.size	TEST_CASE2, .Lfunc_end1-TEST_CASE2
	.cfi_endproc
                                        # -- End function
	.option	pop
	.option	push
	.option	arch, +a, +d, +f, +m, +zaamo, +zalrsc, +zicsr, +zifencei, +zmmul
	.globl	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
.Lfunc_begin2:
	.loc	1 46 0 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:46:0
	.cfi_startproc
# %bb.0:
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sw	ra, 28(sp)                      # 4-byte Folded Spill
	sw	s0, 24(sp)                      # 4-byte Folded Spill
	sw	s1, 20(sp)                      # 4-byte Folded Spill
	sw	s2, 16(sp)                      # 4-byte Folded Spill
	.cfi_offset ra, -4
	.cfi_offset s0, -8
	.cfi_offset s1, -12
	.cfi_offset s2, -16
	addi	s0, sp, 32
	.cfi_def_cfa s0, 0
.Ltmp46:
	.loc	1 47 3 prologue_end             # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:47:3
	lui	s2, %hi(.L_MergedGlobals)
	sw	zero, %lo(.L_MergedGlobals)(s2)
	addi	a0, s2, %lo(.L_MergedGlobals)
	sw	zero, 4(a0)
	.loc	1 49 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:49:3
	lui	s1, %hi(.L.str.3)
	addi	s1, s1, %lo(.L.str.3)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 49 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:49:33
	call	TEST_CASE1
	.loc	1 49 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:49:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 49 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:49:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 50 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:50:3
	lui	s1, %hi(.L.str.4)
	addi	s1, s1, %lo(.L.str.4)
	mv	a0, s1
	call	ara_case_begin
	.loc	1 50 33 is_stmt 0               # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:50:33
	call	TEST_CASE2
	.loc	1 50 73                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:50:73
	lw	a1, %lo(.L_MergedGlobals)(s2)
	.loc	1 50 47                         # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:50:47
	mv	a0, s1
	call	ara_case_end
	.loc	1 53 3 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:53:3
	j	.LBB2_1
.LBB2_1:
.Ltmp47:
	.loc	1 53 3 is_stmt 0                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:53:3
	lui	a0, %hi(.L_MergedGlobals)
	lw	a0, %lo(.L_MergedGlobals)(a0)
	blez	a0, .LBB2_3
	j	.LBB2_2
.LBB2_2:
.Ltmp48:
	.loc	1 53 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:53:3
	lui	s1, %hi(.L_MergedGlobals)
	lw	a2, %lo(.L_MergedGlobals)(s1)
	lui	a0, %hi(.L.str.5)
	addi	a0, a0, %lo(.L.str.5)
	lui	a1, %hi(.L.str.6)
	addi	a1, a1, %lo(.L.str.6)
	call	printf_
	lw	a0, %lo(.L_MergedGlobals)(s1)
	sw	a0, -20(s0)
	j	.LBB2_4
.Ltmp49:
.LBB2_3:
	.loc	1 53 3                          # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:53:3
	lui	a0, %hi(.L.str.7)
	addi	a0, a0, %lo(.L.str.7)
	lui	a1, %hi(.L.str.6)
	addi	a1, a1, %lo(.L.str.6)
	call	printf_
	sw	zero, -20(s0)
	j	.LBB2_4
.Ltmp50:
.LBB2_4:
	.loc	1 54 1 is_stmt 1                # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:54:1
	lw	a0, -20(s0)
	.cfi_def_cfa sp, 32
	.loc	1 54 1 epilogue_begin is_stmt 0 # thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c:54:1
	lw	ra, 28(sp)                      # 4-byte Folded Reload
	lw	s0, 24(sp)                      # 4-byte Folded Reload
	lw	s1, 20(sp)                      # 4-byte Folded Reload
	lw	s2, 16(sp)                      # 4-byte Folded Reload
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Ltmp51:
.Lfunc_end2:
	.size	main, .Lfunc_end2-main
	.cfi_endproc
                                        # -- End function
	.option	pop
	.type	.L__const.TEST_CASE1.Vv1,@object # @__const.TEST_CASE1.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv1:
	.word	5                               # 0x5
	.word	10                              # 0xa
	.word	15                              # 0xf
	.word	20                              # 0x14
	.size	.L__const.TEST_CASE1.Vv1, 16

	.type	.L__const.TEST_CASE1.Vv2,@object # @__const.TEST_CASE1.Vv2
	.p2align	2, 0x0
.L__const.TEST_CASE1.Vv2:
	.word	4294967295                      # 0xffffffff
	.word	2                               # 0x2
	.word	4294967293                      # 0xfffffffd
	.word	4                               # 0x4
	.size	.L__const.TEST_CASE1.Vv2, 16

	.type	Ri32,@object                    # @Ri32
	.local	Ri32
	.comm	Ri32,4096,128
	.type	.L__const.TEST_CASE1.vact,@object # @__const.TEST_CASE1.vact
	.p2align	2, 0x0
.L__const.TEST_CASE1.vact:
	.word	3                               # 0x3
	.word	4                               # 0x4
	.word	9                               # 0x9
	.word	8                               # 0x8
	.size	.L__const.TEST_CASE1.vact, 16

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Checking the results of the test case %d:\n"
	.size	.L.str, 43

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Index %d FAILED. Got %d, expected %d.\n"
	.size	.L.str.1, 39

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"PASSED.\n"
	.size	.L.str.2, 9

	.type	.L__const.TEST_CASE2.Vv1,@object # @__const.TEST_CASE2.Vv1
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv1:
	.word	5                               # 0x5
	.word	10                              # 0xa
	.word	15                              # 0xf
	.word	20                              # 0x14
	.size	.L__const.TEST_CASE2.Vv1, 16

	.type	.L__const.TEST_CASE2.Vv2,@object # @__const.TEST_CASE2.Vv2
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv2:
	.word	1                               # 0x1
	.word	2                               # 0x2
	.word	3                               # 0x3
	.word	4294967292                      # 0xfffffffc
	.size	.L__const.TEST_CASE2.Vv2, 16

	.type	.L__const.TEST_CASE2.Vv0,@object # @__const.TEST_CASE2.Vv0
	.p2align	2, 0x0
.L__const.TEST_CASE2.Vv0:
	.word	10                              # 0xa
	.word	0                               # 0x0
	.word	0                               # 0x0
	.word	0                               # 0x0
	.size	.L__const.TEST_CASE2.Vv0, 16

	.type	.L__const.TEST_CASE2.vact,@object # @__const.TEST_CASE2.vact
	.p2align	2, 0x0
.L__const.TEST_CASE2.vact:
	.word	0                               # 0x0
	.word	4                               # 0x4
	.word	0                               # 0x0
	.word	12                              # 0xc
	.size	.L__const.TEST_CASE2.vact, 16

	.type	.L.str.3,@object                # @.str.3
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.3:
	.asciz	"TEST_CASE1"
	.size	.L.str.3, 11

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"TEST_CASE2"
	.size	.L.str.4, 11

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"ERROR: %s failed %d tests!\n"
	.size	.L.str.5, 28

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c"
	.size	.L.str.6, 130

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"PASSED: %s!\n"
	.size	.L.str.7, 13

	.type	.L_MergedGlobals,@object        # @_MergedGlobals
	.local	.L_MergedGlobals
	.comm	.L_MergedGlobals,8,4
	.globl	num_failed
.set num_failed, .L_MergedGlobals
	.size	num_failed, 4
	.globl	test_case
.set test_case, .L_MergedGlobals+4
	.size	test_case, 4
	.section	.debug_abbrev,"",@progbits
	.byte	1                               # Abbreviation Code
	.byte	17                              # DW_TAG_compile_unit
	.byte	1                               # DW_CHILDREN_yes
	.byte	37                              # DW_AT_producer
	.byte	37                              # DW_FORM_strx1
	.byte	19                              # DW_AT_language
	.byte	5                               # DW_FORM_data2
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	114                             # DW_AT_str_offsets_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	16                              # DW_AT_stmt_list
	.byte	23                              # DW_FORM_sec_offset
	.byte	27                              # DW_AT_comp_dir
	.byte	37                              # DW_FORM_strx1
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	115                             # DW_AT_addr_base
	.byte	23                              # DW_FORM_sec_offset
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	2                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	3                               # Abbreviation Code
	.byte	1                               # DW_TAG_array_type
	.byte	1                               # DW_CHILDREN_yes
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	4                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	5                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	6                               # Abbreviation Code
	.byte	36                              # DW_TAG_base_type
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	11                              # DW_AT_byte_size
	.byte	11                              # DW_FORM_data1
	.byte	62                              # DW_AT_encoding
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	7                               # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.ascii	"\210\001"                      # DW_AT_alignment
	.byte	15                              # DW_FORM_udata
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	8                               # Abbreviation Code
	.byte	33                              # DW_TAG_subrange_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	55                              # DW_AT_count
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	9                               # Abbreviation Code
	.byte	53                              # DW_TAG_volatile_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	10                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	11                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	12                              # Abbreviation Code
	.byte	15                              # DW_TAG_pointer_type
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	13                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	14                              # Abbreviation Code
	.byte	11                              # DW_TAG_lexical_block
	.byte	1                               # DW_CHILDREN_yes
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	15                              # Abbreviation Code
	.byte	52                              # DW_TAG_variable
	.byte	0                               # DW_CHILDREN_no
	.byte	2                               # DW_AT_location
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	16                              # Abbreviation Code
	.byte	46                              # DW_TAG_subprogram
	.byte	0                               # DW_CHILDREN_no
	.byte	17                              # DW_AT_low_pc
	.byte	27                              # DW_FORM_addrx
	.byte	18                              # DW_AT_high_pc
	.byte	6                               # DW_FORM_data4
	.byte	64                              # DW_AT_frame_base
	.byte	24                              # DW_FORM_exprloc
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	11                              # DW_FORM_data1
	.byte	39                              # DW_AT_prototyped
	.byte	25                              # DW_FORM_flag_present
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	63                              # DW_AT_external
	.byte	25                              # DW_FORM_flag_present
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	17                              # Abbreviation Code
	.byte	22                              # DW_TAG_typedef
	.byte	0                               # DW_CHILDREN_no
	.byte	73                              # DW_AT_type
	.byte	19                              # DW_FORM_ref4
	.byte	3                               # DW_AT_name
	.byte	37                              # DW_FORM_strx1
	.byte	58                              # DW_AT_decl_file
	.byte	11                              # DW_FORM_data1
	.byte	59                              # DW_AT_decl_line
	.byte	5                               # DW_FORM_data2
	.byte	0                               # EOM(1)
	.byte	0                               # EOM(2)
	.byte	0                               # EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0 # Length of Unit
.Ldebug_info_start0:
	.half	5                               # DWARF version number
	.byte	1                               # DWARF Unit Type
	.byte	4                               # Address Size (in bytes)
	.word	.debug_abbrev                   # Offset Into Abbrev. Section
	.byte	1                               # Abbrev [1] 0xc:0x257 DW_TAG_compile_unit
	.byte	0                               # DW_AT_producer
	.half	29                              # DW_AT_language
	.byte	1                               # DW_AT_name
	.word	.Lstr_offsets_base0             # DW_AT_str_offsets_base
	.word	.Lline_table_start0             # DW_AT_stmt_list
	.byte	2                               # DW_AT_comp_dir
	.byte	10                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin0       # DW_AT_high_pc
	.word	.Laddr_table_base0              # DW_AT_addr_base
	.byte	2                               # Abbrev [2] 0x23:0xa DW_TAG_variable
	.word	45                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	0
	.byte	3                               # Abbrev [3] 0x2d:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x32:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	43                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	5                               # Abbrev [5] 0x39:0x4 DW_TAG_base_type
	.byte	3                               # DW_AT_name
	.byte	8                               # DW_AT_encoding
	.byte	1                               # DW_AT_byte_size
	.byte	6                               # Abbrev [6] 0x3d:0x4 DW_TAG_base_type
	.byte	4                               # DW_AT_name
	.byte	8                               # DW_AT_byte_size
	.byte	7                               # DW_AT_encoding
	.byte	2                               # Abbrev [2] 0x41:0xa DW_TAG_variable
	.word	75                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	1
	.byte	3                               # Abbrev [3] 0x4b:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x50:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	39                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x57:0xa DW_TAG_variable
	.word	97                              # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	2
	.byte	3                               # Abbrev [3] 0x61:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x66:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	9                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x6d:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	49                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	3
	.byte	3                               # Abbrev [3] 0x77:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x7c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	11                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0x83:0xa DW_TAG_variable
	.word	119                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	50                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	4
	.byte	2                               # Abbrev [2] 0x8d:0xa DW_TAG_variable
	.word	151                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	53                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	5
	.byte	3                               # Abbrev [3] 0x97:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0x9c:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	28                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xa3:0xa DW_TAG_variable
	.word	173                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	53                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	6
	.byte	3                               # Abbrev [3] 0xad:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xb2:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	130                             # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	2                               # Abbrev [2] 0xb9:0xa DW_TAG_variable
	.word	195                             # DW_AT_type
	.byte	1                               # DW_AT_decl_file
	.byte	53                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	7
	.byte	3                               # Abbrev [3] 0xc3:0xc DW_TAG_array_type
	.word	57                              # DW_AT_type
	.byte	4                               # Abbrev [4] 0xc8:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	13                              # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	7                               # Abbrev [7] 0xcf:0xd DW_TAG_variable
	.byte	5                               # DW_AT_name
	.word	220                             # DW_AT_type
	.byte	3                               # DW_AT_decl_file
	.byte	30                              # DW_AT_decl_line
	.ascii	"\200\001"                      # DW_AT_alignment
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	8
	.byte	3                               # Abbrev [3] 0xdc:0xd DW_TAG_array_type
	.word	233                             # DW_AT_type
	.byte	8                               # Abbrev [8] 0xe1:0x7 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.half	1024                            # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0xe9:0x5 DW_TAG_volatile_type
	.word	238                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0xee:0x8 DW_TAG_typedef
	.word	246                             # DW_AT_type
	.byte	7                               # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	197                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0xf6:0x4 DW_TAG_base_type
	.byte	6                               # DW_AT_name
	.byte	5                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	11                              # Abbrev [11] 0xfa:0xb DW_TAG_variable
	.byte	8                               # DW_AT_name
	.word	246                             # DW_AT_type
                                        # DW_AT_external
	.byte	4                               # DW_AT_decl_file
	.byte	36                              # DW_AT_decl_line
	.byte	2                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	11                              # Abbrev [11] 0x105:0xd DW_TAG_variable
	.byte	9                               # DW_AT_name
	.word	246                             # DW_AT_type
                                        # DW_AT_external
	.byte	4                               # DW_AT_decl_file
	.byte	38                              # DW_AT_decl_line
	.byte	4                               # DW_AT_location
	.byte	161
	.byte	9
	.byte	35
	.byte	4
	.byte	12                              # Abbrev [12] 0x112:0x5 DW_TAG_pointer_type
	.word	238                             # DW_AT_type
	.byte	13                              # Abbrev [13] 0x117:0x66 DW_TAG_subprogram
	.byte	10                              # DW_AT_low_pc
	.word	.Lfunc_end0-.Lfunc_begin0       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	10                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	10                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x122:0x12 DW_TAG_lexical_block
	.byte	11                              # DW_AT_low_pc
	.word	.Ltmp4-.Ltmp3                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x128:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	12                              # DW_AT_decl_line
	.word	560                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x134:0x12 DW_TAG_lexical_block
	.byte	12                              # DW_AT_low_pc
	.word	.Ltmp6-.Ltmp5                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x13a:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	13                              # DW_AT_decl_line
	.word	560                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x146:0x36 DW_TAG_lexical_block
	.byte	13                              # DW_AT_low_pc
	.word	.Ltmp19-.Ltmp7                  # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x14c:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	589                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x157:0x12 DW_TAG_lexical_block
	.byte	14                              # DW_AT_low_pc
	.word	.Ltmp9-.Ltmp8                   # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x15d:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	84
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	274                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x169:0x12 DW_TAG_lexical_block
	.byte	15                              # DW_AT_low_pc
	.word	.Ltmp18-.Ltmp10                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x16f:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	19                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	15                              # DW_AT_decl_line
	.word	585                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	13                              # Abbrev [13] 0x17d:0xa4 DW_TAG_subprogram
	.byte	16                              # DW_AT_low_pc
	.word	.Lfunc_end1-.Lfunc_begin1       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	11                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	18                              # DW_AT_decl_line
                                        # DW_AT_prototyped
                                        # DW_AT_external
	.byte	14                              # Abbrev [14] 0x188:0x12 DW_TAG_lexical_block
	.byte	17                              # DW_AT_low_pc
	.word	.Ltmp25-.Ltmp24                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x18e:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	104
	.byte	13                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	20                              # DW_AT_decl_line
	.word	560                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x19a:0x12 DW_TAG_lexical_block
	.byte	18                              # DW_AT_low_pc
	.word	.Ltmp27-.Ltmp26                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1a0:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	88
	.byte	16                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	21                              # DW_AT_decl_line
	.word	560                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1ac:0x12 DW_TAG_lexical_block
	.byte	19                              # DW_AT_low_pc
	.word	.Ltmp29-.Ltmp28                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1b2:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	72
	.byte	20                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	22                              # DW_AT_decl_line
	.word	560                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1be:0x29 DW_TAG_lexical_block
	.byte	20                              # DW_AT_low_pc
	.word	.Ltmp31-.Ltmp30                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1c4:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	68
	.byte	21                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	23                              # DW_AT_decl_line
	.word	601                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x1cf:0xb DW_TAG_variable
	.byte	2                               # DW_AT_location
	.byte	145
	.byte	64
	.byte	23                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	23                              # DW_AT_decl_line
	.word	601                             # DW_AT_type
	.byte	15                              # Abbrev [15] 0x1da:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\274\177"
	.byte	24                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	23                              # DW_AT_decl_line
	.word	601                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x1e7:0x39 DW_TAG_lexical_block
	.byte	21                              # DW_AT_low_pc
	.word	.Ltmp44-.Ltmp32                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1ed:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\250\177"
	.byte	18                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	589                             # DW_AT_type
	.byte	14                              # Abbrev [14] 0x1f9:0x13 DW_TAG_lexical_block
	.byte	22                              # DW_AT_low_pc
	.word	.Ltmp34-.Ltmp33                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x1ff:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\270\177"
	.byte	17                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	274                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	14                              # Abbrev [14] 0x20c:0x13 DW_TAG_lexical_block
	.byte	23                              # DW_AT_low_pc
	.word	.Ltmp43-.Ltmp35                 # DW_AT_high_pc
	.byte	15                              # Abbrev [15] 0x212:0xc DW_TAG_variable
	.byte	3                               # DW_AT_location
	.byte	145
	.ascii	"\244\177"
	.byte	19                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	25                              # DW_AT_decl_line
	.word	585                             # DW_AT_type
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	0                               # End Of Children Mark
	.byte	16                              # Abbrev [16] 0x221:0xf DW_TAG_subprogram
	.byte	24                              # DW_AT_low_pc
	.word	.Lfunc_end2-.Lfunc_begin2       # DW_AT_high_pc
	.byte	1                               # DW_AT_frame_base
	.byte	88
	.byte	12                              # DW_AT_name
	.byte	1                               # DW_AT_decl_file
	.byte	46                              # DW_AT_decl_line
                                        # DW_AT_prototyped
	.word	246                             # DW_AT_type
                                        # DW_AT_external
	.byte	3                               # Abbrev [3] 0x230:0xc DW_TAG_array_type
	.word	572                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x235:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	9                               # Abbrev [9] 0x23c:0x5 DW_TAG_volatile_type
	.word	577                             # DW_AT_type
	.byte	10                              # Abbrev [10] 0x241:0x8 DW_TAG_typedef
	.word	585                             # DW_AT_type
	.byte	15                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.byte	202                             # DW_AT_decl_line
	.byte	5                               # Abbrev [5] 0x249:0x4 DW_TAG_base_type
	.byte	14                              # DW_AT_name
	.byte	7                               # DW_AT_encoding
	.byte	4                               # DW_AT_byte_size
	.byte	3                               # Abbrev [3] 0x24d:0xc DW_TAG_array_type
	.word	238                             # DW_AT_type
	.byte	4                               # Abbrev [4] 0x252:0x6 DW_TAG_subrange_type
	.word	61                              # DW_AT_type
	.byte	4                               # DW_AT_count
	.byte	0                               # End Of Children Mark
	.byte	17                              # Abbrev [17] 0x259:0x9 DW_TAG_typedef
	.word	585                             # DW_AT_type
	.byte	22                              # DW_AT_name
	.byte	2                               # DW_AT_decl_file
	.half	302                             # DW_AT_decl_line
	.byte	0                               # End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.word	104                             # Length of String Offsets Set
	.half	5
	.half	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)" # string offset=0
.Linfo_string1:
	.asciz	"/home/user/research/materials/thesis_rvv_20260921/artifacts/rvv_validation_delivery_20261009/ara83/adapter/legacy_extract_vasub.c" # string offset=86
.Linfo_string2:
	.asciz	"/home/user/research/materials/rvdbt-review-20261010" # string offset=216
.Linfo_string3:
	.asciz	"char"                          # string offset=268
.Linfo_string4:
	.asciz	"__ARRAY_SIZE_TYPE__"           # string offset=273
.Linfo_string5:
	.asciz	"Ri32"                          # string offset=293
.Linfo_string6:
	.asciz	"int"                           # string offset=298
.Linfo_string7:
	.asciz	"int32_t"                       # string offset=302
.Linfo_string8:
	.asciz	"num_failed"                    # string offset=310
.Linfo_string9:
	.asciz	"test_case"                     # string offset=321
.Linfo_string10:
	.asciz	"TEST_CASE1"                    # string offset=331
.Linfo_string11:
	.asciz	"TEST_CASE2"                    # string offset=342
.Linfo_string12:
	.asciz	"main"                          # string offset=353
.Linfo_string13:
	.asciz	"Vv1"                           # string offset=358
.Linfo_string14:
	.asciz	"unsigned int"                  # string offset=362
.Linfo_string15:
	.asciz	"uint32_t"                      # string offset=375
.Linfo_string16:
	.asciz	"Vv2"                           # string offset=384
.Linfo_string17:
	.asciz	"Ri32_t"                        # string offset=388
.Linfo_string18:
	.asciz	"vact"                          # string offset=395
.Linfo_string19:
	.asciz	"i"                             # string offset=400
.Linfo_string20:
	.asciz	"Vv0"                           # string offset=402
.Linfo_string21:
	.asciz	"vtype"                         # string offset=406
.Linfo_string22:
	.asciz	"uintptr_t"                     # string offset=412
.Linfo_string23:
	.asciz	"vl"                            # string offset=422
.Linfo_string24:
	.asciz	"vlmax"                         # string offset=425
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.word	.Linfo_string5
	.word	.Linfo_string6
	.word	.Linfo_string7
	.word	.Linfo_string8
	.word	.Linfo_string9
	.word	.Linfo_string10
	.word	.Linfo_string11
	.word	.Linfo_string12
	.word	.Linfo_string13
	.word	.Linfo_string14
	.word	.Linfo_string15
	.word	.Linfo_string16
	.word	.Linfo_string17
	.word	.Linfo_string18
	.word	.Linfo_string19
	.word	.Linfo_string20
	.word	.Linfo_string21
	.word	.Linfo_string22
	.word	.Linfo_string23
	.word	.Linfo_string24
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0 # Length of contribution
.Ldebug_addr_start0:
	.half	5                               # DWARF version number
	.byte	4                               # Address size
	.byte	0                               # Segment selector size
.Laddr_table_base0:
	.word	.L.str
	.word	.L.str.1
	.word	.L.str.2
	.word	.L.str.3
	.word	.L.str.4
	.word	.L.str.5
	.word	.L.str.6
	.word	.L.str.7
	.word	Ri32
	.word	.L_MergedGlobals
	.word	.Lfunc_begin0
	.word	.Ltmp3
	.word	.Ltmp5
	.word	.Ltmp7
	.word	.Ltmp8
	.word	.Ltmp10
	.word	.Lfunc_begin1
	.word	.Ltmp24
	.word	.Ltmp26
	.word	.Ltmp28
	.word	.Ltmp30
	.word	.Ltmp32
	.word	.Ltmp33
	.word	.Ltmp35
	.word	.Lfunc_begin2
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 20.1.8 (++20250708082409+6fb913d3e2ec-1~exp1~20250708202428.132)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
