import json,csv,re,sys,subprocess,hashlib,shutil,collections
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';W=R.parents[2];A=W/'artifacts/external_suite_coverage_20261007';sys.path.insert(0,str(P));from common import funcs,body,parser
j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
records=[];repo=R/'history/ara';rev='34bd3bc152421b4601a7bf3d6e8e91ffb545c99e';hp='apps/riscv-tests/isa/macros/vector/vector_macros.h'
def cmd(label,args,timeout=45):
 try:p=subprocess.run(args,capture_output=True,timeout=timeout);rc=p.returncode;o=p.stdout;e=p.stderr
 except subprocess.TimeoutExpired as x:rc=None;o=x.stdout or b'';e=x.stderr or b''
 (R/'history'/(label+'.stdout')).write_bytes(o);(R/'history'/(label+'.stderr')).write_bytes(e);records.append(dict(label=label,command=args,returncode=rc));save('HISTORY_COMMANDS.json',records);return o.decode()
cmd('pinned', ['git','-C',str(repo),'rev-parse',rev]);cmd('macro_history',['git','-C',str(repo),'log',rev,'--format=%H %s','--',hp]);cmd('legacy_definition_search',['git','-C',str(repo),'log',rev,'-S','VEC_CMP_32','--format=%H %s','--',hp]);cmd('preflatten_gitlink',['git','-C',str(repo),'ls-tree','-r','ac8cab1^','apps/riscv-tests']);cmd('preflatten_submodule',['git','-C',str(repo),'show','ac8cab1^:.gitmodules']);cmd('preflatten_access',['git','ls-remote','https://iis-git.ee.ethz.ch/ara_release/riscv-tests.git'],15)
for commit in ['34bd3bc','ac8cab1','6770aef','48953ae']:
 t=cmd('header_'+commit,['git','-C',str(repo),'show',commit+':'+hp]);(R/'history'/('vector_macros.'+commit+'.h')).write_text(t)
# Freshly reproduce original legacy failure with pre-adapter header and preserved isolated compile flags.
base=R/'baseline';base.mkdir(exist_ok=True)
for f in ['vector_macros.h','float_macros.h','user_runtime.h']:shutil.copy2(P/'adapter'/f,base/f)
cmd0=next(x['command']for x in j(R/'BUILD_COMMANDS.json')if x['step']=='legacy_extract_vasub-ir');cmd0=[x.replace(str(R/'adapter'),str(base))if x.startswith('-I')else x for x in cmd0];cmd0[cmd0.index('-emit-llvm')+1]=str(R/'upstream/vasub.c');cmd0[-1]=str(base/'vasub.ll')
p=subprocess.run(cmd0,capture_output=True);(base/'stdout').write_bytes(p.stdout);(base/'stderr').write_bytes(p.stderr);save('BASELINE_BUILD.json',dict(command=cmd0,returncode=p.returncode));assert p.returncode!=0
# All twenty ledger obligations; no canonical mutation.
rows=[x for x in csv.DictReader((A/'SUITE_RUN_MANIFEST.csv').open())if x['suite']=='Ara'and x['row_kind']=='SOURCE_CASE'and x['dut_status']=='BUILD_ERROR'];assert len(rows)==20
save('ORIGINAL_BUILD_OBLIGATIONS.json',rows)
# Explicitly examine each intact original function in the 107-form fallback.
d=j(R.parent/'ara82/FORM_DETAILS.json');cases={}
for form,entry in d.items():
 if entry['category']!='ORIGINAL_FUNCTION_PROFILE_BLOCKED':continue
 for a in entry['assertions']:
  key=(a['source_absolute'],a['function']);cases.setdefault(key,dict(source=a['source_absolute'],function=a['function'],forms=set(),original_blocker=a['blocker']))['forms'].add(form)
out=[]
for (path,fn),item in cases.items():
 s=Path(path).read_text();f=funcs(s)[fn];b=parser['clean'](body(s,f));sew=None;ops=[]
 for m in re.finditer(r'VSET\([^,]+,\s*e(\d+),[^)]*\)|(?:__asm__|asm)\s+volatile\s*\(\s*"([^"\\]+)',b):
  if m[1]:sew=int(m[1])
  else:ops.append(dict(line=s[:f['start']+m.start()].count('\n')+1,sew=sew,assembly=m[2]))
 fp16=[x for x in ops if x['sew']==16 and x['assembly'].startswith(('vf','vmf')) and not re.fullmatch(r'vfncvt\.(?:rtz\.)?xu?\.f\.w.*|vfwcvt\.f\.xu?\.v.*',x['assembly'])]
 scalar64=[dict(line=s[:f['start']+m.start()].count('\n')+1,declaration=m[0])for m in re.finditer(r'(?:const\s+)?(?:u?int64_t)\s+scalar\s*=[^;]+;',b)]
 ei64=[x for x in ops if 'ei64' in x['assembly']]
 item.update(forms=sorted(item['forms']),source_sha256=sha(Path(path)),body_sha256=hashlib.sha256(body(s,f).encode()).hexdigest(),fp16_operations=fp16,scalar64_declarations=scalar64,ei64_operations=ei64,all_target_assembly=ops)
 item['eligibility']='BLOCKED_INTACT_FUNCTION_FP16'if fp16 else'BLOCKED_INTACT_FUNCTION_RV64_INPUT'if scalar64 or ei64 else'REQUIRES_MANUAL_REVIEW'
 out.append(item)
save('PROFILE_FUNCTION_SCREEN.json',out);print(collections.Counter(x['eligibility']for x in out));print('107 forms:',len(set(f for x in out for f in x['forms'])))
