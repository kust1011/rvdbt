from common import *
flags=['clang-20','--target=riscv32-unknown-elf','-march=rv32g','-mabi=ilp32d','-O0','-g','-ffreestanding','-fno-builtin','-fno-vectorize','-fno-slp-vectorize','-msmall-data-limit=0','-I'+str(R/'adapter'),'-I'+str(R/'upstream'),'-DPRINTF_DISABLE_SUPPORT_FLOAT','-DPRINTF_DISABLE_SUPPORT_LONG_LONG']
records=j(R/'BUILD_COMMANDS.json')if (R/'BUILD_COMMANDS.json').exists()else[]
def execute(label,cmd):
 x=subprocess.run(cmd,capture_output=True);(R/'logs'/(label+'.stdout')).write_bytes(x.stdout);(R/'logs'/(label+'.stderr')).write_bytes(x.stderr);records.append(dict(step=label,command=cmd,returncode=x.returncode));save('BUILD_COMMANDS.json',records);return x.returncode==0
def compile(name,source):
 ir=R/'logs'/(name+'.ll');asm=R/'logs'/(name+'.s');obj=R/'logs'/(name+'.o')
 for suffix,cmd in [('ir',flags+['-include',str(R/'adapter/asm_environment.h'),'-S','-emit-llvm',str(source),'-o',str(ir)]),('assembly',['llc-20','--no-integrated-as',str(ir),'-o',str(asm)]),('object',['clang-20','--target=riscv32-unknown-elf','-march=rv32gv','-mabi=ilp32d','-c',str(asm),'-o',str(obj)])]:
  if not execute(name+'-'+suffix,cmd):return None
  if suffix=='ir'and source.stem.startswith('rv32_output_derivative_'):
   import re,difflib
   original=ir.read_text();converted=[];count=0
   for line in original.splitlines(True):
    m=re.match(r'(\s*)(%[\w.]+) = call i64 asm sideeffect (\"vsetivli .*?\", \"=r\"\(\).*?)\n$',line)
    if m:
     temp='%ara_xlen_'+str(count);converted.append(m[1]+temp+' = call i32 asm sideeffect '+m[3]+'\n'+m[1]+m[2]+' = zext i32 '+temp+' to i64\n');count+=1
    else:converted.append(line)
   assert count>0;new=''.join(converted);(R/'provenance'/(name+'.ir-before.ll')).write_text(original);(R/'provenance'/(name+'.ir.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True))));ir.write_text(new);save(name+'-IR_ADAPTER.json',dict(architectural_output_bits=32,C_destination_bits=64,zero_extended_outputs=count,source_body_literal_expected_unchanged=True,derivative_semantics=True))
 return str(obj)
def build(c):
 elf=R/'bin'/(c['name']+'.elf')
 if elf.exists():assert c.get('elf_sha256')==sha(elf);return True
 runtime=str(R/'logs/user_runtime.o');printf=str(R/'logs/printf.o')
 if not Path(runtime).exists():assert compile('user_runtime',R/'adapter/user_runtime.c')
 if not Path(printf).exists():assert compile('printf',R/'upstream/printf.c')
 obj=compile(c['name'],R/'adapter'/(c['name']+'.c'))
 if obj:
  cmd=['clang-20','--target=riscv32-unknown-elf','-march=rv32gv','-mabi=ilp32d','-static','-nostdlib','-fuse-ld=lld','-Wl,--no-relax','-Wl,-T,'+str(R/'adapter/link.ld'),str(R/'adapter/start.S'),obj,runtime,printf,'/home/user/opt/xpack-riscv-none-elf-gcc-14.2.0-1/lib/gcc/riscv-none-elf/14.2.0/rv32imafd_zicsr/ilp32d/libgcc.a','-o',str(elf)]
  if execute(c['name']+'-link',cmd):
   c['elf_sha256']=sha(elf);execute(c['name']+'-disassembly',['llvm-objdump-20','-d',str(elf)]);execute(c['name']+'-symbols',['llvm-nm-20','-S',str(elf)]);return True
 return False
if __name__=='__main__':
 gs=j(R/'GROUPS.json')
 for c in gs:
  if c['disposition']=='READY':
   if not build(c):c['disposition']='BUILD_ERROR'
   save('GROUPS.json',gs)
