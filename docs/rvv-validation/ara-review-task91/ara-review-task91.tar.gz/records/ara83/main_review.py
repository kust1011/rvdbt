"""Independently re-evaluate preserved outputs, not new ISA execution."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from checker import check_cases

groups = json.loads((ROOT / 'GROUPS.json').read_text())
rows = []
for group in groups:
    if group['name'] not in ['legacy_extract_vasub', 'legacy_extract_vasubu',
                             'legacy_extract_vsux', 'legacy_extract_vpopc_m']:
        continue
    for arm in ['reference', 'B', 'M1', 'M2', 'BOTH']:
        base = ROOT / ('raw' if arm == 'reference' else 'remote-raw') / group['name'] / arm
        result = json.loads((base / 'result.json').read_text())
        raw = (base / 'stdout').read_bytes()
        ok, _, cases = check_cases(group, result['returncode'], raw)
        assert ok and result['returncode'] == 0
        assert b'FAILED' not in raw and b'ERROR' not in raw
        assert all(c['original_success_lines'] == c['expected_original_checker_calls'] for c in cases)
        changed = raw.replace(b'PASSED.', b'FAILED.', 1)
        assert changed != raw and not check_cases(group, 0, changed)[0]
        assert not check_cases(group, 1, raw)[0]
        rows.append({'case': group['name'], 'arm': arm, 'raw_result_accepted': True,
                     'functions': len(cases), 'parser_negative_controls': 2})
assert len(rows) == 20
report = {'scope': 'Adapted original typed predicates; not recovered historical macro bodies',
          'rechecked_runs': rows, 'DUT': 16, 'reference': 4,
          'whole_original_suite_pass': False, 'new_ISA_executions': 0}
(ROOT / 'MAIN_REVIEW.json').write_text(json.dumps(report, indent=2) + '\n')
print('Accepted 16 DUT + 4 reference raw receipts; 40 parser rejection checks.')
