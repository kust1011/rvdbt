import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';j=lambda p:json.loads(p.read_text());configs=[]
for g in j(R/'GROUPS.json'):
 if 'elf_sha256'not in g:continue
 for arm in ['reference','B','M1','M2','BOTH']:
  if arm=='reference':c=dict(case=g['name'],arm=arm,elf_sha256=g['elf_sha256'])
  else:c=dict(next(x for x in j(P/'CONFIGS.json')if x['case']=='batch01_vand'and x['arm']==arm));c.update(case=g['name'],source_row_ids=g['source_row_ids'],elf_sha256=g['elf_sha256'],VLEN=g['vlen'])
  configs.append(c)
(R/'CONFIGS.json').write_text(json.dumps(configs,indent=2)+'\n')
