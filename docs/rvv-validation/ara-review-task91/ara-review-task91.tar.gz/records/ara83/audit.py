import json,hashlib,re,collections
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
groups=[g for g in j(R/'GROUPS.json')if g.get('elf_sha256')];results=[];targets=[]
for g in groups:
 assert sha(R/'bin'/(g['name']+'.elf'))==g['elf_sha256']
 for arm in ['reference','B','M1','M2','BOTH']:
  p=R/('raw'if arm=='reference'else'remote-raw')/g['name']/arm
  z=j(p/'result.json');assert z['status']=='PASS'and z['returncode']==0 and z['elf_sha256']==g['elf_sha256']
  assert j(p/'IDENTITY.json')==j(p/'IDENTITY_AFTER.json')
  obs=j(p/'observations.json');assert obs['vsets']==[[v['line'],v['avl'],v['actual_vl'],v['vtype']]for v in g['vsets']]
  assert obs['assertions']==[[a['id'],a['elements'],a['width']//8,a['avl'],a['vtype'],a['elements'],1]for a in g['assertions']]
  cr=j(p/'case-results.json');assert len(cr)==len(g['functions'])and all(c['status']=='PASS'for c in cr)
  stderr=(p/'stderr').read_text();admission=[x for x in stderr.splitlines()if x.startswith(('RVV_DIRECT','RVV_RUN ','RVV_FAST'))]
  if arm in ['M1','BOTH']:assert 'runs_formed=0 multi_member_runs=0 members_admitted=0'in stderr
  results.append(dict(z,raw_path=str(p),command=j(p/'command.json'),identity=j(p/'IDENTITY.json'),cases=cr,method_census=admission,M1_target_admission='NONE_OBSERVED',M2_target_admission='UNOBSERVED',source_label=g['source_status']))
 dis=(R/'logs'/(g['name']+'-disassembly.stdout')).read_text()
 for c in g['case_metadata']:
  for t in c['targets']:
   op=t['opcode'];emitted='vcpop.m'if op=='vpopc.m'else op
   hits=[line for line in dis.splitlines()if re.search(r'\b'+re.escape(emitted)+r'\b',line)]
   assert hits;targets.append(dict(case=g['name'],function=c['function'],source_line=t['line'],original_opcode=op,emitted_opcode=emitted,ELF_sha256=g['elf_sha256'],disassembly_lines=hits))
save('EXECUTION_RESULTS.json',results);save('TARGET_INSTRUCTIONS.json',targets)
canonical=j(R.parent/'ara82/RECONCILIATION_SUMMARY.json')['input_sha256'];assert all(sha(Path(p))==h for p,h in canonical.items())
assert all(sha(R/f)==sha(P/f)for f in ['runner.py','checker.py','run.original.py.txt'])
screen=j(R/'PROFILE_FUNCTION_SCREEN.json');assert all(x['eligibility'].startswith('BLOCKED')for x in screen)
summary=dict(reference_calls=4,DUT_calls=16,reference_statuses=dict(collections.Counter(x['status']for x in results if x['arm']=='reference')),DUT_statuses=dict(collections.Counter(x['status']for x in results if x['arm']!='reference')),original_functions_executed=8,DUT_function_invocations=32,reference_function_invocations=8,DUT_vector_checker_calls=28,DUT_scalar_checker_calls=4,DUT_vector_element_comparisons=112,DUT_scalar_comparisons=4,original_build_obligations=20,original_files=6,obligations_executed_with_adapter=8,remaining_obligations=12,original_failures_retained=True,canonical_sha256_unchanged=canonical,profile_forms=107,profile_intact_functions=len(screen),profile_function_blockers=dict(collections.Counter(x['eligibility']for x in screen)),profile_eligible_intact_functions=0,runner_and_checker_byte_identical=True,all_executable_identities_verified=True,all_exit0_no_timeout=True,production_modified=False)
save('AUDIT.json',summary);print(json.dumps(summary,indent=2))
