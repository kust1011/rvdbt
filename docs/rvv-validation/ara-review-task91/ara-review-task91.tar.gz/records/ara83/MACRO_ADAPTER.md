# Legacy environment adapter contract

Pinned Ara source is 34bd3bc152421b4601a7bf3d6e8e91ffb545c99e. The twenty ledger BUILD_ERROR obligations are twenty functions in six files, not twenty files. All six original files and original errors remain separately preserved.

The recovered runnable environment uses pinned Ara definitions through `legacy_environment.h`. This is a documented environment adapter, not an upstream patch and not a claim that the missing historical macro bodies were recovered. The public Ara header history back to flatten commit ac8cab177e8b2ccf239f356a7ce4ac6823cefe9f has no VEC_CMP_32 definition. Before flattening, riscv-tests was private submodule aac5b6e0ccadea1fb81c09d13ffe11f697e624ff at git@iis-git.ee.ethz.ch:ara_release/riscv-tests.git. Its HTTPS endpoint requires credentials; the retained access diagnostic is the precise historical blocker.

The adapter's equivalence is scoped to the executed functions' explicit typed load / typed equality / clear contracts, not unspecified behavior of an unavailable historical implementation:

| Original call | Pinned implementation | Preserved predicate/operation |
| --- | --- | --- |
| VLOAD_U8/16/32/64 | VLOAD_8/16/32/64 | volatile uintN_t literal array, vector load of same width, same VL and register |
| VEC_CMP_U8/16/32/64 | VCMP_U8/16/32/64 | store same vector at same VL; compare each original literal using uintN_t equality; increment num_failed and return on mismatch |
| VEC_CMP_32 | VCMP_I32 | int32_t equality of all four original expected entries; every expected entry in executed vasub cases is nonnegative and representable, so signed/unsigned spelling ambiguity cannot change equality truth |
| VEC_EQUAL_U8/16/32/64_RAW | VVCMP_U8/16/32/64 | compare original memory pointer against every original expected literal using uintN_t equality; original fail/return behavior |
| CLEAR | VCLEAR | clear destination vector before masked operation, then restore VL/vtype; every checked inactive destination entry remains zero |

Each executed body is byte-identical to its original source, including target assembly, inputs and expected literals. The observer is the unchanged Task52 observer surrounding those same pinned comparisons, not a replacement golden. No comparator calls, entries, or failure paths are removed. The macro's original format diagnostics are reused. No vxrm value is injected: averaging inputs/expected retain original startup-state dependency (the reference and DUT both satisfy the literals; vxrm itself is not observed).

Original uint64_t scalar operands in vasub/vasubu TEST_CASE3/4 are excluded and remain blockers; no truncation, type edit, or inline-asm operand repair was made. vlx/vsx TEST_CASE7 and original vsux TEST_CASE7 need ei64 index support outside RV32; excluded, not reclassified. The original complete groups remain BUILD_ERROR, independently of partial extracted passes. vpopc_m retains its only original function and complete main order; its original `vpopc.m` is accepted by clang's assembler and emitted as `vcpop.m` without source edit.

MEMBARRIER has no definition in the pinned include closure or recovered public header history. It is left unresolved. vlx stays BUILD_ERROR. vsx proceeds past the adapter but the original vsxei8/16/32 instructions are not recognized by the current RVV1 assembler. Those are retained build errors, with no invented mnemonic replacement. No unsafe memory test or context-stripped reduction is executed.

Memory preflight: vasub/vasubu each use VL4 and four initialized 32-bit load elements (including v0), with four original equality entries. CLEAR touches only vector registers. vsux selected functions have four initialized index/data/output elements, offsets 0/1/2/3 (8-bit), 0/2/4/6 (16-bit), 0/4/8/12 (32-bit): every store is within the actual 4/8/16-byte output owner. vpopc loads four initialized uint32 entries for VL4 and stores one uint32 into a four-entry output. Pinned checker datasets have 1024 entries; stores of VL4 are bounded. All executed inputs and expected values are original. No padding or allocation expansion was used to conceal out-of-bounds access.

Independent same-ELF reference: retained Spike/pk identities from Task52. Reference command ISA has minimum Zvl128, whereas clean961 uses --vlen=1024. Actual checked VL4, LMUL1, SEW32 (and SEW8/16 for vsux) agree in raw. This is same-ELF independent semantic evidence at the recorded configurations; equal maximum VLEN is not claimed. The reference's actual maximum VLEN is not observed by this checker.

No test or canonical ledger modifications, production changes, commits or pushes. PASS is limited to all original predicates of the labeled functions with this explicitly documented adapter. Historical legacy macro recovery itself remains incomplete and requires upstream/private-source review.
