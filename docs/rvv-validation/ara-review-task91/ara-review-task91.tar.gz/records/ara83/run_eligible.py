import subprocess,json,time
from pathlib import Path
R=Path(__file__).resolve().parent
records=[]
def run(cmd):
 t=time.time();p=subprocess.run(cmd,capture_output=True);records.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),elapsed=time.time()-t));(R/'LAUNCH_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n');print(p.stdout.decode(),end='',flush=True);assert p.returncode==0
for name in ['vasub','vasubu','vsux','vpopc_m']:
 name='legacy_extract_'+name
 if name!='legacy_extract_vasub':run(['python3',str(R/'runner.py'),name,'reference'])
 for arm in ['B','M1','M2','BOTH']:
  if name=='legacy_extract_vasub'and arm=='B':continue
  run(['ssh','xbd','python3 /home/vick/ara83/runner.py '+name+' '+arm])
