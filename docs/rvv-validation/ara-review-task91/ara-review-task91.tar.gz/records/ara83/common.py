from pathlib import Path
import json,subprocess,hashlib
R=Path(__file__).resolve().parent
j=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+"\n")
