import json,shutil,hashlib,subprocess,collections
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
(R/'provenance/original-build-errors').mkdir(exist_ok=True)
for file in ['vasub','vasubu','vlx','vpopc_m','vsux','vsx']:
 for p in (P/'logs').glob('batch_'+file+'-*.stderr'):
  if p.stat().st_size:shutil.copy2(p,R/'provenance/original-build-errors'/p.name)
rows=j(R/'ORIGINAL_BUILD_OBLIGATIONS.json');executed={(g['file'],fn)for g in j(R/'GROUPS.json')if g.get('elf_sha256')for fn in g['functions']}
for row in rows:
 file=Path(row['source_file']).stem;fn=row['source_case'];row['original_status_retained']=row['dut_status'];row['Task83_status']='PASS_DOCUMENTED_ENVIRONMENT_ADAPTER'if(file,fn)in executed else'BLOCKED_RV64_SCALAR_INPUT_INTERFACE'if file in ['vasub','vasubu']else'BLOCKED_RV64_EI64_INDEX'if fn=='TEST_CASE7'else'BUILD_ERROR_UNDEFINED_MEMBARRIER'if file=='vlx'else'BUILD_ERROR_ORIGINAL_VSXEI_MNEMONIC'
 row['Task83_raw']=str(R/'EXECUTION_RESULTS.json')if(file,fn)in executed else''
save('OBLIGATION_RESULTS.json',rows)
identity={}
for name in ['clang-20','llc-20','llvm-objdump-20','llvm-nm-20']:
 p=Path(shutil.which(name)).resolve();identity[name]=dict(path=str(p),sha256=sha(p),version=subprocess.check_output([name,'--version']).decode().splitlines()[0])
p=Path('/home/user/opt/xpack-riscv-none-elf-gcc-14.2.0-1/lib/gcc/riscv-none-elf/14.2.0/rv32imafd_zicsr/ilp32d/libgcc.a');identity['libgcc']=dict(path=str(p),sha256=sha(p));save('COMPILER_RUNTIME_IDENTITY.json',identity)
# Two first launches preceded run_eligible.py; preserve commands and receipt links explicitly.
launch=j(R/'LAUNCH_COMMANDS.json');launch[:0]=[dict(command=['python3',str(R/'runner.py'),'legacy_extract_vasub','reference'],returncode=0,stdout='legacy_extract_vasub reference PASS\n',raw_receipt=str(R/'raw/legacy_extract_vasub/reference')),dict(command=['ssh','xbd','python3 /home/vick/ara83/runner.py legacy_extract_vasub B'],returncode=0,stdout='legacy_extract_vasub B PASS\n',raw_receipt=str(R/'remote-raw/legacy_extract_vasub/B'))];save('LAUNCH_COMMANDS.json',launch)
# Retain all bounded artifacts' hashes; do not recursively enumerate git object database.
hashes={str(p.relative_to(R)):sha(p)for d in ['adapter','upstream','provenance','logs','bin','raw','remote-raw','baseline']for p in(R/d).rglob('*')if p.is_file()};save('EVIDENCE_SHA256.json',hashes)
