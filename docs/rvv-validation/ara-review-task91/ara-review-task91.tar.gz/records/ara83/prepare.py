import sys,json,shutil,re,difflib,hashlib,subprocess,collections
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'ara-remainder52';W=R.parents[2];sys.path.insert(0,str(P))
from common import funcs,body,parser
j=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
for d in ['adapter','upstream','logs','bin','provenance']:(R/d).mkdir(exist_ok=True)
for f in ['runner.py','checker.py','run.original.py.txt','REFERENCE_IDENTITY.json']:shutil.copy2(P/f,R/f)
for p in (P/'upstream').iterdir():
 if p.suffix in ['.h','.c']:shutil.copy2(p,R/'upstream'/p.name)
for f in ['vector_macros.h','float_macros.h','user_runtime.c','user_runtime.h','start.S','link.ld','asm_environment.h']:shutil.copy2(P/'adapter'/f,R/'adapter'/f)
# A single legacy spelling adapter uses upstream typed load/store/equality and register-clear definitions.
compat='''/* Legacy environment adapter: original calls/literals remain unchanged.
 * Typed equality and original return-on-failure are supplied by pinned VCMP.
 * See MACRO_ADAPTER.md for the equivalence contract and unavailable history. */
#define CLEAR(reg) VCLEAR(reg)
#define VEC_CMP_32(id, reg, ...) VCMP_I32(id, reg, __VA_ARGS__)
'''
for width in [8,16,32,64]:
 compat+=f'#define VLOAD_U{width}(reg, ...) VLOAD_{width}(reg, __VA_ARGS__)\n'
 compat+=f'#define VEC_CMP_U{width}(id, reg, ...) VCMP_U{width}(id, reg, __VA_ARGS__)\n'
 compat+=f'#define VEC_EQUAL_U{width}_RAW(id, ptr, ...) VVCMP_U{width}(id, ptr, __VA_ARGS__)\n'
(R/'adapter/legacy_environment.h').write_text(compat)
h=R/'adapter/vector_macros.h';before=h.read_text();h.write_text(before+'\n#include "legacy_environment.h"\n');(R/'provenance/vector_macros.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),h.read_text().splitlines(True))))
# uint64 scalar inputs are preserved and excluded, not truncated into RV32.
selection={'vasub':['TEST_CASE1','TEST_CASE2'],'vasubu':['TEST_CASE1','TEST_CASE2'],'vsux':['TEST_CASE1','TEST_CASE3','TEST_CASE5'],'vlx':['TEST_CASE1','TEST_CASE3','TEST_CASE5'],'vsx':['TEST_CASE1','TEST_CASE3','TEST_CASE5'],'vpopc_m':['TEST_CASE1']}
cs=j(P/'CASES.json');groups=[];pres=[]
for file,fns in selection.items():
 src=W/next(c['source_file']for c in cs if c['file']==file);s=src.read_text();fs=funcs(s);new=s[:fs['main']['start']]
 for fn,f in sorted(fs.items(),key=lambda x:x[1]['start'],reverse=True):
  if fn.startswith('TEST_CASE')and fn not in fns:new=new[:f['start']]+re.sub(r'[^\n]',' ',new[f['start']:f['end']])+new[f['end']:]
 main=body(s,fs['main'])
 for fn in re.findall(r'\bTEST_CASE\w+\b(?=\s*\(\s*\)\s*;)',parser['clean'](main)):
  main=re.sub(r'\b'+fn+r'\s*\(\s*\)\s*;',('ara_case_begin("'+fn+'"); '+fn+'(); ara_case_end("'+fn+'",num_failed);')if fn in fns else'/* RV64 original function retained in upstream; excluded here */',main)
 new+=main+'\n';name='legacy_extract_'+file;(R/'adapter'/(name+'.c')).write_text(new);shutil.copy2(src,R/'upstream'/(file+'.c'))
 (R/'provenance'/(name+'.diff')).write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True))))
 meta=[]
 for fn in fns:
  c=json.loads(json.dumps(next(c for c in cs if c['file']==file and c['function']==fn)));b=body(s,fs[fn]);assert body(new,funcs(new)[fn])==b
  assertions=[]
  for m in re.finditer(r'\b(VEC_CMP_(U?)(8|16|32|64)|VEC_EQUAL_(U)(8|16|32|64)_RAW)\(\s*(\d+),\s*(\w+),\s*(.*?)\);',parser['clean'](b),re.S):
   vals=parser['split'](m[8]);width=int(m[3]or m[5]);cfg=c['vsets'][-1];assertions.append(dict(id=int(m[6]),width=width,elements=len(vals),expected_literals=vals,vd=m[7],checker=m[1],avl=cfg['avl'],vtype=cfg['vtype']))
  c.update(assertions=assertions,expected_vector_ids=[a['id']for a in assertions],expected_long_elements={},expected_scalar_ids=[1]if file=='vpopc_m'else[],checker_calls=len(assertions)+(file=='vpopc_m'),vector_assertions=len(assertions),comparisons=sum(a['elements']for a in assertions),runtime_group=name)
  meta.append(c);pres.append(dict(file=file,function=fn,body_sha256=hashlib.sha256(b.encode()).hexdigest(),source_sha256=sha(src),body_identical=True,source_path=str(src)))
 g=dict(name=name,file=file,functions=fns,source_row_ids=[c['source_row_id']for c in meta],case_metadata=meta,vlen=max(c['vlen']for c in meta),vsets=[v for c in meta for v in c['vsets']],assertions=[a for c in meta for a in c['assertions']],vector_assertions=sum(c['vector_assertions']for c in meta),comparisons=sum(c['comparisons']for c in meta),reasons=[],disposition='READY',observer='case-spans-v2',source_status='DERIVATIVE_EXTRACTED_ORIGINAL_FUNCTIONS; original BUILD_ERROR retained')
 groups.append(g)
save('GROUPS.json',groups);save('PRESERVATION.json',pres)
# Use established build script with isolated paths; no production changes.
(R/'common.py').write_text('from pathlib import Path\nimport json,subprocess,hashlib\nR=Path(__file__).resolve().parent\nj=lambda p:json.loads(p.read_text())\nsha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()\ndef save(n,x):(R/n).write_text(json.dumps(x,indent=2)+"\\n")\n')
shutil.copy2(P/'build.py',R/'build.py')
