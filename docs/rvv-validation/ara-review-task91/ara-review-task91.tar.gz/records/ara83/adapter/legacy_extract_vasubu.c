// Copyright 2021 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Author: Matheus Cavalcante <matheusd@iis.ee.ethz.ch>
//         Basile Bougenot <bbougenot@student.ethz.ch>

#include "vector_macros.h"

void TEST_CASE1(void) {
  VSET(4, e32, m1);
  VLOAD_U32(v1, 5, 10, 15, 20);
  VLOAD_U32(v2, 1, 2, 3, 4);
  __asm__ volatile("vasubu.vv v3, v1, v2" ::);
  VEC_CMP_U32(1, v3, 2, 4, 6, 8);
}

void TEST_CASE2(void) {
  VSET(4, e32, m1);
  VLOAD_U32(v1, 5, 10, 15, 20);
  VLOAD_U32(v2, 1, 2, 3, 4);
  VLOAD_U32(v0, 10, 0, 0, 0);
  CLEAR(v3);
  __asm__ volatile("vasubu.vv v3, v1, v2, v0.t" ::);
  VEC_CMP_U32(2, v3, 0, 4, 0, 8);
}

                       
                   
                               
                            
                                                               
                                 
 

                       
                   
                               
                            
                             
            
                                                                     
                                 
 

int main(void) {
  INIT_CHECK();
  enable_vec();
  ara_case_begin("TEST_CASE1"); TEST_CASE1(); ara_case_end("TEST_CASE1",num_failed);
  ara_case_begin("TEST_CASE2"); TEST_CASE2(); ara_case_end("TEST_CASE2",num_failed);
  /* RV64 original function retained in upstream; excluded here */
  /* RV64 original function retained in upstream; excluded here */
  EXIT_CHECK();
}
