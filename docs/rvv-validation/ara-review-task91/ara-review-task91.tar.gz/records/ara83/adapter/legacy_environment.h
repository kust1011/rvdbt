// Local observer/environment adaptation; repository MIT terms in licenses/rvdbt-MIT.txt.
// Task91 distribution: legal notice restored; compiled historical payload below is unchanged.
/* Legacy environment adapter: original calls/literals remain unchanged.
 * Typed equality and original return-on-failure are supplied by pinned VCMP.
 * See MACRO_ADAPTER.md for the equivalence contract and unavailable history. */
#define CLEAR(reg) VCLEAR(reg)
#define VEC_CMP_32(id, reg, ...) VCMP_I32(id, reg, __VA_ARGS__)
#define VLOAD_U8(reg, ...) VLOAD_8(reg, __VA_ARGS__)
#define VEC_CMP_U8(id, reg, ...) VCMP_U8(id, reg, __VA_ARGS__)
#define VEC_EQUAL_U8_RAW(id, ptr, ...) VVCMP_U8(id, ptr, __VA_ARGS__)
#define VLOAD_U16(reg, ...) VLOAD_16(reg, __VA_ARGS__)
#define VEC_CMP_U16(id, reg, ...) VCMP_U16(id, reg, __VA_ARGS__)
#define VEC_EQUAL_U16_RAW(id, ptr, ...) VVCMP_U16(id, ptr, __VA_ARGS__)
#define VLOAD_U32(reg, ...) VLOAD_32(reg, __VA_ARGS__)
#define VEC_CMP_U32(id, reg, ...) VCMP_U32(id, reg, __VA_ARGS__)
#define VEC_EQUAL_U32_RAW(id, ptr, ...) VVCMP_U32(id, ptr, __VA_ARGS__)
#define VLOAD_U64(reg, ...) VLOAD_64(reg, __VA_ARGS__)
#define VEC_CMP_U64(id, reg, ...) VCMP_U64(id, reg, __VA_ARGS__)
#define VEC_EQUAL_U64_RAW(id, ptr, ...) VVCMP_U64(id, ptr, __VA_ARGS__)
