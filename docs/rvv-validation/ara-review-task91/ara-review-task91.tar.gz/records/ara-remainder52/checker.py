from pathlib import Path
import json,re,ast
R=Path(__file__).resolve().parent;W=R.parents[2]
def observations(raw):
 orig=(R/'run.original.py.txt').read_text();env={'re':re,'json':json,'Path':Path}
 tree=ast.parse(orig)
 for node in tree.body:
  if isinstance(node,ast.FunctionDef):exec(ast.get_source_segment(orig,node),env)
 return env['observations'](raw)
def check_cases(g,rc,raw):
 text=raw.decode(errors='replace');obs=observations(raw);out=[];scalar_cursor=0
 for c in g['case_metadata']:
  fn=c['function'];m=re.search(r'ARA_CASE_BEGIN '+re.escape(fn)+r' vsets=(\d+) assertions=(\d+) comparisons=(\d+)\n(.*?)ARA_CASE_END '+re.escape(fn)+r' failures=(\d+) vsets=(\d+) assertions=(\d+) comparisons=(\d+)\n',text,re.S)
  if not m:out.append(dict(function=fn,status='TIMEOUT'if rc is None else'CRASH'if rc<0 else'BLOCKED',reason='original function begin/end not completed; no execution inferred'));continue
  vb,ab,cb,body,fails,ve,ae,ce=m.groups();vb,ab,cb,fails,ve,ae,ce=map(int,[vb,ab,cb,fails,ve,ae,ce]);asserts=obs['assertions'][ab:ae];completed=all(x[-1]==1 and x[-2]==x[1]for x in asserts)
  # C source ID/expected vector literal counts preserved; static scalar and configuration equality calls recorded separately.
  direct=[x for x in c['assertions']if not x.get('long_checker_substring',False)];index=0;ids_match=True
  for a in asserts:
   if index<len(direct)and a[0]==direct[index]['id']:
    d=direct[index];ids_match&=a[1]==d['elements']and a[2]==d['width']//8;index+=1
  ids_match &= [a[0]for a in asserts]==c['expected_vector_ids']
  ids_match &= all(a[1]==int(c['expected_long_elements'][str(a[0])])for a in asserts if str(a[0])in c['expected_long_elements'])
  scalar_ids=c.get('expected_scalar_ids',[]);scalars=obs['scalars'][scalar_cursor:scalar_cursor+len(scalar_ids)];scalar_cursor+=len(scalar_ids)
  scalar_ok=[x[0]for x in scalars]==scalar_ids and all(x[5:7]==x[7:9] and x[9:11]==[1,1]for x in scalars)
  original_failed='FAILED'in body or 'ERROR'in body
  original_check_calls=c['checker_calls'];total_original_completed=len(re.findall(r'PASSED\.',body))
  ok=not original_failed and completed and ids_match and scalar_ok and index==len(direct)and total_original_completed==original_check_calls
  if c.get('no_oracle'):status='BLOCKED';reason='Actual original load function executed; all equality assertions commented upstream. Completion is not ISA validation.'
  else:status='PASS'if ok else'RESULT_MISMATCH';reason='original equality/control completed'if ok else'original failed/incomplete checker or observer identity mismatch retained'
  out.append(dict(function=fn,source_row_id=c['source_row_id'],status=status,original_checker_accepted=ok,reason=reason,assertions=asserts,vsets=obs['vsets'][vb:ve],comparisons=ce-cb,original_success_lines=total_original_completed,expected_original_checker_calls=original_check_calls,body_output=body))
 ok=all(x['status']=='PASS'for x in out)and rc==0 and 'ARA_SUMMARY'in text
 return ok,obs,out
