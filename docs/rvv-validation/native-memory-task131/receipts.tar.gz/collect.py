from pathlib import Path
import hashlib,json,subprocess,shutil,re
root=Path('/home/vick/rvdbt-native-memory-task131')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(root/n).write_text(json.dumps(d,indent=2)+'\n')
identity=json.loads((root/'SOURCE_IDENTITY.json').read_text())
diff=[p for p,h in identity['files'].items() if sha(root/'source'/p)!=h]
assert not diff,diff
save('SOURCE_EQUALITY.json',{'commit':identity['commit'],'checked':len(identity['files']),'differences':diff})
prev=Path('/home/vick/rvdbt-native-memory-task130/source/dbt/third_party')
deps={str(p.relative_to(prev)):sha(p) for p in prev.rglob('*') if p.is_file()}
assert all(sha(root/'source/dbt/third_party'/p)==h for p,h in deps.items())
save('DEPENDENCY_EQUALITY.json',{'against':str(prev),'checked':len(deps),'differences':[],'files':deps})
cache=(root/'build/CMakeCache.txt').read_text()
flags={str(p.relative_to(root)):p.read_text() for p in (root/'build').rglob('flags.make')}
assert 'RVV_HOST_CHUNK_BITS:STRING=512' in cache
for t in ['dbtstatic','elfrun','rv32_native_memory_fault_test']:
 f=next(v for k,v in flags.items() if f'{t}.dir/flags.make' in k)
 assert '-DRVV_HOST_CHUNK_BITS=512' in f and '-mavx512f' in f and '-mavx512bw' in f
save('FLAGS_AUDIT.json',{'cache':cache,'actual_flags':flags})
tests=['rv32_native_memory_fault_test','rv32_native_memory_site_test','vle32v_typedchunk_route_test','vse32v_typedchunk_route_test','rv32_unit_memory_fault_test']
assert (root/'build.rc').read_text().strip()=='0' and (root/'build.tests.rc').read_text().strip()=='0'
results={}
for t in tests:
 suffix='.final' if t in tests[:2] else ''
 assert (root/(t+suffix+'.rc')).read_text().strip()=='0'
 results[t]={'rc':0,'stdout':t+suffix+'.stdout','stderr':t+suffix+'.stderr','last_line':(root/(t+suffix+'.stdout')).read_text().splitlines()[-1]}
save('FOCUSED_RESULTS.json',results)
assert (root/'BUILD_SHA256.txt').read_bytes()==(root/'BUILD_SHA256.final.txt').read_bytes()
q=json.loads((root/'external/QUEUE.json').read_text());original=json.loads(Path('/home/vick/act-current121/QUEUE.json').read_text())
assert len(q['calls'])==3 and all(c in original['calls'] for c in q['calls'])
assert all(r['status']=='PASS' for r in json.loads((root/'external/RESULTS.json').read_text()))
inputs=json.loads((root/'external/INPUTS.json').read_text())
assert all(sha(Path(p))==h for p,h in inputs.items())
save('EXTERNAL_AUDIT.json',{'unchanged_original_calls':3,'whole_file_pass':3,'reference_calls':0,'predicate':q['predicate'],'input_differences':[],'final_production_equal':True,'production':{p:sha(root/p) for p in ['build/bin/elfrun','build/lib/libdbtjitshared.so']}})
# Independent disassembly of the production callback. All TLS is initial-exec.
syms=subprocess.check_output(['nm',str(root/'build/bin/elfrun')],text=True)
sym=next(line.split()[-1] for line in syms.splitlines() if 'rvv_native_fault' in line and 'HandleSignal' in line)
dis=subprocess.check_output(['objdump','-d','--disassemble='+sym,str(root/'build/bin/elfrun')],text=True)
(root/'NATIVE_CALLBACK.disasm').write_text(dis)
assert not re.search(r'\tcall\s',dis), 'production callback contains call'
save('ASYNC_CALLBACK_AUDIT.json',{'symbol':sym,'disassembly_sha256':sha(root/'NATIVE_CALLBACK.disasm'),'calls':0,'tls_get_addr_calls':0})
(root/'BUILD_TEST_SHA256.json').write_text(json.dumps({t:sha(root/'build/bin'/t) for t in tests},indent=2)+'\n')
receipts=root/'receipts';receipts.mkdir(exist_ok=True)
for p in root.iterdir():
 if p.is_file() and p.suffix!='.gz':shutil.copy2(p,receipts/p.name)
for d in ['external','external.attempt1','focused']:
 shutil.copytree(root/d,receipts/d,ignore=shutil.ignore_patterns('work','cache'),dirs_exist_ok=True)
manifest={str(p.relative_to(receipts)):sha(p) for p in receipts.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
(receipts/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['tar','-czf',str(root/'receipts.tar.gz'),'-C',str(receipts),'.'],check=True)
print(json.dumps({'files':len(manifest),'archive_sha256':sha(root/'receipts.tar.gz'),'source_files':len(identity['files']),'dependency_files':len(deps)}))
