import pathlib,json,hashlib,subprocess,tarfile
r=pathlib.Path('/home/vick/rvdbt-goldens-task137')
expected=json.loads((r/'EXPECTED_SOURCE.json').read_text());result={}
for arm,v in expected.items():
 diffs=[]
 for name,h in v['files'].items():
  p=r/arm/'source'/name
  if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:diffs.append(name)
 assert not diffs,(arm,diffs)
 result[arm]={'revision':v['revision'],'files':len(v['files']),'differences':diffs}
(r/'SOURCE_EQUALITY.json').write_text(json.dumps(result,indent=2))
def deps(arm):
 d=r/arm/'source/dbt/third_party'
 return {str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for sub in ('asmjit','elfio') for p in (d/sub).rglob('*') if p.is_file() and '.git' not in p.parts}
a=deps('control');b=deps('current');assert a==b
# Baseline dependencies directly compare with successful Task136 retained build dependencies.
d=pathlib.Path('/home/vick/rvdbt-grouped-memory-task136/source/dbt/third_party')
assert all(hashlib.sha256((d/p).read_bytes()).hexdigest()==h for p,h in a.items())
(r/'DEPENDENCY_EQUALITY.json').write_text(json.dumps({'files':len(a),'differences':0,'manifest':a},indent=2))
for arm in ('control','current'):
 root=r/arm;cache=(root/'build/CMakeCache.txt').read_text();assert 'RVV_HOST_CHUNK_BITS:STRING=512' in cache
 commands=json.loads((root/'build/compile_commands.json').read_text())
 prod=[c for c in commands if 'CMakeFiles/dbtstatic.dir/' in c['command'] or 'CMakeFiles/dbtjitshared.dir/' in c['command']]
 cpp=[c for c in prod if c['file'].endswith('.cpp')]
 assert all(all(f in c['command'] for f in ['-mavx512f','-mavx512bw','-O3','-DNDEBUG']) for c in cpp)
 (root/'FLAGS_AUDIT.json').write_text(json.dumps({'production_commands':len(prod),'cpp':len(cpp),'host_chunk_bits':512,'checked_flags':['-mavx512f','-mavx512bw','-O3','-DNDEBUG']},indent=2))
 (root/'CMakeCache.txt').write_text(cache);(root/'compile_commands.json').write_text(json.dumps(commands,indent=2))
 (root/'CODEGEN_SOURCE.cpp').write_bytes((root/'source/dbt/qmc/qcg/rvv_vector_run_codegen_test.cpp').read_bytes())
 commands=[['lscpu'],['clang++-22','--version'],['objdump','--version'],['uname','-a'],['uptime']]
 for i,cmd in enumerate(commands):
  (r/('host'+str(i)+'.json')).write_text(json.dumps({'command':cmd,'stdout':subprocess.check_output(cmd).decode()},indent=2))
 if arm=='current':
  p=subprocess.run(['ldd','-r',str(root/'build/bin/elfrun')],capture_output=True,text=True);assert p.returncode==0 and 'undefined symbol' not in p.stdout+p.stderr
  (root/'ldd.txt').write_text(p.stdout+p.stderr)
# Archive small diagnostic/check receipts, not build trees or external corpora.
files=[p for p in r.rglob('*') if p.is_file() and not any(x in ('source','build') for x in p.relative_to(r).parts) and p.name not in ('receipts.tar.gz','MANIFEST.json')]
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(r/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(r/'receipts.tar.gz','w:gz') as t:
 for p in files+[r/'MANIFEST.json']:t.add(p,arcname=str(p.relative_to(r)))
print('collected',len(files),'files')
